from __future__ import annotations

from typing import TYPE_CHECKING

from .aot_cache import AOTAutotuneCache as AOTAutotuneCache
from .aot_kernel import aot_kernel as aot_kernel
from .config_fragment import BooleanFragment as BooleanFragment
from .config_fragment import EnumFragment as EnumFragment
from .config_fragment import IntegerFragment as IntegerFragment
from .config_fragment import ListOf as ListOf
from .config_fragment import NumThreadsFragment as NumThreadsFragment
from .config_fragment import PowerOfTwoFragment as PowerOfTwoFragment
from .config_spec import ConfigSpec as ConfigSpec
from .de_surrogate_hybrid import DESurrogateHybrid as DESurrogateHybrid
from .differential_evolution import (
    DifferentialEvolutionSearch as DifferentialEvolutionSearch,
)
from .effort_profile import AutotuneEffortProfile as AutotuneEffortProfile
from .effort_profile import DifferentialEvolutionConfig as DifferentialEvolutionConfig
from .effort_profile import FinalSelectionConfig as FinalSelectionConfig
from .effort_profile import LLMSearchConfig as LLMSearchConfig
from .effort_profile import PatternSearchConfig as PatternSearchConfig
from .effort_profile import RandomSearchConfig as RandomSearchConfig
from .external import UserConfigSpec as UserConfigSpec
from .external import autotune as autotune
from .finite_search import CachedFiniteSearch as CachedFiniteSearch
from .finite_search import FiniteSearch as FiniteSearch
from .finite_search import from_cache as from_cache
from .handoff import HandoffCandidate as HandoffCandidate
from .handoff import HandoffMeasurement as HandoffMeasurement
from .handoff import HandoffPoint as HandoffPoint
from .handoff import HandoffPolicy as HandoffPolicy
from .handoff import HandoffProgress as HandoffProgress
from .handoff import find_handoff as find_handoff
from .handoff_agent import HandoffAgentResult as HandoffAgentResult
from .handoff_agent import HandoffAgentRound as HandoffAgentRound
from .handoff_bundle import HandoffBundle as HandoffBundle
from .handoff_bundle import build_handoff as build_handoff
from .handoff_cli import CLISourceAgent as CLISourceAgent
from .handoff_evaluation import HandoffCaseResult as HandoffCaseResult
from .handoff_evaluation import HandoffEvaluation as HandoffEvaluation
from .handoff_evaluation import evaluate_handoff as evaluate_handoff
from .llm_search import LLMGuidedSearch as LLMGuidedSearch
from .llm_seeded_lfbo import LLMSeededLFBOTreeSearch as LLMSeededLFBOTreeSearch
from .llm_seeded_lfbo import LLMSeededSearch as LLMSeededSearch
from .local_cache import LocalAutotuneCache as LocalAutotuneCache
from .local_cache import StrictLocalAutotuneCache as StrictLocalAutotuneCache
from .pattern_search import InitialPopulationStrategy as InitialPopulationStrategy
from .pattern_search import PatternSearch as PatternSearch
from .random_search import RandomSearch as RandomSearch
from .remote_cache import RemoteAutotuneCache as RemoteAutotuneCache
from .remote_cache import RemoteCacheBackend as RemoteCacheBackend
from .remote_cache import StrictRemoteAutotuneCache as StrictRemoteAutotuneCache
from .surrogate_pattern_search import LFBOPatternSearch
from .surrogate_pattern_search import LFBOTreeSearch

if TYPE_CHECKING:
    from .base_search import BaseSearch

search_algorithms: dict[str, type[BaseSearch]] = {
    "DESurrogateHybrid": DESurrogateHybrid,
    "LFBOPatternSearch": LFBOPatternSearch,
    "LFBOTreeSearch": LFBOTreeSearch,
    "LLMGuidedSearch": LLMGuidedSearch,
    "LLMSeededSearch": LLMSeededSearch,
    "LLMSeededLFBOTreeSearch": LLMSeededLFBOTreeSearch,
    "DifferentialEvolutionSearch": DifferentialEvolutionSearch,
    "FiniteSearch": FiniteSearch,
    "PatternSearch": PatternSearch,
    "RandomSearch": RandomSearch,
}

cache_classes = {
    "LocalAutotuneCache": LocalAutotuneCache,
    "StrictLocalAutotuneCache": StrictLocalAutotuneCache,
    "RemoteAutotuneCache": RemoteAutotuneCache,
    "StrictRemoteAutotuneCache": StrictRemoteAutotuneCache,
    "AOTAutotuneCache": AOTAutotuneCache,
}

initial_population_strategies: dict[str, InitialPopulationStrategy] = {
    e.value: e for e in InitialPopulationStrategy
}
