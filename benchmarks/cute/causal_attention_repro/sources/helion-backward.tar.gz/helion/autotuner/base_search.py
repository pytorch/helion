from __future__ import annotations

import abc
import collections
import contextlib
import copy
import dataclasses
import functools
import hashlib
import inspect
import logging
import marshal
import math
from math import inf
import os
from pathlib import Path
import random
import re
import statistics
import sys
import time
from typing import TYPE_CHECKING
from typing import Callable
from typing import Literal
from typing import NamedTuple
from typing import Protocol
from typing import cast
from unittest.mock import patch

import torch
import torch.distributed as dist
from torch.utils._pytree import tree_flatten

from .. import exc
from .._compat import extract_device
from .._compat import get_device_name
from ..runtime.cute_structural_config import CuteStructuralConfig
from ..runtime.cute_structural_config import StructuralPolicyError
from ..runtime.cute_structural_config import bound_structural_policy
from ..runtime.cute_structural_config import require_same_structural_policy
from ..runtime.settings import _env_get_int
from ..runtime.settings import _env_get_optional_int
from .benchmark_provider import _COMPILER_SEED_TIMEOUT_RETRY_LIMIT
from .benchmark_provider import BenchmarkProvider
from .benchmark_provider import BenchmarkResult
from .benchmark_provider import IsolatedBenchmarkFailure
from .benchmark_provider import IsolatedBenchmarkTiming
from .benchmark_provider import LocalBenchmarkProvider
from .benchmark_provider import MultiShapeBenchmarkProvider
from .benchmark_provider import _clone_args
from .benchmark_provider import _MultiShapeAutotuneArgs
from .benchmark_provider import _searching_candidates
from .benchmark_provider import _unset_fn
from .benchmark_worker import BenchmarkWorkerUnkillable
from .benchmarking import MirroredBenchmarkTrace
from .benchmarking import clear_jit_fast_path_caches
from .benchmarking import do_bench
from .benchmarking import interleaved_bench
from .benchmarking import mirrored_bench_generic
from .effort_profile import get_effort_profile
from .handoff import _observe_handoff
from .handoff import _refresh_handoff
from .logger import AutotuneLogEntry
from .logger import AutotuningLogger
from .metrics import AutotuneMetrics
from .metrics import KernelMetadata
from .metrics import _run_post_autotune_hooks
from .precompile_future import PrecompileFuture as PrecompileFuture
from .search_space_logger import canonical_config_id
from helion._dist_utils import all_gather_object
from helion._dist_utils import is_master_rank
from helion._dist_utils import sync_object

if TYPE_CHECKING:
    from collections.abc import Iterator
    from collections.abc import Sequence
    from typing_extensions import Self

    from ..runtime.config import Config
    from ..runtime.cute_structural_policy import CuteStructuralPolicy
    from ..runtime.settings import Settings
    from . import ConfigSpec
    from .config_generation import ConfigGeneration
    from .config_generation import FlatConfig
    from .local_cache import SavedBestConfig
    from .search_space_logger import SearchSpaceTracker
    from helion.autotuner.effort_profile import AutotuneEffortProfile
    from helion.autotuner.effort_profile import FinalSelectionConfig


@functools.cache
def _warn_dataset_without_log(log: AutotuningLogger) -> None:
    """Warn (once) that ``autotune_log_details`` needs ``autotune_log`` (the base path
    the ``.meta.jsonl`` sits next to) or nothing is collected. Cached so the
    warning fires once per logger instead of once per config."""
    log.warning(
        "HELION_AUTOTUNE_LOG_DETAILS is set but HELION_AUTOTUNE_LOG is not; no "
        "autotune dataset will be collected. Set HELION_AUTOTUNE_LOG to a base "
        "path to enable collection."
    )


# Use the standard do_bench effort for confirmation instead of the adaptive
# rebenchmark repeat, which can amplify a single optimistic subprocess timing.
_SUSPICIOUS_REBENCHMARK_WARMUP = 25
_SUSPICIOUS_REBENCHMARK_REP = 100
# A finalist timing is only "suspiciously fast" when it undercuts the search
# time by more than the batched flushed-graph timer resolves (~0.3 us on B200):
# confirming costs a fresh worker process per finalist.
_SUSPICIOUS_REBENCHMARK_MIN_DELTA_MS = 0.001
_FINAL_REBENCHMARK_TOP_K_ENV = "HELION_AUTOTUNE_FINAL_REBENCHMARK_TOP_K"
_FINAL_REBENCHMARK_TOP_K_DEFAULT = 8
# The cute/flash-attention search surface has a wide config space where verifying
# more finalists materially improves the final pick. Other backends do not need
# the extra rebenchmark cost (it ~2.5x'd autotune wall-time on cheap kernels), so
# the larger finalist set is scoped to cute only.
_FINAL_REBENCHMARK_TOP_K_CUTE = 32
_FINAL_REBENCHMARK_TARGET_MS_ENV = "HELION_AUTOTUNE_FINAL_REBENCHMARK_TARGET_MS"
_FINAL_REBENCHMARK_TARGET_MS_DEFAULT = 5000.0
_FINAL_REBENCHMARK_TARGET_MS_MAX = 60000.0
_FINAL_REBENCHMARK_ISOLATED_ENV = "HELION_AUTOTUNE_FINAL_REBENCHMARK_ISOLATED"
_FINAL_REBENCHMARK_PINNED_TOLERANCE_ENV = (
    "HELION_AUTOTUNE_FINAL_REBENCHMARK_PINNED_TOLERANCE"
)
_FINAL_REBENCHMARK_PINNED_TOLERANCE_DEFAULT = 0.0
_REBENCHMARK_TARGET_MS_DEFAULT = 200.0
_REBENCHMARK_INTERLEAVED_REPEAT_MAX = 20_000
# The only env override of the harness-grade final selection (full effort):
# the number of steady-window rounds, for A/B runs against the profile.
# HELION_AUTOTUNE_FINAL_SELECTION_ROUNDS=0 restores the single-pass final
# verification (and its HELION_AUTOTUNE_FINAL_REBENCHMARK_* knobs).
_FINAL_SELECTION_ROUNDS_ENV = "HELION_AUTOTUNE_FINAL_SELECTION_ROUNDS"
# The search phase never gives up more than this share of a wall-clock budget
# to the final selection: the selection only re-times configs the search
# found, so a small budget must stay mostly search; the phase is then sized
# to whatever is left when it starts (``FinalSelectionConfig.fit_to_seconds``).
_FINAL_SELECTION_RESERVE_FRACTION = 0.25
# Single-pass verification knobs the final selection does not read.
_FINAL_SELECTION_IGNORED_ENVS = (
    _FINAL_REBENCHMARK_TARGET_MS_ENV,
    _FINAL_REBENCHMARK_ISOLATED_ENV,
)
_final_selection_ignored_envs_warned = False
_CUTE_FLASH_CONFIG_GENERATION_POLICY_VERSION = 8


class _HasDeviceAndProcessGroupName(Protocol):
    device: torch.device
    process_group_name: str | None


class _AutotunableKernel(Protocol):
    @property
    def config_spec(self) -> ConfigSpec: ...

    @property
    def settings(self) -> Settings: ...

    @property  # pyrefly: ignore[bad-return]
    def env(self) -> _HasDeviceAndProcessGroupName: ...

    @property
    def configs(self) -> Sequence[Config]: ...

    def compile_config(
        self,
        config: Config | dict[str, object] | None = None,
        *,
        allow_print: bool = True,
    ) -> Callable[..., object]:
        """Compile a kernel for the given config, used for accuracy checking."""
        ...

    def bench_compile_config(
        self,
        config: Config | dict[str, object] | None = None,
        *,
        allow_print: bool = True,
    ) -> Callable[..., object]:
        """Compile a kernel for the given config, used for benchmarking.

        By default this is the same as compile_config. Override to return
        a different callable for benchmarking, e.g. a fused kernel that
        includes prologue/epilogue code from Inductor.
        """
        ...

    def format_kernel_decorator(self, config: Config, settings: Settings) -> str: ...

    def get_cached_path(self, config: Config | None = None) -> str | None: ...

    def to_code(
        self,
        config: Config | dict[str, object] | None = None,
        *,
        emit_repro_caller: bool = False,
        output_origin_lines: bool | None = None,
    ) -> str | None:
        """Return source for the selected backend, or None if unavailable."""
        ...

    def to_triton_code(
        self,
        config: Config | dict[str, object] | None = None,
        *,
        emit_repro_caller: bool = False,
        output_origin_lines: bool | None = None,
    ) -> str | None: ...

    def maybe_log_repro(
        self,
        log_func: Callable[[str], None],
        args: Sequence[object],
        config: Config | None = None,
    ) -> None: ...

    def extra_cache_key(self) -> str:
        """Return extra data folded into the disk-cache key.

        Implementations should return ``""`` to leave the cache key
        unchanged, or a non-empty string to differentiate cache entries
        for the same kernel source and args.
        """
        ...

    def supports_subprocess_benchmark(self) -> bool:
        """Whether autotuning may benchmark compiled configs in a subprocess."""
        ...

    def is_cacheable(self) -> bool:
        """Whether this kernel supports the autotuning disk cache."""
        ...


_CODE_OBJECT_RE = re.compile(r"<code object .+?, line \d+>")


def normalize_autotune_seed_configs(
    settings: Settings,
    *,
    structural_policy: CuteStructuralPolicy
    | Callable[[], CuteStructuralPolicy | None]
    | None = None,
) -> tuple[Config, ...]:
    """Return user-provided autotune seed configs from settings as concrete Configs."""
    from ..runtime.config import Config

    seed_configs = settings.autotune_seed_configs
    if seed_configs is None:
        return ()
    if isinstance(seed_configs, CuteStructuralConfig):
        seed_configs = (seed_configs,)
    if isinstance(seed_configs, Config):
        return (seed_configs,)
    if isinstance(seed_configs, dict):
        return (Config.from_dict(seed_configs),)
    result = []
    for seed_config in seed_configs:
        if isinstance(seed_config, CuteStructuralConfig):
            # Legacy search-policy inspection can run before binding. Only a
            # new envelope needs the captured bound's policy, so resolve lazily.
            policy = (
                structural_policy()
                if callable(structural_policy)
                else structural_policy
            )
            require_same_structural_policy(
                seed_config.policy,
                policy or settings.get_cute_structural_policy()
                if settings.backend == "cute"
                else None,
                context="Late autotune seed envelope",
            )
            result.append(seed_config.config)
        else:
            result.append(
                Config.from_dict(seed_config)
                if isinstance(seed_config, dict)
                else seed_config
            )
    return tuple(result)


def _file_sha256(filename: str | None) -> str | None:
    if filename is None:
        return None
    try:
        return hashlib.sha256(Path(filename).read_bytes()).hexdigest()
    except OSError:
        return None


class _UncacheablePythonFunctionPolicy(TypeError):
    pass


def _python_global_cache_policy(value: object, seen: set[int]) -> object:
    if inspect.isfunction(value):
        policy = _python_function_cache_policy_impl(value, seen)
        if policy is None:
            raise _UncacheablePythonFunctionPolicy(
                f"cannot fingerprint Python helper {value.__qualname__}"
            )
        return policy
    if inspect.ismodule(value):
        return {
            "kind": "module",
            "name": value.__name__,
            "version": getattr(value, "__version__", None),
            "file_sha256": _file_sha256(getattr(value, "__file__", None)),
        }
    if inspect.isbuiltin(value):
        return {
            "kind": "builtin",
            "module": value.__module__,
            "qualname": value.__qualname__,
        }
    return value


def _python_function_cache_policy_impl(
    callback: object, seen: set[int]
) -> dict[str, object] | None:
    if not inspect.isfunction(callback):
        return None
    identity = {
        "module": callback.__module__,
        "qualname": callback.__qualname__,
    }
    if id(callback) in seen:
        return {**identity, "recursive_reference": True}
    source_file = inspect.getsourcefile(callback)
    if source_file is None:
        return None
    seen.add(id(callback))
    try:
        module_sha256 = _file_sha256(source_file)
        code_sha256 = hashlib.sha256(marshal.dumps(callback.__code__)).hexdigest()
        closure = tuple(cell.cell_contents for cell in (callback.__closure__ or ()))
        closure_vars = inspect.getclosurevars(callback)
    except (OSError, TypeError, ValueError):
        return None
    return {
        **identity,
        "module_sha256": module_sha256,
        "code_sha256": code_sha256,
        "defaults": callback.__defaults__,
        "kwdefaults": callback.__kwdefaults__,
        "closure": closure,
        "globals": {
            name: _python_global_cache_policy(value, seen)
            for name, value in sorted(closure_vars.globals.items())
        },
        "builtins": {
            name: _python_global_cache_policy(value, seen)
            for name, value in sorted(closure_vars.builtins.items())
        },
        "unbound": tuple(sorted(closure_vars.unbound)),
    }


def _python_function_cache_policy(callback: object) -> dict[str, object] | None:
    """Fingerprint a Python function and the runtime globals it reads."""
    try:
        return _python_function_cache_policy_impl(callback, set())
    except _UncacheablePythonFunctionPolicy:
        return None


def _autotune_search_acf_cache_policy(paths: Sequence[str]) -> tuple[object, ...]:
    return tuple({"path": path, "sha256": _file_sha256(path)} for path in paths)


def _normalize_spec_key_str(s: str) -> str:
    """Normalize a specialization_key string for cache comparison.

    Applied to both the ``str()`` that put() stores and the ``str()`` of the
    live key, so the two sides can only differ where this function differs.
    Replaces code object repr strings with a stable '<code>' sentinel,
    allowing FROM_BEST_AVAILABLE to match function arguments based
    on their closure values only, ignoring code object identity.
    """
    return _CODE_OBJECT_RE.sub("<code>", s)


class BaseAutotuner(abc.ABC):
    """
    Abstract base class for all autotuners and classes that wrap autotuners, like caching.
    """

    @abc.abstractmethod
    def autotune(self, *, skip_cache: bool = False) -> Config:
        raise NotImplementedError


class BaseSearch(BaseAutotuner):
    """
    Base class for search algorithms. This class defines the interface and utilities for all
    search algorithms.

    Attributes:
        kernel: The kernel to be tuned (any ``_AutotunableKernel``).
        settings: The settings associated with the kernel.
        config_spec: The configuration specification for the kernel.
        args: The arguments to be passed to the kernel.
        counters: A counter to track various metrics during the search.
    """

    def __init__(
        self,
        kernel: _AutotunableKernel,
        args: Sequence[object],
        benchmark_provider_cls: Callable[
            ..., BenchmarkProvider
        ] = LocalBenchmarkProvider,
    ) -> None:
        """
        Initialize the BaseSearch object.

        Args:
            kernel: The kernel to be tuned.
            args: The arguments to be passed to the kernel.
        """
        super().__init__()
        self.kernel = kernel
        self.settings: Settings = kernel.settings
        if isinstance(self.settings.autotune_config_overrides, CuteStructuralConfig):
            raise StructuralPolicyError(
                "Policy-bearing autotune overrides must be supplied before "
                "creating a new Kernel; late overrides must be an ordinary "
                "dictionary for the already selected config schema."
            )
        self.config_spec: ConfigSpec = kernel.config_spec
        if not self.config_spec.backend.supports_precompile():
            # Backend.autotune() does this too, but a search can also be
            # constructed directly on a bound kernel.
            self.settings.autotune_precompile = None
        self.args: Sequence[object] = args
        self.log = AutotuningLogger(self.settings)
        self.best_perf_so_far = inf
        self._benchmark_provider_cls = benchmark_provider_cls
        self._prepared = False
        self._skip_cache = False
        self._autotune_budget_start: float | None = None
        self._benchmarked_members: dict[Config, PopulationMember] = {}
        self._pinned_finalist_configs: set[Config] = set()
        self._pinned_finalist_members: dict[Config, PopulationMember] = {}
        # configs whose isolated benchmark worker could not be reaped: their
        # kernel may have hung, so they are never returned as the result
        self._unkillable_configs: set[Config] = set()
        self._search_space_tracker: SearchSpaceTracker | None = None
        self._uncacheable_search_policy_nonce: str | None = None
        self._search_policy_cacheable = True

    def _algorithm_cache_policy(self) -> dict[str, object] | None:
        """Return explicit behavior-affecting state for a built-in search."""
        return None

    def _final_rebenchmark_cache_policy(self) -> dict[str, object]:
        return {"enabled": False}

    def cache_policy(self) -> dict[str, object] | None:
        """Return the effective search policy used by CuTe-flash cache keys.

        Unknown search subclasses and arbitrary callbacks fail closed: callers
        give them a one-shot cache key instead of risking reuse across different
        candidate sets or benchmark objectives.
        """
        from . import search_algorithms

        if type(self) not in search_algorithms.values():
            return None
        algorithm = self._algorithm_cache_policy()
        settings = self.settings
        baseline_fn_policy = (
            None
            if settings.autotune_baseline_fn is None
            else _python_function_cache_policy(settings.autotune_baseline_fn)
        )
        if (
            algorithm is None
            or any(
                callback is not None
                for callback in (
                    settings.autotune_config_filter,
                    settings.autotune_benchmark_fn,
                    settings.autotune_baseline_accuracy_check_fn,
                )
            )
            or (
                settings.autotune_baseline_fn is not None and baseline_fn_policy is None
            )
        ):
            return None

        if self.config_spec.cute_flash_search_enabled:
            algorithm = {
                **algorithm,
                "cute_flash_config_generation_policy_version": (
                    _CUTE_FLASH_CONFIG_GENERATION_POLICY_VERSION
                ),
            }

        return {
            "schema": "cute_flash_search_policy_v3",
            "search_class": f"{type(self).__module__}.{type(self).__qualname__}",
            "algorithm": algorithm,
            "settings": {
                "autotune_effort": settings.autotune_effort,
                "autotune_budget_seconds": settings.autotune_budget_seconds,
                "autotune_config_overrides": settings.autotune_config_overrides,
                "autotune_seed_configs": normalize_autotune_seed_configs(
                    settings,
                    structural_policy=lambda: bound_structural_policy(
                        self.kernel, captured=True
                    ),
                ),
                "compiler_seed_configs": tuple(self.config_spec.compiler_seed_configs),
                "compiler_seed_timeout_retry_repetitions": (
                    self.config_spec.compiler_seed_timeout_retry_repetitions
                ),
                "compiler_seed_timeout_retry_limit_per_source": (
                    _COMPILER_SEED_TIMEOUT_RETRY_LIMIT
                ),
                "config_value_priors_version": getattr(
                    self.config_spec.backend, "config_value_priors_version", None
                ),
                "autotune_force_persistent": settings.autotune_force_persistent,
                "disable_autotuner_heuristics": settings.disable_autotuner_heuristics,
                "autotune_accuracy_check": settings.autotune_accuracy_check,
                "autotune_baseline_fn": baseline_fn_policy,
                "autotune_baseline_atol": settings.autotune_baseline_atol,
                "autotune_baseline_rtol": settings.autotune_baseline_rtol,
                "autotune_adaptive_timeout": settings.autotune_adaptive_timeout,
                "autotune_compile_timeout": settings.autotune_compile_timeout,
                "autotune_benchmark_subprocess": (
                    settings.autotune_benchmark_subprocess
                ),
                "autotune_benchmark_timeout": settings.autotune_benchmark_timeout,
                "autotune_precompile": settings.autotune_precompile,
                "autotune_precompile_jobs": settings.autotune_precompile_jobs,
                "autotune_ignore_errors": settings.autotune_ignore_errors,
                "autotune_best_of_k": settings.autotune_best_of_k,
                "autotune_with_torch_compile_fusion": (
                    settings.autotune_with_torch_compile_fusion
                ),
                "autotune_rebenchmark_threshold": (
                    settings.get_rebenchmark_threshold()
                ),
                "autotune_suspicious_rebenchmark_ratio": (
                    settings.get_suspicious_rebenchmark_ratio()
                ),
                "autotune_best_available_max_configs": (
                    settings.autotune_best_available_max_configs
                ),
                "autotune_best_available_max_cache_scan": (
                    settings.autotune_best_available_max_cache_scan
                ),
                "autotune_search_acf": _autotune_search_acf_cache_policy(
                    settings.autotune_search_acf
                ),
            },
            "final_rebenchmark": self._final_rebenchmark_cache_policy(),
        }

    @property
    def performance_unit(self) -> Literal["ms", "ratio"]:
        args = getattr(self, "args", ())
        if isinstance(args, _MultiShapeAutotuneArgs) and args.relative_to is not None:
            return "ratio"
        return "ms"

    @property
    def performance_suffix(self) -> str:
        return "x" if self.performance_unit == "ratio" else "ms"

    def format_performance(self, value: float) -> str:
        return f"{value:.4f}{self.performance_suffix}"

    def _prepare(self) -> None:
        """Some initialization deferred until autotuning actually runs.

        This is called at the start of autotune() so that cache hits skip it.
        """
        if self._prepared:
            return
        self._prepared = True
        self._autotune_budget_start = time.perf_counter()
        seed = self.settings.autotune_random_seed
        random.seed(seed)
        self.log(f"Autotune random seed: {seed}")
        budget = self.settings.autotune_budget_seconds
        if budget is not None:
            self.log(f"Autotune budget: {budget}s")
        kernel_obj = getattr(self.kernel, "kernel", None)
        kernel_source = ""
        if kernel_obj is not None:
            try:
                kernel_source = kernel_obj.kernel_source()
            except OSError:
                self.log.debug("Failed to read Helion kernel source", exc_info=True)
        kernel_name = getattr(kernel_obj, "name", "")
        if isinstance(self.args, _MultiShapeAutotuneArgs):
            case_tensors = []
            for _, case_args in self.args.cases:
                leaves, _ = tree_flatten(case_args)
                case_tensors.append(
                    [value for value in leaves if isinstance(value, torch.Tensor)]
                )
            input_shapes = str(
                [
                    [tuple(tensor.shape) for tensor in tensors]
                    for tensors in case_tensors
                ]
            )
            dtypes = str(
                [[str(tensor.dtype) for tensor in tensors] for tensors in case_tensors]
            )
        else:
            tensors = [arg for arg in self.args if isinstance(arg, torch.Tensor)]
            input_shapes = str([tuple(t.shape) for t in tensors])
            dtypes = str([str(t.dtype) for t in tensors])
        hardware = get_device_name(extract_device(self.args)) or ""
        self._autotune_metrics: AutotuneMetrics = AutotuneMetrics(
            kernel_name=kernel_name,
            kernel_source=kernel_source,
            input_shapes=input_shapes,
            dtypes=dtypes,
            hardware=hardware,
            random_seed=self.settings.autotune_random_seed,
            search_algorithm=type(self).__name__,
        )
        # Analyze search space if logging is enabled. Diagnostic only; a failure
        # must not prevent autotuning from running. Verbose logging implies the
        # summary, so either setting enables the analysis.
        if (
            self.settings.autotune_log_search_space
            or self.settings.autotune_log_search_space_verbose
        ):
            try:
                from .search_space_logger import SearchSpaceTracker
                from .search_space_logger import analyze_search_space

                hardware_spec, specialization_key = (
                    self._get_current_hardware_and_specialization()
                )
                report = analyze_search_space(
                    self.config_spec,
                    kernel_name=kernel_name,
                    specialization_key=specialization_key,
                    hardware=hardware_spec,
                    config_overrides=self.settings.autotune_config_overrides or None,
                    advanced_controls_files=self.settings.autotune_search_acf or None,
                )
                self._search_space_tracker = SearchSpaceTracker(report)
            except Exception:
                self.log.warning(
                    "Search space analysis setup failed; the end-of-run summary "
                    "will be skipped (autotuning continues normally)",
                    exc_info=True,
                )
                self._search_space_tracker = None
        host_function = getattr(self.kernel, "host_function", None)
        from .base_cache import should_skip_cache

        metadata_settings = self.settings.to_dict()
        metadata_settings["effective_cache_read_bypass"] = bool(
            self._skip_cache or should_skip_cache()
        )
        self._kernel_metadata: KernelMetadata = KernelMetadata(
            kernel_name=kernel_name,
            kernel_source=kernel_source,
            input_shapes=input_shapes,
            dtypes=dtypes,
            hardware=hardware,
            settings=metadata_settings,
            _device_ir=getattr(host_function, "_device_ir", None),
            cute_structural_policy=bound_structural_policy(self.kernel),
        )
        provider_cls = (
            MultiShapeBenchmarkProvider
            if isinstance(self.args, _MultiShapeAutotuneArgs)
            else self._benchmark_provider_cls
        )
        self.benchmark_provider = provider_cls(
            kernel=self.kernel,
            settings=self.settings,
            config_spec=self.config_spec,
            args=self.args,
            log=self.log,
            autotune_metrics=self._autotune_metrics,
        )
        if self.config_spec.compiler_seed_timeout_retry_repetitions is not None:
            seed_config_gen = self.config_spec.create_config_generation(
                overrides=self.settings.autotune_config_overrides or None,
                advanced_controls_files=self.settings.autotune_search_acf or None,
                process_group_name=self.kernel.env.process_group_name,
            )
            self.benchmark_provider.set_compiler_seed_configs(
                [config for _flat, config in seed_config_gen.seed_flat_config_pairs()]
            )
        self.benchmark_provider.set_budget_exceeded_fn(self._autotune_budget_exceeded)

    def _is_restricted_search(self) -> bool:
        """Whether the search space is the user's pinned configs.

        A kernel decorated with ``configs=[...]`` (and not ``force_autotune``)
        tunes only between those user-chosen configs, so its telemetry is a
        biased, non-representative slice; such runs are excluded from data
        collection. ``force_autotune`` searches the full space and is collected.
        Best-effort: a missing kernel object / ``configs`` attribute reads as
        "not restricted" so a genuine search is never dropped by accident.
        """
        kernel_obj = getattr(self.kernel, "kernel", None)
        configs = getattr(kernel_obj, "configs", None)
        return bool(configs) and not self.settings.force_autotune

    # Set once the search phase hands over to the final selection, which then
    # spends the budget share ``_budget_reserve_seconds`` kept back for it.
    _budget_reserve_released: bool = False
    # Longest wall time between two generation-boundary budget checks of the
    # search phase (``_autotune_budget_exceeded_across_ranks``: the generation
    # loops and the flash qualification passes call it once per generation).
    # A budget check only stops new compiles; the generation in flight still
    # finishes its benchmark pass, which took 60-120 s past the check in
    # flash searches, so the search phase also holds back one generation of
    # overrun for the final selection (``_in_flight_hold_back_seconds``).
    _longest_generation_seconds: float = 0.0
    _last_generation_boundary: float | None = None

    def _budget_reserve_seconds(self) -> float:
        """Wall-clock seconds the search phase leaves for the final selection."""
        return 0.0

    def _minimum_final_selection_seconds(self) -> float:
        """Estimated seconds of the final selection's smallest plan."""
        return 0.0

    def _in_flight_hold_back_seconds(self, budget: float, reserve: float) -> float:
        """Seconds the search phase stops early on top of ``reserve`` so the
        generation in flight can finish without spending the reserve.

        The reserve and the hold-back together take at most the reserve's
        share of the budget (``_FINAL_SELECTION_RESERVE_FRACTION``): the
        selection sizes itself to what is left when it starts, so a long
        generation shortens the selection rather than the search. The
        selection's smallest plan is the exception, it stays reserved
        whenever a quarter of the budget covers it: when the generation
        would eat the reserve down past it, the hold-back grows by the
        difference (never beyond one generation) and the search stops one
        generation plus that plan before the budget ends.
        """
        longest = self._longest_generation_seconds
        cap = max(reserve, _FINAL_SELECTION_RESERVE_FRACTION * budget)
        keeps_minimum = longest + self._minimum_final_selection_seconds() - reserve
        return min(longest, max(cap - reserve, keeps_minimum))

    def _autotune_budget_exceeded(self) -> bool:
        budget = self.settings.autotune_budget_seconds
        if budget is None or self._autotune_budget_start is None:
            return False
        elapsed = time.perf_counter() - self._autotune_budget_start
        reserve = (
            0.0 if self._budget_reserve_released else self._budget_reserve_seconds()
        )
        in_flight = (
            self._in_flight_hold_back_seconds(budget, reserve) if reserve > 0 else 0.0
        )
        if elapsed < budget - reserve - in_flight:
            return False
        if reserve > 0:
            self.log(
                f"Autotune budget {budget}s exceeded for the search phase "
                f"(elapsed {elapsed:.1f}s, {reserve:.0f}s reserved for the final "
                f"selection plus {in_flight:.0f}s for the generation in flight); "
                "returning best-so-far."
            )
        else:
            self.log(
                f"Autotune budget {budget}s exceeded "
                f"(elapsed {elapsed:.1f}s); returning best-so-far."
            )
        return True

    def _budgeted_range(self, *args: int) -> Iterator[int]:
        """Yield ``range(*args)`` until the autotune budget is exhausted."""
        for value in range(*args):
            if self._autotune_budget_exceeded_across_ranks():
                return
            yield value

    def _autotune_budget_exceeded_across_ranks(self) -> bool:
        """Synchronize CuTe-flash budget exhaustion before the next round."""
        now = time.perf_counter()
        if not self._budget_reserve_released:
            if self._last_generation_boundary is not None:
                self._longest_generation_seconds = max(
                    self._longest_generation_seconds,
                    now - self._last_generation_boundary,
                )
            self._last_generation_boundary = now
        exceeded = self._autotune_budget_exceeded()
        if not getattr(
            getattr(self, "config_spec", None), "cute_flash_search_enabled", False
        ):
            return exceeded
        return any(
            all_gather_object(
                exceeded,
                process_group_name=self.kernel.env.process_group_name,
            )
        )

    @classmethod
    def get_kwargs_from_profile(
        cls, profile: AutotuneEffortProfile, settings: Settings
    ) -> dict[str, object]:
        """
        Retrieve extra kwargs from the effort profile for the autotuner.
        """
        kwargs: dict[str, object] = {}

        if settings.autotune_max_generations is not None:
            kwargs.setdefault("max_generations", settings.autotune_max_generations)

        return kwargs

    def set_adaptive_compile_timeout(
        self,
        members: list[PopulationMember],
        min_seconds: float,
        quantile: float,
    ) -> None:
        """
        Compute and set an adaptive compile timeout based on observed compile times.

        Uses the specified quantile of compile times from the population:
            adaptive_timeout = min(max(quantile_value, min_seconds), original_timeout)

        This feature must be enabled via the setting autotune_adaptive_timeout=True
        or the environment variable HELION_AUTOTUNE_ADAPTIVE_TIMEOUT=1.

        Args:
            members: List of population members with compile_time information.
            min_seconds: Lower bound for the adaptive timeout in seconds.
            quantile: The quantile of compile times to use (e.g., 0.9 for 90th percentile).
        """
        if not self.settings.autotune_adaptive_timeout:
            return

        # Collect valid compile times (non-None and positive)
        compile_times = [
            m.compile_time
            for m in members
            if m.compile_time is not None and m.compile_time > 0
        ]

        if not compile_times:
            self.log("No valid compile times found, keeping default timeout")
            return

        original_timeout = self.settings.autotune_compile_timeout

        # Compute the quantile
        compile_times_sorted = sorted(compile_times)
        quantile_index = min(
            int(len(compile_times_sorted) * quantile),
            len(compile_times_sorted) - 1,
        )
        quantile_value = compile_times_sorted[quantile_index]

        # adaptive_timeout = min(max(quantile_value, min_seconds), original_timeout)
        adaptive_timeout = int(min(max(quantile_value, min_seconds), original_timeout))

        self.settings.autotune_compile_timeout = adaptive_timeout

        self.log(
            f"Adaptive compile timeout: {adaptive_timeout}s "
            f"({quantile:.0%} percentile={quantile_value:.1f}s, "
            f"bounds=[{min_seconds}s, {original_timeout}s])"
        )

    def _apply_config_filter(
        self, configs: list[Config]
    ) -> tuple[list[Config], list[int]]:
        """Apply backend and user filters, returning configs and source indices."""
        config_filter = self.settings.autotune_config_filter
        filtered: list[Config | None] = []
        for config in configs:
            candidate = config_filter(config) if config_filter is not None else config
            if candidate is not None and not self._backend_config_is_viable(candidate):
                candidate = None
            filtered.append(candidate)
        for config, result in zip(configs, filtered, strict=True):
            if (
                result is None
                and self.log.trace_enabled
                and (config_id := self.log.register_config(config)) is not None
            ):
                self.log.record_trace_entry(
                    AutotuneLogEntry(
                        generation=self._autotune_metrics.num_generations,
                        status="filtered",
                        perf_ms=None,
                        compile_time=None,
                        config_id=config_id,
                        config=config,
                        objective_unit=self.performance_unit,
                    )
                )
        passing_indices = [i for i, fc in enumerate(filtered) if fc is not None]
        passing_configs = cast(
            "list[Config]",
            [filtered[i] for i in passing_indices],
        )
        return passing_configs, passing_indices

    def _backend_config_is_viable(self, config: Config) -> bool:
        """Return whether the backend can cheaply rule out an autotune config."""
        return self.config_spec.backend.autotune_config_is_viable(
            self.config_spec, config
        )

    def benchmark_batch(
        self,
        configs: list[Config],
        *,
        desc: str = "Benchmarking",
        raise_if_no_viable_config: bool = True,
    ) -> list[BenchmarkResult]:
        """Compile and benchmark a batch of configurations.

        Applies the config filter, delegates to the provider, and tracks
        best performance.

        Args:
            configs: A list of configurations to benchmark.
            desc: Description for the progress bar.
            raise_if_no_viable_config: Re-raise the compile error when nothing
                has been measured yet and the whole batch fails to compile.
                Pass ``False`` for a batch that has a fallback population.

        Returns:
            A list of BenchmarkResult entries, one per input config.
        """
        passing_configs, passing_indices = self._apply_config_filter(configs)
        filtered_at = time.perf_counter()
        # Record configs for exploration tracking. Diagnostic only; must never
        # interfere with benchmarking.
        if self._search_space_tracker is not None:
            try:
                for config in passing_configs:
                    self._search_space_tracker.record_config(config)
            except Exception:
                self.log.debug(
                    "Exploration tracking failed; continuing autotuning",
                    exc_info=True,
                )
        inner_results = self.benchmark_provider.benchmark(
            passing_configs,
            desc=desc,
            raise_if_no_viable_config=raise_if_no_viable_config,
        )

        if len(passing_indices) == len(configs):
            results = inner_results
        else:
            inner_iter = iter(inner_results)
            passing_set = set(passing_indices)
            results = []
            for i, config in enumerate(configs):
                if i in passing_set:
                    results.append(next(inner_iter))
                else:
                    self.log.debug(
                        f"Config filtered out before benchmarking: {config!r}"
                    )
                    results.append(
                        BenchmarkResult(
                            config=config,
                            fn=lambda *a, **kw: None,
                            perf=inf,
                            status="filtered",
                            compile_time=None,
                            completed_at=filtered_at,
                        )
                    )

        for r in results:
            if r.perf < self.best_perf_so_far:
                self.best_perf_so_far = r.perf

        # Check for handoff when enabled. If triggered, raise an internal stop
        # signal that find_handoff() catches after nested searches clean up
        # their resources.
        _observe_handoff(self, results)
        return results

    def benchmark(self, config: Config) -> BenchmarkResult:
        """Compile and benchmark a single configuration.

        Convenience wrapper around ``benchmark_batch`` for the
        single-config case.

        Args:
            config: The configuration to benchmark.

        Returns:
            A BenchmarkResult with the compiled function and performance.
        """
        return self.benchmark_batch([config])[0]

    def _generation_invalid_config_count(self) -> int:
        """Number of candidate configs rejected as InvalidConfig during search.

        These are candidates that a config fragment / normalize step ruled out
        before they could be benchmarked (so they never reach the exploration
        tracker's valid-config path). The base implementation reports zero;
        subclasses that own a :class:`ConfigGeneration` expose its running
        count so the search-space logger can report explored-invalid alongside
        explored-valid.
        """
        return 0

    def autotune(self, *, skip_cache: bool = False) -> Config:
        """
        Perform autotuning to find the best configuration.

        This method searches for the optimal configuration by benchmarking multiple configurations.

        Returns:
            The best configuration found during autotuning.
        """
        with self.log.autotune_tracing(type(self).__name__):
            config = self._autotune_with_logging(skip_cache=skip_cache)
            self.log.record_selected_config(config)
            return config

    def _autotune_with_logging(self, *, skip_cache: bool) -> Config:
        self._skip_cache = skip_cache
        # Constructing the benchmark provider compiles the reference baseline.
        with _searching_candidates():
            self._prepare()
        start = time.perf_counter()
        exit_stack = contextlib.ExitStack()
        best: Config | None = None
        try:
            with exit_stack:
                exit_stack.enter_context(_searching_candidates())
                if self.settings.autotune_log:
                    # .csv/.log follow the log path; the dataset (.meta.jsonl) also
                    # needs opt-in and a representative (non-restricted) search.
                    collect_dataset = (
                        self.settings.autotune_log_details
                        and not self._is_restricted_search()
                    )
                    exit_stack.enter_context(
                        self.log.autotune_logging(
                            metadata=self._kernel_metadata,
                            collect_dataset=collect_dataset,
                        )
                    )
                elif self.settings.autotune_log_details:
                    _warn_dataset_without_log(self.log)
                self.log.reset()
                # Autotuner triggers bugs in remote triton compile service.
                # Skip storing Triton intermediate IRs (.ttir, .ttgir, .llir, etc.)
                # during autotuning to reduce cache size by ~40%. Only binaries and
                # metadata are needed for execution.
                env_overrides = {"TRITON_LOCAL_BUILD": "1"}
                if "TRITON_STORE_BINARY_ONLY" not in os.environ:
                    env_overrides["TRITON_STORE_BINARY_ONLY"] = "1"
                exit_stack.enter_context(
                    patch.dict(os.environ, env_overrides, clear=False)
                )
                self.benchmark_provider.setup()
                exit_stack.callback(self.benchmark_provider.cleanup)
                try:
                    best = self._autotune()
                    if isinstance(
                        self.benchmark_provider, MultiShapeBenchmarkProvider
                    ) and isinstance(self.args, _MultiShapeAutotuneArgs):
                        if not self.benchmark_provider.has_valid_measurement(best):
                            raise exc.NoConfigFound
                        if not self.args.defer_selected_log:
                            self.benchmark_provider.log_selected(best)
                finally:
                    self._finalize_autotune_metrics(best)
        except BenchmarkWorkerUnkillable as error:
            if best is None or best in self._unkillable_configs:
                raise
            # The search already selected a config; only the post-search
            # teardown of a benchmark worker failed (a hung kernel keeps the
            # worker alive past SIGKILL). Keep the result instead of
            # discarding the whole search.
            self.log.warning(
                "Keeping the selected config although a benchmark worker could "
                f"not be reaped after the search finished: {error}"
            )
        assert best is not None
        end = time.perf_counter()
        kernel_decorator = self.kernel.format_kernel_decorator(best, self.settings)

        self.log(
            f"Autotuning complete in {end - start:.1f}s after searching {self._autotune_metrics.num_configs_tested} configs.\n"
            "One can hardcode the best config and skip autotuning with:\n"
            f"    {kernel_decorator}\n",
            level=logging.INFO + 5,
        )
        if self._autotune_metrics.num_accuracy_failures:
            self.log.warning(
                f"{self._autotune_metrics.num_accuracy_failures} of "
                f"{self._autotune_metrics.num_configs_tested} configs failed due "
                "to accuracy checks."
            )
        if self._autotune_metrics.num_compile_failures:
            self.log.warning(
                f"{self._autotune_metrics.num_compile_failures} of "
                f"{self._autotune_metrics.num_configs_tested} configs failed due "
                "to compile failures."
            )
        if self._autotune_metrics.num_worker_failures:
            self.log.warning(
                f"{self._autotune_metrics.num_worker_failures} of "
                f"{self._autotune_metrics.num_configs_tested} configs failed in "
                "isolated benchmark workers."
            )
        # Log search space analysis. This is purely diagnostic; any failure
        # here (analysis, logging, or writing report files) must never block or
        # crash autotuning, so the whole block is best-effort.
        if (
            self.settings.autotune_log_search_space
            or self.settings.autotune_log_search_space_verbose
        ):
            try:
                from .local_cache import stable_autotune_hash
                from .search_space_logger import log_search_space_comparison

                tracker = self._search_space_tracker
                if tracker is None:
                    from .search_space_logger import SearchSpaceTracker
                    from .search_space_logger import analyze_search_space

                    hardware_spec, specialization_key = (
                        self._get_current_hardware_and_specialization()
                    )
                    tracker = SearchSpaceTracker(
                        analyze_search_space(
                            self.config_spec,
                            kernel_name=self._autotune_metrics.kernel_name,
                            specialization_key=specialization_key,
                            hardware=hardware_spec,
                            config_overrides=(
                                self.settings.autotune_config_overrides or None
                            ),
                            advanced_controls_files=(
                                self.settings.autotune_search_acf or None
                            ),
                        )
                    )
                tracker.record_invalid(self._generation_invalid_config_count())
                report = tracker.finish(
                    search_algorithm=type(self).__name__,
                    elapsed_seconds=end - start,
                )
                log_search_space_comparison(self.log._logger, report)
                if self.settings.autotune_log_search_space_path:
                    saved_path = report.save(
                        self.settings.autotune_log_search_space_path,
                        stable_autotune_hash(self),
                    )
                    if saved_path:
                        self.log(f"Search space analysis saved to: {saved_path}")
            except Exception:
                self.log.warning(
                    "Search space logging failed; the end-of-run summary was not "
                    "emitted (autotuning result is unaffected)",
                    exc_info=True,
                )
        cached_path = self.kernel.get_cached_path(best)
        if cached_path is not None and is_master_rank():
            self.log(f"Code of selected kernel: {cached_path}")
        self.kernel.maybe_log_repro(self.log.warning, self.args, best)
        if self.settings.print_output_code:
            triton_code = self.kernel.to_triton_code(best)
            if triton_code is not None:
                print(triton_code, file=sys.stderr)
        return best

    def _get_current_hardware_and_specialization(
        self,
    ) -> tuple[str | None, str | None]:
        """Return (hardware, specialization_key) for matching cached configs."""
        hardware = get_device_name(extract_device(self.args))

        inner_kernel = getattr(self.kernel, "kernel", None)
        if inner_kernel is None or not hasattr(
            inner_kernel, "_base_specialization_key"
        ):
            return hardware, None
        spec_key = inner_kernel._base_specialization_key(self.args)
        # Compare in the exact form put() stores: str() of the raw key.
        # Normalizing the key as an object tree is not equivalent: pytree
        # rebuilds torch.Size as a plain tuple, which reprs differently.
        specialization_key = _normalize_spec_key_str(str(spec_key))

        return hardware, specialization_key

    def _find_similar_cached_configs(
        self, max_configs: int, *, config_spec_hash: str | None = None
    ) -> list[SavedBestConfig]:
        """Return cached configs matching hardware and specialization.

        Scans the local cache first; if more configs are needed and a remote
        backend is configured, queries it via ``RemoteCacheBackend.list()``
        and merges the results, deduplicating against local entries. Explicit
        cache disabling always suppresses these seeds. Forced autotuning
        suppresses them only for CuTe flash, whose structural search must stay
        independent of previous winners; other backends keep their warm-start
        seeds under forced autotuning, which forces a fresh search rather than
        discarding prior measurements.
        """
        from .base_cache import should_skip_cache

        if (
            self._skip_cache and self.config_spec.cute_flash_search_enabled
        ) or should_skip_cache():
            return []

        from .local_cache import get_helion_cache_dir
        from .local_cache import iter_cache_entries
        from .local_cache import parse_cache_entry
        from .remote_cache import _load_remote_backend_if_configured

        current_hardware, current_spec_key = (
            self._get_current_hardware_and_specialization()
        )
        if current_hardware is None or current_spec_key is None:
            return []

        current_fingerprint_hash = (
            config_spec_hash
            if config_spec_hash is not None
            else self.config_spec.cache_fingerprint_hash(
                advanced_controls_files=self.settings.autotune_search_acf or None
            )
        )

        def is_compatible(entry: SavedBestConfig) -> bool:
            return (
                entry.flat_config is not None
                and entry.hardware == current_hardware
                and _normalize_spec_key_str(entry.specialization_key)
                == current_spec_key
                and entry.config_spec_hash == current_fingerprint_hash
                and entry.cute_structural_policy == bound_structural_policy(self.kernel)
            )

        matching: list[SavedBestConfig] = []
        seen: set[str] = set()

        def consider(entry: SavedBestConfig) -> bool:
            """Return True once we have enough matches to stop scanning."""
            if not is_compatible(entry):
                return False
            assert entry.flat_config is not None
            dedup_key = repr(entry.flat_config)
            if dedup_key in seen:
                return False
            matching.append(entry)
            seen.add(dedup_key)
            return len(matching) >= max_configs

        for entry in iter_cache_entries(
            get_helion_cache_dir(),
            max_scan=self.settings.autotune_best_available_max_cache_scan,
        ):
            if consider(entry):
                return matching

        backend = _load_remote_backend_if_configured()
        if backend is None:
            return matching

        # Over-fetch 2x to absorb filtered / duplicate entries.
        remaining = max_configs - len(matching)
        try:
            # Materialize eagerly so any backend failure surfaces here, not
            # mid-iteration when partial results are already in `matching`.
            raw_entries = list(backend.list(max_results=remaining * 2))
        except Exception:
            self.log.warning(
                "Remote cache list failed, using local matches only", exc_info=True
            )
            return matching

        for raw in raw_entries:
            try:
                entry = parse_cache_entry(raw)
            except ValueError:
                continue
            if consider(entry):
                break

        return matching

    def _autotune(self) -> Config:
        """
        Abstract method to perform the actual autotuning.

        This method must be implemented by subclasses.

        Raises:
            NotImplementedError: If the method is not implemented.
        """
        raise NotImplementedError

    def _autotune_seed_configs(self) -> Sequence[Config]:
        """Return user-provided autotune seed configs normalized from settings."""
        return normalize_autotune_seed_configs(
            self.settings,
            structural_policy=lambda: bound_structural_policy(
                self.kernel, captured=True
            ),
        )

    def set_generation(self, generation: int) -> None:
        self._autotune_metrics.num_generations = generation

    def _finalize_autotune_metrics(self, best_config: Config | None = None) -> None:
        """Finalize run metrics and link population winners to measured source.

        Population searches retain compiled callables for benchmarked members,
        which lets us record the selected generated-source hash without
        recompiling. Final verification can re-pick a member while older noisy
        timings still make ``self.best`` point at a different config, so inspect
        all retained members for the returned config. Search implementations that
        do not retain a match leave the source fields unset rather than claiming
        an unverifiable linkage.
        """
        if best_config is not None:
            self._autotune_metrics.selected_config = copy.deepcopy(best_config.config)
            if isinstance(
                self, PopulationBasedSearch
            ) and self.config_spec.backend.should_deduplicate_generated_sources(
                self.config_spec
            ):
                selected_member = getattr(self, "_selected_member", None)
                retained_members = [
                    *(() if selected_member is None else (selected_member,)),
                    *getattr(self, "population", ()),
                    *getattr(self, "_benchmarked_members", {}).values(),
                    *getattr(self, "_pinned_finalist_members", {}).values(),
                ]
                for member in retained_members:
                    if member.config != best_config:
                        continue
                    source_hash = self.config_spec.backend.generated_source_hash(
                        member.fn
                    )
                    if source_hash is None:
                        continue
                    if self._autotune_metrics.selected_source_hash is None:
                        self._autotune_metrics.selected_source_hash = source_hash
                    if self.benchmark_provider.has_measured_source_hash(source_hash):
                        self._autotune_metrics.selected_source_hash = source_hash
                        self._autotune_metrics.selected_source_was_measured = True
                        break
        best_perf = self.best_perf_so_far
        if self.performance_unit == "ratio":
            best_perf = (
                self.benchmark_provider.raw_latency(best_config)
                if best_config is not None
                and isinstance(self.benchmark_provider, MultiShapeBenchmarkProvider)
                else inf
            )
        self._autotune_metrics.best_perf_ms = (
            best_perf if math.isfinite(best_perf) else 0.0
        )
        self._autotune_metrics.finalize()
        _run_post_autotune_hooks(self._autotune_metrics)


def check_population_consistency(
    population: Sequence[PopulationMember],
    process_group_name: str | None = None,
) -> None:
    if os.getenv("HELION_DEBUG_DISTRIBUTED") != "1" or not dist.is_initialized():
        return

    # remove unpickled fields
    sanitized_population = tuple((p.config, p.perfs) for p in population)
    all_sanitized_population = all_gather_object(
        sanitized_population, process_group_name=process_group_name
    )
    if all_sanitized_population != all_sanitized_population[:1] * len(
        all_sanitized_population
    ):
        raise exc.InconsistantConfigsAcrossRanks


@dataclasses.dataclass
class PopulationMember:
    """
    Represents a member of the population in population-based search algorithms.

    Attributes:
        perfs (list[float]): The performance of the configuration, accumulated over multiple benchmarks.
        flat_values (FlatConfig): The flat representation of the configuration values.
        config (Config): The full configuration object.
        compile_time (float | None): The compilation time for this configuration.
    """

    fn: Callable[..., object]
    perfs: list[float]
    flat_values: FlatConfig
    config: Config
    status: Literal[
        "ok",
        "error",
        "timeout",
        "peer_compilation_fail",
        "filtered",
        "deduplicated",
        "accuracy_error",
        "source_rejected",
        "unknown",
    ] = "unknown"
    compile_time: float | None = None

    @property
    def perf(self) -> float:
        return self.perfs[-1]


def performance(member: PopulationMember) -> float:
    """
    Retrieve the performance of a population member.  Used as a sort key.

    Args:
        member: The population member.

    Returns:
        The performance of the member.
    """
    return member.perf


class _PrivateBenchmarkArgs(NamedTuple):
    """Candidate-private kernel arguments for an in-process re-timing.

    ``sacrificial`` absorbs the allocator's recycled addresses and must stay
    alive while ``by_member`` is in use: a single recycled clone would let a
    later candidate inherit L2 eviction priority from an earlier candidate
    that touched the same addresses (for example an ``l2_last`` store).
    """

    sacrificial: Sequence[object]
    by_member: list[Sequence[object]]


class _FinalSelectionMeasurer(Protocol):
    """Steady-window timer the final selection drives one finalist at a time.

    A ``BenchmarkWorkerUnkillable`` raised by either method names the finalist
    it was timing in ``fn_index``.
    """

    def __enter__(self) -> Self: ...

    def __exit__(self, exc_type: object, *exc_info: object) -> None: ...

    def warm(self, index: int, duration_ms: int) -> None:
        """Run finalist ``index`` for ``duration_ms`` to settle the clocks."""
        ...

    def measure(
        self, index: int, warmup_ms: int, rep_ms: int
    ) -> IsolatedBenchmarkTiming:
        """Median of one ``warmup_ms``+``rep_ms`` steady window of finalist
        ``index``; ``None`` when no reading could be taken."""
        ...


class _WorkerFinalSelectionMeasurer:
    """Times finalists in the killable benchmark worker (one long-lived
    process, so a hung finalist is reaped instead of hanging the search).
    With ``private_copies`` every finalist reads its own argument copies,
    which are released when the phase ends."""

    def __init__(
        self,
        provider: LocalBenchmarkProvider,
        fns: Sequence[Callable[..., object]],
        *,
        private_copies: bool,
        timeout_s: float,
    ) -> None:
        self.provider = provider
        self.fns = list(fns)
        self.private_copies = private_copies
        self.slots: list[int | None] = [
            index if private_copies else None for index in range(len(self.fns))
        ]
        self.timeout_s = timeout_s

    def __enter__(self) -> Self:
        return self

    def __exit__(self, exc_type: object, *exc_info: object) -> None:
        # The worker stays up for later phases; its private argument copies
        # (up to half of the free device memory) must not. A worker that
        # raised on the way out (hung, died) is not asked to release them.
        if self.private_copies and exc_type is None:
            self.provider.release_private_argument_copies()

    def warm(self, index: int, duration_ms: int) -> None:
        self._window(index, warmup=duration_ms, rep=1, desc="Final selection warmup")

    def measure(
        self, index: int, warmup_ms: int, rep_ms: int
    ) -> IsolatedBenchmarkTiming:
        return self._window(index, warmup=warmup_ms, rep=rep_ms, desc="Final selection")

    def _window(
        self, index: int, *, warmup: int, rep: int, desc: str
    ) -> IsolatedBenchmarkTiming:
        try:
            results = self.provider.benchmark_isolated(
                [self.fns[index]],
                warmup=warmup,
                rep=rep,
                desc=desc,
                args_slots=[self.slots[index]],
                timeout=self.timeout_s,
            )
        except BenchmarkWorkerUnkillable as error:
            # the batch held this one finalist
            error.fn_index = index
            raise
        if results is None:
            return None
        return results[0]


class _InProcessFinalSelectionMeasurer:
    """Times finalists in the autotuning process with the backend's steady
    bench; ``args_by_fn`` holds each finalist's (possibly private) arguments."""

    def __init__(
        self,
        fns: Sequence[Callable[..., object]],
        args: _PrivateBenchmarkArgs | Sequence[object],
        steady_bench: Callable[..., float | tuple[float, ...]],
        *,
        process_group_name: str | None,
        log: AutotuningLogger,
    ) -> None:
        self.fns = list(fns)
        # the private clones stay alive (with their sacrificial clone) until exit
        self.args: _PrivateBenchmarkArgs | Sequence[object] | None = args
        self.args_by_fn: list[Sequence[object]] = (
            list(args.by_member)
            if isinstance(args, _PrivateBenchmarkArgs)
            else [args] * len(self.fns)
        )
        self.steady_bench = steady_bench
        self.process_group_name = process_group_name
        self.log = log

    def __enter__(self) -> Self:
        return self

    def __exit__(self, exc_type: object, *exc_info: object) -> None:
        for fn in self.fns:
            clear_jit_fast_path_caches(fn, self.log)
        self.args_by_fn = []
        self.args = None

    def warm(self, index: int, duration_ms: int) -> None:
        self._bench(index, duration_ms, 1)

    def measure(
        self, index: int, warmup_ms: int, rep_ms: int
    ) -> IsolatedBenchmarkTiming:
        return self._bench(index, warmup_ms, rep_ms)

    def _bench(self, index: int, warmup_ms: int, rep_ms: int) -> float:
        run = functools.partial(self.fns[index], *self.args_by_fn[index])
        try:
            timing = self.steady_bench(
                run,
                warmup=warmup_ms,
                rep=rep_ms,
                return_mode="median",
                process_group_name=self.process_group_name,
            )
        finally:
            clear_jit_fast_path_caches(self.fns[index], self.log)
        if isinstance(timing, tuple):
            timing = timing[0]
        return float(timing)


class PopulationBasedSearch(BaseSearch):
    """
    Base class for search algorithms that use a population of configurations.

    Attributes:
        population (list[PopulationMember]): The current population of configurations.
        flat_spec (list[ConfigSpecFragment]): The flattened configuration specification.
    """

    # Harness-grade final selection policy, resolved from the effort profile
    # of ``settings.autotune_effort`` (full effort only; the lower efforts
    # keep the single-pass final verification). It is a benchmarking policy
    # rather than a search-algorithm knob, so it is not a constructor
    # argument and ``_final_rebenchmark_cache_policy`` carries it.
    final_selection: FinalSelectionConfig | None = None

    def __init__(
        self,
        kernel: _AutotunableKernel,
        args: Sequence[object],
        *,
        finishing_rounds: int = 0,
    ) -> None:
        """
        Initialize the PopulationBasedSearch object.

        Args:
            kernel: The kernel to be tuned.
            args: The arguments to be passed to the kernel.
            finishing_rounds: Number of finishing rounds to run after the main search.
        """
        super().__init__(kernel, args)
        self.finishing_rounds = finishing_rounds
        self.final_selection = self._final_selection_from_settings(self.settings)
        self.population: list[PopulationMember] = []
        # Population members corresponding to compiler-seeded configs from
        # ``ConfigSpec.compiler_seed_configs``.  Tracked separately so the
        # final-pick verification phase can re-include them as candidates
        # even when the surrogate-driven search has pruned them away from
        # ``self.population``.
        self._compiler_seed_members: list[PopulationMember] = []
        self._best_available_seed_configs: list[Config] = []
        self._selected_member: PopulationMember | None = None
        self._terminal_refinement_members: dict[Config, PopulationMember] | None = None
        self.config_gen: ConfigGeneration = self.config_spec.create_config_generation(
            overrides=self.settings.autotune_config_overrides or None,
            advanced_controls_files=self.settings.autotune_search_acf or None,
            process_group_name=kernel.env.process_group_name,
            compiler_coverage_enabled=not self.settings.disable_autotuner_heuristics,
        )

    def _generation_invalid_config_count(self) -> int:
        return self.config_gen.invalid_config_count

    def _final_rebenchmark_cache_policy(self) -> dict[str, object]:
        return {
            "enabled": True,
            # 2: the non-isolated finalist shootout uses paired interleaved
            # timing instead of sequential steady windows.
            # 3: an in-process fallback for a mutated-argument kernel gives
            # every finalist private storage, preventing cross-config L2
            # eviction-priority leakage.
            # Fresh finalist processes cannot inherit cached argument storage
            # or live allocations from candidates measured earlier in search.
            "timing_version": 4,
            "top_k": self._final_rebenchmark_top_k(),
            "target_ms": self._final_rebenchmark_target_ms(),
            "isolated": self._final_rebenchmark_use_isolated(),
            "pinned_tolerance": self._final_rebenchmark_pinned_tolerance(),
            "repeat_cap": os.getenv("HELION_CAP_REBENCHMARK_REPEAT"),
            # The harness-grade final selection replaces the pass above at
            # full effort; like the knobs above it decides which finalist is
            # returned, not which candidates the search visits.
            "final_selection": (
                None
                if self.final_selection is None
                else dataclasses.asdict(self.final_selection)
            ),
        }

    @staticmethod
    def _final_selection_from_profile(
        profile: AutotuneEffortProfile,
    ) -> FinalSelectionConfig | None:
        """The profile's final selection policy with the rounds override."""
        policy = profile.final_selection
        if policy is None:
            return None
        rounds = _env_get_optional_int(_FINAL_SELECTION_ROUNDS_ENV)
        if rounds is not None:
            policy = dataclasses.replace(policy, rounds=max(0, rounds))
        if policy.rounds <= 0:
            return None
        return policy

    @classmethod
    def _final_selection_from_settings(
        cls, settings: Settings
    ) -> FinalSelectionConfig | None:
        return cls._final_selection_from_profile(
            get_effort_profile(settings.autotune_effort)
        )

    @classmethod
    def get_kwargs_from_profile(
        cls, profile: AutotuneEffortProfile, settings: Settings
    ) -> dict[str, object]:
        """
        Retrieve extra kwargs from the effort profile for the autotuner.
        """
        finishing_rounds = _env_get_optional_int("HELION_AUTOTUNE_FINISHING_ROUNDS")
        if finishing_rounds is None:
            finishing_rounds = profile.finishing_rounds

        return {
            "finishing_rounds": finishing_rounds,
            **super().get_kwargs_from_profile(profile, settings),
        }

    def _final_selection_enabled(self) -> bool:
        """Whether the final pick runs the interleaved steady-window shootout."""
        return (
            self.final_selection is not None
            and self.settings.autotune_benchmark_fn is None
            and not isinstance(self.benchmark_provider, MultiShapeBenchmarkProvider)
        )

    def _final_selection_shortlist_estimate(self) -> int:
        """Longest shortlist ``final_rebenchmark_best`` can hand the selection:
        the retained ``top_k``, the pinned seeds and the incumbent (appended
        when a later phase re-timed it above the shortlist's numbers)."""
        return self._final_rebenchmark_top_k() + len(self._pinned_finalist_configs) + 1

    def _budget_reserve_seconds(self) -> float:
        budget = self.settings.autotune_budget_seconds
        if budget is None or not self._final_selection_enabled():
            return 0.0
        policy = self.final_selection
        assert policy is not None
        return min(
            policy.estimated_seconds(self._final_selection_shortlist_estimate()),
            _FINAL_SELECTION_RESERVE_FRACTION * budget,
        )

    def _minimum_final_selection_seconds(self) -> float:
        if not self._final_selection_enabled():
            return 0.0
        policy = self.final_selection
        assert policy is not None
        smallest = policy.budget_ladder()[-1]
        return smallest.estimated_seconds(self._final_selection_shortlist_estimate())

    def _final_selection_plan(self, shortlist: int) -> FinalSelectionConfig | None:
        """The policy sized to the budget left when the phase starts.

        Without a budget the profile's policy runs as is. Rank 0's plan is
        used on every rank so the ranks take the same windows together.
        """
        policy = self.final_selection
        assert policy is not None
        budget = self.settings.autotune_budget_seconds
        if budget is not None and self._autotune_budget_start is not None:
            remaining = budget - (time.perf_counter() - self._autotune_budget_start)
            plan = policy.fit_to_seconds(remaining, shortlist)
            if plan is None:
                smallest = policy.budget_ladder()[-1].estimated_seconds(shortlist)
                self.log(
                    f"Final selection skipped: {remaining:.0f}s of the "
                    f"{budget}s budget remain, less than the {smallest:.0f}s of "
                    "its smallest plan; returning the search's best."
                )
            elif plan != policy:
                self.log(
                    f"Final selection sized to the {remaining:.0f}s left of the "
                    f"{budget}s budget: up to {plan.finalists(shortlist)} finalists x "
                    f"{plan.rounds} rounds"
                    + (", no screen" if policy.screens(shortlist) else "")
                    + (
                        ", no thermal warmup"
                        if plan.thermal_warmup_ms == 0 < policy.thermal_warmup_ms
                        else ""
                    )
                )
            policy = plan
        return sync_object(
            policy, process_group_name=self.kernel.env.process_group_name
        )

    def _warn_ignored_final_rebenchmark_envs(self) -> None:
        """Say once that the single-pass knobs do not steer the selection."""
        global _final_selection_ignored_envs_warned
        if _final_selection_ignored_envs_warned:
            return
        ignored = [name for name in _FINAL_SELECTION_IGNORED_ENVS if name in os.environ]
        if not ignored:
            return
        _final_selection_ignored_envs_warned = True
        self.log.warning(
            f"{', '.join(ignored)} only steer the single-pass final verification; "
            "the full-effort final selection ignores them (set "
            f"{_FINAL_SELECTION_ROUNDS_ENV}=0 to run that verification instead)."
        )

    @property
    def best(self) -> PopulationMember:
        """
        Retrieve the best configuration in the population.

        Returns:
            The best population member.
        """
        return min(self.population, key=performance)

    @best.setter
    def best(self, value: PopulationMember) -> None:
        """Replace the current best member in the population."""
        idx = min(range(len(self.population)), key=lambda i: self.population[i].perf)
        self.population[idx] = value

    def capture_compiler_seed_members(
        self, members: Sequence[PopulationMember]
    ) -> None:
        """Record which ``members`` came from compiler-seeded configs (TPU only).

        Only the TPU/Pallas final-pick consumes this, so it's a no-op elsewhere.
        Matches members against ``config_gen.seed_flat_config_pairs()`` so the
        final-pick phase can re-include a seed even if the search later prunes it.
        """
        self._compiler_seed_members = []
        if not self._final_pick_supported():
            return
        try:
            seed_pairs = self.config_gen.seed_flat_config_pairs()
        except Exception:
            return
        if not seed_pairs:
            return
        seed_flats: list[FlatConfig] = [flat for flat, _config in seed_pairs]
        for member in members:
            if member.flat_values in seed_flats:
                self._compiler_seed_members.append(member)

    def benchmark_flat(self, flat_values: FlatConfig) -> PopulationMember:
        """
        Benchmark a flat configuration.

        Args:
            flat_values: The flat configuration values.

        Returns:
            A population member with the benchmark results.
        """
        canonical_flat, config = self.config_gen.canonicalize_flat(flat_values)
        member = PopulationMember(_unset_fn, [], canonical_flat, config)
        self.benchmark_population([member], desc="Benchmarking")
        return member

    def benchmark_flat_batch(
        self,
        to_check: list[FlatConfig],
        *,
        random_fallback_target: int | None = None,
    ) -> list[PopulationMember]:
        """
        Benchmark multiple flat configurations in parallel.

        The first ``len(to_check)`` entries of the returned list preserve
        positional correspondence with ``to_check``.  Invalid configurations
        that cannot be unflattened are represented as ``PopulationMember``
        objects with ``perf == inf`` and ``status == "error"`` (they are not
        benchmarked).

        Args:
            to_check: A list of flat configurations to benchmark.
            random_fallback_target: When given, ``to_check`` is a seed-only
                initial population; see :meth:`benchmark_initial_population`.

        Returns:
            A list of population members with the benchmark results, one per
            entry in *to_check*.  When ``random_fallback_target`` is given and
            every entry fails, the random fallback members are appended after
            the positional entries, so the list is then longer than
            ``to_check``.
        """
        from ..runtime.config import Config

        valid: list[PopulationMember] = []
        result: list[PopulationMember] = []
        for flat in to_check:
            m = self.make_unbenchmarked(flat)
            if m is not None:
                valid.append(m)
                result.append(m)
            else:
                result.append(
                    PopulationMember(
                        _unset_fn, [float("inf")], flat, Config(), status="error"
                    )
                )

        if random_fallback_target is None:
            self.benchmark_population(valid)
            return result
        num_valid = len(valid)
        self.benchmark_initial_population(
            valid, random_fallback_target=random_fallback_target
        )
        result.extend(valid[num_valid:])
        return result

    def make_unbenchmarked(self, flat_values: FlatConfig) -> PopulationMember | None:
        """
        Create a population member with unbenchmarked configuration.  You
        should pass the result of this to benchmark_population.

        Args:
            flat_values: The flat configuration values.

        Returns:
            A population member with undefined performance, or None if the
            configuration is invalid.
        """
        try:
            canonical_flat, config = self.config_gen.canonicalize_flat(flat_values)
        except exc.InvalidConfig:
            self.config_gen.invalid_config_count += 1
            return None
        if not self._backend_config_is_viable(config):
            self.config_gen.invalid_config_count += 1
            return None
        return PopulationMember(_unset_fn, [], canonical_flat, config)

    def _pad_initial_population_with_unique_random(
        self,
        population: Sequence[FlatConfig],
        target: int,
        *,
        generation: ConfigGeneration | None = None,
    ) -> list[FlatConfig]:
        """Pad an initial population with normalized, unique random configs."""
        generation = self.config_gen if generation is None else generation
        result: list[FlatConfig] = []
        seen: set[Config] = set()
        invalid = 0
        duplicate = 0

        def append_if_valid(flat: FlatConfig) -> None:
            nonlocal invalid, duplicate
            try:
                canonical_flat, config = generation.canonicalize_flat(flat)
            except exc.InvalidConfig:
                invalid += 1
                return
            if not self._backend_config_is_viable(config):
                invalid += 1
                return
            if config in seen:
                duplicate += 1
                return
            seen.add(config)
            result.append(canonical_flat)

        for flat in population:
            append_if_valid(flat)

        attempts = 0
        max_attempts = max(64, max(0, target - len(result)) * 64)
        while len(result) < target and attempts < max_attempts:
            attempts += 1
            append_if_valid(generation.random_flat())

        if len(result) < target:
            self.log(
                "Generated only "
                f"{len(result)}/{target} unique valid initial population configs "
                f"after {attempts} random attempts "
                f"({invalid} invalid, {duplicate} duplicate)."
            )
        if attempts or invalid or duplicate:
            self.log(
                f"Initial population after unique random padding: {len(result)} total"
            )
        return result

    def _replace_backend_rejected_initial_configs(
        self,
        population: Sequence[FlatConfig],
        target: int,
    ) -> list[FlatConfig]:
        """Refill only when backend screening rejects an initial candidate."""
        for flat in population:
            try:
                _canonical_flat, config = self.config_gen.canonicalize_flat(flat)
            except exc.InvalidConfig:
                continue
            if not self._backend_config_is_viable(config):
                return self._pad_initial_population_with_unique_random(
                    population, target
                )
        return list(population)

    def _generate_best_available_population_flat(
        self, *, generation: ConfigGeneration | None = None
    ) -> list[FlatConfig]:
        """
        Generate initial population using default config, explicit seed configs,
        and cached configs.

        Starts with explicit seed configs, compiler-owned seed configs,
        caller-provided best-available seeds, and the default configuration,
        then adds up to MAX_BEST_AVAILABLE_CONFIGS matching cached configs from
        previous runs. Seeds are tried before the raw default so backend-promoted
        fast paths (for example CuTe flash attention) are benchmarked first even
        when the seed is not also promoted to
        ``ConfigSpec.compiler_default_config``. Explicit seed configs are not
        suppressed by cache-skip settings. No random configs are added.

        Returns:
            A list of unique FlatConfig values for the initial population.
            Minimum size is 1 (default), plus any valid unique explicit/compiler
            seed configs and up to autotune_best_available_max_configs cached
            configs.
        """
        projected = generation is not None and generation._initial_sampling
        generation = self.config_gen if generation is None else generation
        max_configs = self.settings.autotune_best_available_max_configs

        seen: set[Config] = set()
        result: list[FlatConfig] = []
        pinned_configs: set[Config] = set()

        # User seed configs are explicit requests, so try them before compiler-owned
        # seeds, the raw default, and cached configs while still deduplicating
        # normalized configs.
        for flat, transferred_config in generation.user_seed_flat_config_pairs(
            self._autotune_seed_configs(), self.log
        ):
            if transferred_config not in seen:
                seen.add(transferred_config)
                pinned_configs.add(transferred_config)
                result.append(flat)

        # Compiler-owned seeds come from ConfigSpec.compiler_seed_configs;
        # they encode backend/compiler heuristics and complement user seed configs.
        # Keep them before the raw fragment default so expensive fallback defaults
        # cannot starve a known fast compiler seed in FROM_BEST_AVAILABLE mode.
        for flat, transferred_config in generation.seed_flat_config_pairs(self.log):
            if transferred_config not in seen:
                seen.add(transferred_config)
                pinned_configs.add(transferred_config)
                result.append(flat)

        for config in self._best_available_seed_configs:
            try:
                flat = generation.flatten(config)
                transferred_config = generation.unflatten(flat)
                if transferred_config not in seen:
                    seen.add(transferred_config)
                    pinned_configs.add(transferred_config)
                    result.append(flat)
            except (ValueError, TypeError, KeyError, AssertionError) as e:
                self.log(f"Failed to transfer explicit seed config: {e}")

        default_flat = generation.default_flat()
        default_config = generation.unflatten(default_flat)
        if default_config not in seen:
            seen.add(default_config)
            pinned_configs.add(default_config)
            result.append(default_flat)
        self._pinned_finalist_configs.update(
            copy.deepcopy(config) for config in pinned_configs
        )
        self.log("Starting with seed/default configs")

        cached_entries = (
            self._find_similar_cached_configs(
                max_configs,
                config_spec_hash=self.config_spec.projected_cache_fingerprint_hash(
                    advanced_controls_files=self.settings.autotune_search_acf or None
                ),
            )
            if projected
            else self._find_similar_cached_configs(max_configs)
        )

        if cached_entries:
            self.log.debug(
                f"Found {len(cached_entries)} cached config(s) from previous runs"
            )

        duplicates = 0
        for i, entry in enumerate(cached_entries):
            try:
                self.log.debug(f"Cached config {i + 1}: {entry.config}")
                flat = entry.to_mutable_flat_config()
                if projected:
                    flat, transferred_config = generation.projected_cache_flat_pair(
                        flat
                    )
                else:
                    transferred_config = generation.unflatten(flat)
                if transferred_config in seen:
                    duplicates += 1
                    self.log.debug(
                        f"Cached config {i + 1} is a duplicate, skipping: {transferred_config}"
                    )
                    continue
                seen.add(transferred_config)
                result.append(flat)
                self.log.debug(
                    f"Cached config {i + 1} (transferred): {transferred_config}"
                )
            except (
                ValueError,
                TypeError,
                KeyError,
                AssertionError,
                exc.InvalidConfig,
            ) as e:
                self.log(f"Failed to transfer cached config {i + 1}: {e}")
                continue

        if duplicates > 0:
            self.log.debug(f"Discarded {duplicates} duplicate config(s)")

        self.log(f"Seed/default/cache population: {len(result)} total")

        return result

    def _append_compiler_coverage(
        self, population: list[FlatConfig], *, use_cache: bool
    ) -> list[FlatConfig]:
        from .compiler_coverage import append_compiler_coverage

        def cached_configs() -> list[Config]:
            if not use_cache:
                return []
            result: list[Config] = []
            for entry in self._find_similar_cached_configs(
                self.settings.autotune_best_available_max_configs
            ):
                try:
                    result.append(
                        self.config_gen.strict_unflatten(entry.to_mutable_flat_config())
                    )
                except (
                    exc.InvalidConfig,
                    ValueError,
                    TypeError,
                    KeyError,
                    AssertionError,
                ) as error:
                    self.log(
                        f"Failed to transfer expanded coverage cache config: {error}"
                    )
            return result

        result, outcomes = append_compiler_coverage(
            population,
            self.config_gen,
            cached_configs=cached_configs,
            pin=self.pin_finalist_config,
        )
        self.compiler_coverage_outcomes = outcomes
        for outcome in outcomes:
            self.log.debug(
                f"Compiler coverage {outcome.mechanism} ({outcome.origin}): "
                f"{outcome.outcome}; requested={outcome.requested}, effective={outcome.effective}"
            )
        return result

    def set_best_available_seed_configs(
        self,
        configs: Sequence[Config],
    ) -> None:
        self._best_available_seed_configs = list(configs)

    def benchmark_population(
        self,
        members: list[PopulationMember],
        *,
        desc: str = "Benchmarking",
        raise_if_no_viable_config: bool = True,
    ) -> list[PopulationMember]:
        """
        Benchmark multiple population members in parallel.  Members should be created with make_unbenchmarked.

        Args:
            members: The list of population members to benchmark.
            desc: Description for the progress bar.
            raise_if_no_viable_config: See :meth:`BaseSearch.benchmark_batch`.
        """
        results = self.benchmark_batch(
            [m.config for m in members],
            desc=desc,
            raise_if_no_viable_config=raise_if_no_viable_config,
        )
        for member, result in zip(members, results, strict=True):
            member.config = result.config
            member.flat_values = self.config_gen.flatten(result.config)
            member.perfs.append(result.perf)
            member.fn = result.fn
            member.status = result.status
            member.compile_time = result.compile_time
            self._record_benchmarked_member(member)
        repairs = self.benchmark_provider.take_effective_source_repairs()
        if repairs:
            self._apply_effective_source_repairs(repairs, members)
        return members

    def benchmark_initial_population(
        self,
        members: list[PopulationMember],
        *,
        random_fallback_target: int | None = None,
        visited: set[Config] | None = None,
        desc: str = "Initial population",
    ) -> list[PopulationMember]:
        """Benchmark the initial population, recovering from an all-failing seed set.

        ``random_fallback_target`` is the number of unique random configs to
        add when ``members`` holds only seed/default/cache configs and none of
        them compiles or runs (for example a backend default config that
        raises ``BackendUnsupported`` for this kernel). It counts configs
        beyond the seeds, so the fallback is the same size however many
        cached configs were seeded. ``None`` keeps the immediate re-raise of
        the compile error, which is right for random populations: their total
        failure already shows the search space is broken, so padding would
        only double the time to the same error. Fallback members are appended
        to ``members`` (and ``visited``) in place; when no fallback config can
        be generated, or the fallback also fails entirely, the compile error
        is raised exactly as for a random population.
        """
        self.benchmark_population(
            members,
            desc=desc,
            raise_if_no_viable_config=random_fallback_target is None,
        )
        if random_fallback_target is None or any(
            math.isfinite(member.perf) for member in members
        ):
            return members
        compile_error = self.benchmark_provider.take_no_viable_config_error()
        seen = {member.config for member in members} if visited is None else visited
        fallback: list[PopulationMember] = []
        # The padding helper re-adds the seeds first, so pad past them.
        for flat in self._pad_initial_population_with_unique_random(
            [member.flat_values for member in members],
            len(members) + random_fallback_target,
        ):
            member = self.make_unbenchmarked(flat)
            if member is not None and member.config not in seen:
                seen.add(member.config)
                fallback.append(member)
        if not fallback:
            # Nothing to fall back to: surface the real compile error rather
            # than letting the search end in a generic NoConfigFound.
            if compile_error is not None:
                raise compile_error
            return members
        self.log.warning(
            f"None of the {len(members)} seed/default/cache configs compiled or "
            "ran (the backend may not support the default config for this "
            f"kernel); continuing with {len(fallback)} random configs."
        )
        self.benchmark_population(fallback, desc="Random fallback population")
        members.extend(fallback)
        return members

    def _apply_effective_source_repairs(
        self,
        repairs: dict[Config, BenchmarkResult],
        current_members: Sequence[PopulationMember],
    ) -> None:
        """Repair failed members after a later config proves the same source."""
        candidates = [
            *current_members,
            *self.population,
            *self._compiler_seed_members,
            *self._benchmarked_members.values(),
            *self._pinned_finalist_members.values(),
            *(getattr(self, "_terminal_refinement_members", None) or {}).values(),
        ]
        seen: set[int] = set()
        for member in candidates:
            if id(member) in seen:
                continue
            seen.add(id(member))
            repair = repairs.get(member.config)
            if repair is None or (member.perfs and math.isfinite(member.perf)):
                continue
            if member.perfs:
                member.perfs = [
                    repair.perf if not math.isfinite(perf) else perf
                    for perf in member.perfs
                ]
            else:
                member.perfs.append(repair.perf)
            member.fn = repair.fn
            member.status = repair.status
            member.compile_time = None
            self._record_benchmarked_member(member)

    def _record_benchmarked_member(self, member: PopulationMember) -> None:
        """Keep successful benchmarked members available for final verification."""
        terminal_members = getattr(self, "_terminal_refinement_members", None)
        if terminal_members is not None:
            self._record_terminal_refinement_member(terminal_members, member)
        if not member.perfs or not math.isfinite(member.perf):
            return
        if member.config in self._pinned_finalist_configs:
            self._record_best_member_for_config(
                self._pinned_finalist_members, member.config, member
            )
        top_k = self._final_rebenchmark_top_k()
        if top_k <= 1:
            return
        self._record_best_member_for_config(
            self._benchmarked_members, member.config, member
        )
        self._prune_benchmarked_members(top_k)

    def _record_terminal_refinement_member(
        self,
        target: dict[Config, PopulationMember],
        member: PopulationMember,
    ) -> None:
        """Refresh terminal history without replacing a reusable result by failure."""
        existing = target.get(member.config)

        def reusable(candidate: PopulationMember | None) -> bool:
            return bool(
                candidate is not None
                and candidate.status in {"ok", "deduplicated"}
                and candidate.perfs
                and math.isfinite(candidate.perf)
            )

        if reusable(existing) and not reusable(member):
            return
        self._record_best_member_for_config(
            target,
            member.config,
            member,
            replace=True,
        )

    def _record_best_member_for_config(
        self,
        target: dict[Config, PopulationMember],
        config: Config,
        member: PopulationMember,
        *,
        replace: bool = False,
        replace_ties: bool = False,
    ) -> None:
        existing = target.get(config)
        member_perf = self._finalist_history_perf(member)
        existing_perf = (
            inf if existing is None else self._finalist_history_perf(existing)
        )
        if (
            replace
            or existing is None
            or member_perf < existing_perf
            or (replace_ties and member_perf == existing_perf)
        ):
            # Config is mutable and hashes on its contents, and the autotuner
            # mutates configs in place (normalize / neighbor generation). Store
            # a private snapshot so a later mutation of the original config
            # cannot change this key's hash (-> KeyError on prune / orphaned
            # entries) or the config recompiled during final verification. The
            # performance list is mutable too, so do not let later rebenchmarks
            # silently alter a supposedly historical snapshot.
            snapshot = copy.deepcopy(config)
            target[snapshot] = dataclasses.replace(
                member,
                perfs=copy.deepcopy(member.perfs),
                flat_values=copy.deepcopy(member.flat_values),
                config=snapshot,
            )

    def _uses_verified_finalist_history(self) -> bool:
        """Whether finalist retention should follow the latest verified timing."""
        config_spec = getattr(self, "config_spec", None)
        return bool(
            config_spec is not None
            and getattr(config_spec, "cute_flash_search_enabled", False)
        )

    def _finalist_history_perf(self, member: PopulationMember) -> float:
        if self._uses_verified_finalist_history():
            if member.perfs and math.isfinite(member.perf):
                return member.perf
            return inf
        return self._member_low_water_perf(member)

    def _refresh_benchmarked_members_after_rebenchmark(
        self, members: Sequence[PopulationMember]
    ) -> None:
        """Refresh finalist history after its source members are rebenchmarked.

        Long CuTe kernels can have optimistic first-call timings. Candidates are
        initially recorded before the normal higher-effort rebenchmark, so the
        first sample must not permanently decide which configs survive in the
        bounded final-verification history. Other backends preserve their prior
        low-water ranking and do not reinsert configs that were already pruned;
        they still need an explicit refresh now that snapshots own their perf lists.
        A failed duplicate retains the last successful snapshot for final checking,
        unless source quarantine has invalidated that snapshot too.
        """
        terminal_members = getattr(self, "_terminal_refinement_members", None)
        if terminal_members is not None:
            for member in members:
                self._record_terminal_refinement_member(terminal_members, member)

        benchmarked_members = getattr(self, "_benchmarked_members", None)
        pinned_configs = getattr(self, "_pinned_finalist_configs", None)
        pinned_members = getattr(self, "_pinned_finalist_members", None)
        if (
            benchmarked_members is None
            or pinned_configs is None
            or pinned_members is None
        ):
            return

        use_verified_history = self._uses_verified_finalist_history()
        top_k = self._final_rebenchmark_top_k()
        refreshed_configs: dict[Config, None] = {}
        finite_members: dict[Config, PopulationMember] = {}
        for member in members:
            if not member.perfs:
                continue
            refreshed_configs.setdefault(member.config, None)
            history_perf = self._finalist_history_perf(member)
            if not math.isfinite(history_perf):
                continue
            existing = finite_members.get(member.config)
            if existing is None or history_perf < self._finalist_history_perf(existing):
                finite_members[member.config] = member

        for config in refreshed_configs:
            member = finite_members.get(config)
            if member is None and use_verified_history and terminal_members is not None:
                # The higher-effort rebenchmark invalidated every fresh sample
                # for this config; drop any older ok snapshot so terminal
                # refinement re-measures the config instead of resurrecting a
                # quarantined result.
                terminal_members.pop(config, None)
            if config in pinned_configs and member is not None:
                self._record_best_member_for_config(
                    pinned_members,
                    config,
                    member,
                    replace=use_verified_history,
                    replace_ties=not use_verified_history,
                )
            elif config in pinned_configs and use_verified_history:
                existing = pinned_members.get(config)
                if existing is not None and not math.isfinite(
                    self._finalist_history_perf(existing)
                ):
                    pinned_members.pop(config, None)
            if top_k <= 1 or (
                not use_verified_history and config not in benchmarked_members
            ):
                continue
            if member is not None:
                # CuTe flash reinserts configs pruned by their initial sample.
                # Other backends only refresh existing snapshots above.
                self._record_best_member_for_config(
                    benchmarked_members,
                    config,
                    member,
                    replace=use_verified_history,
                    replace_ties=not use_verified_history,
                )
            elif use_verified_history:
                existing = benchmarked_members.get(config)
                if existing is not None and not math.isfinite(
                    self._finalist_history_perf(existing)
                ):
                    benchmarked_members.pop(config, None)
        if use_verified_history and top_k > 1:
            self._prune_benchmarked_members(top_k)

    def _prune_benchmarked_members(self, top_k: int) -> None:
        if len(self._benchmarked_members) <= top_k:
            return
        for config, _member in sorted(
            self._benchmarked_members.items(),
            key=lambda item: self._finalist_history_perf(item[1]),
        )[top_k:]:
            del self._benchmarked_members[config]

    def pin_finalist_config(self, config: Config) -> None:
        """Always include a seed/default config in final verification if benchmarked."""
        # Snapshot: configs are mutated in place after being added (see
        # _record_best_member_for_config), which would corrupt this set.
        self._pinned_finalist_configs.add(copy.deepcopy(config))

    def pin_finalist_configs(self, configs: Sequence[Config]) -> None:
        for config in configs:
            self.pin_finalist_config(config)

    def _final_rebenchmark_top_k_default(self) -> int:
        backend_name = getattr(getattr(self, "config_spec", None), "backend_name", None)
        if backend_name == "cute":
            return _FINAL_REBENCHMARK_TOP_K_CUTE
        return _FINAL_REBENCHMARK_TOP_K_DEFAULT

    def _final_rebenchmark_top_k(self) -> int:
        default = self._final_rebenchmark_top_k_default()
        raw = os.getenv(_FINAL_REBENCHMARK_TOP_K_ENV)
        if raw is None:
            return default
        try:
            return max(0, int(raw))
        except ValueError:
            self.log.warning(
                f"Ignoring invalid {_FINAL_REBENCHMARK_TOP_K_ENV}={raw!r}; "
                f"using {default}."
            )
            return default

    def _final_rebenchmark_target_ms(self) -> float:
        raw = os.getenv(_FINAL_REBENCHMARK_TARGET_MS_ENV)
        if raw is None:
            return _FINAL_REBENCHMARK_TARGET_MS_DEFAULT
        try:
            target_ms = float(raw)
        except ValueError:
            self.log.warning(
                f"Ignoring invalid {_FINAL_REBENCHMARK_TARGET_MS_ENV}={raw!r}; "
                f"using {_FINAL_REBENCHMARK_TARGET_MS_DEFAULT}."
            )
            return _FINAL_REBENCHMARK_TARGET_MS_DEFAULT
        if not math.isfinite(target_ms):
            self.log.warning(
                f"Ignoring non-finite {_FINAL_REBENCHMARK_TARGET_MS_ENV}={raw!r}; "
                f"using {_FINAL_REBENCHMARK_TARGET_MS_DEFAULT}."
            )
            return _FINAL_REBENCHMARK_TARGET_MS_DEFAULT
        return min(
            _FINAL_REBENCHMARK_TARGET_MS_MAX,
            max(_REBENCHMARK_TARGET_MS_DEFAULT, target_ms),
        )

    def _final_rebenchmark_use_isolated(self) -> bool:
        from ..runtime.settings import _env_get_bool

        # Default to ISOLATED finalist timing on cute: the interleaved bench
        # lets L2 cache-POLICY state leak between candidates that read the
        # same input tensors (an ``l2_last`` candidate pins its inputs in L2
        # and every rival free-rides on the hits, so the config CAUSING the
        # speedup can never out-measure the others).  Isolated mode times
        # each finalist in its own steady window — the same regime the
        # deployment-style do_bench measures — with suspicious-result
        # confirmation guarding against thermal drift between windows.
        backend_name = getattr(getattr(self, "config_spec", None), "backend_name", None)
        default = backend_name == "cute"
        try:
            return _env_get_bool(_FINAL_REBENCHMARK_ISOLATED_ENV, default)
        except ValueError:
            self.log.warning(
                f"Ignoring invalid {_FINAL_REBENCHMARK_ISOLATED_ENV}="
                f"{os.getenv(_FINAL_REBENCHMARK_ISOLATED_ENV)!r}; using {default}."
            )
            return default

    def _final_rebenchmark_pinned_tolerance(self) -> float:
        raw = os.getenv(_FINAL_REBENCHMARK_PINNED_TOLERANCE_ENV)
        if raw is None:
            return _FINAL_REBENCHMARK_PINNED_TOLERANCE_DEFAULT
        try:
            tolerance = float(raw)
        except ValueError:
            self.log.warning(
                f"Ignoring invalid {_FINAL_REBENCHMARK_PINNED_TOLERANCE_ENV}={raw!r}; "
                f"using {_FINAL_REBENCHMARK_PINNED_TOLERANCE_DEFAULT}."
            )
            return _FINAL_REBENCHMARK_PINNED_TOLERANCE_DEFAULT
        if not math.isfinite(tolerance) or tolerance < 0:
            self.log.warning(
                f"Ignoring invalid {_FINAL_REBENCHMARK_PINNED_TOLERANCE_ENV}={raw!r}; "
                f"using {_FINAL_REBENCHMARK_PINNED_TOLERANCE_DEFAULT}."
            )
            return _FINAL_REBENCHMARK_PINNED_TOLERANCE_DEFAULT
        return tolerance

    @staticmethod
    def _repeat_for_target_ms(target_ms: float, best_perf_so_far: float) -> int:
        if math.isfinite(best_perf_so_far) and best_perf_so_far > 0:
            base_repeat_float = target_ms / best_perf_so_far
            base_repeat = (
                _REBENCHMARK_INTERLEAVED_REPEAT_MAX
                if not math.isfinite(base_repeat_float)
                else int(base_repeat_float)
            )
        else:
            base_repeat = 1000
        return min(_REBENCHMARK_INTERLEAVED_REPEAT_MAX, max(3, base_repeat))

    @staticmethod
    def _repeat_reference_perf(members: list[PopulationMember]) -> float:
        finite = [
            member.perf
            for member in members
            if member.perfs and math.isfinite(member.perf) and member.perf > 0
        ]
        return max(finite, default=inf)

    @staticmethod
    def _isolated_rep_ms(target_ms: float, benchmark_timeout_s: int) -> int:
        timeout_budget_ms = max(1, int(benchmark_timeout_s * 500))
        rep_ms = min(int(target_ms), timeout_budget_ms)
        if (capstr := os.getenv("HELION_CAP_REBENCHMARK_REPEAT")) is not None:
            rep_ms = min(rep_ms, int(capstr))
        return max(1, rep_ms)

    @staticmethod
    def _steady_rebenchmark_rep_ms(target_ms: float) -> int:
        rep_ms = int(target_ms)
        if (capstr := os.getenv("HELION_CAP_REBENCHMARK_REPEAT")) is not None:
            rep_ms = min(rep_ms, int(capstr))
        return max(1, rep_ms)

    @staticmethod
    def _member_low_water_perf(member: PopulationMember) -> float:
        finite = [perf for perf in member.perfs if math.isfinite(perf)]
        return min(finite, default=inf)

    def final_rebenchmark_best(self, best: PopulationMember) -> PopulationMember:
        """Recheck the best seen configs before returning an autotuned result.

        Generation searches can end on a noisy late measurement, especially when a
        budget expires mid-generation. Keep a small history of every compiled
        member and perform one apples-to-apples final verification over the best
        unique configs observed during the run.
        """
        by_config: dict[Config, PopulationMember] = {}
        candidates = [
            *self._pinned_finalist_members.values(),
            *self._benchmarked_members.values(),
            *getattr(self, "population", ()),
            best,
        ]
        for member in candidates:
            if not member.perfs or not math.isfinite(
                self._finalist_history_perf(member)
            ):
                continue
            existing = by_config.get(member.config)
            if existing is None or self._finalist_history_perf(
                member
            ) < self._finalist_history_perf(existing):
                by_config[member.config] = member

        live_candidates = [
            member for member in candidates if math.isfinite(member.perf)
        ]
        if math.isfinite(best.perf):
            fallback = best
        elif live_candidates:
            fallback = min(live_candidates, key=performance)
        else:
            raise exc.NoConfigFound

        use_final_selection = self._final_selection_enabled()
        # The single-pass verification is skipped once a wall-clock budget is
        # spent; the final selection instead reserved its share of the budget
        # during the search (``_budget_reserve_seconds``) and sizes itself to
        # what is left (``_final_selection_plan``).
        if not use_final_selection and self._autotune_budget_exceeded_across_ranks():
            return fallback
        top_k = self._final_rebenchmark_top_k()
        if top_k <= 1:
            return fallback

        pinned = [
            member
            for config, member in by_config.items()
            if config in self._pinned_finalist_configs
        ]
        pinned_configs = {member.config for member in pinned}
        remaining = [
            member
            for member in by_config.values()
            if member.config not in pinned_configs
        ]
        finalists = [
            *pinned,
            *sorted(remaining, key=self._finalist_history_perf)[:top_k],
        ]
        # The incumbent defends its title even when later phases re-timed it
        # above the shortlist's search numbers.
        incumbent = by_config.get(best.config)
        if incumbent is not None and incumbent not in finalists:
            finalists.append(incumbent)
        if len(finalists) < 2:
            live_finalists = [
                member for member in finalists if math.isfinite(member.perf)
            ]
            return min(live_finalists, key=performance, default=fallback)

        before = min(finalists, key=performance)
        if use_final_selection:
            self._warn_ignored_final_rebenchmark_envs()
            plan = self._final_selection_plan(len(finalists))
            if plan is None:
                return fallback
            after = self._run_final_selection(
                finalists,
                pinned_configs,
                before if incumbent is None else incumbent,
                plan,
            )
        else:
            # Finalists have already survived the normal benchmark path. Time
            # the last shortlist with the paired event-based interleaved bench
            # so clock/thermal drift between per-candidate timing windows
            # cannot mis-rank near-tied finalists (unpaired sequential steady
            # windows measured 1-3% apart on identical configs). If a user
            # explicitly opts into isolated finalist timing, keep suspicious
            # confirmation enabled for the in-process fallback.
            use_isolated = self._final_rebenchmark_use_isolated()
            self.rebenchmark(
                finalists,
                desc=f"Final verification top {len(finalists)} configs",
                target_ms=self._final_rebenchmark_target_ms(),
                use_isolated=use_isolated,
                confirm_suspicious=use_isolated,
                use_interleaved=not use_isolated,
                candidate_private_args=use_isolated,
            )
            live_finalists = [
                member for member in finalists if math.isfinite(member.perf)
            ]
            if not live_finalists:
                raise exc.NoConfigFound
            after = self._prefer_pinned_within_tolerance(
                min(live_finalists, key=performance), live_finalists, pinned_configs
            )
        if after.config != before.config:
            self.log(
                "Final verification selected a different config: "
                f"{self.format_performance(before.perf)} -> "
                f"{self.format_performance(after.perf)}"
            )
        return after

    def _prefer_pinned_within_tolerance(
        self,
        after: PopulationMember,
        live: Sequence[PopulationMember],
        pinned_configs: set[Config],
    ) -> PopulationMember:
        """A pinned seed within the tolerance of the best finalist wins the tie."""
        live_pinned = [member for member in live if member.config in pinned_configs]
        if not live_pinned:
            return after
        pinned_after = min(live_pinned, key=performance)
        tolerance = self._final_rebenchmark_pinned_tolerance()
        if pinned_after.perf <= after.perf * (1.0 + tolerance):
            return pinned_after
        return after

    def _steady_bench(self) -> Callable[..., float | tuple[float, ...]]:
        """The backend's steady-window timer, or the generic ``do_bench``."""
        return self.config_spec.backend.get_do_bench() or do_bench

    def _private_benchmark_args(self, count: int) -> _PrivateBenchmarkArgs:
        """Private clones of the kernel arguments for ``count`` candidates.

        Raises ``torch.OutOfMemoryError`` when they do not fit on the device.
        """
        process_group_name = self.kernel.env.process_group_name
        clones = [
            _clone_args(self.args, process_group_name, idx_to_clone=None)
            for _ in range(count + 1)
        ]
        return _PrivateBenchmarkArgs(clones[0], clones[1:])

    def _shared_benchmark_args(self) -> Sequence[object]:
        """The kernel arguments every candidate of a re-timing shares: a clone
        of the mutated arguments when the kernel has any, else the originals."""
        mutated = self.benchmark_provider.mutated_arg_indices
        if len(mutated) == 0:
            return self.args
        return _clone_args(
            self.args, self.kernel.env.process_group_name, idx_to_clone=mutated
        )

    def _final_selection_measurer(
        self, finalists: Sequence[PopulationMember], policy: FinalSelectionConfig
    ) -> _FinalSelectionMeasurer:
        """Steady-window timer for the finalists: the killable benchmark worker
        when the search benchmarks in one, otherwise in-process."""
        provider = self.benchmark_provider
        window_s = (policy.warmup_ms + policy.rep_ms) / 1000.0
        thermal_s = (policy.thermal_warmup_ms + policy.rep_ms) / 1000.0
        # The timer sizes its repetitions from an estimate pass, so a kernel
        # that runs slower in the window than in the estimate stretches the
        # window; three times the longest window still finishes, and 15 s
        # covers a worker spawn with its wrapper and argument loads.
        timeout_s = max(
            float(self.settings.autotune_benchmark_timeout),
            3.0 * max(window_s, thermal_s) + 15.0,
        )
        if isinstance(provider, LocalBenchmarkProvider):
            private_copies = provider.private_argument_copies_affordable(len(finalists))
            if provider.steady_window_benchmark_available():
                return _WorkerFinalSelectionMeasurer(
                    provider,
                    [member.fn for member in finalists],
                    private_copies=private_copies,
                    timeout_s=timeout_s,
                )
        else:
            private_copies = False
        args: _PrivateBenchmarkArgs | Sequence[object] | None = None
        if private_copies and not dist.is_initialized():
            try:
                args = self._private_benchmark_args(len(finalists))
            except torch.OutOfMemoryError:
                self.log.warning(
                    "Final selection could not allocate private argument copies; "
                    "finalists share one argument set."
                )
        if args is None:
            args = self._shared_benchmark_args()
        return _InProcessFinalSelectionMeasurer(
            [member.fn for member in finalists],
            args,
            self._steady_bench(),
            process_group_name=self.kernel.env.process_group_name,
            log=self.log,
        )

    def _run_final_selection(
        self,
        finalists: list[PopulationMember],
        pinned_configs: set[Config],
        incumbent: PopulationMember,
        policy: FinalSelectionConfig,
    ) -> PopulationMember:
        """Pick the returned config with interleaved harness-grade windows.

        The shortlist is screened once in the sustained clock regime (when it
        is long enough to be worth it), the best ``top_k`` survivors plus the
        best pinned seed and the ``incumbent`` then run ``rounds`` rounds of
        steady windows whose order alternates every round, and the median
        across rounds decides (see ``FinalSelectionConfig``). Every decision
        that depends on a reading is taken by rank 0 and broadcast, so
        distributed ranks time the same finalist in every window.
        """
        start = time.perf_counter()
        count = len(finalists)
        screen: list[float | None] = [None] * count
        readings: list[list[float]] = [[] for _ in range(count)]
        failures: list[Literal["error", "timeout"] | None] = [None] * count
        process_group_name = self.kernel.env.process_group_name

        def take(index: int, warmup_ms: int, rep_ms: int) -> float | None:
            result = measurer.measure(index, warmup_ms, rep_ms)
            if isinstance(result, IsolatedBenchmarkFailure):
                failures[index] = result.status
                return None
            if result is None or not math.isfinite(result) or result <= 0:
                return None
            return float(result)

        try:
            with self._final_selection_measurer(finalists, policy) as measurer:
                if policy.thermal_warmup_ms > 0:
                    measurer.warm(finalists.index(incumbent), policy.thermal_warmup_ms)
                screened = policy.screens(count)
                if screened:
                    for index in range(count):
                        screen[index] = take(
                            index, policy.screen_warmup_ms, policy.screen_rep_ms
                        )

                def rank_key(index: int) -> float:
                    if not screened:
                        return self._finalist_history_perf(finalists[index])
                    reading = screen[index]
                    return inf if reading is None else reading

                alive = [index for index in range(count) if failures[index] is None]
                ranked = sorted(alive, key=rank_key)
                survivors = ranked[: policy.top_k]
                pinned_alive = [
                    index
                    for index in ranked
                    if finalists[index].config in pinned_configs
                ]
                if pinned_alive and pinned_alive[0] not in survivors:
                    survivors.append(pinned_alive[0])
                # The incumbent defends its title like the pinned seed: it
                # was shortlisted even where later phases re-timed it above
                # the shortlist's search numbers, which rank it last here
                # whenever the shortlist is not screened.
                incumbent_index = finalists.index(incumbent)
                if incumbent_index in alive and incumbent_index not in survivors:
                    survivors.append(incumbent_index)
                # rank 0 decides who goes on so every rank runs the same windows
                survivors = sync_object(
                    survivors, process_group_name=process_group_name
                )
                for round_index in range(policy.rounds):
                    # A finalist that failed, timed out or missed a reading in
                    # an earlier round cannot compete (it needs a reading from
                    # every round), so it is not timed again: a hung finalist
                    # would otherwise cost every remaining round a timeout.
                    disqualified = sync_object(
                        [
                            index
                            for index in survivors
                            if failures[index] is not None
                            or len(readings[index]) < round_index
                        ],
                        process_group_name=process_group_name,
                    )
                    order = survivors if round_index % 2 == 0 else survivors[::-1]
                    for index in order:
                        if index in disqualified:
                            continue
                        reading = take(index, policy.warmup_ms, policy.rep_ms)
                        if reading is not None:
                            readings[index].append(reading)
        except BenchmarkWorkerUnkillable as error:
            self._record_unkillable(finalists, error)
            raise

        members = [finalists[index] for index in survivors]
        # A finalist competes on the median of a reading from every round: a
        # round it failed, timed out or produced no reading in disqualifies
        # it (one lucky reading must not win over consistently timed rivals).
        results: list[IsolatedBenchmarkTiming] = []
        for index in survivors:
            status = failures[index]
            if status is not None:
                results.append(IsolatedBenchmarkFailure(status))
            elif len(readings[index]) == policy.rounds:
                results.append(statistics.median(readings[index]))
            else:
                results.append(None)
        results = sync_object(results, process_group_name=process_group_name)
        timings, failure_statuses = self._resolve_isolated_rebenchmark_results(
            members, results
        )
        self._apply_rebenchmark_timings(
            members, timings, failure_statuses=failure_statuses
        )
        live = [
            member
            for member, result in zip(members, results, strict=True)
            if isinstance(result, float) and math.isfinite(member.perf)
        ]
        if not live:
            self.log.warning(
                "Final selection took no complete steady-window readings; "
                "keeping the search's best config."
            )
            live = [member for member in members if math.isfinite(member.perf)]
        if not live:
            raise exc.NoConfigFound
        after = self._prefer_pinned_within_tolerance(
            min(live, key=performance), live, pinned_configs
        )
        self._log_final_selection(
            finalists,
            survivors,
            screen,
            readings,
            results,
            after,
            pinned_configs,
            policy,
            wall_s=time.perf_counter() - start,
        )
        return after

    def _log_final_selection(
        self,
        finalists: Sequence[PopulationMember],
        survivors: Sequence[int],
        screen: Sequence[float | None],
        readings: Sequence[Sequence[float]],
        results: Sequence[IsolatedBenchmarkTiming],
        selected: PopulationMember,
        pinned_configs: set[Config],
        policy: FinalSelectionConfig,
        *,
        wall_s: float,
    ) -> None:
        result_by_index = dict(zip(survivors, results, strict=True))

        def verdict(index: int) -> str | None:
            result = result_by_index[index]
            if isinstance(result, IsolatedBenchmarkFailure):
                return result.status
            if result is None:
                return "incomplete"
            return None

        def sort_key(index: int) -> float:
            result = result_by_index[index]
            return result if isinstance(result, float) else inf

        rows: list[dict[str, object]] = []
        lines: list[str] = []
        for index in sorted(survivors, key=sort_key):
            member = finalists[index]
            samples = list(readings[index])
            result = result_by_index[index]
            median = result if isinstance(result, float) else None
            config_id = canonical_config_id(member.config)
            rows.append(
                {
                    "config_id": config_id,
                    "pinned": member.config in pinned_configs,
                    "search_ms": member.perfs[0] if member.perfs else None,
                    "screen_ms": screen[index],
                    "rounds_ms": samples,
                    "median_ms": median,
                    "disqualified": verdict(index),
                }
            )
            marks = ("*" if member is selected else " ") + (
                "P" if member.config in pinned_configs else " "
            )
            median_text = (
                self.format_performance(median)
                if median is not None
                else verdict(index) or "n/a"
            )
            rounds_text = " ".join(f"{sample:.4f}" for sample in samples)
            screen_text = "" if screen[index] is None else f"{screen[index]:.4f}"
            search_text = (
                self.format_performance(member.perfs[0]) if member.perfs else "n/a"
            )
            lines.append(
                f"  {marks} {median_text:>10} [{rounds_text}] screen={screen_text} "
                f"search={search_text} {config_id}"
            )
        self.log(
            f"Final selection: {len(finalists)} shortlisted, {len(survivors)} "
            f"finalists x {policy.rounds} rounds of {policy.warmup_ms}+{policy.rep_ms} ms "
            f"windows in {wall_s:.1f}s; selected "
            f"{self.format_performance(selected.perf)} (* selected, P pinned seed):\n"
            + "\n".join(lines)
        )
        self._autotune_metrics.final_selection = {
            "policy": dataclasses.asdict(policy),
            "shortlisted": len(finalists),
            "finalists": len(survivors),
            "wall_s": wall_s,
            "selected_config_id": canonical_config_id(selected.config),
            "rows": rows,
        }

    def compare(self, a: PopulationMember, b: PopulationMember) -> int:
        """
        Compare two population members based on their performance, possibly with re-benchmarking.

        Args:
            a: The first population member.
            b: The second population member.

        Returns:
            -1 if a is better than b, 1 if b is better than a, 0 if they are equal.
        """
        if self.should_rebenchmark(a) and self.should_rebenchmark(b):
            self.rebenchmark([a, b])
        return (a.perf > b.perf) - (a.perf < b.perf)

    def should_rebenchmark(self, member: PopulationMember) -> bool:
        """
        Determine if a population member should be re-benchmarked to avoid outliers.

        Args:
            member: The population member to check.

        Returns:
            True if the member should be re-benchmarked, False otherwise.
        """
        threshold = self.settings.get_rebenchmark_threshold()
        return member.perf < threshold * self.best_perf_so_far and math.isfinite(
            member.perf
        )

    def rebenchmark(
        self,
        members: list[PopulationMember],
        *,
        desc: str = "Rebenchmarking",
        target_ms: float = _REBENCHMARK_TARGET_MS_DEFAULT,
        use_isolated: bool = True,
        confirm_suspicious: bool = True,
        use_interleaved: bool = True,
        candidate_private_args: bool = False,
    ) -> None:
        """
        Re-benchmark a list of population members to avoid outliers.

        Args:
            members: The list of population members to rebenchmark.
            desc: Description for the progress bar.
            candidate_private_args: Use a fresh worker process per candidate;
                when unavailable, keep argument storage private in-process.
        """
        if len(members) < 2:
            return
        if isinstance(self.benchmark_provider, MultiShapeBenchmarkProvider):
            provider_timings = self.benchmark_provider.rebenchmark(
                [member.config for member in members],
                [member.perf for member in members],
                desc=desc,
            )
            # The provider records only fresh joint measurements; skipped work
            # can return retained timings that must not become new trace rows.
            self._apply_rebenchmark_timings(
                members, provider_timings, trace_results=[None] * len(members)
            )
            return

        # Size the in-process repeat from the candidates being rechecked. A
        # global optimistic outlier can be the reason we are rebenchmarking.
        repeat = PopulationBasedSearch._repeat_for_target_ms(
            target_ms, PopulationBasedSearch._repeat_reference_perf(members)
        )
        if (capstr := os.getenv("HELION_CAP_REBENCHMARK_REPEAT")) is not None:
            repeat = min(repeat, int(capstr))
        repeat = max(1, repeat)

        in_process_isolation = False
        if use_isolated and self.settings.autotune_benchmark_fn is None:
            try:
                isolated_results = self.benchmark_provider.benchmark_isolated(
                    [m.fn for m in members],
                    warmup=1,
                    rep=PopulationBasedSearch._isolated_rep_ms(
                        target_ms, self.settings.autotune_benchmark_timeout
                    ),
                    desc=desc,
                    fresh_process=candidate_private_args,
                )
            except BenchmarkWorkerUnkillable as error:
                self._record_unkillable(members, error)
                raise
            if isolated_results is not None:
                new_timings, failure_statuses = (
                    self._resolve_isolated_rebenchmark_results(
                        members, isolated_results
                    )
                )
                new_timings, failure_statuses = sync_object(
                    (new_timings, failure_statuses),
                    process_group_name=self.kernel.env.process_group_name,
                )
                self._apply_rebenchmark_timings(
                    members,
                    new_timings,
                    failure_statuses=failure_statuses,
                    trace_results=isolated_results,
                )
                return
            if candidate_private_args and dist.is_initialized():
                self.log.warning(
                    "Candidate-private mutated-argument isolation is unavailable "
                    "for distributed in-process rebenchmarking."
                )
            in_process_isolation = candidate_private_args and not dist.is_initialized()

        private_args: _PrivateBenchmarkArgs | None = None
        if (
            in_process_isolation
            and len(self.benchmark_provider.mutated_arg_indices) > 0
        ):
            # Every finalist gets private live tensor storage, including
            # inputs that the kernel only reads (see ``_PrivateBenchmarkArgs``
            # for the sacrificial clone it keeps alive).
            try:
                private_args = self._private_benchmark_args(len(members))
            except torch.OutOfMemoryError as error:
                raise exc.AutotuneError(
                    "Unable to allocate candidate-private mutated arguments "
                    "for in-process finalist isolation. Reduce "
                    f"{_FINAL_REBENCHMARK_TOP_K_ENV} and retry."
                ) from error
            benchmark_args_by_member = private_args.by_member
        else:
            benchmark_args_by_member = [self._shared_benchmark_args()] * len(members)

        def make_rebenchmark_callable(
            member: PopulationMember,
            benchmark_args: Sequence[object],
            *,
            clear_each_call: bool,
        ) -> Callable[[], object]:
            run_member = functools.partial(member.fn, *benchmark_args)

            def wrapped() -> object:
                if clear_each_call:
                    try:
                        return run_member()
                    finally:
                        clear_jit_fast_path_caches(member.fn, self.log)
                else:
                    return run_member()

            return wrapped

        try:
            if use_interleaved or self.settings.autotune_benchmark_fn is not None:
                iterator = [
                    make_rebenchmark_callable(
                        member,
                        benchmark_args,
                        clear_each_call=True,
                    )
                    for member, benchmark_args in zip(
                        members, benchmark_args_by_member, strict=True
                    )
                ]
                benchmark_function: Callable[..., list[float]]
                if self.settings.autotune_benchmark_fn is not None:
                    benchmark_function = self.settings.autotune_benchmark_fn
                else:
                    interleaved_benchmark = (
                        self.config_spec.backend.get_interleaved_bench()
                        or interleaved_bench
                    )
                    # ``repeat`` is sized from candidate kernel time alone; for
                    # microsecond kernels the fixed per-call overhead dominates
                    # and the capped repeat count can take minutes of wall
                    # clock. Keep the whole pass near the sequential-window
                    # budget it replaced (target_ms per candidate).
                    interleaved_kwargs: dict[str, object] = {
                        "max_total_ms": target_ms * len(members)
                    }
                    if interleaved_benchmark is interleaved_bench:
                        # the batched graph timer agrees its batch over the
                        # kernel's process group so every rank launches alike
                        interleaved_kwargs["process_group_name"] = (
                            self.kernel.env.process_group_name
                        )
                    benchmark_function = functools.partial(
                        interleaved_benchmark, **interleaved_kwargs
                    )
                if self.settings.autotune_progress_bar:
                    new_timings = benchmark_function(iterator, repeat=repeat, desc=desc)
                else:
                    new_timings = benchmark_function(iterator, repeat=repeat)
            else:
                iterator = [
                    make_rebenchmark_callable(
                        member,
                        benchmark_args,
                        clear_each_call=False,
                    )
                    for member, benchmark_args in zip(
                        members, benchmark_args_by_member, strict=True
                    )
                ]
                steady_bench = self._steady_bench()
                rep_ms = self._steady_rebenchmark_rep_ms(target_ms)
                warmup_ms = min(1000, rep_ms)
                new_timings = []
                for fn in iterator:
                    timing = steady_bench(
                        fn,
                        warmup=warmup_ms,
                        rep=rep_ms,
                        return_mode="median",
                        process_group_name=self.kernel.env.process_group_name,
                    )
                    if isinstance(timing, tuple):
                        timing = timing[0]
                    new_timings.append(float(timing))
        finally:
            for m in members:
                clear_jit_fast_path_caches(m.fn, self.log)
        if confirm_suspicious:
            new_timings = self._confirm_suspicious_rebenchmark_timings(
                members,
                new_timings,
                desc=desc,
            )
        resolved_timings, failure_statuses = self._resolve_isolated_rebenchmark_results(
            members, new_timings
        )
        resolved_timings, failure_statuses = sync_object(
            (resolved_timings, failure_statuses),
            process_group_name=self.kernel.env.process_group_name,
        )
        self._apply_rebenchmark_timings(
            members,
            resolved_timings,
            failure_statuses=failure_statuses,
            trace_results=new_timings,
        )

    def mirrored_rebenchmark(
        self,
        members: list[PopulationMember],
        *,
        desc: str,
        target_ms: float = _REBENCHMARK_TARGET_MS_DEFAULT,
    ) -> MirroredBenchmarkTrace:
        """Rebenchmark candidates with deterministic mirrored wall-time sweeps."""
        if len(members) < 2:
            return MirroredBenchmarkTrace([], [], [member.perf for member in members])
        if isinstance(self.benchmark_provider, MultiShapeBenchmarkProvider):
            raise exc.AutotuneError(
                "mirrored terminal refinement does not support multi-shape benchmarking"
            )
        if self.settings.autotune_benchmark_fn is not None:
            raise exc.AutotuneError(
                "mirrored terminal refinement requires the default benchmark function"
            )

        repeat_reference_perf_ms = self._repeat_reference_perf(members)
        repeat = self._repeat_for_target_ms(target_ms, repeat_reference_perf_ms)
        if (capstr := os.getenv("HELION_CAP_REBENCHMARK_REPEAT")) is not None:
            repeat = min(repeat, int(capstr))
            repeat = max(2, repeat - repeat % 2)
        else:
            repeat = max(2, repeat + repeat % 2)

        if self.benchmark_provider.mutated_arg_indices:
            benchmark_args = _clone_args(
                self.args,
                self.kernel.env.process_group_name,
                idx_to_clone=self.benchmark_provider.mutated_arg_indices,
            )
        else:
            benchmark_args = self.args

        def after_call(index: int) -> None:
            clear_jit_fast_path_caches(members[index].fn, self.log)

        try:
            trace = mirrored_bench_generic(
                [functools.partial(member.fn, *benchmark_args) for member in members],
                repeat=repeat,
                desc=desc if self.settings.autotune_progress_bar else None,
                after_call=after_call,
            )
            trace = dataclasses.replace(
                trace,
                target_ms=target_ms,
                repeat_reference_perf_ms=repeat_reference_perf_ms,
            )
            trace = sync_object(
                trace,
                process_group_name=self.kernel.env.process_group_name,
            )
            self._apply_rebenchmark_timings(members, trace.medians_ms)
            return trace
        finally:
            for member in members:
                clear_jit_fast_path_caches(member.fn, self.log)

    def _resolve_isolated_rebenchmark_results(
        self,
        members: Sequence[PopulationMember],
        results: Sequence[IsolatedBenchmarkTiming],
    ) -> tuple[list[float], list[Literal["error", "timeout"] | None]]:
        invalidate_failures = bool(
            getattr(
                getattr(self, "config_spec", None),
                "cute_flash_search_enabled",
                False,
            )
        )
        timings: list[float] = []
        failure_statuses: list[Literal["error", "timeout"] | None] = []
        for member, result in zip(members, results, strict=True):
            if isinstance(result, IsolatedBenchmarkFailure):
                if invalidate_failures:
                    timings.append(inf)
                    failure_statuses.append(result.status)
                elif result.status == "error":
                    # Preserve the pre-existing behavior for a sticky runtime
                    # error outside CuTe flash: remove it from the current
                    # ranking without changing its benchmark status.
                    timings.append(inf)
                    failure_statuses.append(None)
                else:
                    timings.append(member.perf)
                    failure_statuses.append(None)
            else:
                timings.append(member.perf if result is None else result)
                failure_statuses.append(None)
        return timings, failure_statuses

    def _apply_rebenchmark_timings(
        self,
        members: Sequence[PopulationMember],
        timings: Sequence[float],
        *,
        failure_statuses: Sequence[Literal["error", "timeout"] | None] | None = None,
        trace_results: Sequence[IsolatedBenchmarkTiming] | None = None,
    ) -> None:
        if failure_statuses is None:
            failure_statuses = [None] * len(members)
        if trace_results is None:
            trace_results = timings
        for member, timing, failure_status, trace_result in zip(
            members, timings, failure_statuses, trace_results, strict=True
        ):
            config_id = (
                self.log.register_config(member.config)
                if trace_result is not None and self.log.trace_enabled
                else None
            )
            if config_id is not None and trace_result is not None:
                trace_status = (
                    trace_result.status
                    if isinstance(trace_result, IsolatedBenchmarkFailure)
                    else failure_status
                )
                perf = timing if trace_status is None else inf
                self.log.record_trace_entry(
                    AutotuneLogEntry(
                        generation=self._autotune_metrics.num_generations,
                        status=trace_status
                        or ("ok" if math.isfinite(perf) else "error"),
                        perf_ms=(
                            perf
                            if self.performance_unit == "ms"
                            else self.benchmark_provider.raw_latency(member.config)
                            if isinstance(
                                self.benchmark_provider, MultiShapeBenchmarkProvider
                            )
                            else None
                        ),
                        compile_time=None,
                        config_id=config_id,
                        config=member.config,
                        objective=perf,
                        objective_unit=self.performance_unit,
                    ),
                    event="rebenchmark",
                )
            if failure_status is not None:
                continue
            member.perfs.append(timing)
            if timing < self.best_perf_so_far:
                self.best_perf_so_far = timing
        invalidated = self._invalidate_cute_flash_rebenchmark_failures(
            members, failure_statuses
        )
        refreshed = list(members)
        refreshed.extend(invalidated)
        self._refresh_benchmarked_members_after_rebenchmark(refreshed)
        if invalidated:
            self._recompute_cute_flash_best_perf(refreshed)
        _refresh_handoff(refreshed)

    def _invalidate_cute_flash_rebenchmark_failures(
        self,
        members: Sequence[PopulationMember],
        failure_statuses: Sequence[Literal["error", "timeout"] | None],
    ) -> list[PopulationMember]:
        failed_member_statuses = {
            id(member): status
            for member, status in zip(members, failure_statuses, strict=True)
            if status is not None
        }
        if not failed_member_statuses:
            return []

        backend = self.config_spec.backend
        failed_config_statuses = {
            member.config: status
            for member, status in zip(members, failure_statuses, strict=True)
            if status is not None
        }
        failed_source_statuses: dict[str, Literal["error", "timeout"]] = {}
        for member, status in zip(members, failure_statuses, strict=True):
            if status is None:
                continue
            source_hash = backend.generated_source_hash(member.fn)
            if source_hash is not None:
                existing = failed_source_statuses.get(source_hash)
                if existing != "timeout":
                    failed_source_statuses[source_hash] = status

        for source_hash in failed_source_statuses:
            self.benchmark_provider.invalidate_effective_source_hash(source_hash)

        candidates = [
            *members,
            *getattr(self, "population", ()),
            *getattr(self, "_compiler_seed_members", ()),
            *getattr(self, "_benchmarked_members", {}).values(),
            *getattr(self, "_pinned_finalist_members", {}).values(),
            *(getattr(self, "_terminal_refinement_members", None) or {}).values(),
        ]
        invalidated: list[PopulationMember] = []
        invalidated_configs = set(failed_config_statuses)
        seen: set[int] = set()
        for member in candidates:
            if id(member) in seen:
                continue
            seen.add(id(member))
            status = failed_member_statuses.get(id(member))
            if status is None:
                status = failed_config_statuses.get(member.config)
            if status is None and failed_source_statuses:
                source_hash = backend.generated_source_hash(member.fn)
                if source_hash is not None:
                    status = failed_source_statuses.get(source_hash)
            if status is None:
                continue
            member.perfs[:] = [inf]
            member.status = status
            invalidated.append(member)
            invalidated_configs.add(member.config)
        self._invalidate_rebenchmark_training_targets(
            invalidated_configs,
            set(failed_source_statuses),
        )
        return invalidated

    def _invalidate_rebenchmark_training_targets(
        self,
        failed_configs: set[Config],
        failed_source_hashes: set[str],
    ) -> None:
        """Let surrogate searches discard targets for quarantined CuTe sources."""
        return None

    def _recompute_cute_flash_best_perf(
        self, members: Sequence[PopulationMember]
    ) -> None:
        candidates = [
            *members,
            *getattr(self, "population", ()),
            *getattr(self, "_compiler_seed_members", ()),
            *getattr(self, "_benchmarked_members", {}).values(),
            *getattr(self, "_pinned_finalist_members", {}).values(),
            *(getattr(self, "_terminal_refinement_members", None) or {}).values(),
        ]
        self.best_perf_so_far = min(
            (
                member.perf
                for member in candidates
                if member.perfs and math.isfinite(member.perf)
            ),
            default=inf,
        )

    def _confirm_suspicious_rebenchmark_timings(
        self,
        members: list[PopulationMember],
        timings: list[float],
        *,
        desc: str,
    ) -> list[IsolatedBenchmarkTiming]:
        updated: list[IsolatedBenchmarkTiming] = list(timings)
        ratio = self.settings.get_suspicious_rebenchmark_ratio()
        if ratio is None or ratio <= 0:
            return updated

        suspicious = [
            i
            for i, (member, timing) in enumerate(zip(members, timings, strict=True))
            if math.isfinite(timing)
            and math.isfinite(member.perf)
            and timing < ratio * member.perf
            and member.perf - timing > _SUSPICIOUS_REBENCHMARK_MIN_DELTA_MS
        ]
        if not suspicious:
            return updated

        try:
            confirmed = self.benchmark_provider.benchmark_isolated(
                [members[i].fn for i in suspicious],
                warmup=_SUSPICIOUS_REBENCHMARK_WARMUP,
                rep=_SUSPICIOUS_REBENCHMARK_REP,
                desc=f"{desc}: confirming suspicious timings",
            )
        except BenchmarkWorkerUnkillable as error:
            self._record_unkillable([members[i] for i in suspicious], error)
            raise
        if confirmed is None:
            return updated

        for i, timing in zip(suspicious, confirmed, strict=True):
            if timing is not None:
                updated[i] = timing
        return updated

    def rebenchmark_population(
        self,
        members: list[PopulationMember] | None = None,
        *,
        desc: str = "Rebenchmarking",
    ) -> None:
        """
        Re-benchmark the entire population to avoid outliers.

        Args:
            members: The list of population members to rebenchmark.
            desc: Description for the progress bar.
        """
        if members is None:
            members = self.population
        self.rebenchmark([p for p in members if self.should_rebenchmark(p)], desc=desc)

    def statistics(self) -> str:
        """
        Generate statistics for the current population.

        Returns:
            A string summarizing the population performance.
        """
        return population_statistics(self.population)

    def run_finishing_phase(
        self, best: PopulationMember, rounds: int
    ) -> PopulationMember:
        """
        Run finishing rounds to minimize the configuration by resetting attributes to defaults.

        This phase attempts to simplify the found configuration by resetting as many
        attributes as possible to their default values, while ensuring performance
        does not get worse. It's similar to pattern search but mutations only move
        towards the default configuration.

        Args:
            best: The best configuration found during the main search.
            rounds: Number of finishing rounds to run. If 0, returns best unchanged.

        Returns:
            The minimized configuration (may be the same as input if no simplifications helped).
        """
        if rounds <= 0:
            self._selected_member = best
            return best

        self.log(f"Starting finishing phase with {rounds} rounds")
        default_flat = self.config_gen.default_flat()
        current = best

        for round_num in self._budgeted_range(1, rounds + 1):
            simplified = False
            candidates: list[PopulationMember] = [current]

            # Generate candidates by resetting each parameter to its default
            for i in range(len(current.flat_values)):
                if current.flat_values[i] != default_flat[i]:
                    # Create a new config with this parameter reset to default
                    new_flat = [*current.flat_values]
                    new_flat[i] = default_flat[i]
                    candidate = self.make_unbenchmarked(new_flat)
                    # Only add if valid and produces a different config
                    if candidate is not None and candidate.config != current.config:
                        candidates.append(candidate)

            if len(candidates) <= 1:
                self.log(f"Finishing round {round_num}: no more parameters to simplify")
                break

            # Benchmark the candidates
            unbenchmarked = [m for m in candidates if len(m.perfs) == 0]
            if unbenchmarked:
                self.set_generation(self._autotune_metrics.num_generations + 1)
                self.benchmark_population(
                    unbenchmarked, desc=f"Finishing round {round_num}"
                )

            # Rebenchmark all candidates (including current) for fair comparison
            self.rebenchmark(candidates, desc=f"Finishing round {round_num}: verifying")

            # Log performance of each candidate at debug level
            current_perf = current.perf
            for candidate in candidates[1:]:
                delta = candidate.perf - current_perf
                delta_pct = (delta / current_perf * 100) if current_perf != 0 else 0
                status = "ok" if candidate.perf <= current_perf else "worse"
                self.log.debug(
                    f"  reset to {candidate.config}: "
                    f"{self.format_performance(candidate.perf)} "
                    f"(delta={delta:+.4f}{self.performance_suffix}, "
                    f"{delta_pct:+.1f}%) [{status}]"
                )

            # Collect all single-attribute resets that maintained performance
            good_candidates = [
                c
                for c in candidates[1:]
                if math.isfinite(c.perf) and c.perf <= current.perf
            ]

            if len(good_candidates) > 1:
                # Try combining all good single-attribute resets at once
                combined_flat = [*current.flat_values]
                for c in good_candidates:
                    for i in range(len(combined_flat)):
                        if c.flat_values[i] != current.flat_values[i]:
                            combined_flat[i] = c.flat_values[i]
                combined = self.make_unbenchmarked(combined_flat)
                if combined is not None and combined.config != current.config:
                    self.benchmark_population(
                        [combined],
                        desc=f"Finishing round {round_num}: combined",
                    )
                    self.rebenchmark(
                        [current, combined],
                        desc=f"Finishing round {round_num}: verifying combined",
                    )
                    if math.isfinite(combined.perf) and combined.perf <= current.perf:
                        current = combined
                        simplified = True

            if not simplified and good_candidates:
                current = good_candidates[0]
                simplified = True

            if simplified:
                self.log(
                    f"Finishing round {round_num}: simplified to {current.config}, "
                    f"perf={self.format_performance(current.perf)}"
                )
            else:
                self.log(
                    f"Finishing round {round_num}: no simplification maintained performance, stopping early"
                )
                break

        # Multi-shape winners must stay explicit: minimizing can collapse an
        # optional tuned reset and a compiler-promoted default to the same key.
        minimal_config = (
            current.config
            if isinstance(self.args, _MultiShapeAutotuneArgs)
            else current.config.minimize(self.config_spec)
        )
        current = PopulationMember(
            fn=current.fn,
            perfs=current.perfs,
            flat_values=self.config_gen.flatten(minimal_config),
            config=minimal_config,
            status=current.status,
            compile_time=current.compile_time,
        )
        self._selected_member = current
        self.log(f"Finishing phase complete: final config={current.config}")
        return current

    def _final_pick_supported(self) -> bool:
        """True only on Pallas/TPU; final-pick is untested on other backends."""
        return self.config_spec.backend_name == "pallas"

    def run_final_pick_verification(
        self,
        best: PopulationMember,
        top_k: int | None = None,
    ) -> PopulationMember:
        """Re-benchmark the top-``top_k`` candidates once and re-pick the fastest.

        Beats the noisy single search-time median.  Compiler seeds are merged in.
        Knob: ``HELION_AUTOTUNE_FINAL_PICK_TOP_K`` (10).
        """
        if top_k is None:
            top_k = max(0, _env_get_int("HELION_AUTOTUNE_FINAL_PICK_TOP_K", 10))
        if top_k <= 1:
            return best

        # Candidates: ``best`` first, then the finite population + compiler seeds
        # (so a search-pruned seed still competes), ranked by perf and deduped by
        # identity, capped at top_k.  getattr covers ``__new__`` test scaffolds.
        seed_members = getattr(self, "_compiler_seed_members", []) or []
        ranked = sorted(
            (m for m in (*self.population, *seed_members) if math.isfinite(m.perf)),
            key=performance,
        )
        candidates: list[PopulationMember] = []
        seen: set[int] = set()
        for member in (best, *ranked):
            if id(member) in seen:
                continue
            seen.add(id(member))
            candidates.append(member)
            if len(candidates) >= top_k:
                break
        if len(candidates) < 2:
            return best

        # TPU/Pallas: re-rank by per-call on-device µs when available; else fall
        # back to the absolute-median rebench.
        device_micros_bench = self._resolve_device_micros_paired_bench()
        if device_micros_bench is not None:
            return self._run_final_pick_verification_device_micros(
                best, candidates, device_micros_bench=device_micros_bench
            )
        return self._rebench_and_pick(best, candidates)

    def _rebench_and_pick(
        self, best: PopulationMember, candidates: list[PopulationMember]
    ) -> PopulationMember:
        """Re-benchmark ``candidates`` by absolute median and return the fastest."""
        self.rebenchmark(candidates, desc="Final-pick verification")
        best_member = min(candidates, key=performance)
        if not math.isfinite(best_member.perf):
            return best
        if best_member is not best:
            self.log(
                f"Final-pick re-picked {best_member.config} "
                f"({self.format_performance(best_member.perf)}) over {best.config}"
            )
        self.best_perf_so_far = min(self.best_perf_so_far, best_member.perf)
        return best_member

    def _record_unkillable(
        self, members: list[PopulationMember], error: BenchmarkWorkerUnkillable
    ) -> None:
        """Remember the candidate whose isolated worker could not be reaped."""
        if error.fn_index is not None and 0 <= error.fn_index < len(members):
            self._unkillable_configs.add(members[error.fn_index].config)

    def _finalize(self) -> Config:
        """Finishing phase, terminal refinement, final selection (or the
        single-pass final verification) and the final-pick re-rank.

        Shared tail of every search's ``_autotune``; the final-pick re-rank
        runs only on TPU/Pallas (see ``_final_pick_supported``).
        """
        best = self.best
        try:
            if self._final_selection_enabled():
                # The finishing phase and the terminal refinement generate
                # candidates and compare them with the search's short windows;
                # their picks join the shortlist of the final selection, which
                # runs last so the returned config is the one that won the
                # harness-grade shootout rather than a later short-window pick.
                # They spend the search phase's share of the budget: the
                # reserve kept for the final selection opens only once they
                # are done.
                best = self.run_finishing_phase(best, self.finishing_rounds)
                best = self.run_terminal_refinement(best)
                self._budget_reserve_released = True
                best = self.final_rebenchmark_best(best)
                self._selected_member = best
            else:
                self._budget_reserve_released = True
                best = self.final_rebenchmark_best(best)
                best = self.run_finishing_phase(best, self.finishing_rounds)
                best = self.run_terminal_refinement(best)
            if self._final_pick_supported():
                best = self.run_final_pick_verification(best)
        except BenchmarkWorkerUnkillable as error:
            # A benchmark worker survived SIGKILL (a hung kernel), so no further
            # worker may be launched and the verification phases cannot run.
            # Keep the best config the search measured instead of discarding
            # the search, except the candidate that hung the worker.
            live = [
                member
                for member in (best, self.best, *self.population)
                if math.isfinite(member.perf)
                and member.config not in self._unkillable_configs
            ]
            if not live:
                raise
            best = min(live, key=performance)
            self.log.warning(
                f"Final verification abandoned; keeping {best.config} "
                f"({self.format_performance(best.perf)}): {error}"
            )
        self.best = best
        return best.config

    def run_terminal_refinement(self, best: PopulationMember) -> PopulationMember:
        """Run an optional backend/search-specific post-search refinement."""
        return best

    def _resolve_device_micros_paired_bench(
        self,
    ) -> Callable[..., list[tuple[float, float]]] | None:
        """Paired device-µs bench from the backend, or None.

        Pallas/TPU returns a ``jax.profiler`` closure (per-call on-chip µs) when
        ``static_shapes`` is on and ``HELION_AUTOTUNE_PALLAS_RANK_BY=device_time`` (the
        default); other backends and the ``wall_time`` opt-out return None.
        """
        # settings/config_spec are unset on the minimal final-pick test scaffolds;
        # real searches always have them.
        settings = getattr(self, "settings", None)
        config_spec = getattr(self, "config_spec", None)
        if (
            isinstance(
                getattr(self, "benchmark_provider", None),
                MultiShapeBenchmarkProvider,
            )
            or settings is None
            or config_spec is None
            or not settings.static_shapes
        ):
            return None
        return config_spec.backend.get_paired_device_micros_bench()

    def _run_final_pick_verification_device_micros(
        self,
        best: PopulationMember,
        candidates: list[PopulationMember],
        *,
        device_micros_bench: Callable[..., list[tuple[float, float]]],
    ) -> PopulationMember:
        """Re-rank the cohort by per-call on-chip µs instead of wall-clock.

        ``device_micros_bench`` returns ``(device_micros, delta-vs-best)`` per candidate;
        per-call device µs isn't masked by the ~125µs dispatch overhead. Picks the
        smallest delta (tie-broken by absolute device µs). Device µs is not folded
        into ``perfs`` (those are wall-clock ms). Falls back to the absolute-median
        rebench on any error.
        """
        if len(self.benchmark_provider.mutated_arg_indices) > 0:
            benchmark_args = _clone_args(
                self.args,
                self.kernel.env.process_group_name,
                idx_to_clone=self.benchmark_provider.mutated_arg_indices,
            )
        else:
            benchmark_args = self.args
        candidate_fns: list[Callable[..., object]] = [
            functools.partial(member.fn, *benchmark_args) for member in candidates
        ]
        reference_fn: Callable[..., object] = functools.partial(
            best.fn, *benchmark_args
        )
        desc = (
            "Final-pick verification device_micros"
            if self.settings.autotune_progress_bar
            else None
        )
        try:
            results = device_micros_bench(candidate_fns, reference_fn, desc=desc)
        except Exception as err:
            self.log(f"Device-µs re-rank failed ({err!r}); falling back to rebench.")
            return self._rebench_and_pick(best, candidates)

        # results[i] == (absolute device µs, paired delta vs best).
        device_micros_by_slot = [device_micros for device_micros, _ in results]
        delta_by_slot = [delta for _, delta in results]
        if not any(math.isfinite(u) and math.isfinite(d) for u, d in results):
            self.log(
                "Device-µs re-rank got no finite readings; falling back to rebench."
            )
            return self._rebench_and_pick(best, candidates)

        def _device_key(slot: int) -> tuple[float, float]:
            delta, device_micros = delta_by_slot[slot], device_micros_by_slot[slot]
            if not math.isfinite(delta) or not math.isfinite(device_micros):
                return (inf, inf)
            return (delta, device_micros)

        best_slot = min(range(len(candidates)), key=_device_key)
        if not math.isfinite(delta_by_slot[best_slot]):
            return best
        best_member = candidates[best_slot]

        # Every delta is measured against a fresh run of ``best``. Sampling
        # noise can make the incumbent's own pair nonzero, so the smallest
        # positive delta may belong to another candidate. Keep the incumbent
        # unless at least one paired measurement is actually faster.
        if best_member is not best and delta_by_slot[best_slot] >= 0:
            return best

        if best_member is not best:
            self.log(
                f"Final-pick re-picked {best_member.config} (delta "
                f"{delta_by_slot[best_slot]:+.3f}µs, absolute "
                f"{device_micros_by_slot[best_slot]:.3f}µs) over {best.config}"
            )
        return best_member


def population_statistics(population: list[PopulationMember]) -> str:
    """
    Create a summary of the population performance.

    Args:
        population: The population of configurations.

    Returns:
        A string summarizing the performance of the population.
    """
    population = sorted(population, key=performance)
    status_counts: collections.Counter[str] = collections.Counter()
    working: list[PopulationMember] = []
    for member in population:
        status = member.status
        if math.isfinite(member.perf):
            working.append(member)
            if status not in {"ok", "error", "timeout"}:
                status = "ok"
        else:
            if status not in {"error", "timeout"}:
                status = "error"
        if status == "timeout":
            status_counts["timeout"] += 1
        elif status == "error":
            status_counts["error"] += 1
        else:
            status_counts["ok"] += 1
    if len(working) == 0:
        raise exc.NoConfigFound
    count_parts = [
        f"{label}={status_counts[label]}"
        for label in ("error", "timeout", "ok")
        if status_counts[label]
    ]
    perf_parts = (
        f"min={working[0].perf:.4f}",
        f"mid={working[len(working) // 2].perf:.4f}",
        f"max={working[-1].perf:.4f}",
    )
    lines = [f"{' '.join(count_parts)} | {' '.join(perf_parts)}", "best:"]
    best_config = dict(population[0].config)
    key_width = max((len(k) for k in best_config), default=0)
    lines.extend(f"  {k:<{key_width}} = {v!r}" for k, v in best_config.items())
    return "\n" + "\n".join(lines)
