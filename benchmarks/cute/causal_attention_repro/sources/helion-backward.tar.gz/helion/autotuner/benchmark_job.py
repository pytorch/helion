"""Picklable benchmark job executed inside a ``BenchmarkWorker``."""

from __future__ import annotations

import dataclasses
import functools
from typing import TYPE_CHECKING
from typing import cast

import torch

from .accuracy import assert_close
from .benchmarking import do_bench
from .benchmarking import do_bench_generic
from .benchmarking import synchronize_device
from .kernel_args import load_private_kernel_args
from .kernel_args import load_trusted_kernel_args
from .logger import capture_output
from .precompile_future import _load_compiled_fn
from .precompile_future import _unload_compiled_fn

if TYPE_CHECKING:
    from ..runtime.kernel import CompiledConfig
    from .precompile_future import SerializedCompiledFunction


class CompiledFunctionLoadError(Exception):
    """The benchmark worker could not reconstruct a generated wrapper."""


def _load_compiled_fn_for_worker(
    fn_spec: SerializedCompiledFunction,
) -> CompiledConfig:
    try:
        return _load_compiled_fn(fn_spec)
    except Exception as error:
        raise CompiledFunctionLoadError(
            f"{type(error).__qualname__}: {error}"
        ) from error


@dataclasses.dataclass
class BenchmarkJob:
    fn_spec: SerializedCompiledFunction
    args_path: str
    warmup: int = 1
    rep: int = 50
    use_wall_clock: bool = False
    fixed_repetitions: int | None = None
    probe_long_kernel: bool = False
    # Finalist slot whose private argument copies this job reads (None shares
    # the cached arguments with every other job).
    args_slot: int | None = None

    def __call__(self) -> float:
        # Subprocess inherits parent stderr; capture so Triton runtime
        # diagnostics don't leak to the user's terminal.
        with capture_output():
            fn = _load_compiled_fn_for_worker(self.fn_spec)
            try:
                if self.args_slot is None:
                    args = load_trusted_kernel_args(self.args_path)
                else:
                    args = load_private_kernel_args(self.args_path, self.args_slot)
                bench = do_bench_generic if self.use_wall_clock else do_bench
                # return_mode="median" guarantees a float return.
                benchmark_fn = functools.partial(fn, *args)
                result = bench(
                    benchmark_fn,
                    return_mode="median",
                    warmup=self.warmup,
                    rep=self.rep,
                    fixed_repetitions=self.fixed_repetitions,
                    probe_long_kernel=self.probe_long_kernel,
                )
                return cast(
                    "float",
                    result,
                )
            finally:
                _unload_compiled_fn(fn)


@functools.cache
def _load_trusted_baseline_output(path: str) -> object:
    return torch.load(path, weights_only=False)


@dataclasses.dataclass(frozen=True)
class AccuracyCheckResult:
    ok: bool
    message: str = ""


@dataclasses.dataclass
class AccuracyCheckJob:
    fn_spec: SerializedCompiledFunction
    args_path: str
    baseline_path: str
    atol: float
    rtol: float
    scale_atol: bool = False

    def __call__(self) -> AccuracyCheckResult:
        # Keep compile/launch diagnostics out of the autotune progress stream.
        with capture_output():
            fn = _load_compiled_fn_for_worker(self.fn_spec)
            try:
                args = load_trusted_kernel_args(self.args_path)
                baseline_output = _load_trusted_baseline_output(self.baseline_path)
                output = fn(*args)
                synchronize_device()
            finally:
                _unload_compiled_fn(fn)

        try:
            assert_close(
                output,
                baseline_output,
                atol=self.atol,
                rtol=self.rtol,
                scale_atol_by_expected_rms=self.scale_atol,
            )
        except AssertionError as e:
            return AccuracyCheckResult(ok=False, message=str(e))
        return AccuracyCheckResult(ok=True)
