from __future__ import annotations

import abc
import ast
import dataclasses
import math
from typing import TYPE_CHECKING
from typing import ClassVar
from typing import NamedTuple
from typing import cast

import sympy
import torch

from .. import exc
from .ast_extension import ExtendedAST
from .ast_extension import create
from .ast_extension import expr_from_string
from .ast_extension import statement_from_string
from .compile_environment import CompileEnvironment
from .cute.cutedsl_compat import emit_pipeline_advance
from .cute.device_state import Tcgen05GroupedSchedulerMode
from .cute.strategies import TCGEN05_BATCH_RASTER_DEFAULT
from .cute.strategies import TCGEN05_BATCH_RASTER_SLOWEST
from .cute.strategies import TCGEN05_L2_SWIZZLE_SIZE_DEFAULT
from .cute.strategies import batch_raster_from_config
from .cute.strategies import l2_swizzle_size_from_config
from .cute.tcgen05_constants import TCGEN05_GROUPED_STATIC_SPECIALIZATION_MAX_GROUPS
from .cute.tcgen05_constants import TCGEN05_GROUPED_WORKLIST_MAILBOX_FIELD_COUNT
from .cute.tcgen05_constants import TCGEN05_SCHED_CONSUMER_WAIT_MODE_CONFIG_KEY
from .cute.tcgen05_constants import TCGEN05_SCHED_CONSUMER_WAIT_MODE_NORMAL
from .cute.tcgen05_constants import TCGEN05_SCHED_CONSUMER_WAIT_MODE_WARP_LEADER
from .cute.tcgen05_constants import TCGEN05_SCHED_STAGE_COUNT_CONFIG_KEY
from .cute.tcgen05_constants import TCGEN05_TWO_CTA_MAX_K_TILES
from .cute.tcgen05_constants import Tcgen05GroupedRuntimeTileField
from .device_function import DeviceFunction
from .device_function import TensorArg
from .host_function import HostFunction
from .host_function import NoCurrentFunction


def typed_program_id(dim: int = 0) -> str:
    """Generate backend-specific program ID expression.

    Triton uses tl.program_id(). CuTe uses block_idx() as the virtual program ID.
    """
    env = CompileEnvironment.current()
    return env.backend.program_id_expr(dim, index_dtype=env.index_type())


def _stmt_name_uses(stmt: ast.AST) -> tuple[set[str], set[str]]:
    """Return ``(reads, writes)`` for the names referenced in ``stmt``."""
    reads: set[str] = set()
    writes: set[str] = set()
    for node in ast.walk(stmt):
        if isinstance(node, ast.Name):
            if isinstance(node.ctx, ast.Store):
                writes.add(node.id)
            else:
                reads.add(node.id)
        if isinstance(node, ast.AugAssign) and isinstance(node.target, ast.Name):
            reads.add(node.target.id)
    return reads, writes


def _prune_dead_side_effect_free_generated_assignments(
    statements: list[ast.stmt], live_out: set[str]
) -> tuple[list[ast.stmt], set[str]]:
    """Prune dead pure name assignments and return their live-in names.

    ``statements`` must be straight-line assignments with side-effect-free RHSs.
    Compiler-generated reads from immutable metadata tables satisfy that contract.
    """
    live = set(live_out)
    kept: list[ast.stmt] = []
    for stmt in reversed(statements):
        assert (
            isinstance(stmt, ast.Assign)
            and len(stmt.targets) == 1
            and isinstance(stmt.targets[0], ast.Name)
        ), "dead generated-assignment pruning requires simple name assignments"
        target = stmt.targets[0].id
        reads, writes = _stmt_name_uses(stmt)
        assert writes == {target}
        if target not in live:
            continue
        kept.append(stmt)
        live.remove(target)
        live.update(reads)
    kept.reverse()
    return kept, live


def _literal_mailbox_access_fields(
    node: ast.AST, mailbox_name: str
) -> tuple[set[int], set[int]]:
    """Return generated literal mailbox fields read and written below ``node``.

    Reject unexpected indexing so producer publication cannot omit a field.
    """
    accesses = [
        access
        for access in ast.walk(node)
        if isinstance(access, ast.Subscript)
        and isinstance(access.value, ast.Name)
        and access.value.id == mailbox_name
    ]
    direct_mailbox_names = {id(access.value) for access in accesses}
    snapshot_reads: set[int] = set()
    for call in ast.walk(node):
        if not (
            isinstance(call, ast.Call)
            and isinstance(call.func, ast.Name)
            and call.func.id == "_cute_inline_asm_elementwise"
        ):
            continue
        # Selected-grouped mailboxes are unstaged. Recognize only our exact
        # non-speculatable literal-field load, not arbitrary pointer escapes,
        # inline assembly, or dynamic offsets. This preserves the publication
        # omission proof when the consumer uses a leader-owned snapshot.
        for pointer in ast.walk(call):
            if not (
                isinstance(pointer, ast.BinOp)
                and isinstance(pointer.op, ast.Add)
                and isinstance(pointer.left, ast.Attribute)
                and pointer.left.attr == "iterator"
                and isinstance(pointer.left.value, ast.Name)
                and pointer.left.value.id == mailbox_name
                and isinstance(pointer.right, ast.Call)
                and len(pointer.right.args) == 1
                and isinstance(pointer.right.args[0], ast.Constant)
                and type(pointer.right.args[0].value) is int
            ):
                continue
            field = cast("int", pointer.right.args[0].value)
            expected = _sched_mailbox_load_expr(mailbox_name, field)
            if ast.dump(call) == ast.dump(expected):
                snapshot_reads.add(field)
                direct_mailbox_names.add(id(pointer.left.value))
    assert all(
        id(name) in direct_mailbox_names
        for name in ast.walk(node)
        if isinstance(name, ast.Name)
        and name.id == mailbox_name
        and isinstance(name.ctx, ast.Load)
    ), "generated mailbox use must be a direct literal field access"

    reads: set[int] = snapshot_reads
    writes: set[int] = set()
    for access in accesses:
        field_expr = access.slice
        if isinstance(field_expr, ast.Tuple):
            assert field_expr.elts
            field_expr = field_expr.elts[0]
        assert (
            isinstance(field_expr, ast.Call)
            and isinstance(field_expr.func, ast.Attribute)
            and isinstance(field_expr.func.value, ast.Name)
            and field_expr.func.value.id == "cutlass"
            and field_expr.func.attr == "Int32"
            and len(field_expr.args) == 1
            and not field_expr.keywords
            and isinstance(field_expr.args[0], ast.Constant)
            and type(field_expr.args[0].value) is int
        ), "generated mailbox accesses require a literal Int32 field"
        field = cast("int", field_expr.args[0].value)
        if isinstance(access.ctx, ast.Store):
            writes.add(field)
        else:
            assert isinstance(access.ctx, ast.Load)
            reads.add(field)
    return reads, writes


def _clone_ast_value(value: object) -> object:
    if isinstance(value, list):
        return [_clone_ast_value(item) for item in value]
    if isinstance(value, tuple):
        return tuple(_clone_ast_value(item) for item in value)
    if isinstance(value, ast.AST):
        from .tile_dependency import TILE_DEPENDENCY_SITE_ID_ATTR

        fields = {
            field: _clone_ast_value(getattr(value, field)) for field in value._fields
        }
        if isinstance(value, ExtendedAST):
            cloned = value.copy(**fields)
        else:
            cloned = ast.copy_location(type(value)(**fields), value)
        if (site_id := getattr(value, TILE_DEPENDENCY_SITE_ID_ATTR, None)) is not None:
            setattr(cloned, TILE_DEPENDENCY_SITE_ID_ATTR, site_id)
        return cloned
    return value


def _clone_stmt(stmt: ast.stmt) -> ast.stmt:
    return cast("ast.stmt", _clone_ast_value(stmt))


_TCGEN05_WORK_TILE_MAILBOX_VALID = 3


_SCHED_MAILBOX_LOAD_ASM = (
    "{ .reg .pred leader; mov.u32 $0, 0; "
    "setp.eq.u32 leader, $2, 0; @leader ld.volatile.shared.u32 $0, [$1]; }"
)


def _sched_mailbox_load_expr(
    mailbox: str, field: int, stage: str | None = None
) -> ast.AST:
    tensor = mailbox if stage is None else f"{mailbox}[None, {stage}]"
    return expr_from_string(
        f"_cute_inline_asm_elementwise((("
        f"{tensor}.iterator + cutlass.Int32({field})).toint(), "
        "cute.arch.lane_idx()), asm={assembly}, "
        "constraints={constraints}, dtype=cutlass.Int32, is_pure=False)",
        assembly=create(ast.Constant, value=_SCHED_MAILBOX_LOAD_ASM),
        # Zero initialization precedes both inputs' uses: the output must not
        # overlap either the address or lane input register.
        constraints=create(ast.Constant, value="=&r,r,r,~{memory}"),
    )


@dataclasses.dataclass(frozen=True)
class _SchedMailboxSnapshot:
    """Warp-uniform registers loaded only by the lane that acquired the stage."""

    valid: str
    fields: dict[int, str]

    @classmethod
    def create(
        cls, device_function: DeviceFunction, prefix: str, fields: tuple[int, ...]
    ) -> _SchedMailboxSnapshot | None:
        if (
            device_function.config.get(
                TCGEN05_SCHED_CONSUMER_WAIT_MODE_CONFIG_KEY,
                TCGEN05_SCHED_CONSUMER_WAIT_MODE_NORMAL,
            )
            != TCGEN05_SCHED_CONSUMER_WAIT_MODE_WARP_LEADER
        ):
            # Do not even allocate names in normal mode: its generated code
            # and producer/publication protocol must remain unchanged.
            return None
        return cls(
            device_function.new_var(f"{prefix}_mailbox_valid"),
            {
                field: device_function.new_var(f"{prefix}_mailbox_{field}")
                for field in fields
            },
        )

    def read_block(
        self, mailbox: str, valid_var: str, valid_field: int, stage: str | None
    ) -> list[ast.stmt]:
        def read(field: int, name: str) -> list[ast.stmt]:
            return [
                statement_from_string(
                    f"{name} = {{load}}",
                    load=_sched_mailbox_load_expr(mailbox, field, stage),
                ),
                statement_from_string(f"{name} = cute.arch.shuffle_sync({name}, 0)"),
            ]

        # Selected-grouped sentinels initialize only valid, including on an
        # empty work stream. Never read their uninitialized payload fields.
        result = read(valid_field, self.valid)
        result.append(
            statement_from_string(f"{valid_var} = {self.valid} != cutlass.Int32(0)")
        )
        if self.fields:
            result.extend(
                statement_from_string(f"{name} = cutlass.Int32(0)")
                for name in self.fields.values()
            )
            result.append(
                create(
                    ast.If,
                    test=expr_from_string(valid_var),
                    body=[
                        stmt
                        for field, name in self.fields.items()
                        for stmt in read(field, name)
                    ],
                    orelse=[],
                )
            )
        return result


def _build_sched_pipeline_consumer_wait_block(
    *,
    sched_pipeline: str,
    sched_consumer_state: str,
    work_tile_smem: str,
    valid_var: str,
    valid_slot_index: int = _TCGEN05_WORK_TILE_MAILBOX_VALID,
    work_tile_stage_index: str | None = None,
    snapshot: _SchedMailboxSnapshot | None = None,
) -> list[ast.stmt]:
    """Emit the consumer-side wait block for the ``ROLE_LOCAL_WITH_SCHEDULER``
    sched_pipeline: ``consumer_wait`` → ``fence_view_async_shared``
    → ``sync_warp`` → read the work-tile valid flag.

    Shared between ``_build_role_local_while_with_scheduler`` (the
    TMA-load / MMA-exec / epi consumer roles) and
    ``_build_c_input_warp_role_local_while`` (the C-input warp role
    introduced in ``cute_plan.md`` §7.5.3.2's producer-body split).
    Each call site supplies a fresh ``valid_var`` so the per-role
    valid flag has its own SMEM name; the other three arguments
    are pipeline-level and identical across roles.

    ``mbarrier.wait`` PTX stalls the issuing thread until the phase
    flips, so all 32 threads in the warp can call ``consumer_wait``
    safely (no lane-0 gate needed). The async-shared fence
    serializes the scheduler-warp's SMEM writes against the
    consumer's proxy view of SMEM, and ``sync_warp`` keeps the warp
    lanes consistent before they read the valid flag from SMEM.

    Each call returns *fresh* AST nodes — caller-supplied factory
    pattern (insertion-point-specific copies of the same shape)
    so downstream AST passes are not corrupted by sharing nodes
    across multiple parents.

    Diagnostic ``tcgen05_sched_consumer_wait_mode="warp_leader"``
    instead gates ``consumer_wait`` to lane 0 and reconverges the warp
    before the async-shared fence. Only that acquiring lane may read the
    mailbox; a valid-first register snapshot broadcasts those values to the
    warp. Explicit predication, volatility and a memory clobber prevent LLVM
    from speculating shared loads into non-acquiring lanes or past release.
    """
    try:
        wait_mode = DeviceFunction.current().config.get(
            TCGEN05_SCHED_CONSUMER_WAIT_MODE_CONFIG_KEY,
            TCGEN05_SCHED_CONSUMER_WAIT_MODE_NORMAL,
        )
    except NoCurrentFunction:
        wait_mode = TCGEN05_SCHED_CONSUMER_WAIT_MODE_NORMAL
    valid_slot = (
        f"{work_tile_smem}[cutlass.Int32({valid_slot_index})]"
        if work_tile_stage_index is None
        else (
            f"{work_tile_smem}[cutlass.Int32({valid_slot_index}), "
            f"{work_tile_stage_index}]"
        )
    )
    if wait_mode == TCGEN05_SCHED_CONSUMER_WAIT_MODE_WARP_LEADER:
        assert snapshot is not None
        return [
            create(
                ast.If,
                test=expr_from_string("cute.arch.lane_idx() == cutlass.Int32(0)"),
                body=[
                    statement_from_string(
                        f"{sched_pipeline}.consumer_wait({sched_consumer_state})"
                    ),
                ],
                orelse=[],
            ),
            statement_from_string("cute.arch.sync_warp()"),
            statement_from_string("cute.arch.fence_view_async_shared()"),
            statement_from_string("cute.arch.sync_warp()"),
            *snapshot.read_block(
                work_tile_smem, valid_var, valid_slot_index, work_tile_stage_index
            ),
        ]
    return [
        statement_from_string(
            f"{sched_pipeline}.consumer_wait({sched_consumer_state})"
        ),
        statement_from_string("cute.arch.fence_view_async_shared()"),
        statement_from_string("cute.arch.sync_warp()"),
        statement_from_string(f"{valid_var} = {valid_slot} != cutlass.Int32(0)"),
    ]


def _build_sched_pipeline_consumer_release_block(
    *,
    sched_pipeline: str,
    sched_consumer_state: str,
) -> list[ast.stmt]:
    """Emit the consumer-side release block for the
    ``ROLE_LOCAL_WITH_SCHEDULER`` sched_pipeline: whole-warp
    ``consumer_release`` → ``advance_state`` → ``sync_warp``.

    Companion to ``_build_sched_pipeline_consumer_wait_block``.
    Every lane reads scheduler metadata, so every lane must release the
    stage after its own reads. A lane-0 arrival alone does not order the
    other lanes' shared-memory reads before the producer reuses the stage.
    The matching setup counts 32 arrivals per consumer warp, including
    cluster-routed releases. The ``sync_warp`` after the advance keeps
    the register-resident consumer state consistent; it is not the
    shared-memory lifetime handshake.
    """
    return [
        statement_from_string(
            f"{sched_pipeline}.consumer_release({sched_consumer_state})"
        ),
        statement_from_string(emit_pipeline_advance(sched_consumer_state)),
        statement_from_string("cute.arch.sync_warp()"),
    ]


_TCGEN05_GROUPED_SELECTED_MAILBOX_CTA_M = 0
_TCGEN05_GROUPED_SELECTED_MAILBOX_CTA_N = 1
_TCGEN05_GROUPED_SELECTED_MAILBOX_VALID = 2
_TCGEN05_GROUPED_SELECTED_MAILBOX_METADATA_IDX = 3
_TCGEN05_GROUPED_SELECTED_MAILBOX_GROUP_IDX = 4
_TCGEN05_GROUPED_SELECTED_MAILBOX_PROBLEM_M = 5
_TCGEN05_GROUPED_SELECTED_MAILBOX_PROBLEM_N = 6
_TCGEN05_GROUPED_SELECTED_MAILBOX_PROBLEM_K = 7
_TCGEN05_GROUPED_SELECTED_MAILBOX_GLOBAL_M_START = 8

if TYPE_CHECKING:
    from .cute.cute_mma import _Tcgen05SchedPipelinePlan
    from .cute.device_state import CuteTcgen05MatmulPlan
    from .inductor_lowering import CodegenState

NUM_SM_VAR = "_NUM_SM"
MAX_ACTIVE_CLUSTERS_VAR = "_MAX_ACTIVE_CLUSTERS"
NUM_XCD_VAR = "_NUM_XCDS"


class PIDInfo(NamedTuple):
    pid_var: str
    block_size_var: str
    numel: sympy.Expr | str  # Can be a sympy.Expr or a string for data-dependent bounds
    block_id: int

    def num_pids_expr(self, *, is_device: bool) -> str:
        """Get the number of PIDs expression for device or host."""
        if is_device:
            context = DeviceFunction.current()
        else:
            context = HostFunction.current()
        # Handle both sympy.Expr and string numel (for data-dependent bounds)
        if isinstance(self.numel, str):
            numel_str = self.numel
        else:
            numel_str = context.sympy_expr(self.numel)
        if self.block_size_var == "1":
            return numel_str
        if not is_device:
            # Grid dimensions are always non-negative, so we can use integer
            # arithmetic directly instead of a function call like triton.cdiv.
            return f"(({numel_str}) + ({self.block_size_var}) - 1) // ({self.block_size_var})"
        return CompileEnvironment.current().backend.cdiv_expr(
            numel_str, self.block_size_var, is_device=is_device
        )

    def static_num_pids(self) -> int | None:
        """The PID count when both the extent and the block size are static."""
        if isinstance(self.numel, str) or not isinstance(
            self.numel, (int, sympy.Integer)
        ):
            return None
        numel = int(self.numel)
        if self.block_size_var == "1":
            return numel
        block_size = DeviceFunction.current().resolved_int_constexpr(
            self.block_size_var
        )
        if block_size is None:
            return None
        return -(-numel // block_size)


def _sum_pids(exprs: list[str]) -> str:
    """Sum PID-count expressions, folding all-static terms into one literal."""
    if exprs and all(e.isdigit() for e in exprs):
        return str(sum(int(e) for e in exprs))
    return " + ".join(exprs)


@dataclasses.dataclass
class ProgramIDs(abc.ABC):
    """Base class for all program ID strategies with common functionality."""

    shared_pid_var: str | None = None
    pid_info: list[PIDInfo] = dataclasses.field(default_factory=list)

    def append(self, pid: PIDInfo) -> None:
        self.pid_info.append(pid)

    @abc.abstractmethod
    def codegen(self, state: CodegenState) -> None:
        raise NotImplementedError

    @abc.abstractmethod
    def codegen_grid(self) -> ast.AST:
        """Generate grid launch expression for kernel execution."""
        raise NotImplementedError

    def total_pids_expr(self, *, is_device: bool) -> str:
        """Get total PIDs expression for device or host."""
        counts = [pid.static_num_pids() for pid in self.pid_info]
        if None not in counts:
            return str(math.prod(cast("list[int]", counts)))
        return " * ".join(
            f"({pid.num_pids_expr(is_device=is_device)})" for pid in self.pid_info
        )

    def setup_persistent_kernel(
        self, device_function: DeviceFunction, total_pids_expr: str | None = None
    ) -> list[ast.stmt] | None:
        """Setup persistent kernel if supported. Returns None if not a persistent kernel."""
        return None

    def _setup_persistent_kernel_and_wrap_body(
        self,
        device_function: DeviceFunction,
        virtual_pid_var: str,
        range_expr: str,
        total_pids_expr: str | None = None,
    ) -> list[ast.stmt]:
        """Complete persistent kernel setup: prepare body, wrap in loop, and return."""
        from .ast_extension import create

        # Prepare body for persistent loop
        wrapped_body = list(device_function.body)
        if isinstance(device_function.pid, ForEachProgramID):
            shared_pid_var = device_function.pid.shared_pid_var
            wrapped_body = [
                statement_from_string(f"{shared_pid_var} = {virtual_pid_var}"),
                *wrapped_body,
            ]

        # Create the persistent loop that wraps the entire body
        persistent_loop = create(
            ast.For,
            target=create(ast.Name, id=virtual_pid_var, ctx=ast.Store()),
            iter=expr_from_string(range_expr),
            body=wrapped_body,
            orelse=[],
            type_comment=None,
        )
        return [persistent_loop]

    @property
    def virtual_program_id(self) -> str:
        """Get the virtual program ID expression for this strategy."""
        return typed_program_id(0)

    def _is_persistent(self) -> bool:
        """Check if this is a persistent strategy. Default False."""
        return False

    def _decompose_pid_to_statements(
        self, pid_var: str, state: CodegenState
    ) -> list[ast.stmt]:
        """Generate statements to decompose a single PID variable into multiple PID components."""
        num_blocks = [
            state.device_function.new_var(f"num_blocks_{i}")
            for i in range(len(self.pid_info[:-1]))
        ]
        statements = [
            statement_from_string(f"{num_block} = {pid.num_pids_expr(is_device=True)}")
            for num_block, pid in zip(num_blocks, self.pid_info[:-1], strict=True)
        ]
        for i, pid in enumerate(self.pid_info):
            expr = pid_var
            if i > 0:
                divisor = " * ".join(num_blocks[:i])
                expr = f"({expr}) // ({divisor})"
            if i + 1 < len(self.pid_info):
                expr = f"({expr}) % ({num_blocks[i]})"
            statements.append(statement_from_string(f"{pid.pid_var} = {expr}"))
        return statements


@dataclasses.dataclass
class ForEachProgramID(ProgramIDs):
    """
    Represent multiple top level for loops in the Helion kernel.  Turns into `if` statements in generated code.
    """

    # pyrefly: ignore [bad-override]
    shared_pid_var: str
    cases: list[ProgramIDs] = dataclasses.field(default_factory=list)
    case_phases: list[int] = dataclasses.field(default_factory=list)
    pid_info: list[PIDInfo] = dataclasses.field(default_factory=list, init=False)
    barrier_after_root: set[int] = dataclasses.field(default_factory=set)

    def codegen_pid_init(self) -> list[ast.stmt]:
        # Check if persistent kernels are enabled in config - if so, skip regular initialization
        # as it will be handled by the persistent loop wrapper
        from .device_function import DeviceFunction

        current_device_fn = DeviceFunction.current()
        pid_type = current_device_fn.config.get("pid_type", "flat")
        if isinstance(pid_type, str) and pid_type.startswith("persistent"):
            return []
        return [statement_from_string(f"{self.shared_pid_var} = {typed_program_id(0)}")]

    def _cdiv_sum(self, state: CodegenState, exclude_last: bool = False) -> str:
        """Sum the non-empty cdiv expressions from cases (empty if none)."""
        cases = self.cases[:-1] if exclude_last else self.cases
        blocks = [
            cdiv
            for pid in cases
            if (cdiv := pid.total_pids_expr(is_device=True))  # drop empty expressions
        ]
        return _sum_pids(blocks)

    def codegen_test(self, state: CodegenState) -> ast.AST:
        return expr_from_string(f"{self.shared_pid_var} < ({self._cdiv_sum(state)})")

    def setup_persistent_kernel(
        self, device_function: DeviceFunction, total_pids_expr: str | None = None
    ) -> list[ast.stmt] | None:
        total_expr = self.total_pids_expr(is_device=True)
        # If there is only one phase, fall back to existing behavior.
        has_phases = len(set(self.case_phases)) > 1

        def _base_strategy(pid: ProgramIDs) -> ProgramIDs:
            from .tile_strategy import L2GroupingProgramIDs

            if isinstance(pid, L2GroupingProgramIDs):
                assert pid.parent_strategy is not None, (
                    "L2 grouping strategy is missing its parent"
                )
                return pid.parent_strategy
            return pid

        base_strategy = _base_strategy(self.cases[0])

        if not has_phases:
            return base_strategy.setup_persistent_kernel(device_function, total_expr)

        # We expect a persistent-blocked strategy when barriers are present.
        if not base_strategy._is_persistent():
            return base_strategy.setup_persistent_kernel(device_function, total_expr)

        assert isinstance(base_strategy, PersistentProgramIDs)
        assert base_strategy.is_blocked, (
            "multi-phase kernels currently require persistent_blocked"
        )

        if HostFunction.current().device_ir.implicit_dependency_starts:
            from .cross_loop_codegen import emit_cross_loop_schedule

            return emit_cross_loop_schedule(
                self, base_strategy, device_function, total_expr
            )

        # Delegate to helper for phase-split persistent loops
        return self._emit_phase_loops(base_strategy, device_function, total_expr)

    def total_pids_expr(self, *, is_device: bool) -> str:
        """Get total PIDs expression for ForEachProgramID (sum of all pids)."""
        cdivs = [pid.total_pids_expr(is_device=is_device) for pid in self.cases]
        return _sum_pids(cdivs)

    def codegen(self, state: CodegenState) -> None:
        blocks = self._cdiv_sum(state, exclude_last=True)
        if blocks:
            env = CompileEnvironment.current()
            block_expr = env.backend.cast_expr(f"({blocks})", env.index_type())
            state.codegen.statements_stack[-1].insert(
                0,
                statement_from_string(
                    f"{self.shared_pid_var} = {self.shared_pid_var} - {block_expr}"
                    if env.backend_name == "cute"
                    else f"{self.shared_pid_var} -= {block_expr}"
                ),
            )

    def codegen_grid(self) -> ast.AST:
        # Check if any of the pids is a persistent strategy
        if self.cases[0]._is_persistent():
            # Use SM count grid for persistent kernels
            return self.cases[0].codegen_grid()

        # When persistent kernels are not active, use the full grid size
        return expr_from_string(f"({self.total_pids_expr(is_device=False)},)")

    def _prepare_persistent_body(
        self,
        body: list[ast.AST],
        device_function: DeviceFunction,
        virtual_pid_var: str,
    ) -> list[ast.AST]:
        """Prepare body for persistent loop - handle ForEachProgramID assignment."""
        # In persistent kernels, replace ForEachProgramID init with virtual_pid assignment
        return [
            statement_from_string(f"{self.shared_pid_var} = {virtual_pid_var}"),
            *body,
        ]

    def _phase_boundaries(self) -> list[str]:
        """Compute cumulative PID boundaries at phase transitions."""
        cdivs = [pid.total_pids_expr(is_device=True) for pid in self.cases]
        boundaries: list[str] = []
        running = "0"
        prev_phase = self.case_phases[0]
        for idx, cdiv in enumerate(cdivs):
            running = _sum_pids([running, cdiv])
            next_phase = (
                self.case_phases[idx + 1]
                if idx + 1 < len(self.case_phases)
                else prev_phase
            )
            if next_phase != prev_phase or idx == len(cdivs) - 1:
                boundaries.append(running)
            prev_phase = next_phase
        return boundaries

    def _emit_phase_loops(
        self,
        strategy: PersistentProgramIDs,
        device_function: DeviceFunction,
        total_expr: str,
    ) -> list[ast.stmt]:
        """Emit persistent loops split by KernelPhase boundaries."""
        from .tile_strategy import TileStrategy

        backend = CompileEnvironment.current().backend
        device_function.preamble.extend(
            strategy._persistent_setup_statements(total_expr)
        )

        boundaries = self._phase_boundaries()
        block_ids = [pid.block_id for pid in strategy.pid_info]

        def range_expr(begin: str, end: str) -> str:
            return TileStrategy.get_range_call_str(
                device_function.config, block_ids, begin=begin, end=end
            )

        base_body = self._prepare_persistent_body(
            device_function.body, device_function, strategy.virtual_pid_var
        )

        barrier_stmt = None
        if len(boundaries) > 1:
            sem_arg = device_function.new_var("x_grid_sem", dce=False)
            barrier_stmt = backend.grid_barrier_stmt(sem_arg)
            if barrier_stmt is not None:
                barrier_dtype = backend.barrier_semaphore_dtype()
                device_function.arguments.append(
                    TensorArg(
                        sem_arg,
                        torch.empty(1, device="meta", dtype=barrier_dtype),
                        f"torch.zeros((1,), device={strategy.get_device_str()}, dtype={barrier_dtype})",
                    )
                )

        loops: list[ast.stmt] = []
        start_expr = "0"
        for boundary in boundaries:
            cond = expr_from_string(
                f"({strategy.virtual_pid_var} >= ({start_expr})) and ({strategy.virtual_pid_var} < ({boundary}))"
            )
            loop_body = [create(ast.If, test=cond, body=list(base_body), orelse=[])]
            loops.append(
                create(
                    ast.For,
                    target=create(
                        ast.Name, id=strategy.virtual_pid_var, ctx=ast.Store()
                    ),
                    iter=expr_from_string(
                        range_expr(strategy.start_pid_var, strategy.end_pid_var)
                    ),
                    body=loop_body,
                    orelse=[],
                    type_comment=None,
                )
            )
            if boundary != boundaries[-1] and barrier_stmt is not None:
                loops.extend(device_function.cta_barrier(barrier_stmt))
            start_expr = boundary
        return loops


class XYZProgramIDs(ProgramIDs):
    """Use the cuda x/y/z launch grid for PIDs"""

    def codegen(self, state: CodegenState) -> None:
        for i, pid in enumerate(self.pid_info):
            state.codegen.statements_stack[-1].insert(
                i, statement_from_string(f"{pid.pid_var} = {typed_program_id(i)}")
            )

    def codegen_grid(self) -> ast.AST:
        env = CompileEnvironment.current()
        if env.backend.name != "pallas":
            assert len(self.pid_info) <= 3
        return expr_from_string(
            f"({', '.join(pid.num_pids_expr(is_device=False) for pid in self.pid_info)},)"
        )

    @property
    def virtual_program_id(self) -> str:
        """
        XYZProgramIDs uses multi-dimensional program IDs and doesn't have a single
        virtual program ID. Wrappers like L2GroupingProgramIDs must explicitly
        handle XYZProgramIDs by flattening the multi-dimensional IDs themselves.
        """
        raise NotImplementedError(
            "XYZProgramIDs does not support virtual_program_id. "
            "Use explicit flattening of multi-dimensional program IDs instead."
        )


def _xcd_device_str() -> str:
    """Device expression for the current compile device (for host-side helpers)."""
    host_function = HostFunction.current()
    device = CompileEnvironment.current().device
    origins = [
        o for t, o in host_function.tensor_to_origin.items() if t.device == device
    ]
    if origins:
        return f"{origins[0].host_str()}.device"
    return f"torch.{device!r}"


def _maybe_emit_xcd_remap(
    device_function: DeviceFunction,
    pid_expr: str,
    total_expr: str,
    active_total_expr: str | None = None,
) -> tuple[list[ast.stmt], str]:
    """Optionally remap a program id into contiguous per-XCD regions.

    No-op (returns ``([], pid_expr)``) unless ``xcd_remap`` is enabled.  When
    enabled, emits the AITER-style contiguous-XCD remap (matching aiter
    ``remap_xcd``) and returns the name of the remapped variable.

    Used for:
    - ``flat`` / ``persistent_interleaved``: the (virtual) program id over the
      logical tile count;
    - ``persistent_blocked``: the worker id (``program_id(0)``) over the grid
      size, remapping which contiguous block each worker owns.
    """
    if not device_function.config.get("xcd_remap", False):
        return [], pid_expr

    # Inject _NUM_XCDS as a host-computed constexpr (mirrors _NUM_SM).
    if device_function.constexpr_arg(NUM_XCD_VAR):
        device_function.codegen.host_statements.append(
            statement_from_string(
                f"{NUM_XCD_VAR} = helion.runtime.get_num_xcd({_xcd_device_str()})"
            )
        )

    new_var = device_function.new_var
    pids_per = new_var("xcd_pids_per", dce=True)
    tall = new_var("xcd_tall", dce=True)
    xcd = new_var("xcd_id", dce=True)
    local = new_var("xcd_local_pid", dce=True)
    out = new_var("xcd_pid", dce=True)
    nx = NUM_XCD_VAR
    total = f"({active_total_expr or total_expr})"
    # Matches aiter remap_xcd: the first `tall` XCDs own one extra contiguous PID.
    stmts = [
        statement_from_string(f"{pids_per} = ({total} + {nx} - 1) // {nx}"),
        statement_from_string(f"{tall} = {total} % {nx}"),
        statement_from_string(f"{tall} = tl.where({tall} == 0, {nx}, {tall})"),
        statement_from_string(f"{xcd} = ({pid_expr}) % {nx}"),
        statement_from_string(f"{local} = ({pid_expr}) // {nx}"),
        statement_from_string(
            f"{out} = tl.where("
            f"{xcd} < {tall}, "
            f"{xcd} * {pids_per} + {local}, "
            f"{tall} * {pids_per} + ({xcd} - {tall}) * ({pids_per} - 1) + {local})"
        ),
    ]
    if active_total_expr is not None:
        guarded = new_var("xcd_pid", dce=True)
        stmts.append(
            statement_from_string(
                f"{guarded} = tl.where(({pid_expr}) < {total}, {out}, {total})"
            )
        )
        out = guarded
    return stmts, out


class FlatProgramIDs(ProgramIDs):
    """Only use the x grid and compute other dimensions"""

    def codegen(self, state: CodegenState) -> None:
        pid_var = self.shared_pid_var or typed_program_id(0)
        remap_stmts, pid_var = _maybe_emit_xcd_remap(
            state.device_function,
            pid_var,
            self.total_pids_expr(is_device=True),
        )
        statements = self._decompose_pid_to_statements(pid_var, state)
        state.codegen.statements_stack[-1][:] = [
            *remap_stmts,
            *statements,
            *state.codegen.statements_stack[-1],
        ]

    def codegen_grid(self) -> ast.AST:
        return expr_from_string(f"({self.total_pids_expr(is_device=False)},)")


@dataclasses.dataclass
class WorklistProgramIDs(ProgramIDs):
    """Compact-worklist grid: one program per work item.

    ``codegen`` emits ``_wid = pl.program_id(0)`` and recovers the owner
    coordinate from the ``owner_ids`` scalar-prefetch ref (``work_<owner>_ref[
    _wid]``) so owner-indexed tensors slice the right owner; ``codegen_grid``
    renders the **static** ``UPPER`` (megablocks bound) as the host grid
    positional, while the compact launcher overrides it with the traced
    ``num_work``.
    """

    upper_expr: str = "1"

    def codegen(self, state: CodegenState) -> None:
        from .pallas.compact_worklist import owner_ref_name

        env = CompileEnvironment.current()
        plan = env.compact_worklist_plan
        assert plan is not None
        stmts: list[ast.stmt] = [statement_from_string(f"_wid = {typed_program_id(0)}")]
        if self.pid_info:
            # owner_ids is always in the metadata (see metadata_arg_names): the
            # owner-grid prologue (q_offsets[seq]) is not DCE'd, so the owner pid
            # must be a valid owner index, NOT the work id (which ranges over
            # work items and would index q_offsets out of bounds).
            owner_pid = self.pid_info[0].pid_var
            ref = owner_ref_name(plan) + "_ref"
            stmts.append(statement_from_string(f"{owner_pid} = {ref}[_wid]"))
        state.codegen.statements_stack[-1][:] = [
            *stmts,
            *state.codegen.statements_stack[-1],
        ]

    def codegen_grid(self) -> ast.AST:
        return expr_from_string(f"({self.upper_expr},)")


class CuteProgramIDs(FlatProgramIDs):
    """Flat PID strategy for CuTe pointwise kernels."""


@dataclasses.dataclass
class L2GroupingProgramIDs(ProgramIDs):
    """Used grouped iteration order to promote L2 cache reuse in matmuls"""

    pid_info: list[PIDInfo] = dataclasses.field(default_factory=list, init=False)
    parent_strategy: ProgramIDs | None = dataclasses.field(default=None)
    group_size: int = 1

    def append(self, pid: PIDInfo) -> None:
        """Delegate to parent strategy."""
        assert self.parent_strategy is not None
        self.parent_strategy.append(pid)

    def codegen(self, state: CodegenState) -> None:
        # Generate L2 grouping logic
        # Note: Persistent kernel setup is handled by ForEachProgramID if needed
        assert self.parent_strategy is not None
        parent_pids = self.parent_strategy.pid_info
        assert len(parent_pids) >= 2, "L2 grouping requires at least 2 dimensions"
        new_var = state.device_function.new_var

        # Apply L2 grouping to the 2 fastest varying dimensions (pid_0, pid_1)
        # These are always the first 2 dimensions in the PID decomposition
        num_dims = len(parent_pids)
        assignments = []
        parent = self.parent_strategy
        parent_is_blocked = parent._is_persistent() and getattr(
            parent, "is_blocked", False
        )

        # Generate size variables for all dimensions (except the last which doesn't need one)
        num_blocks: list[str] = []
        for i in range(num_dims - 1):
            num_block_var = new_var(f"num_blocks_{i}", dce=True)
            assignments.append(
                (num_block_var, parent_pids[i].num_pids_expr(is_device=True))
            )
            num_blocks.append(num_block_var)

        # Determine the base PID to use for L2 grouping.
        # For XYZ strategy, we need to compute a flattened index from the multi-dimensional
        # program IDs since L2 grouping works on a flat 1D PID space.
        if isinstance(self.parent_strategy, XYZProgramIDs):
            # XYZ uses separate program_id(0), program_id(1), etc. for each dimension.
            # We flatten these into a single index using row-major order:
            # flattened_pid = pid_0 + pid_1 * num_blocks_0 + pid_2 * num_blocks_0 * num_blocks_1 + ...
            terms = [typed_program_id(0)]
            for i in range(1, num_dims):
                multiplier = " * ".join(num_blocks[:i])
                terms.append(f"{typed_program_id(i)} * ({multiplier})")
            pid = " + ".join(terms)
        elif isinstance(state.device_function.pid, ForEachProgramID):
            # For ForEachProgramID, use the shared PID variable
            pid = state.device_function.pid.shared_pid_var
        else:
            # For other strategies (Flat, Persistent), use the virtual_program_id
            pid = self.virtual_program_id

        # xcd_remap (if enabled) regroups the PID space into contiguous per-XCD
        # regions *before* L2 grouping orders tiles within it.  For a blocked
        # persistent parent the remap is applied at the worker->block level in
        # the persistent setup instead, so skip it here to avoid double-remap.
        if parent_is_blocked:
            xcd_stmts: list[ast.stmt] = []
        else:
            xcd_stmts, pid = _maybe_emit_xcd_remap(
                state.device_function,
                pid,
                parent.total_pids_expr(is_device=True),
            )

        # Apply L2 grouping to the 2 fastest varying dimensions (pid_0, pid_1)
        fastest_m_idx = 0  # pid_0 (fastest varying)
        fastest_n_idx = 1  # pid_1 (second fastest varying)

        # Extract the 2D portion for the fastest 2 dimensions
        inner_2d_size = new_var("inner_2d_size", dce=True)
        inner_2d_pid = new_var("inner_2d_pid", dce=True)

        num_pid_m = new_var("num_pid_m", dce=True)
        num_pid_n = new_var("num_pid_n", dce=True)
        num_pid_in_group = new_var("num_pid_in_group", dce=True)
        group_id = new_var("group_id", dce=True)
        first_pid_m = new_var("first_pid_m", dce=True)
        group_size_m = new_var("group_size_m", dce=True)

        # Set up L2 grouping for the fastest 2 dimensions
        inner_2d_assignments = [
            (num_pid_m, parent_pids[fastest_m_idx].num_pids_expr(is_device=True)),
            (num_pid_n, parent_pids[fastest_n_idx].num_pids_expr(is_device=True)),
        ]

        # Only add modulo for 3D+ cases where we need to extract the 2D portion
        if num_dims > 2:
            inner_2d_assignments.extend(
                [
                    (inner_2d_size, f"{num_pid_m} * {num_pid_n}"),
                    (
                        inner_2d_pid,
                        f"{pid} % {inner_2d_size}",
                    ),  # Extract fastest 2D portion
                ]
            )
        else:
            # For 2D case, the entire PID space is the 2D space
            inner_2d_assignments.append((inner_2d_pid, pid))

        assignments.extend(inner_2d_assignments)
        # ``group_size_m`` is the number of M tiles in this PID's group:
        # ``min(num_pid_m - first_pid_m, group_size)``.  Its two divisions are
        # the only runtime-divisor divisions of the decode (every other divisor
        # is a tile count), and a runtime divisor costs a full reciprocal
        # sequence on the tile-coordinate critical path.  When the M tile count
        # is static the value is known: every group is full when the count is
        # a multiple of the group size (``group_id < num_pid_m / group_size``
        # because the flattened PID stays below ``num_pid_m * num_pid_n``), and
        # a count no larger than the group size means there is a single group
        # (``group_id == 0``) holding every M tile.  Same mapping, constant
        # divisors.
        # The fold is a CuTe-backend trim; Triton renders keep the runtime
        # ``min`` so their generated code stays byte-identical.
        static_num_pid_m = (
            parent_pids[fastest_m_idx].static_num_pids()
            if CompileEnvironment.current().backend_name == "cute"
            else None
        )
        if static_num_pid_m is not None and static_num_pid_m <= self.group_size:
            group_size_m_expr = num_pid_m
        elif static_num_pid_m is not None and static_num_pid_m % self.group_size == 0:
            group_size_m_expr = f"{self.group_size}"
        else:
            group_size_m_expr = None
        cluster_n = self._decode_cluster_n()
        if cluster_n > 1:
            # Cluster-aware grouped decode (tcgen05 cluster_n > 1). The
            # CUTLASS persistent scheduler hands the ``cluster_n`` CTAs
            # paired along the cluster's N axis the same tile_m and
            # consecutive tile_n — virtual pids exactly ``num_pid_m``
            # apart — and the A multicast fills every peer's SMEM half
            # from one TMA load issued for that shared tile_m. The plain
            # grouped decode below permutes each CTA's virtual pid
            # independently, so peers can decode DIFFERENT tile_m and
            # silently corrupt the multicast. Decode at cluster-box
            # granularity instead ((1 M tile) x (cluster_n N tiles)):
            # peers collapse to one box pid, the grouped raster permutes
            # whole boxes, and the within-box lane recovers each peer's
            # N tile. Reduces to the plain decode at cluster_n=1.
            lane_n = new_var("cluster_lane_n", dce=True)
            box_pid = new_var("cluster_box_pid", dce=True)
            num_box_n = new_var("num_cluster_box_n", dce=True)
            assignments.extend(
                [
                    (lane_n, f"({inner_2d_pid} // {num_pid_m}) % {cluster_n}"),
                    (
                        box_pid,
                        (
                            f"(({inner_2d_pid} // {num_pid_m}) // {cluster_n})"
                            f" * {num_pid_m} + {inner_2d_pid} % {num_pid_m}"
                        ),
                    ),
                    (num_box_n, f"({num_pid_n} + {cluster_n - 1}) // {cluster_n}"),
                    (num_pid_in_group, f"{self.group_size} * {num_box_n}"),
                    (group_id, f"{box_pid} // {num_pid_in_group}"),
                    (first_pid_m, f"{group_id} * {self.group_size}"),
                    (
                        group_size_m,
                        group_size_m_expr
                        or f"min({num_pid_m} - {first_pid_m}, {self.group_size})",
                    ),
                    (
                        parent_pids[fastest_m_idx].pid_var,
                        f"{first_pid_m} + (({box_pid} % {num_pid_in_group}) % {group_size_m})",
                    ),
                    (
                        parent_pids[fastest_n_idx].pid_var,
                        (
                            f"(({box_pid} % {num_pid_in_group}) // {group_size_m})"
                            f" * {cluster_n} + {lane_n}"
                        ),
                    ),
                ]
            )
        else:
            assignments.extend(
                [
                    (num_pid_in_group, f"{self.group_size} * {num_pid_n}"),
                    (group_id, f"{inner_2d_pid} // {num_pid_in_group}"),
                    (first_pid_m, f"{group_id} * {self.group_size}"),
                    (
                        group_size_m,
                        group_size_m_expr
                        or f"min({num_pid_m} - {first_pid_m}, {self.group_size})",
                    ),
                    (
                        parent_pids[fastest_m_idx].pid_var,
                        f"{first_pid_m} + (({inner_2d_pid} % {num_pid_in_group}) % {group_size_m})",
                    ),
                    (
                        parent_pids[fastest_n_idx].pid_var,
                        f"({inner_2d_pid} % {num_pid_in_group}) // {group_size_m}",
                    ),
                ]
            )

        # Process remaining dimensions (if any) using standard decomposition
        for i in range(2, num_dims):
            expr = pid
            # Add divisor for all faster dimensions
            if i > 0:
                divisor = " * ".join(num_blocks[:i])
                expr = f"({expr}) // ({divisor})"
            # Add modulo unless this is the outermost dimension
            if i + 1 < num_dims:  # Not the outermost dimension
                expr = f"({expr}) % {num_blocks[i]}"

            assignments.append((parent_pids[i].pid_var, expr))

        statements = [
            statement_from_string(f"{var} = {expr}") for var, expr in assignments
        ]

        state.codegen.statements_stack[-1][:] = [
            *xcd_stmts,
            *statements,
            *state.codegen.statements_stack[-1],
        ]

    def _decode_cluster_n(self) -> int:
        """The cluster-N width the grouped decode must respect.

        Only the tcgen05 persistent scheduler pairs CTAs along a cluster N
        axis (A-multicast peers must decode the same tile_m). This runs at
        grid-lowering time, before the tcgen05 matmul plan is registered,
        so ``_tcgen05_cluster_n`` reads the config knob. Safe because the
        pid strategy and the mma lowering derive the tcgen05 choice from
        the same ``_kernel_specialized_mma_impl`` probe: when this parent
        is ``Tcgen05PersistentProgramIDs`` and the kernel compiles, the
        launch uses the knob's cluster_n — cute_mma raises
        ``BackendUnsupported`` on the tcgen05 cluster_n demotion paths,
        and a late non-tcgen05 fallback never registers a matmul plan,
        which the tcgen05 persistent layout asserts on before any launch.
        The padding gate in cute_mma (N tile count divisible by
        cluster_n) keeps the box decode a bijection over in-range tiles
        for every launchable grid.
        """
        parent = self.parent_strategy
        if isinstance(parent, Tcgen05PersistentProgramIDs):
            return parent._tcgen05_cluster_n()
        return 1

    @property
    def virtual_program_id(self) -> str:
        """Get the virtual program ID expression using parent strategy."""
        assert self.parent_strategy is not None
        return self.parent_strategy.virtual_program_id

    def codegen_grid(self) -> ast.AST:
        assert self.parent_strategy is not None
        return self.parent_strategy.codegen_grid()

    def setup_persistent_kernel(
        self, device_function: DeviceFunction, total_pids_expr: str | None = None
    ) -> list[ast.stmt] | None:
        """Delegate to parent strategy."""
        assert self.parent_strategy is not None
        return self.parent_strategy.setup_persistent_kernel(
            device_function, total_pids_expr
        )

    def _is_persistent(self) -> bool:
        """Forward to parent strategy."""
        assert self.parent_strategy is not None
        return self.parent_strategy._is_persistent()

    def total_pids_expr(self, *, is_device: bool) -> str:
        """Forward to parent strategy."""
        assert self.parent_strategy is not None
        return self.parent_strategy.total_pids_expr(is_device=is_device)


class PersistentProgramIDs(ProgramIDs):
    """Base class for persistent kernels that use num_sms grid size."""

    def __init__(self, is_blocked: bool = False) -> None:
        super().__init__()
        self.is_blocked: bool = is_blocked
        device_function = DeviceFunction.current()
        self.virtual_pid_var: str = device_function.new_var("virtual_pid")
        self.total_pids_var: str = device_function.new_var("total_pids")
        # Get num_sm_multiplier from config for multi-occupancy support
        # pyrefly: ignore [bad-assignment]
        self.num_sm_multiplier: int = device_function.config.get("num_sm_multiplier", 1)
        # Compute grid size expression based on multiplier
        if self.num_sm_multiplier == 1:
            self.grid_size_expr: str = NUM_SM_VAR
        else:
            self.grid_size_expr = f"({NUM_SM_VAR} * {self.num_sm_multiplier})"
        # Generate variables and range expression based on strategy type
        if self.is_blocked:
            self.block_size_var: str = device_function.new_var("block_size")
            self.start_pid_var: str = device_function.new_var("start_pid")
            self.end_pid_var: str = device_function.new_var("end_pid")
            self.range_kwargs: dict[str, str] = {
                "begin": self.start_pid_var,
                "end": self.end_pid_var,
            }
        else:
            self.range_kwargs: dict[str, str] = {
                "begin": typed_program_id(0),
                "end": self.total_pids_var,
                "step": self.grid_size_expr,
            }
        if device_function.constexpr_arg(NUM_SM_VAR):
            reserved_sms = CompileEnvironment.current().settings.persistent_reserved_sms
            reserved_arg = f", reserved_sms={reserved_sms}" if reserved_sms > 0 else ""
            device_function.codegen.host_statements.append(
                statement_from_string(
                    f"{NUM_SM_VAR} = helion.runtime.get_num_sm({self.get_device_str()}{reserved_arg})"
                )
            )

    def get_device_str(self) -> str:
        """Get the device string for the current device, reusing the first tensor's origin."""
        host_function = HostFunction.current()
        device = CompileEnvironment.current().device
        origins = [
            o for t, o in host_function.tensor_to_origin.items() if t.device == device
        ]
        if origins:
            return f"{origins[0].host_str()}.device"
        return f"torch.{device!r}"

    def codegen_grid(self) -> ast.AST:
        # Use num_sms * multiplier for persistent kernels (multi-occupancy)
        return expr_from_string(f"({self.grid_size_expr},)")

    def _persistent_setup_statements(self, total_pids_expr: str) -> list[ast.stmt]:
        """Generate the preamble statements for persistent kernel setup."""
        env = CompileEnvironment.current()
        backend = env.backend
        # Cast total_pids to match the index type so all persistent scheduling
        # variables (start_pid, end_pid, etc.) have consistent types.
        if env.index_dtype != torch.int32:
            total_pids_expr = backend.cast_expr(total_pids_expr, env.index_type())
        stmts: list[ast.stmt] = [
            statement_from_string(f"{self.total_pids_var} = {total_pids_expr}"),
        ]
        if (
            self.is_blocked
            and self.block_size_var
            and self.start_pid_var
            and self.end_pid_var
        ):
            stmts.append(
                statement_from_string(
                    f"{self.block_size_var} = {backend.cdiv_expr(self.total_pids_var, self.grid_size_expr, is_device=True)}"
                )
            )
            worker = typed_program_id(0)
            if DeviceFunction.current().config.get("xcd_remap", False):
                new_var = DeviceFunction.current().new_var
                safe_block_size = new_var("xcd_safe_block_size", dce=True)
                active_workers = new_var("xcd_active_workers", dce=True)
                stmts.extend(
                    [
                        statement_from_string(
                            f"{safe_block_size} = tl.maximum({self.block_size_var}, 1)"
                        ),
                        statement_from_string(
                            f"{active_workers} = {backend.cdiv_expr(self.total_pids_var, safe_block_size, is_device=True)}"
                        ),
                    ]
                )
                # Remap only the workers that own at least one block.  Slack
                # workers are sent past the end of the compact worker domain so
                # their persistent range is empty after end clipping.
                wstmts, worker = _maybe_emit_xcd_remap(
                    DeviceFunction.current(),
                    typed_program_id(0),
                    active_workers,
                    active_workers,
                )
                stmts.extend(wstmts)
            stmts.extend(
                [
                    statement_from_string(
                        f"{self.start_pid_var} = {worker} * {self.block_size_var}"
                    ),
                    statement_from_string(
                        f"{self.end_pid_var} = {self.start_pid_var} + {self.block_size_var}"
                    ),
                    create(
                        ast.If,
                        test=expr_from_string(
                            f"{self.end_pid_var} > {self.total_pids_var}"
                        ),
                        body=[
                            statement_from_string(
                                f"{self.end_pid_var} = {self.total_pids_var}"
                            )
                        ],
                        orelse=[],
                    ),
                ]
            )
        return stmts

    def setup_persistent_kernel(
        self, device_function: DeviceFunction, total_pids_expr: str | None = None
    ) -> list[ast.stmt] | None:
        """Setup persistent kernel and return the wrapped body."""
        # Get total PIDs expression
        if total_pids_expr is None:
            total_pids_expr = self.total_pids_expr(is_device=True)

        device_function.preamble.extend(
            self._persistent_setup_statements(total_pids_expr)
        )
        # Collect all block IDs from PID info for range configuration
        pid_block_ids = []
        for pid_info in self.pid_info:
            pid_block_ids.append(pid_info.block_id)

        from .tile_strategy import TileStrategy

        range_expr = TileStrategy.get_range_call_str(
            device_function.config, pid_block_ids, **self.range_kwargs
        )
        return self._setup_persistent_kernel_and_wrap_body(
            device_function, self.virtual_pid_var, range_expr, total_pids_expr
        )

    def _is_persistent(self) -> bool:
        """Check if this is a persistent strategy."""
        return True

    def _decompose_virtual_pid(
        self,
        state: CodegenState,
        virtual_pid_var: str,
        setup_statements: list[ast.stmt],
    ) -> None:
        """Decompose virtual PID into individual PID variables."""
        # Use shared_pid_var if available, otherwise virtual_pid_var
        pid_var = self.shared_pid_var or virtual_pid_var
        # Interleaved: remap each virtual pid into per-XCD contiguous regions
        # (matches aiter's per-tile remap_xcd).  Blocked remaps the worker->block
        # assignment in the persistent setup instead, so it is skipped here.
        if not self.is_blocked:
            remap_stmts, pid_var = _maybe_emit_xcd_remap(
                state.device_function,
                pid_var,
                self.total_pids_expr(is_device=True),
            )
            setup_statements.extend(remap_stmts)
        statements = self._decompose_pid_to_statements(pid_var, state)
        setup_statements.extend(statements)

    def _generate_pid_statements(self, state: CodegenState) -> list[ast.stmt]:
        """Generate PID decomposition statements based on setup state."""
        if not self.virtual_pid_var:
            # Generate regular PID decomposition
            return self._decompose_pid_to_statements(
                self.shared_pid_var or typed_program_id(0), state
            )

        # Generate persistent PID decomposition
        statements = []
        self._decompose_virtual_pid(state, self.virtual_pid_var, statements)
        return statements

    def _prepend_statements(
        self, state: CodegenState, statements: list[ast.stmt]
    ) -> None:
        """Prepend statements to current statement stack."""
        current_statements = state.codegen.statements_stack[-1]
        current_statements[:] = [*statements, *current_statements]

    def codegen(self, state: CodegenState) -> None:
        """Common codegen logic for persistent kernels."""
        is_shared_pid = isinstance(state.device_function.pid, ForEachProgramID)

        # Set up persistent loop if needed (non-ForEachProgramID case only)
        if not is_shared_pid and not self.virtual_pid_var:
            self.setup_persistent_kernel(state.device_function)

        # Generate and prepend PID decomposition statements
        statements = self._generate_pid_statements(state)
        self._prepend_statements(state, statements)

    @property
    def virtual_program_id(self) -> str:
        """Get the virtual program ID expression for persistent strategies."""
        return self.virtual_pid_var


class PersistentBlockedProgramIDs(PersistentProgramIDs):
    """Persistent kernels where each SM processes a contiguous block of virtual PIDs."""

    def __init__(self) -> None:
        super().__init__(is_blocked=True)


class PersistentInterleavedProgramIDs(PersistentProgramIDs):
    """Persistent kernels where each SM processes every num_sms-th virtual PID."""

    def __init__(self) -> None:
        super().__init__(is_blocked=False)


class Tcgen05PersistentProgramIDs(PersistentProgramIDs):
    """tcgen05 persistent scheduler for blocked and interleaved PID orders."""

    _VALIDATED_TWO_CTA_MAX_K_TILES: ClassVar[int] = TCGEN05_TWO_CTA_MAX_K_TILES

    def __init__(self, *, is_blocked: bool) -> None:
        super().__init__(is_blocked=is_blocked)

    def _tcgen05_plan(self) -> CuteTcgen05MatmulPlan | None:
        try:
            return DeviceFunction.current().cute_state.matmul_plan
        except NoCurrentFunction:
            # Unit tests exercise builder helpers without entering a
            # DeviceFunction; in that context the tcgen05 plan-dependent
            # branches should behave like the legacy 1-CTA path.
            return None

    def _tcgen05_cluster_m(self) -> int:
        if (plan := self._tcgen05_plan()) is not None:
            return plan.cluster_m
        config = DeviceFunction.current().config
        cluster_m = int(str(config.get("tcgen05_cluster_m", 1)))
        return max(1, min(cluster_m, 2))

    def _tcgen05_cluster_n(self) -> int:
        # The tcgen05 plan owns ``cluster_n`` once the matmul plan has been
        # registered (cute_mma derives the validated value and stores it on
        # the plan). Outside the matmul codegen path the helper falls back
        # to the config knob; non-tcgen05 paths see cluster_n=1 from the
        # config default and never reach this method's result anyway.
        if (plan := self._tcgen05_plan()) is not None:
            return plan.cluster_n
        config = DeviceFunction.current().config
        cluster_n = int(str(config.get("tcgen05_cluster_n", 1)))
        return max(1, min(cluster_n, 2))

    def _tcgen05_l2_swizzle_size(self) -> int:
        """Return the L2 tile-scheduler swizzle size (Quack ``max_swizzle_size``).

        Returned value is the integer that will be threaded into
        ``cutlass.utils.PersistentTileSchedulerParams(swizzle_size=...)``.
        Default ``TCGEN05_L2_SWIZZLE_SIZE_DEFAULT`` (= ``1``) means no
        swizzle (preserves byte-identity vs the cycle 41 baseline).
        Larger values group consecutive cluster linear-IDs along the
        slow raster axis to promote L2 reuse on bandwidth-bound shapes.

        Mirrors ``_tcgen05_cluster_m`` / ``_tcgen05_cluster_n``: fall
        back to the legacy default when no matmul plan and no
        ``DeviceFunction`` are registered. Unit tests exercise the
        scheduler-prelude builders without a registered plan and
        expect the no-swizzle byte-identity path. Reads via the
        canonical ``l2_swizzle_size_from_config`` helper so
        codegen and the strategies layer share one decode.
        """
        if (plan := self._tcgen05_plan()) is not None:
            return plan.l2_swizzle_size
        try:
            config = DeviceFunction.current().config
        except NoCurrentFunction:
            return TCGEN05_L2_SWIZZLE_SIZE_DEFAULT
        return l2_swizzle_size_from_config(config)

    def _tcgen05_persistent_tile_sched_params_args(
        self, *, cluster_m: int, cluster_n: int
    ) -> str:
        """Format the constructor args for ``PersistentTileSchedulerParams``.

        Always passes the problem shape and cluster shape. When
        ``l2_swizzle_size > 1`` also passes the ``swizzle_size=`` kwarg
        so the CuTe scheduler folds in the L2 grouping math; when the
        size is ``1`` the kwarg is omitted to keep the no-swizzle path
        byte-identical to pre-cycle-42.

        Caller passes ``cluster_m`` / ``cluster_n`` so unit tests that
        exercise scheduler-prelude builders without a registered
        ``CuteTcgen05MatmulPlan`` (and without an active
        ``DeviceFunction``) can drive the helper from the
        ``_Tcgen05PersistentLayout`` they constructed locally.
        """
        problem = self._tcgen05_num_tiles_expr(is_device=True, cluster_n=cluster_n)
        l2_swizzle = self._tcgen05_l2_swizzle_size()
        if l2_swizzle <= 1:
            return f"{problem}, ({cluster_m}, {cluster_n}, 1)"
        return f"{problem}, ({cluster_m}, {cluster_n}, 1), swizzle_size={l2_swizzle}"

    def _tcgen05_is_two_cta(self) -> bool:
        if (plan := self._tcgen05_plan()) is not None:
            return plan.is_two_cta
        return False

    def _tcgen05_has_scheduler_warp(self) -> bool:
        plan = self._tcgen05_plan()
        return plan is not None and plan.has_scheduler_warp

    def _tcgen05_uses_grouped_static_persistent(self) -> bool:
        plan = self._tcgen05_plan()
        return bool(plan is not None and plan.grouped is not None)

    def _tcgen05_uses_grouped_worklist_nm_scheduler_mailbox(self) -> bool:
        plan = self._tcgen05_plan()
        return bool(
            plan is not None
            and plan.accumulator_view == "nm"
            and plan.has_scheduler_warp
            and plan.uses_role_local_persistent_body
            and plan.grouped is not None
            and plan.grouped.scheduler_mode
            is Tcgen05GroupedSchedulerMode.DEVICE_GROUP_SEARCH
        )

    def _tcgen05_uses_grouped_worklist_nm_runtime_table(self) -> bool:
        plan = self._tcgen05_plan()
        return bool(
            plan is not None
            and plan.accumulator_view == "nm"
            and plan.uses_role_local_persistent_body
            and plan.grouped is not None
            and plan.grouped.uses_runtime_tile_table
        )

    def _tcgen05_uses_grouped_worklist_nm_runtime_direct(self) -> bool:
        plan = self._tcgen05_plan()
        return bool(
            plan is not None
            and plan.grouped is not None
            and plan.grouped.scheduler_mode
            is Tcgen05GroupedSchedulerMode.RUNTIME_DIRECT
        )

    def _tcgen05_uses_grouped_worklist_nm_runtime_clc(self) -> bool:
        plan = self._tcgen05_plan()
        return bool(
            plan is not None
            and plan.grouped is not None
            and plan.grouped.scheduler_mode is Tcgen05GroupedSchedulerMode.RUNTIME_CLC
        )

    def _tcgen05_sched_pipeline_plan(self) -> _Tcgen05SchedPipelinePlan | None:
        try:
            return DeviceFunction.current().cute_state.sched_pipeline_plan
        except NoCurrentFunction:
            return None

    def _tcgen05_sched_stage_count(self) -> int:
        plan = self._tcgen05_plan()
        if plan is None:
            return 0
        return max(plan.sched_stage_count, 0)

    def _tcgen05_uses_staged_work_tile_mailbox(self) -> bool:
        return self._tcgen05_sched_stage_count() > 1

    def _tcgen05_work_tile_slot_for_state(
        self,
        layout: Tcgen05PersistentProgramIDs._Tcgen05PersistentLayout,
        i: int,
        pipeline_state: str | None,
    ) -> str:
        if pipeline_state is None:
            return f"{layout.work_tile_smem}[cutlass.Int32({i})]"
        return f"{layout.work_tile_smem}[cutlass.Int32({i}), {pipeline_state}.index]"

    def _tcgen05_work_tile_slot(
        self, layout: Tcgen05PersistentProgramIDs._Tcgen05PersistentLayout, i: int
    ) -> str:
        if not self._tcgen05_uses_staged_work_tile_mailbox():
            return self._tcgen05_work_tile_slot_for_state(layout, i, None)
        sched_plan = self._tcgen05_sched_pipeline_plan()
        assert sched_plan is not None
        return self._tcgen05_work_tile_slot_for_state(
            layout, i, sched_plan.consumer_state
        )

    def _tcgen05_work_tile_producer_slot(
        self, layout: Tcgen05PersistentProgramIDs._Tcgen05PersistentLayout, i: int
    ) -> str:
        if not self._tcgen05_uses_staged_work_tile_mailbox():
            return self._tcgen05_work_tile_slot_for_state(layout, i, None)
        sched_plan = self._tcgen05_sched_pipeline_plan()
        assert sched_plan is not None
        return self._tcgen05_work_tile_slot_for_state(
            layout, i, sched_plan.producer_state
        )

    def _tcgen05_work_tile_producer_smem_ptr(
        self, layout: Tcgen05PersistentProgramIDs._Tcgen05PersistentLayout
    ) -> str:
        if not self._tcgen05_uses_staged_work_tile_mailbox():
            return layout.work_tile_smem_ptr
        sched_plan = self._tcgen05_sched_pipeline_plan()
        assert sched_plan is not None
        return (
            f"{layout.work_tile_smem}[None, {sched_plan.producer_state}.index].iterator"
        )

    def _tcgen05_work_tile_mailbox_field_count(self) -> int:
        if self._tcgen05_uses_grouped_worklist_nm_scheduler_mailbox():
            return TCGEN05_GROUPED_WORKLIST_MAILBOX_FIELD_COUNT
        return 4

    def _tcgen05_has_validated_role_local_two_cta_runtime(self) -> bool:
        plan = self._tcgen05_plan()
        return bool(
            plan is not None
            and plan.is_two_cta
            and plan.uses_role_local_persistent_body
            and plan.k_tile_count <= self._VALIDATED_TWO_CTA_MAX_K_TILES
        )

    def _tcgen05_uses_cluster_m2_one_cta_role_local_bridge(self) -> bool:
        plan = self._tcgen05_plan()
        return bool(
            plan is not None
            and plan.uses_cluster_m2_one_cta_role_local_bridge
            and plan.cluster_m == 2
            and not plan.is_two_cta
            and plan.uses_role_local_persistent_body
        )

    def _tcgen05_output_tile_dims_expr(self, *, is_device: bool) -> list[str]:
        plan = self._tcgen05_plan()
        if plan is not None and plan.row_union is not None:
            union = plan.row_union
            if union.schedule is not None:
                rows = (
                    (union.m + plan.bn - 1) // plan.bn
                    if union.linear_record_clc
                    else union.m // plan.bn
                )
                return [str(union.n // plan.bm), str(rows), "1"]
            return [str(union.m // plan.bm), str(union.n // plan.bn), "1"]
        assert len(self.pid_info) <= 3, (
            "tcgen05 persistent scheduler supports at most 3 PID dimensions"
        )
        dims = [pid.num_pids_expr(is_device=is_device) for pid in self.pid_info]
        while len(dims) < 3:
            dims.append("1")
        return dims

    def _tcgen05_batched_grid(self) -> bool:
        """Batched (leading passthrough) tcgen05 grid: PID axes (batch, m, n)."""
        if len(self.pid_info) != 3:
            return False
        plan = self._tcgen05_plan()
        return plan is None or plan.row_union is None

    def _tcgen05_batched_cluster_n2(self, *, cluster_n: int | None = None) -> bool:
        """Batched grid whose clusters pair N tiles (``cluster_n > 1``) on dim 1."""
        if cluster_n is None:
            cluster_n = self._tcgen05_cluster_n()
        return cluster_n > 1 and self._tcgen05_batched_grid()

    def _tcgen05_batch_raster(self) -> str:
        """``tcgen05_batch_raster``; the default outside a device function."""
        try:
            config = DeviceFunction.current().config
        except NoCurrentFunction:
            return TCGEN05_BATCH_RASTER_DEFAULT
        return batch_raster_from_config(config)

    def _tcgen05_scheduler_axes(
        self, *, cluster_n: int | None = None
    ) -> tuple[int, ...]:
        """PID axis carried by each scheduler dim (dim 0 is walked fastest).

        The scheduler pairs its ``cluster_m`` CTAs along dim 0 and its
        ``cluster_n`` CTAs along dim 1, so dim 1 must be N whenever
        ``cluster_n=2``.  Plain grids keep their PID order.  A batched kernel's
        PID order is (batch, m, n); its ``tcgen05_batch_raster`` chooses the
        walk: ``batch_fastest`` keeps the batch on dim 0 (the CtaGroup.TWO
        pair rides the batch axis: dim 0 is ``batch * cluster_m`` so both
        CTAs of a pair see the same batch and tile) and, for ``cluster_n=2``,
        swaps the trailing dims so the A-multicast peers differ in N;
        ``batch_slowest`` walks (m, n, batch), so consecutive clusters
        exhaust one batch and share its A tile across the N peers and its B
        tile across the M clusters at the same time.
        ``_tcgen05_linear_virtual_pid_expr`` reads the coordinates back in
        PID order.  ``cluster_n`` may be passed by builders that run without
        an active device function (the persistent-loop unit tests).
        """
        identity = tuple(range(len(self.pid_info)))
        if not self._tcgen05_batched_grid():
            return identity
        if self._tcgen05_batch_raster() == TCGEN05_BATCH_RASTER_SLOWEST:
            return (1, 2, 0)
        if self._tcgen05_batched_cluster_n2(cluster_n=cluster_n):
            return (0, 2, 1)
        return identity

    def _tcgen05_scheduler_tile_dims_expr(
        self, *, is_device: bool, cluster_n: int | None = None
    ) -> list[str]:
        dims = self._tcgen05_output_tile_dims_expr(is_device=is_device)
        axes = self._tcgen05_scheduler_axes(cluster_n=cluster_n)
        if len(axes) == 3:
            dims = [dims[axis] for axis in axes]
        if self._tcgen05_is_two_cta():
            # CtaGroup.TWO uses two CTAs to produce one logical tile along
            # the scheduler's dim 0. Model that dim as CTA slots, then
            # collapse back to the logical coordinate when binding
            # virtual_pid for PID decomposition.
            dims[0] = f"({dims[0]}) * {self._tcgen05_cluster_m()}"
        # cluster_n>1 leaves the scheduler N dim equal to the logical N
        # tile count; the cluster_shape ``(cluster_m, cluster_n, 1)``
        # passed to ``PersistentTileSchedulerParams`` allocates one
        # cluster per ``cluster_n`` consecutive N tiles. Each CTA in the
        # cluster's N axis sees a distinct ``tile_idx[1]`` so the
        # virtual_pid mapping uses the raw scheduler tile_idx[1] as the
        # logical N coordinate.
        return dims

    def _tcgen05_num_tiles_expr(
        self, *, is_device: bool, cluster_n: int | None = None
    ) -> str:
        dims = self._tcgen05_scheduler_tile_dims_expr(
            is_device=is_device, cluster_n=cluster_n
        )
        return f"({', '.join(dims[:3])})"

    def _tcgen05_work_tile_padding_predicate(self, work_tile_var: str) -> str | None:
        """Admit logical clusters, not the scheduler's swizzle-padding slots.

        The raster-along-M scheduler rounds its second *cluster* extent up
        to the swizzle size, and reports those padding slots as valid work.
        Test this coordinate before flattening: a padded coordinate can alias
        a valid PID in the next outer dimension. Cluster-base comparison keeps
        every peer of a legitimate partial edge cluster on the same schedule.
        Dim 1 carries whichever PID axis ``_tcgen05_scheduler_axes`` puts
        there (N under ``cluster_n=2`` or ``batch_slowest``, M otherwise), so
        the static tile count that decides whether padding exists is read
        from that axis, the same one the guard's bound is built from.
        """
        swizzle = self._tcgen05_l2_swizzle_size()
        if swizzle == 1:
            return None
        plan = self._tcgen05_plan()
        if plan is not None and (plan.is_clc_persistent or plan.grouped is not None):
            # CLC cancellation and grouped worklists have separate work-space
            # contracts; this guard covers the ordinary static scheduler only.
            return None
        cluster_n = self._tcgen05_cluster_n()
        if len(self.pid_info) < 2:
            static_tiles = 1
        else:
            pid = self.pid_info[self._tcgen05_scheduler_axes()[1]]
            static_tiles = None
            if isinstance(pid.numel, (int, sympy.Integer)):
                block_size = (
                    1
                    if pid.block_size_var == "1"
                    else CompileEnvironment.current()
                    .block_sizes[pid.block_id]
                    .from_config(DeviceFunction.current().config)
                )
                if isinstance(block_size, int) and block_size > 0:
                    static_tiles = (int(pid.numel) + block_size - 1) // block_size
        if static_tiles is not None:
            clusters = (static_tiles + cluster_n - 1) // cluster_n
            if clusters % swizzle == 0:
                return None
        logical_n = self._tcgen05_scheduler_tile_dims_expr(is_device=True)[1]
        coord = f"{work_tile_var}.tile_idx[1]"
        if cluster_n > 1:
            coord = (
                f"({coord} // cutlass.Int32({cluster_n})) * cutlass.Int32({cluster_n})"
            )
        return f"{coord} < ({logical_n})"

    def _tcgen05_guard_logical_work(
        self, work_tile_var: str, body: list[ast.stmt]
    ) -> list[ast.stmt]:
        predicate = self._tcgen05_work_tile_padding_predicate(work_tile_var)
        if predicate is None:
            return body
        return [create(ast.If, test=expr_from_string(predicate), body=body, orelse=[])]

    def _tcgen05_skip_padding_work(
        self, scheduler_var: str, work_tile_var: str
    ) -> list[ast.stmt]:
        """Seek the next logical work item before shared-mailbox publication.

        Padding is not the terminating sentinel. Always advance past it, and
        publish invalid only after the underlying scheduler is exhausted.
        """
        predicate = self._tcgen05_work_tile_padding_predicate(work_tile_var)
        if predicate is None:
            return []
        return [
            create(
                ast.While,
                test=expr_from_string(
                    f"{work_tile_var}.is_valid_tile and not ({predicate})"
                ),
                body=[
                    statement_from_string(f"{scheduler_var}.advance_to_next_work()"),
                    statement_from_string(
                        f"{work_tile_var} = {scheduler_var}.get_current_work()"
                    ),
                ],
                orelse=[],
            )
        ]

    def _tcgen05_num_work_clusters_expr(self, *, is_device: bool) -> str:
        """Return the number of scheduler work clusters.

        ``StaticPersistentTileScheduler.create`` initializes its current
        work index from ``block_idx.z`` and uses ``block_idx.x/y`` only as
        the CTA's coordinate inside a cluster. The launch grid therefore
        needs one z block per persistent work cluster, not a flat x-only
        ``(_NUM_SM,)`` grid.
        """
        dims = self._tcgen05_scheduler_tile_dims_expr(is_device=is_device)
        cluster_m = self._tcgen05_cluster_m()
        cluster_n = self._tcgen05_cluster_n()
        if cluster_m > 1:
            dims[0] = f"(({dims[0]}) + {cluster_m} - 1) // {cluster_m}"
        if cluster_n > 1:
            # Each cluster covers ``cluster_n`` consecutive logical N tiles.
            dims[1] = f"(({dims[1]}) + {cluster_n} - 1) // {cluster_n}"
        return " * ".join(f"({dim})" for dim in dims[:3])

    def _tcgen05_max_active_clusters_var(self) -> str:
        """Host constexpr: clusters of this kernel's size the device co-schedules.

        ``_NUM_SM // cluster_size`` is exact for the CtaGroup.TWO pair but
        over-counts larger clusters (a cluster lives inside one GPC and the
        GPCs hold uneven TPC counts: a B200 holds 33 four-CTA clusters, not
        37), and every surplus persistent cluster is a second hardware wave
        that re-runs the prologue.  ``helion.runtime.get_max_active_clusters``
        asks the driver once per device and cluster size.
        """
        cluster_size = self._tcgen05_cluster_m() * self._tcgen05_cluster_n()
        reserved_sms = CompileEnvironment.current().settings.persistent_reserved_sms
        reserved_arg = f", reserved_sms={reserved_sms}" if reserved_sms > 0 else ""
        return DeviceFunction.current().host_constexpr_def(
            MAX_ACTIVE_CLUSTERS_VAR,
            f"helion.runtime.get_max_active_clusters("
            f"{self.get_device_str()}, {cluster_size}{reserved_arg})",
        )

    def _tcgen05_whole_cluster_capacity_expr(self) -> str:
        """Persistent capacity in whole clusters of ``cluster_m * cluster_n`` CTAs."""
        cluster_size = self._tcgen05_cluster_m() * self._tcgen05_cluster_n()
        if cluster_size > 2:
            return self._tcgen05_max_active_clusters_var()
        return f"max(1, ({self.grid_size_expr}) // {cluster_size})"

    def _tcgen05_max_persistent_work_clusters_expr(self) -> str:
        """Return the launch-grid persistent work-cluster capacity.

        Capacity is in cluster slots; divide by ``cluster_m`` (V-pair
        size) so each cluster slot consumes one SM regardless of
        ``cluster_n``. Independent of ``cluster_n`` so cluster_n=2
        does not collapse the launch to one wave.  Batched cluster_n=2
        grids (whose 4-CTA clusters outnumber the SMs: 16 x 512x768x1024
        launches 64 clusters) are capped in whole clusters instead, so
        the persistent CTAs recycle their pipelines across tiles rather
        than leaving a second hardware wave to re-run the prologue; the
        whole-cluster cap is the device's co-resident cluster count
        (``_MAX_ACTIVE_CLUSTERS``), which for clusters larger than the
        CtaGroup.TWO pair is below ``_NUM_SM // cluster_size``.
        """
        cluster_m = self._tcgen05_cluster_m()
        cluster_n = self._tcgen05_cluster_n()
        if self._tcgen05_batched_cluster_n2():
            return self._tcgen05_whole_cluster_capacity_expr()
        if cluster_m * cluster_n == 1:
            plan = self._tcgen05_plan()
            if (
                plan is not None
                and plan.row_union is not None
                and plan.row_union.resident_ctas != 1
            ):
                return f"({self.grid_size_expr}) * {plan.row_union.resident_ctas}"
            return self.grid_size_expr
        plan = self._tcgen05_plan()
        if (
            plan is not None
            and plan.row_union is not None
            and plan.row_union.schedule is not None
        ):
            return self._tcgen05_whole_cluster_capacity_expr()
        return f"max(1, ({self.grid_size_expr}) // {cluster_m})"

    def _tcgen05_grid_work_clusters_expr(self, total_clusters: str) -> str:
        """Return the scheduler z dimension for the persistent launch grid."""
        max_persistent_clusters = self._tcgen05_max_persistent_work_clusters_expr()
        return f"min(({total_clusters}), ({max_persistent_clusters}))"

    def codegen_grid(self) -> ast.AST:
        # Tcgen05 persistent kernels use CUTLASS' z-indexed scheduler instead
        # of the parent virtual-PID loop. Validated role-local CtaGroup.TWO
        # caps the launch at persistent work-cluster capacity. Validated
        # role-local CtaGroup.TWO uses per-role scheduler loops over this same
        # capped grid, so it can recycle CTA-local pipeline/TMEM state across
        # logical work tiles. Guarded legacy fallback and K-over-cap
        # CtaGroup.TWO use the same capped grid but still raise before launch.
        # Multi-root ForEach kernels are still host-guarded because this grid
        # is derived from this case's pid_info only.
        cluster_m = self._tcgen05_cluster_m()
        cluster_n = self._tcgen05_cluster_n()
        total_clusters = self._tcgen05_num_work_clusters_expr(is_device=False)
        plan = self._tcgen05_plan()
        if plan is not None and plan.is_clc_persistent:
            # G2-H (cute_plan.md): CLC mode launches the *full*
            # problem grid (one cluster slot per problem cluster),
            # not the persistent sub-grid. The hardware tile-scheduler
            # then controls which clusters actually run; CLC's
            # ``try_cancel`` lets a running cluster cancel and steal
            # work from a not-yet-started cluster. Mirrors Quack's
            # ``get_grid_shape`` for ``PersistenceMode.CLC`` and
            # cutlass-DSL's ``ClcDynamicPersistentTileScheduler.get_grid_shape``
            # which both return the full problem grid for CLC mode.
            # Capping the launch like the static path does (``min(total,
            # max_persistent)``) starves the hardware of pending
            # clusters and causes CLC to immediately return ``valid=0``
            # on the first query, terminating the persistent loop
            # after iteration 0 (verified via ``cute.printf``).
            return expr_from_string(f"({cluster_m}, {cluster_n}, {total_clusters})")
        grid_work_clusters = self._tcgen05_grid_work_clusters_expr(total_clusters)
        return expr_from_string(f"({cluster_m}, {cluster_n}, {grid_work_clusters})")

    def _tcgen05_logical_m_coord_expr(self, coord: str) -> str:
        if self._tcgen05_is_two_cta():
            return f"({coord}) // cutlass.Int32({self._tcgen05_cluster_m()})"
        if self._tcgen05_uses_cluster_m2_one_cta_role_local_bridge():
            # The shared clustered scheduler publishes ``base_m + peer_rank``
            # into each CTA's SMEM slot. The guarded role-local bridge omits
            # that handoff, so bind each CTA's role-local PID to the same
            # per-peer M coordinate directly.
            return (
                f"({coord}) + "
                "cute.arch.make_warp_uniform(cute.arch.block_idx_in_cluster())"
            )
        return coord

    def _tcgen05_linear_virtual_pid_expr(self, work_tile_var: str) -> str:
        plan = self._tcgen05_plan()
        if plan is not None and plan.row_union is not None:
            return self._tcgen05_linear_virtual_pid_from_coords_expr(
                [f"{work_tile_var}.tile_idx[{i}]" for i in range(3)]
            )
        terms: list[str] = []
        axes = self._tcgen05_scheduler_axes()
        for i, _pid in enumerate(self.pid_info):
            tile_dim = axes.index(i)
            coord = f"{work_tile_var}.tile_idx[{tile_dim}]"
            if tile_dim == 0:
                coord = self._tcgen05_logical_m_coord_expr(coord)
            if i == 0:
                terms.append(coord)
                continue
            stride = " * ".join(
                f"({pid.num_pids_expr(is_device=True)})" for pid in self.pid_info[:i]
            )
            terms.append(f"({coord}) * ({stride})")
        return " + ".join(terms) if terms else "cutlass.Int32(0)"

    def _tcgen05_mailbox_coord_terms(self, slots: list[str]) -> tuple[list[str], int]:
        """Read the scheduler-warp mailbox back as per-PID-axis coordinates.

        The mailbox mirrors ``tile_idx`` slot for slot: slot ``k`` holds the
        scheduler's dim ``k`` (slot 0 counts the CtaGroup.TWO pair's CTA
        slots, and the cluster publish adds each peer's rank to it), so the
        PID axis that ``_tcgen05_scheduler_axes`` puts on dim ``k`` reads slot
        ``k``.  Returns the coordinates in PID order together with the PID
        axis on dim 0, the ``pair_axis`` of
        ``_tcgen05_linear_virtual_pid_from_coords_expr``.
        """
        axes = self._tcgen05_scheduler_axes()
        return [slots[axes.index(i)] for i in range(len(self.pid_info))], axes[0]

    def _tcgen05_linear_virtual_pid_from_coords_expr(
        self, coords: list[str], *, pair_axis: int = 0
    ) -> str:
        """Linearize per-PID-axis scheduler coordinates into the virtual pid.

        ``pair_axis`` names the PID axis that sits on the scheduler's dim 0,
        whose coordinate counts CtaGroup.TWO CTA slots and is collapsed back
        to the logical tile (``_tcgen05_logical_m_coord_expr``).
        """
        plan = self._tcgen05_plan()
        if plan is not None and plan.row_union is not None:
            union = plan.row_union
            if union.linear_record_clc:
                # This profile launches one complete cluster per linear record.
                # CLC returns that same z coordinate; physical rows are the
                # fast axis, independently of the source PID decomposition.
                assert union.schedule is not None
                if [pid.block_id for pid in self.pid_info] == [
                    union.group_block_id,
                    union.m_block_id,
                    union.n_block_id,
                ]:
                    return f"({coords[2]}) * cutlass.Int32({union.groups})"
                row, column = union.schedule.record_coordinates(coords[2], union.m)
                coords = [
                    f"({column}) * cutlass.Int32({plan.cluster_m})",
                    row,
                    "cutlass.Int32(0)",
                ]
            by_block = {
                union.group_block_id: "cutlass.Int32(0)",
                union.m_block_id: coords[0],
                union.n_block_id: coords[1],
            }
            if union.schedule is not None:
                by_block[union.m_block_id] = coords[1]
                by_block[union.n_block_id] = self._tcgen05_logical_m_coord_expr(
                    coords[0]
                )
            assert {pid.block_id for pid in self.pid_info} == set(by_block)
            coords = [by_block[pid.block_id] for pid in self.pid_info]
        terms: list[str] = []
        for i, coord in enumerate(coords[: len(self.pid_info)]):
            if i == pair_axis and not (plan is not None and plan.row_union is not None):
                coord = self._tcgen05_logical_m_coord_expr(coord)
            if i == 0:
                terms.append(coord)
                continue
            stride = " * ".join(
                f"({pid.num_pids_expr(is_device=True)})" for pid in self.pid_info[:i]
            )
            terms.append(f"({coord}) * ({stride})")
        return " + ".join(terms) if terms else "cutlass.Int32(0)"

    def _tcgen05_output_full_tile_expr_for_work_tile(self, work_tile_var: str) -> str:
        """Return whether a scheduler work tile covers a full output tile.

        Used by the scheduler-backed edge path to publish interior tiles and
        fringe tiles through separate scheduler phases while keeping every
        consumer role on the same tile order within each phase. The predicate
        must match the consumer's post-L2-remap ``pid_0`` / ``pid_1`` rather
        than the scheduler's raw tile coordinates; otherwise grouped PID order
        can send a fringe tile down the full-tile TMA-store path.
        """
        assert len(self.pid_info) >= 2, (
            "tcgen05 output full-tile split requires M/N PID dimensions"
        )

        def pid_numel_expr(pid: PIDInfo) -> str:
            if isinstance(pid.numel, str):
                return pid.numel
            return DeviceFunction.current().sympy_expr(pid.numel)

        def l2_grouping() -> int:
            raw = DeviceFunction.current().config.get("l2_groupings", [1])
            if isinstance(raw, (list, tuple)):
                return int(str(raw[0])) if raw else 1
            return int(str(raw))

        # M and N are the trailing two PID axes; any leading axes are
        # passthrough (batch) that only offset memory (mirrors
        # ``_specialized_mma_root_mn_block_ids``), so read M/N from the tail
        # rather than positions 0/1. NOTE: the coord extraction below linearizes
        # over M/N only. Batched *partial*-tile edge splitting would also need
        # the leading passthrough factored out of the virtual pid; that is not a
        # validated path (the multi-tile guard restricts batched 2-CTA to static
        # full tiles, for which this predicate is true for every tile anyway).
        m_pid = self.pid_info[-2]
        n_pid = self.pid_info[-1]
        virtual_pid = self._tcgen05_linear_virtual_pid_expr(work_tile_var)
        num_pid_m = m_pid.num_pids_expr(is_device=True)
        l2_group = l2_grouping()
        cluster_n = self._tcgen05_cluster_n()
        if l2_group > 1 and cluster_n > 1:
            # Mirror ``L2GroupingProgramIDs.codegen``'s cluster-aware box
            # decode exactly: the predicate must classify tiles by the same
            # post-remap (pid_m, pid_n) the consumer decodes, or grouped PID
            # order sends fringe tiles down the full-tile TMA-store path.
            num_pid_n = n_pid.num_pids_expr(is_device=True)
            lane_n = (
                f"((({virtual_pid}) // ({num_pid_m})) % cutlass.Int32({cluster_n}))"
            )
            box_pid = (
                f"(((({virtual_pid}) // ({num_pid_m})) // cutlass.Int32({cluster_n}))"
                f" * ({num_pid_m}) + ({virtual_pid}) % ({num_pid_m}))"
            )
            num_box_n = (
                f"((({num_pid_n}) + cutlass.Int32({cluster_n - 1}))"
                f" // cutlass.Int32({cluster_n}))"
            )
            num_pid_in_group = f"cutlass.Int32({l2_group}) * ({num_box_n})"
            group_id = f"({box_pid}) // ({num_pid_in_group})"
            first_pid_m = f"({group_id}) * cutlass.Int32({l2_group})"
            group_size_m = (
                f"min(({num_pid_m}) - ({first_pid_m}), cutlass.Int32({l2_group}))"
            )
            m_coord = (
                f"({first_pid_m}) + "
                f"((({box_pid}) % ({num_pid_in_group})) % ({group_size_m}))"
            )
            n_coord = (
                f"(((({box_pid}) % ({num_pid_in_group})) // ({group_size_m}))"
                f" * cutlass.Int32({cluster_n}) + {lane_n})"
            )
        elif l2_group > 1:
            num_pid_n = n_pid.num_pids_expr(is_device=True)
            num_pid_in_group = f"cutlass.Int32({l2_group}) * ({num_pid_n})"
            group_id = f"({virtual_pid}) // ({num_pid_in_group})"
            first_pid_m = f"({group_id}) * cutlass.Int32({l2_group})"
            group_size_m = (
                f"min(({num_pid_m}) - ({first_pid_m}), cutlass.Int32({l2_group}))"
            )
            m_coord = (
                f"({first_pid_m}) + "
                f"((({virtual_pid}) % ({num_pid_in_group})) % ({group_size_m}))"
            )
            n_coord = f"(({virtual_pid}) % ({num_pid_in_group})) // ({group_size_m})"
        else:
            m_coord = f"({virtual_pid}) % ({num_pid_m})"
            n_coord = f"({virtual_pid}) // ({num_pid_m})"

        m_extent = pid_numel_expr(m_pid)
        n_extent = pid_numel_expr(n_pid)
        return (
            f"({m_coord}) * ({m_pid.block_size_var}) "
            f"+ ({m_pid.block_size_var}) <= ({m_extent}) "
            "and "
            f"({n_coord}) * ({n_pid.block_size_var}) "
            f"+ ({n_pid.block_size_var}) <= ({n_extent})"
        )

    def _require_tcgen05_plan(self) -> CuteTcgen05MatmulPlan:
        # ``Tcgen05PersistentProgramIDs`` is only instantiated when the kernel
        # selects tcgen05 MMA (see ``tile_strategy.select_pid_strategy``), and
        # ``cute_mma.py`` registers the matmul plan in that path before the
        # persistent kernel setup runs -- unless the MMA pipeline declined the
        # root thread layout (an explicit ``num_threads`` the role launch
        # cannot honour) and the matmul took the generic SIMT lowering, which
        # has no role warps for this scheduler to address.
        plan = self._tcgen05_plan()
        if plan is None:
            raise exc.BackendUnsupported(
                "cute",
                "the persistent tcgen05 pid_type requires the tcgen05 matmul "
                "plan, but the kernel's root thread layout took the generic "
                "SIMT lowering (an explicit num_threads the tcgen05 role "
                "launch cannot honour); use pid_type='flat' or 'xyz', or drop "
                "the explicit M-axis thread count",
            )
        return plan

    def _tcgen05_scheduler_owner_warp_expr(self) -> str:
        plan = self._require_tcgen05_plan()
        return (
            "cute.arch.make_warp_uniform(cute.arch.warp_idx()) "
            f"== cutlass.Int32({plan.persistent_scheduler_owner_warp_id})"
        )

    def _tcgen05_exec_warp_expr(self) -> str:
        plan = self._require_tcgen05_plan()
        return (
            "cute.arch.make_warp_uniform(cute.arch.warp_idx()) "
            f"== cutlass.Int32({plan.exec_warp_id})"
        )

    def _tcgen05_scheduler_store_leader_expr(self) -> str:
        return (
            f"({self._tcgen05_scheduler_owner_warp_expr()}) "
            "and cute.arch.lane_idx() == cutlass.Int32(0)"
        )

    def _tcgen05_cluster_scheduler_leader_expr(self) -> str:
        if self._tcgen05_cluster_m() <= 1:
            return self._tcgen05_scheduler_store_leader_expr()
        return (
            f"({self._tcgen05_scheduler_owner_warp_expr()}) "
            "and cute.arch.make_warp_uniform(cute.arch.block_idx_in_cluster()) == cutlass.Int32(0)"
        )

    def _retarget_tcgen05_shared_scheduler_to_exec(
        self, layout: Tcgen05PersistentProgramIDs._Tcgen05PersistentLayout
    ) -> None:
        """Make the shared persistent loop's scheduler live on the exec warp.

        Once the TMA-load warp is lifted into a role-local sibling loop, the
        scheduler should not ride on that producer role. The exec warp remains
        a single, always-launched warp, so it is a stable owner for the shared
        scheduler prelude and for any residual shared loop kept by validated
        cluster_m=1 or guarded fallback shapes.
        """
        exec_warp = self._tcgen05_exec_warp_expr()
        layout.scheduler_owner_warp = exec_warp
        layout.cluster_scheduler_leader = (
            f"({exec_warp}) "
            "and cute.arch.make_warp_uniform(cute.arch.block_idx_in_cluster()) == cutlass.Int32(0)"
        )
        layout.scheduler_leader_predicate = (
            layout.cluster_scheduler_leader if layout.cluster_m > 1 else exec_warp
        )

    def _tcgen05_store_work_tile_statements(
        self, work_tile_var: str, smem_var: str
    ) -> list[ast.stmt]:
        return [
            statement_from_string(
                f"{smem_var}[cutlass.Int32(0)] = {work_tile_var}.tile_idx[0]"
            ),
            statement_from_string(
                f"{smem_var}[cutlass.Int32(1)] = {work_tile_var}.tile_idx[1]"
            ),
            statement_from_string(
                f"{smem_var}[cutlass.Int32(2)] = {work_tile_var}.tile_idx[2]"
            ),
            statement_from_string(
                f"{smem_var}[cutlass.Int32(3)] = "
                f"(cutlass.Int32(1) if {work_tile_var}.is_valid_tile else cutlass.Int32(0))"
            ),
        ]

    def _tcgen05_scheduler_if(self, predicate: str, body: list[ast.stmt]) -> ast.If:
        return create(
            ast.If,
            test=expr_from_string(predicate),
            body=body,
            orelse=[],
        )

    def _tcgen05_tma_load_role_predicate(self) -> str:
        """Boolean expression that gates the TMA-load warp's role block.

        ``CuteTcgen05MatmulPlan.tma_warp_id`` is the launched-CTA warp
        index assigned to TMA load + (currently) the persistent
        scheduler. Match the tagging that ``cute_mma.py`` already emits
        (``f"{tma_warp} = {warp_idx} == cutlass.Int32({tma_warp_id})"``)
        so the predicate evaluates the same on every warp.
        """
        plan = self._tcgen05_plan()
        assert plan is not None, (
            "tcgen05 TMA-load role predicate requires a registered matmul plan"
        )
        return (
            "cute.arch.make_warp_uniform(cute.arch.warp_idx()) "
            f"== cutlass.Int32({plan.tma_warp_id})"
        )

    def _tcgen05_mma_exec_role_predicate(self) -> str:
        """Boolean expression that gates the MMA-exec warp's role block."""
        plan = self._tcgen05_plan()
        assert plan is not None, (
            "tcgen05 MMA-exec role predicate requires a registered matmul plan"
        )
        return (
            "cute.arch.make_warp_uniform(cute.arch.warp_idx()) "
            f"== cutlass.Int32({plan.exec_warp_id})"
        )

    def _tcgen05_epi_role_predicate(self) -> str:
        """Boolean expression that gates the epilogue warps' role block.

        Workstream A Stage 4 (cycle 93, Path B shared-loop split): when the
        matmul plan carries a store warp (``has_store_warp``), the predicate
        is WIDENED to also admit ``store_warp_id`` so the store warp runs the
        SAME epilogue role-local while as the 4 epi warps — sharing the
        descriptor/SMEM/layout setup and the sched-consumer + subtile loop
        (no re-derivation; this is what makes Path B cheap vs the independent
        store-warp loop of Path A). Inside the loop the per-subtile tail is
        split by warp role with inline gates emitted in the tail source
        (``memory_ops._codegen_cute_store_tcgen05_tile``): the 4 epi warps
        (``epi_active`` = ``warp_idx < epi_warp_count``) own T2R/R2S + the
        C-store producer commit, and the store warp (``warp_idx ==
        store_warp_id``) owns the consumer-wait + TMA-D + consumer-release
        drain. When ``store_warps=0`` the predicate is the historical
        ``warp_idx < epi_warp_count`` and codegen is byte-identical.
        """
        plan = self._tcgen05_plan()
        assert plan is not None, (
            "tcgen05 epilogue role predicate requires a registered matmul plan"
        )
        epi_predicate = (
            "cute.arch.make_warp_uniform(cute.arch.warp_idx()) "
            f"< cutlass.Int32({plan.epi_warp_count})"
        )
        if not plan.has_store_warp:
            return epi_predicate
        return (
            f"({epi_predicate} or "
            "cute.arch.make_warp_uniform(cute.arch.warp_idx()) "
            f"== cutlass.Int32({plan.store_warp_id}))"
        )

    def _tcgen05_scheduler_role_predicate(self) -> str:
        """Boolean expression that gates the scheduler warp's role block.

        Active under ``ROLE_LOCAL_WITH_SCHEDULER`` only; gating is
        ``warp_idx == scheduler_warp_id`` against the dedicated warp
        the matmul plan reserves for centralized tile scheduling.
        """
        plan = self._tcgen05_plan()
        assert plan is not None and plan.has_scheduler_warp, (
            "tcgen05 scheduler role predicate requires a matmul plan "
            "with has_scheduler_warp=True"
        )
        return (
            "cute.arch.make_warp_uniform(cute.arch.warp_idx()) "
            "== cutlass.Int32(plan.scheduler_warp_id)".replace(
                "plan.scheduler_warp_id", str(plan.scheduler_warp_id)
            )
        )

    def _tcgen05_c_input_role_predicate(self) -> str:
        """Boolean expression that gates the C-input warp's role block.

        Active when the matmul plan has ``c_input_warp_count > 0``
        (``cute_plan.md`` §7.5.3.2). The C-input warp sits at warp
        id ``scheduler_warp_id + scheduler_warp_count`` — directly
        after the scheduler warp in the launched-CTA layout. Cycle 1
        of the producer-body split: the role-local while body is
        empty (consumer side still reads from GMEM in
        ``memory_ops._aux_subtile_load_source``); cycle 2 fills in
        the producer GMEM→SMEM cooperative copy, cycle 3 the
        consumer-side SMEM read flip.
        """
        plan = self._tcgen05_plan()
        assert plan is not None and plan.has_c_input_warp, (
            "tcgen05 C-input role predicate requires a matmul plan "
            "with has_c_input_warp=True"
        )
        return (
            "cute.arch.make_warp_uniform(cute.arch.warp_idx()) "
            f"== cutlass.Int32({plan.c_input_warp_id})"
        )

    def _split_tcgen05_invariant_setup(
        self, device_function: DeviceFunction, body: list[ast.stmt]
    ) -> tuple[list[ast.stmt], list[ast.stmt], list[ast.stmt]]:
        """Split the device-function prefix into hoisted setup vs per-tile body.

        Codegen has explicitly tagged the per-tile statements via
        ``cute_state.register_tcgen05_per_tile_stmts``. Everything else can be
        hoisted out of the work-tile loop. This matches Quack's pattern of
        building pipelines once per kernel and replaying state per tile.

        The PID decomposition emitted by ``_decompose_virtual_pid``
        references ``virtual_pid_var`` (defined in the loop header) and
        produces ``pid_0``, ``pid_1`` etc. that are then consumed by
        downstream offset computations. To capture this transitive
        dependency without plumbing tagging through every codegen path, we
        do a single forward pass: seed the per-tile name set with
        ``virtual_pid_var``; any statement that reads or writes a per-tile
        name is itself per-tile, and any names it assigns become per-tile
        too.
        """
        cute_state = device_function.cute_state
        if not cute_state.has_tcgen05_per_tile_marks:
            return [], [], body

        per_tile_names: set[str] = {self.virtual_pid_var}
        hoisted: list[ast.stmt] = []
        epi_role_prelude: list[ast.stmt] = []
        wrapped: list[ast.stmt] = []
        for stmt in body:
            if cute_state.is_tcgen05_epi_role_prelude(stmt):
                epi_role_prelude.append(stmt)
                continue
            reads, writes = _stmt_name_uses(stmt)
            is_per_tile = (
                cute_state.is_tcgen05_per_tile(stmt)
                or bool(reads & per_tile_names)
                or bool(writes & per_tile_names)
            )
            if is_per_tile:
                per_tile_names.update(writes)
                wrapped.append(stmt)
            else:
                hoisted.append(stmt)
        return hoisted, epi_role_prelude, wrapped

    def _collect_tcgen05_role_blocks(
        self, device_function: DeviceFunction, body: list[ast.stmt]
    ) -> list[Tcgen05PersistentProgramIDs._PersistentRoleBlock]:
        """Partition the per-tile body into warp-role blocks (inline weave).

        Thin wrapper around :meth:`_partition_tcgen05_role_blocks` that
        flattens the partitioned result back into a single linear sequence
        of role blocks preserving the original body's emit order. This is
        the legacy producer used by
        :meth:`_build_tcgen05_persistent_tile_body` for the single-shared-
        ``while`` path -- TMA-load role blocks become inline
        ``if {tma_warp_predicate}: ...`` wrappers in their original
        positions inside the per-tile body.

        See :meth:`_partition_tcgen05_role_blocks` for the lower-level
        contract that the role-local-while consumer in
        :meth:`_build_tcgen05_persistent_tile_body_role_local` consumes
        directly.
        """
        partition = self._partition_tcgen05_role_blocks(device_function, body)
        return partition.role_blocks_inline

    def _partition_tcgen05_role_blocks(
        self, device_function: DeviceFunction, body: list[ast.stmt]
    ) -> Tcgen05PersistentProgramIDs._PartitionedRoleBody:
        """Walk the per-tile body and produce a structured role-block partition.

        Returns a :class:`_PartitionedRoleBody` carrying:

        - ``role_blocks_inline``: the legacy linear sequence of role
          blocks preserving the original emit order. Top-level
          role-tagged statements stay sandwiched between shared blocks
          here, ready for the inline-weave consumer to wrap them in
          ``if {role_predicate}: ...``.
        - ``role_blocks_extracted``: each non-shared role block as a
          standalone unit, decoupled from any surrounding shared
          statements. The extract-and-remove consumer in
          :meth:`_build_tcgen05_persistent_tile_body_role_local` lifts
          these into role-local ``while`` loops.
        - ``shared_body_extracted``: the original ``body`` with every
          top-level tagged statement removed. The extract consumer
          weaves this into the shared ``while`` while the extracted
          role blocks fill the role-local ``while`` siblings.

        The producer walks the body in order. Each maximal run of
        consecutive statements tagged for the same role is collapsed into
        a role block gated by that role's warp predicate. Everything else
        lives in the surrounding shared blocks. This preserves the
        original emit order for the inline view: role-tagged statements
        sandwiched between shared statements stay sandwiched, only wrapped
        in a role-gate ``if``. The extracted view removes top-level role
        blocks from the shared body and emits them as role-local sibling
        ``while`` loops.

        Some tagged statements still gate themselves on role predicates
        inline. In the inline view that is functionally redundant with the
        outer role-block ``if``. In the extracted role-local path, newly
        split producer / exec K-loops can drop those inline gates because
        the enclosing role-local ``while`` already restricts execution.

        When no role tags are present, the producer returns a single
        shared block carrying the full body. This is the non-tcgen05 path,
        the universal-MMA path, and any kernel that never registers role
        tags. The consumer
        (``_build_tcgen05_persistent_tile_body``) handles the
        single-block case identically to the pre-split implementation.

        **Nested tags inside top-level loops.** The K-loop's per-iter
        role blocks can be emitted INSIDE the K-loop body via
        ``cg.add_statement(...)``, so they are not top-level statements
        of the per-tile body. Tagged statements found inside top-level
        ``for`` / ``while`` loop bodies get rewritten in place: each
        tagged child statement is wrapped with
        ``if {role_predicate}: <child>`` so the role gate is visible in
        the generated source. This legacy inline path is still used for
        shapes that do not enter the role-local static-full path.

        Recursion is intentionally one level deep: the K-loop is the
        only top-level loop the role partitioner needs to reach into
        today, and a one-level recursion keeps the code simple. If
        future codegen places tagged statements inside nested loops the
        recursion can be deepened then.
        """
        tma_load_predicate = self._tcgen05_tma_load_role_predicate()
        mma_exec_predicate = self._tcgen05_mma_exec_role_predicate()
        epi_predicate = self._tcgen05_epi_role_predicate()
        cute_state = device_function.cute_state
        role_predicates_by_id: dict[int, str] = {}
        for stmt_id in cute_state.tcgen05_tma_load_role_stmt_ids:
            role_predicates_by_id[stmt_id] = tma_load_predicate
        for stmt_id in cute_state.tcgen05_mma_exec_role_stmt_ids:
            assert stmt_id not in role_predicates_by_id, (
                "tcgen05 role statement registered for multiple warp roles"
            )
            role_predicates_by_id[stmt_id] = mma_exec_predicate
        for stmt_id in cute_state.tcgen05_epi_role_stmt_ids:
            assert stmt_id not in role_predicates_by_id, (
                "tcgen05 role statement registered for multiple warp roles"
            )
            role_predicates_by_id[stmt_id] = epi_predicate

        if not role_predicates_by_id:
            single = self._PersistentRoleBlock(role_predicate=None, stmts=list(body))
            return self._PartitionedRoleBody(
                role_blocks_inline=[single],
                role_blocks_extracted=[],
                shared_body_extracted=list(body),
            )

        inline_blocks: list[Tcgen05PersistentProgramIDs._PersistentRoleBlock] = []
        extracted_blocks: list[Tcgen05PersistentProgramIDs._PersistentRoleBlock] = []
        shared_body_extracted: list[ast.stmt] = []
        current_shared: list[ast.stmt] = []
        current_role_predicate: str | None = None
        current_role_stmts: list[ast.stmt] = []
        # Track every role-tag id the partitioner consumes so we can
        # detect a registered tag that never landed in a role block --
        # i.e. a top-level tag that was hoisted out of the work-tile
        # body before the partitioner ran, or a tag buried in a
        # container the recursion does not enter (anything other than
        # a top-level ``for`` / ``while``). Either case would silently
        # drop the role gate, so we assert below.
        visited_role_ids: set[int] = set()

        def role_predicate_for(stmt: ast.stmt) -> str | None:
            return role_predicates_by_id.get(id(stmt))

        def flush_shared() -> None:
            if current_shared:
                inline_blocks.append(
                    self._PersistentRoleBlock(
                        role_predicate=None, stmts=list(current_shared)
                    )
                )
                current_shared.clear()

        def flush_role() -> None:
            nonlocal current_role_predicate
            if current_role_stmts:
                assert current_role_predicate is not None
                # The inline view holds the role block in its original
                # position so the inline-weave consumer keeps the
                # defines-before-uses invariant unchanged. The extracted
                # view holds a structurally-separated copy of the same
                # statements so the role-local-while consumer can lift
                # them into a sibling ``while`` without disturbing the
                # shared body's order.
                inline_blocks.append(
                    self._PersistentRoleBlock(
                        role_predicate=current_role_predicate,
                        stmts=list(current_role_stmts),
                    )
                )
                extracted_blocks.append(
                    self._PersistentRoleBlock(
                        role_predicate=current_role_predicate,
                        stmts=list(current_role_stmts),
                    )
                )
                current_role_stmts.clear()
                current_role_predicate = None

        def wrap_nested_role_in_for_or_while(stmt: ast.stmt) -> None:
            """Walk a top-level ``for`` / ``while`` body; wrap tagged
            children in ``if {role_predicate}: <child>``. Mutates the
            loop body in place so the loop emits with role gating in
            place of the original child."""
            if not isinstance(stmt, (ast.For, ast.While)):
                return
            new_body: list[ast.stmt] = []
            for child in stmt.body:
                child_predicate = role_predicate_for(child)
                if child_predicate is not None:
                    visited_role_ids.add(id(child))
                    new_body.append(
                        create(
                            ast.If,
                            test=expr_from_string(child_predicate),
                            body=[child],
                            orelse=[],
                        )
                    )
                else:
                    new_body.append(child)
            stmt.body = new_body

        for stmt in body:
            role_predicate = role_predicate_for(stmt)
            if role_predicate is not None:
                flush_shared()
                visited_role_ids.add(id(stmt))
                if (
                    current_role_predicate is not None
                    and current_role_predicate != role_predicate
                ):
                    flush_role()
                current_role_predicate = role_predicate
                current_role_stmts.append(stmt)
            else:
                flush_role()
                wrap_nested_role_in_for_or_while(stmt)
                current_shared.append(stmt)
                shared_body_extracted.append(stmt)
        flush_shared()
        flush_role()

        registered_role_ids = frozenset(role_predicates_by_id)
        missed_ids = registered_role_ids - visited_role_ids
        assert not missed_ids, (
            f"{len(missed_ids)} tcgen05 role-tagged statement(s) were "
            "registered but not visited by the role partitioner. Top-level "
            "tagged stmts must also be per-tile-registered (otherwise the "
            "splitter hoists them out of the work-tile body before the "
            "partitioner runs); nested tagged stmts must be direct children "
            "of a top-level ``for`` / ``while`` in the per-tile body (the "
            "recursion is one level deep and does not enter ``if`` / other "
            "containers)."
        )
        return self._PartitionedRoleBody(
            role_blocks_inline=inline_blocks,
            role_blocks_extracted=extracted_blocks,
            shared_body_extracted=shared_body_extracted,
        )

    def _extract_tcgen05_post_loop_stmts(
        self, device_function: DeviceFunction, body: list[ast.stmt]
    ) -> tuple[list[ast.stmt], list[ast.stmt]]:
        """Pull post-loop tagged statements out of ``body``.

        Returns ``(remaining, post_loop)`` preserving relative order.

        Statements registered via ``cute_state.register_tcgen05_post_loop_stmts``
        belong after the persistent work-tile loop (one-shot drains:
        ``producer_tail``, TMEM dealloc, allocator setup). Without this
        extraction they would execute every tile, which wastes work and
        can corrupt pipeline state.
        """
        cute_state = device_function.cute_state
        if not cute_state.has_tcgen05_post_loop_marks:
            return body, []
        remaining: list[ast.stmt] = []
        post_loop: list[ast.stmt] = []
        for stmt in body:
            if cute_state.is_tcgen05_post_loop(stmt):
                post_loop.append(stmt)
            else:
                remaining.append(stmt)
        return remaining, post_loop

    # Host-side variable that binds the total-tile expression once so the
    # guard message can format it. Private name avoids user/host collisions.
    _MULTI_TILE_GUARD_TOTAL_VAR: ClassVar[str] = (
        "_helion_tcgen05_persistent_total_tiles"
    )

    # Error message body for the multi-tile guard. Kept as a class constant so
    # the test pin and the error path stay in sync. ``%d`` is filled in at
    # runtime with the bound total-tile count.
    _MULTI_TILE_GUARD_MESSAGE: ClassVar[str] = (
        "Helion CuTe persistent + tcgen05 currently supports runtime "
        "execution only for validated single-root static full tiles: "
        "tcgen05_cluster_m=1 or role-local CtaGroup.TWO "
        "tcgen05_cluster_m=2 with at most 256 K tiles. Partial K/M/N tile "
        "fallback shapes, CtaGroup.TWO shapes above the validated K-tile "
        "limit, multi-root kernels, and unvalidated cluster_m settings can "
        "produce wrong output, hang, or launch-fail. The kernel was launched "
        "with total_tiles=%d, which is outside the validated persistent "
        "scheduler set for this path. "
        'Use a non-persistent pid_type (e.g. "flat"), pick a single-root '
        "static-full-tile kernel with tcgen05_cluster_m=1, or pick a "
        "validated single-root static-full CtaGroup.TWO shape with at most "
        "256 K tiles."
    )

    def _emit_host_multi_tile_guard(
        self,
        device_function: DeviceFunction,
        host_total_pids_expr: str | None = None,
        guard_threshold: int | str = 1,
    ) -> None:
        """Emit a host-side guard against multi-tile execution.

        The single-root static full-tile role-local path has multi-tile
        runtime coverage for ``tcgen05_cluster_m == 1``. Validated static-full
        CtaGroup.TWO uses role-local scheduler loops over the capped persistent
        grid, so no multi-tile host guard is emitted for that set.
        Legacy non-role-local tcgen05 persistent kernels, multi-root kernels,
        cluster_m > 1 fallback configs, and CtaGroup.TWO configs above the
        validated K-tile cap still hit, or lack coverage for, wrong-output /
        hang / launch-failure modes, so this guard remains for those paths.
        Single-tile cluster_m=1 fallback shapes continue to run.

        The autotuner narrowing in
        ``ConfigSpec.narrow_tcgen05_autotune_to_validated_configs`` removes
        ``persistent_blocked`` / ``persistent_interleaved`` from the search
        space for tcgen05 BF16/FP16 matmuls, so this guard only fires for
        explicit user configs that bypass autotune.

        The threshold is intentionally ``total_tiles > 1`` for guarded
        cluster_m=1 single-root fallback paths. For cluster_m > 1 fallback and
        CtaGroup.TWO shapes above the K-tile cap this converts known launch,
        timeout, and wrong-output failures into a host error. Multi-root kernels use
        ``total_tiles > 0`` because the scheduler grid is derived from only the
        first root case; even one tile in a later case is unsafe.
        """
        host_total_pids = host_total_pids_expr
        if host_total_pids is None:
            host_total_pids = " * ".join(
                f"({pid.num_pids_expr(is_device=False)})" for pid in self.pid_info
            )
        if not host_total_pids:
            return
        # Bind the host-side total-tiles expression once so non-trivial pid-
        # count expressions are not duplicated in the emitted source.
        total_var = self._MULTI_TILE_GUARD_TOTAL_VAR
        device_function.codegen.host_statements.append(
            statement_from_string(f"{total_var} = {host_total_pids}")
        )
        # Use ``repr()`` so the literal survives ``statement_from_string``
        # placeholder parsing (``{word}`` is reserved); ``%d`` interpolates
        # the total-tile count at runtime.
        message_literal = repr(self._MULTI_TILE_GUARD_MESSAGE)
        guard = (
            f"if {total_var} > {guard_threshold}:\n"
            f"    raise RuntimeError({message_literal} % ({total_var},))"
        )
        device_function.codegen.host_statements.append(statement_from_string(guard))

    def _hoist_tcgen05_tma_role_block(
        self, setup: list[ast.stmt], anchor: ast.stmt
    ) -> None:
        """Move the TMA-load warp's role block right after ``anchor``.

        ``cute_mma`` decided ``tcgen05_hoist_tma_role`` (one tile per CTA) and
        recorded the anchor: the cluster ``pipeline_init_arrive`` on the
        clustered path, the mbarrier init fence on the plain merged-init path.
        The prefix's init wait (cluster wait or pipeline-init named barrier)
        is guarded to the other warps and the TMA-load role carries its own
        wait ahead of its first stage.  Everything the role block reads (TMA
        atoms, SMEM operand tensors, the AB pipeline and its producer state,
        multicast masks) is defined before the anchor; the TMEM allocation
        and the other roles follow it unchanged.
        """
        anchor_index = next(index for index, stmt in enumerate(setup) if stmt is anchor)
        tma_predicate = self._tcgen05_tma_load_role_predicate()
        role_indices = [
            index
            for index, stmt in enumerate(setup)
            if index > anchor_index
            and isinstance(stmt, ast.If)
            and ast.unparse(stmt.test) == tma_predicate
        ]
        assert len(role_indices) == 1, (
            "tcgen05 TMA-role hoist expects exactly one TMA-load role block "
            f"after the cluster arrive, found {len(role_indices)}"
        )
        role_block = setup.pop(role_indices[0])
        setup.insert(anchor_index + 1, role_block)

    def _setup_tcgen05_persistent_kernel(
        self,
        device_function: DeviceFunction,
    ) -> list[ast.stmt]:
        wrapped_body = cast("list[ast.stmt]", list(device_function.body))
        multi_root_pid = device_function.pid
        is_multi_root = isinstance(multi_root_pid, ForEachProgramID)
        host_guard_total_pids = None
        if is_multi_root:
            assert isinstance(multi_root_pid, ForEachProgramID)
            shared_pid_var = multi_root_pid.shared_pid_var
            host_guard_total_pids = multi_root_pid.total_pids_expr(is_device=False)
            wrapped_body = [
                statement_from_string(f"{shared_pid_var} = {self.virtual_pid_var}"),
                *wrapped_body,
            ]
        # Order matters: pull post-loop cleanup out FIRST so the per-tile
        # splitter never has a chance to trace those statements into the
        # work-tile body via name propagation. Reversing this would re-
        # introduce the dominance-error class of bugs that motivated the
        # post-loop tag.
        wrapped_body, post_loop_stmts = self._extract_tcgen05_post_loop_stmts(
            device_function, wrapped_body
        )
        hoisted_setup, epi_role_prelude_stmts, wrapped_body = (
            self._split_tcgen05_invariant_setup(device_function, wrapped_body)
        )

        layout = self._build_tcgen05_persistent_layout(device_function)
        partition = self._partition_tcgen05_role_blocks(device_function, wrapped_body)
        use_role_local_body = bool(partition.role_blocks_extracted)
        role_local_predicates = {
            role_block.role_predicate
            for role_block in partition.role_blocks_extracted
            if role_block.role_predicate is not None
        }
        has_all_role_local_bodies = {
            self._tcgen05_tma_load_role_predicate(),
            self._tcgen05_mma_exec_role_predicate(),
            self._tcgen05_epi_role_predicate(),
        }.issubset(role_local_predicates)
        use_validated_cluster_m1_role_local_body = (
            use_role_local_body and layout.cluster_m == 1 and not is_multi_root
        )
        use_validated_two_cta_role_local_body = (
            has_all_role_local_bodies
            and layout.cluster_m == 2
            and self._tcgen05_has_validated_role_local_two_cta_runtime()
            and not is_multi_root
        )
        use_validated_role_local_body = (
            use_validated_cluster_m1_role_local_body
            or use_validated_two_cta_role_local_body
        )
        # Once all three work-producing roles own independent persistent
        # schedulers, a single-root kernel no longer needs the shared scheduler
        # for progress. Whether its loop can actually disappear is decided
        # separately from the generated residual body's meaningful work.
        can_omit_shared_scheduler = has_all_role_local_bodies and not is_multi_root
        omit_shared_loop = (
            can_omit_shared_scheduler
            and not self._tcgen05_shared_loop_has_meaningful_work(
                partition, post_loop_stmts
            )
        )
        if (
            use_validated_role_local_body
            and not omit_shared_loop
            and not self._tcgen05_uses_grouped_static_persistent()
        ):
            # The residual statements would run in a second, shared
            # work-tile loop after the role-local ones, and that launch hangs
            # (even for one constant store).  Running them in the epilogue
            # role's loop instead would have to replace the shared loop's
            # CTA-wide barriers; refuse until it does.
            raise exc.BackendUnsupported(
                "cute",
                "a statement beside the warp roles of a persistent tcgen05 "
                "matmul would run in a shared work-tile loop after them, "
                "which hangs; use a non-persistent pid_type",
            )
        if self._tcgen05_uses_staged_work_tile_mailbox() and not omit_shared_loop:
            raise exc.InvalidConfig(
                f"{TCGEN05_SCHED_STAGE_COUNT_CONFIG_KEY}=2 requires omitted "
                "shared-loop full role-local scheduler codegen"
            )
        if use_role_local_body:
            # Retarget even for guarded cluster_m>1 / multi-root codegen so
            # compile-only inspection still sees the role-local scheduler shape.
            self._retarget_tcgen05_shared_scheduler_to_exec(layout)
        if not use_validated_role_local_body:
            guard_threshold: int | str
            if is_multi_root:
                guard_threshold = 0
            elif layout.cluster_m == 1:
                guard_threshold = 1
            else:
                # cluster_m > 2, cluster_m=2 without the full role-local body,
                # and role-local CtaGroup.TWO above the K-tile cap all use the
                # strict guard.
                guard_threshold = 0
            self._emit_host_multi_tile_guard(
                device_function,
                host_guard_total_pids,
                guard_threshold=guard_threshold,
            )

        setup: list[ast.stmt] = []
        # Fully role-local codegen does not consume the shared work-tile SMEM
        # handoff. Each role owns a scheduler loop over the capped persistent
        # grid, so validated cluster_m=1 and CtaGroup.TWO skip the shared
        # scheduler and residual loop.
        if not omit_shared_loop:
            setup.extend(self._build_tcgen05_persistent_prelude(layout))
        elif self._tcgen05_has_scheduler_warp():
            # ``ROLE_LOCAL_WITH_SCHEDULER`` skips the shared loop but
            # *does* need the per-CTA work-tile SMEM mailbox: the
            # scheduler warp publishes per-tile coords there and
            # consumer warps read them after ``consumer_wait``.
            setup.extend(
                self._build_tcgen05_work_tile_smem_alloc(layout, staged_ok=True)
            )
        setup.extend(hoisted_setup)
        if use_role_local_body:
            if omit_shared_loop:
                role_local_whiles, shared_tile_body = (
                    self._build_tcgen05_persistent_tile_body_role_local(
                        device_function,
                        layout,
                        partition,
                        build_shared_tile_body=False,
                        epi_role_prelude_stmts=epi_role_prelude_stmts,
                        post_loop_stmts=post_loop_stmts,
                    )
                )
            else:
                role_local_whiles, shared_tile_body = (
                    self._build_tcgen05_persistent_tile_body_role_local(
                        device_function,
                        layout,
                        partition,
                        epi_role_prelude_stmts=epi_role_prelude_stmts,
                    )
                )
            setup.extend(role_local_whiles)
            hoist_anchor = device_function.cute_state.tcgen05_tma_role_hoist_anchor
            if hoist_anchor is not None:
                self._hoist_tcgen05_tma_role_block(setup, hoist_anchor)
            if not omit_shared_loop:
                # Partial and multi-root role-local shapes still rejoin the
                # shared loop. Validated fully role-local codegen skips this
                # residual loop; its work is already owned by role-local
                # schedulers and cross-role pipelines.
                setup.append(
                    create(
                        ast.While,
                        test=expr_from_string(layout.work_tile_valid_var),
                        body=shared_tile_body,
                        orelse=[],
                    )
                )
        else:
            setup.append(
                create(
                    ast.While,
                    test=expr_from_string(layout.work_tile_valid_var),
                    body=self._build_tcgen05_persistent_tile_body(
                        layout, partition.role_blocks_inline
                    ),
                    orelse=[],
                )
            )
        setup.extend(post_loop_stmts)
        return setup

    @dataclasses.dataclass
    class _PersistentRoleBlock:
        """One warp-role's contribution to the per-tile work-tile body.

        Each role block carries the statements that conceptually belong
        to one warp role (TMA-load / MMA-exec / epi / scheduler), plus a
        ``role_predicate`` boolean expression that evaluates true on the
        warps that should run those statements. ``role_predicate is
        None`` denotes a "shared" block that runs on every warp -- this
        is the default for kernel statements that have no explicit role
        tag (e.g. PID decomposition, offset compute, cross-role
        ``cute.arch.sync_threads()`` calls).

        The legacy consumer
        (:meth:`_build_tcgen05_persistent_tile_body`) emits each role
        block sequentially inside the single shared work-tile ``while``:
        shared blocks become naked statements, role-gated blocks become
        ``if {role_predicate}: ...`` wrappers. This is functionally
        equivalent to the pre-split persistent body because every
        role-tagged statement was already gated on the same predicate
        inside its emit site (e.g. the initial TMA prefetch was already
        wrapped in ``if {tma_warp}:`` in ``cute_mma.py``).

        The role-local consumer
        (:meth:`_build_tcgen05_persistent_tile_body_role_local`) emits
        one role-local ``while`` per unique role predicate driven by
        its own scheduler instance. In the current mainloop-role
        intermediate, every
        warp still enters the shared body after any role-local work so
        existing CTA-wide ``cute.arch.sync_threads()`` barriers remain
        valid. The AB / acc pipelines carry producer-consumer ordering
        between the role-local TMA producer, role-local MMA exec, and
        shared epilogue consumer.
        """

        role_predicate: str | None
        stmts: list[ast.stmt]

    @dataclasses.dataclass
    class _PartitionedRoleBody:
        """Structured result of :meth:`_partition_tcgen05_role_blocks`.

        Carries three views of the same per-tile body so the inline-
        weave consumer and the role-local-while consumer can each pick
        the form that matches their emission shape:

        - ``role_blocks_inline``: the legacy linear sequence of role
          blocks preserving the original emit order. Top-level
          TMA-load-tagged statements appear sandwiched between shared
          blocks here, ready for the inline-weave consumer to wrap them
          in ``if {role_predicate}: ...``. When tagged statements are
          nested inside a top-level ``for`` / ``while``, the partitioner
          mutates the loop body in place to wrap the tagged child in an
          ``if {role_predicate}:``; the (now-mutated) loop appears in
          this view.
        - ``role_blocks_extracted``: each non-shared run of TMA-load-
          tagged top-level statements as a standalone block, decoupled
          from any surrounding shared statements. The role-local-while
          consumer lifts these into role-local ``while`` siblings.
          Nested tagged statements (inside top-level ``for`` / ``while``
          bodies) are NOT extracted; they stay inside their containing
          loop in ``role_blocks_inline`` / ``shared_body_extracted``.
        - ``shared_body_extracted``: the original ``body`` with every
          top-level tagged statement removed. Note that any top-level
          ``for`` / ``while`` containing nested tagged children appears
          here in its mutated (inline-wrapped) form, so this view is
          fully decoupled from ``role_blocks_extracted`` only when the
          partitioner did not need to recurse.

        The top-level lists are independent: mutating the elements list
        of one view does not affect another. The contained ``ast.stmt``
        nodes, however, are shared across views by reference -- mutating
        a node in place (e.g. wrapping it in an ``ast.If``) is visible
        from every view that references it. Consumers that need to
        rewrite an AST node should ``ast.copy_location`` / construct a
        fresh node rather than mutate in place.
        """

        role_blocks_inline: list[Tcgen05PersistentProgramIDs._PersistentRoleBlock]
        role_blocks_extracted: list[Tcgen05PersistentProgramIDs._PersistentRoleBlock]
        shared_body_extracted: list[ast.stmt]

    @dataclasses.dataclass
    class _Tcgen05PersistentLayout:
        """Variables and predicates threaded through the persistent kernel.

        The layout is materialised once per kernel and shared between the
        prelude (pre-loop init) and the per-tile body. Cluster-only
        fields are unused when ``cluster_m == 1``.
        """

        cluster_m: int
        scheduler_owner_warp: str
        cluster_scheduler_leader: str
        consumer_leader_var: str
        scheduler_leader_predicate: str
        tile_sched_params_var: str
        tile_sched_var: str
        work_tile_var: str
        work_tile_smem_ptr: str
        work_tile_smem: str
        work_tile_smem_tensor: str
        work_tile_coord_vars: list[str]
        work_tile_valid_var: str
        linear_pid_expr: str
        sched_pipeline_mbars: str
        sched_pipeline: str
        sched_pipeline_producer_group: str
        sched_pipeline_consumer_group: str
        sched_producer_state: str
        sched_consumer_state: str
        sched_barrier_ptr: str
        sched_peer_rank: str
        sched_peer_m: str
        refresh_work_tile_stmts: list[ast.stmt]
        work_tile_publish_stmts: list[ast.stmt]
        work_tile_consume_stmts: list[ast.stmt]
        work_tile_release_stmts: list[ast.stmt]
        # ``cluster_n`` is the multicast factor along the cluster N axis;
        # default 1 keeps every existing test (and the cluster_n=1 byte-
        # identity golden) unchanged. Threaded through to the launch grid
        # / scheduler params when cluster_n>1 (cute_plan.md §6.12.7).
        cluster_n: int = 1

    def _build_tcgen05_persistent_layout(
        self, device_function: DeviceFunction
    ) -> _Tcgen05PersistentLayout:
        """Allocate persistent-kernel variables and build the work-tile
        publish/consume/release/refresh statement helpers shared between
        the prelude and the per-tile body.
        """
        cluster_m = self._tcgen05_cluster_m()
        tile_sched_params_var = device_function.new_var("tcgen05_tile_sched_params")
        tile_sched_var = device_function.new_var("tcgen05_tile_sched")
        work_tile_var = device_function.new_var("tcgen05_work_tile")
        work_tile_smem_ptr = device_function.new_var("tcgen05_work_tile_smem_ptr")
        work_tile_smem = device_function.new_var("tcgen05_work_tile_smem")
        work_tile_smem_tensor = device_function.new_var("tcgen05_work_tile_smem_tensor")
        work_tile_coord_vars = [
            device_function.new_var(f"tcgen05_work_tile_idx_{i}") for i in range(3)
        ]
        work_tile_valid_var = device_function.new_var("tcgen05_work_tile_valid")
        scheduler_owner_warp = self._tcgen05_scheduler_owner_warp_expr()
        cluster_scheduler_leader = self._tcgen05_cluster_scheduler_leader_expr()
        consumer_leader_var = device_function.new_var("tcgen05_sched_consumer_leader")
        scheduler_leader_predicate = (
            cluster_scheduler_leader if cluster_m > 1 else scheduler_owner_warp
        )
        coord_terms, pair_axis = self._tcgen05_mailbox_coord_terms(work_tile_coord_vars)
        linear_pid_expr = self._tcgen05_linear_virtual_pid_from_coords_expr(
            coord_terms, pair_axis=pair_axis
        )
        sched_pipeline_mbars = device_function.new_var("tcgen05_sched_pipeline_mbars")
        sched_pipeline = device_function.new_var("tcgen05_sched_pipeline")
        sched_pipeline_producer_group = device_function.new_var(
            "tcgen05_sched_pipeline_producer_group"
        )
        sched_pipeline_consumer_group = device_function.new_var(
            "tcgen05_sched_pipeline_consumer_group"
        )
        sched_producer_state = device_function.new_var("tcgen05_sched_producer_state")
        sched_consumer_state = device_function.new_var("tcgen05_sched_consumer_state")
        sched_barrier_ptr = device_function.new_var("tcgen05_sched_barrier_ptr")
        sched_peer_rank = device_function.new_var("tcgen05_sched_peer_rank")
        sched_peer_m = device_function.new_var("tcgen05_sched_peer_m")

        refresh_work_tile: list[ast.stmt] = [
            statement_from_string(f"{coord_var} = {work_tile_smem}[cutlass.Int32({i})]")
            for i, coord_var in enumerate(work_tile_coord_vars)
        ]
        refresh_work_tile.append(
            statement_from_string(
                f"{work_tile_valid_var} = "
                f"{work_tile_smem}[cutlass.Int32(3)] != cutlass.Int32(0)"
            )
        )

        if cluster_m > 1:
            work_tile_publish: list[ast.stmt] = [
                statement_from_string(
                    f"{sched_pipeline}.producer_acquire({sched_producer_state})"
                ),
                # The shared-loop scheduler bridge remains one-stage: its
                # mailbox is a single 4-Int32 tuple, so the producer arms the
                # consumer-state full mbarrier before the remote stores.
                # Staged mailboxes are only used after the shared loop is
                # omitted in the CLC role-local scheduler path.
                statement_from_string(
                    f"{sched_barrier_ptr} = "
                    f"{sched_pipeline}.producer_get_barrier({sched_consumer_state})"
                ),
                statement_from_string(f"{sched_peer_rank} = cute.arch.lane_idx()"),
                create(
                    ast.If,
                    test=expr_from_string(
                        f"{sched_peer_rank} < cutlass.Int32({cluster_m})"
                    ),
                    body=[
                        statement_from_string(f"{sched_peer_m} = {sched_peer_rank}"),
                        # _cute_store_shared_remote_x4 writes four Int32
                        # values, so each remote async transaction expects
                        # 16 bytes.
                        statement_from_string(
                            "cute.arch.mbarrier_arrive_and_expect_tx("
                            f"{sched_barrier_ptr}, 16, {sched_peer_rank})"
                        ),
                        statement_from_string(
                            f"_cute_store_shared_remote_x4("
                            f"{work_tile_var}.tile_idx[0] + {sched_peer_m}, "
                            f"{work_tile_var}.tile_idx[1], "
                            f"{work_tile_var}.tile_idx[2], "
                            f"(cutlass.Int32(1) if {work_tile_var}.is_valid_tile else cutlass.Int32(0)), "
                            f"smem_ptr={work_tile_smem_ptr}, "
                            f"mbar_ptr={sched_barrier_ptr}, "
                            f"peer_cta_rank_in_cluster={sched_peer_rank})"
                        ),
                    ],
                    orelse=[],
                ),
                statement_from_string(emit_pipeline_advance(sched_producer_state)),
            ]
            work_tile_consume: list[ast.stmt] = [
                statement_from_string(
                    f"{sched_pipeline}.consumer_wait({sched_consumer_state})"
                ),
            ]
            work_tile_release: list[ast.stmt] = [
                statement_from_string(
                    f"{sched_pipeline}.consumer_release({sched_consumer_state})"
                ),
                statement_from_string(emit_pipeline_advance(sched_consumer_state)),
            ]
        else:
            work_tile_publish = self._tcgen05_store_work_tile_statements(
                work_tile_var, work_tile_smem
            )
            work_tile_consume = []
            work_tile_release = []

        return self._Tcgen05PersistentLayout(
            cluster_m=cluster_m,
            cluster_n=self._tcgen05_cluster_n(),
            scheduler_owner_warp=scheduler_owner_warp,
            cluster_scheduler_leader=cluster_scheduler_leader,
            consumer_leader_var=consumer_leader_var,
            scheduler_leader_predicate=scheduler_leader_predicate,
            tile_sched_params_var=tile_sched_params_var,
            tile_sched_var=tile_sched_var,
            work_tile_var=work_tile_var,
            work_tile_smem_ptr=work_tile_smem_ptr,
            work_tile_smem=work_tile_smem,
            work_tile_smem_tensor=work_tile_smem_tensor,
            work_tile_coord_vars=work_tile_coord_vars,
            work_tile_valid_var=work_tile_valid_var,
            linear_pid_expr=linear_pid_expr,
            sched_pipeline_mbars=sched_pipeline_mbars,
            sched_pipeline=sched_pipeline,
            sched_pipeline_producer_group=sched_pipeline_producer_group,
            sched_pipeline_consumer_group=sched_pipeline_consumer_group,
            sched_producer_state=sched_producer_state,
            sched_consumer_state=sched_consumer_state,
            sched_barrier_ptr=sched_barrier_ptr,
            sched_peer_rank=sched_peer_rank,
            sched_peer_m=sched_peer_m,
            refresh_work_tile_stmts=refresh_work_tile,
            work_tile_publish_stmts=work_tile_publish,
            work_tile_consume_stmts=work_tile_consume,
            work_tile_release_stmts=work_tile_release,
        )

    def _build_tcgen05_work_tile_smem_alloc(
        self, layout: _Tcgen05PersistentLayout, *, staged_ok: bool = False
    ) -> list[ast.stmt]:
        """Allocate the per-CTA work-tile SMEM mailbox.

        This stores the work-tile coordinates and validity sentinel, plus
        grouped metadata fields when that scheduler requires them, optionally
        repeated per scheduler stage. Both the cluster_m=2 ONE-CTA bridge path
        and ``ROLE_LOCAL_WITH_SCHEDULER`` use this storage, so the allocation
        is pulled out of
        ``_build_tcgen05_persistent_prelude`` (which is conditionally
        skipped when the residual shared loop is omitted) into its
        own helper that always runs when the work-tile mailbox is
        needed.
        """
        field_count = self._tcgen05_work_tile_mailbox_field_count()
        if self._tcgen05_uses_staged_work_tile_mailbox():
            assert staged_ok, (
                "staged work-tile mailbox requires omitted shared-loop "
                "role-local scheduler codegen"
            )
            plan = self._tcgen05_plan()
            assert plan is not None and plan.is_clc_persistent and plan.cluster_m > 1, (
                "staged work-tile mailbox is only validated for clustered CLC"
            )
            stage_count = self._tcgen05_sched_stage_count()
            alloc_extent = f"cutlass.Int32({field_count * stage_count})"
            layout_expr = (
                f"cute.make_layout(({field_count}, {stage_count}), "
                f"stride=(1, {field_count}))"
            )
        else:
            alloc_extent = str(field_count)
            layout_expr = f"cute.make_layout(({field_count},), stride=(1,))"
        return [
            statement_from_string(
                f"{layout.work_tile_smem_ptr} = cute.arch.alloc_smem("
                f"cutlass.Int32, {alloc_extent}, alignment=16)"
            ),
            statement_from_string(
                f"{layout.work_tile_smem_tensor} = cute.make_tensor("
                f"{layout.work_tile_smem_ptr}, {layout_expr})"
            ),
            statement_from_string(
                f"{layout.work_tile_smem} = {layout.work_tile_smem_tensor}"
            ),
        ]

    def _build_tcgen05_persistent_prelude(
        self, layout: _Tcgen05PersistentLayout
    ) -> list[ast.stmt]:
        """Pre-loop init: allocate SMEM, set up the tile scheduler, fetch
        the initial work tile, and publish/consume it so every warp sees
        a coherent first tile.
        """
        prelude: list[ast.stmt] = [
            statement_from_string(
                f"{layout.tile_sched_params_var} = cutlass.utils.PersistentTileSchedulerParams("
                f"{self._tcgen05_persistent_tile_sched_params_args(cluster_m=layout.cluster_m, cluster_n=layout.cluster_n)})"
            ),
            statement_from_string(
                f"{layout.tile_sched_var} = cutlass.utils.StaticPersistentTileScheduler.create("
                f"{layout.tile_sched_params_var}, cute.arch.block_idx(), cute.arch.grid_dim())"
            ),
            *self._build_tcgen05_work_tile_smem_alloc(layout),
        ]
        if layout.cluster_m > 1:
            prelude.extend(
                [
                    statement_from_string(
                        f"{layout.sched_pipeline_mbars} = cute.arch.alloc_smem(cutlass.Int64, cutlass.Int32(2))"
                    ),
                    # Only the scheduler leader CTA publishes each remote
                    # work tile, so every peer full barrier receives one
                    # arrive-and-expect-tx, not one arrival per cluster CTA.
                    statement_from_string(
                        f"{layout.sched_pipeline_producer_group} = cutlass.pipeline.CooperativeGroup("
                        "cutlass.pipeline.Agent.Thread, 1)"
                    ),
                    statement_from_string(
                        f"{layout.sched_pipeline_consumer_group} = cutlass.pipeline.CooperativeGroup("
                        f"cutlass.pipeline.Agent.Thread, {layout.cluster_m})"
                    ),
                    statement_from_string(
                        f"{layout.sched_pipeline} = cutlass.pipeline.PipelineAsync.create("
                        "num_stages=1, "
                        f"producer_group={layout.sched_pipeline_producer_group}, "
                        f"consumer_group={layout.sched_pipeline_consumer_group}, "
                        f"barrier_storage={layout.sched_pipeline_mbars}, "
                        "consumer_mask=cutlass.Int32(0), "
                        "defer_sync=True)"
                    ),
                    statement_from_string(
                        f"{layout.sched_producer_state} = cutlass.pipeline.make_pipeline_state("
                        "cutlass.pipeline.PipelineUserType.Producer, 1)"
                    ),
                    statement_from_string(
                        f"{layout.sched_consumer_state} = cutlass.pipeline.make_pipeline_state("
                        "cutlass.pipeline.PipelineUserType.Consumer, 1)"
                    ),
                    statement_from_string(
                        f"{layout.consumer_leader_var} = "
                        "cute.arch.make_warp_uniform(cute.arch.warp_idx()) == cutlass.Int32(0) "
                        "and cute.arch.lane_idx() == cutlass.Int32(0)"
                    ),
                    # ``PipelineAsync.create(..., defer_sync=True)`` initializes
                    # the mailbox mbarriers on each CTA's warp 0.  The cluster
                    # leader's scheduler warp can publish to a peer CTA
                    # immediately below, so a CTA-local sync is insufficient:
                    # every peer must finish its local mbarrier initialization
                    # before any remote arrive-and-expect-tx.  The main MMA
                    # pipelines perform their own later rendezvous after their
                    # setup; this earlier one protects the PID mailbox alone.
                    statement_from_string(
                        "cutlass.pipeline.pipeline_init_arrive("
                        "cluster_shape_mn=cute.make_layout("
                        f"({layout.cluster_m}, {layout.cluster_n}, 1)), "
                        "is_relaxed=True)"
                    ),
                    statement_from_string(
                        "cutlass.pipeline.pipeline_init_wait("
                        "cluster_shape_mn=cute.make_layout("
                        f"({layout.cluster_m}, {layout.cluster_n}, 1)))"
                    ),
                ]
            )
        else:
            prelude.append(
                statement_from_string(f"{layout.consumer_leader_var} = False")
            )
        prelude.append(
            self._tcgen05_scheduler_if(
                layout.scheduler_leader_predicate,
                [
                    statement_from_string(
                        f"{layout.work_tile_var} = {layout.tile_sched_var}.initial_work_tile_info()"
                    ),
                    *self._tcgen05_skip_padding_work(
                        layout.tile_sched_var, layout.work_tile_var
                    ),
                    *layout.work_tile_publish_stmts,
                ],
            )
        )
        if layout.cluster_m > 1:
            prelude.append(
                self._tcgen05_scheduler_if(
                    layout.consumer_leader_var,
                    list(layout.work_tile_consume_stmts),
                )
            )
        prelude.append(statement_from_string("cute.arch.sync_threads()"))
        if layout.cluster_m > 1:
            # Only the elected thread waits on the remote transaction, but
            # every mailbox reader crosses the async/shared proxy boundary.
            prelude.append(statement_from_string("cute.arch.fence_view_async_shared()"))
        prelude.extend(layout.refresh_work_tile_stmts)
        if layout.cluster_m > 1:
            # There is one release per CTA. Finish all readers, including the
            # terminal valid flag, before that arrival permits stage reuse.
            prelude.extend(
                [
                    statement_from_string("cute.arch.sync_threads()"),
                    self._tcgen05_scheduler_if(
                        layout.consumer_leader_var,
                        list(layout.work_tile_release_stmts),
                    ),
                ]
            )
        return prelude

    def _emit_role_block_stmts(
        self, role_block: Tcgen05PersistentProgramIDs._PersistentRoleBlock
    ) -> list[ast.stmt]:
        """Emit a role block's statements, gated on its role predicate.

        Shared blocks (``role_predicate is None``) emit naked
        statements -- there is no per-warp gating, every warp runs them.
        Role-gated blocks wrap their statements in ``if {predicate}:``
        so only the matching warps execute the body. An empty
        non-shared block emits nothing (no degenerate ``if {}:``).
        """
        if not role_block.stmts:
            return []
        if role_block.role_predicate is None:
            return list(role_block.stmts)
        return [
            create(
                ast.If,
                test=expr_from_string(role_block.role_predicate),
                body=list(role_block.stmts),
                orelse=[],
            )
        ]

    def _build_tcgen05_persistent_tile_body(
        self,
        layout: _Tcgen05PersistentLayout,
        role_blocks: list[Tcgen05PersistentProgramIDs._PersistentRoleBlock],
        *,
        emit_block_wide_sync: bool = True,
    ) -> list[ast.stmt]:
        """Per-tile body inside the single shared ``while``: run the
        user's kernel body (split into warp-role blocks), then advance
        the scheduler and refresh the published work tile so the next
        iteration sees the updated state.

        Role blocks are emitted in the order returned by
        ``_collect_tcgen05_role_blocks``, which preserves the original
        emit order of the per-tile body. TMA-load role blocks become
        ``if {tma_warp_predicate}: ...`` wrappers in place of the
        original tagged statements; shared blocks emit naked
        statements. The defines-before-uses invariant from the
        pre-split body carries through, so single-tile correctness is
        unchanged. Multi-tile remains gated by the host-side guard when
        this shared-only shape is used for the legacy non-role-local path.
        Static full-tile role-local kernels use sibling role-local loops
        and lift that guard only for validated ``cluster_m == 1`` configs.

        ``emit_block_wide_sync`` controls the per-tile
        ``cute.arch.sync_threads()`` (a CTA-wide barrier). The default
        ``True`` is correct for the current mainloop-role-local
        intermediate because every warp still enters this shared
        ``while`` after any role-local mainloop work. Passing ``False``
        is reserved for the later fully role-local shape where no
        role-local warp reaches the shared loop and the remaining work
        has a replacement non-CTA synchronization scheme. The clustered
        mailbox bridge requires CTA-wide read completion and rejects this
        option until such a replacement protocol is implemented.

        See :meth:`_build_tcgen05_persistent_tile_body_role_local` for
        the role-local-while consumer that lifts non-shared role blocks
        into sibling ``while`` loops.
        """
        if layout.cluster_m > 1 and not emit_block_wide_sync:
            raise exc.InvalidConfig(
                "Clustered scheduler mailbox refresh requires CTA-wide synchronization"
            )
        body: list[ast.stmt] = [
            statement_from_string(f"{self.virtual_pid_var} = {layout.linear_pid_expr}"),
        ]
        for role_block in role_blocks:
            body.extend(self._emit_role_block_stmts(role_block))
        body.append(
            self._tcgen05_scheduler_if(
                layout.scheduler_leader_predicate,
                [
                    statement_from_string(
                        f"{layout.tile_sched_var}.advance_to_next_work()"
                    ),
                    statement_from_string(
                        f"{layout.work_tile_var} = {layout.tile_sched_var}.get_current_work()"
                    ),
                    *self._tcgen05_skip_padding_work(
                        layout.tile_sched_var, layout.work_tile_var
                    ),
                    *layout.work_tile_publish_stmts,
                ],
            )
        )
        if layout.cluster_m > 1:
            body.append(
                self._tcgen05_scheduler_if(
                    layout.consumer_leader_var,
                    list(layout.work_tile_consume_stmts),
                )
            )
        if emit_block_wide_sync:
            body.append(statement_from_string("cute.arch.sync_threads()"))
        if layout.cluster_m > 1:
            body.append(statement_from_string("cute.arch.fence_view_async_shared()"))
        body.extend(layout.refresh_work_tile_stmts)
        if layout.cluster_m > 1:
            body.extend(
                [
                    statement_from_string("cute.arch.sync_threads()"),
                    self._tcgen05_scheduler_if(
                        layout.consumer_leader_var,
                        list(layout.work_tile_release_stmts),
                    ),
                ]
            )
        return body

    def _build_role_local_while(
        self,
        device_function: DeviceFunction,
        layout: _Tcgen05PersistentLayout,
        role_block: Tcgen05PersistentProgramIDs._PersistentRoleBlock,
        scheduler_var_prefix: str,
        dependency_stmts: list[ast.stmt] | None = None,
        role_prelude_stmts: list[ast.stmt] | None = None,
        *,
        emit_pdl_wait: bool = True,
        initialize_tile_counter: bool = True,
        store_aux_per_tile_stmts: list[ast.stmt] | None = None,
        store_aux_predicate: str | None = None,
    ) -> ast.stmt:
        """Build a role-local ``while`` for one extracted role block.

        Each role-local ``while`` carries its own ``StaticPersistentTileScheduler``
        instance constructed with the same cluster shape as the shared
        scheduler (``(layout.cluster_m, 1, 1)``) so the role-local
        scheduler iterates exactly the same tile sequence in the same
        order. The role-local loop body runs the role's statements once
        per tile, advances its own scheduler, and refreshes its own
        work-tile state.

        Cross-role producer-consumer synchronization is via the AB /
        acc pipelines (the existing pipeline barriers carry the data
        dependency); no ``cute.arch.sync_threads()`` is emitted inside
        the role-local loop. The caller decides whether to append a residual
        shared loop after these role-local loops. It is omitted when the
        residual shared body contains only cloned dependency setup and legacy
        barriers that no longer protect shared work.

        The returned statement is the role-local ``while`` itself,
        wrapped in ``if {role_predicate}:`` so only the matching warps
        enter the loop. The caller appends this statement inside the
        persistent kernel's setup list.

        ``scheduler_var_prefix`` selects the prefix for every variable
        name allocated in the role-local while (e.g.
        ``f"{prefix}_tile_sched"``). The caller threads a unique prefix
        per role so two role-local whiles do not collide on the same
        ``DeviceFunction.new_var`` namespace.
        """
        assert role_block.role_predicate is not None, (
            "_build_role_local_while requires a non-shared role block; "
            "shared blocks live in the shared while"
        )

        # ``ROLE_LOCAL_WITH_SCHEDULER`` reroutes the per-role body
        # through the broadcast pipeline. When active, the consumer
        # warp waits on the sched_pipeline, reads the published tile
        # metadata from SMEM, releases the sched stage, then runs its
        # role block.
        # The per-role ``StaticPersistentTileScheduler.create`` is
        # *not* emitted in this mode — the scheduler warp owns the
        # only tile scheduler.
        if (
            self._tcgen05_uses_grouped_worklist_nm_runtime_clc()
            or self._tcgen05_uses_grouped_worklist_nm_scheduler_mailbox()
        ):
            return self._build_grouped_worklist_nm_role_local_while(
                device_function,
                role_block,
                layout=layout,
                scheduler_var_prefix=scheduler_var_prefix,
                dependency_stmts=dependency_stmts,
                role_prelude_stmts=role_prelude_stmts,
                emit_pdl_wait=emit_pdl_wait,
                initialize_tile_counter=initialize_tile_counter,
            )
        if self._tcgen05_has_scheduler_warp():
            return self._build_role_local_while_with_scheduler(
                device_function,
                layout,
                role_block,
                scheduler_var_prefix=scheduler_var_prefix,
                dependency_stmts=dependency_stmts,
                role_prelude_stmts=role_prelude_stmts,
                emit_pdl_wait=emit_pdl_wait,
                initialize_tile_counter=initialize_tile_counter,
                store_aux_per_tile_stmts=store_aux_per_tile_stmts,
                store_aux_predicate=store_aux_predicate,
            )
        if self._tcgen05_uses_grouped_static_persistent():
            return self._build_grouped_static_role_local_while(
                device_function,
                role_block,
                scheduler_var_prefix=scheduler_var_prefix,
                dependency_stmts=dependency_stmts,
                role_prelude_stmts=role_prelude_stmts,
                emit_pdl_wait=emit_pdl_wait,
                initialize_tile_counter=initialize_tile_counter,
            )
        assert store_aux_per_tile_stmts is None, (
            "store-warp aux merge requires ROLE_LOCAL_WITH_SCHEDULER"
        )

        # Match the shared scheduler's cluster shape so the role-local
        # scheduler visits the same tile sequence in the same order.
        # The shared scheduler uses (layout.cluster_m, 1, 1); diverging
        # here would re-order tiles and break AB-pipeline ordering
        # between the TMA-load warp and the consumer warps.
        sched_params_var = device_function.new_var(
            f"{scheduler_var_prefix}_tile_sched_params"
        )
        sched_var = device_function.new_var(f"{scheduler_var_prefix}_tile_sched")
        work_tile_var = device_function.new_var(f"{scheduler_var_prefix}_work_tile")

        prelude: list[ast.stmt] = []
        materialized_pdl = bool(
            device_function.config.get("tcgen05_materialized_pdl", False)
        )
        tma_load_role = (
            role_block.role_predicate == self._tcgen05_tma_load_role_predicate()
            and not device_function.cute_state.tcgen05_pdl_wait_in_prefetch
        )
        if emit_pdl_wait and (
            (
                self._tcgen05_is_two_cta()
                and (
                    tma_load_role
                    or materialized_pdl
                    and device_function.config.get("tcgen05_epilogue_fanout")
                    == "shared"
                    and role_block.role_predicate == self._tcgen05_epi_role_predicate()
                )
            )
            # The one-CTA family waits only when a materialized producer is
            # launched ahead of it, so its plain generated code is unchanged.
            or (materialized_pdl and tma_load_role)
        ):
            # PDL parity with Quack/CUTLASS: TMA producers wait before
            # touching scheduler state or issuing global-memory TMA work.
            prelude.append(statement_from_string("cute.arch.griddepcontrol_wait()"))
        prelude.extend(
            [
                statement_from_string(
                    f"{sched_params_var} = cutlass.utils.PersistentTileSchedulerParams("
                    f"{self._tcgen05_persistent_tile_sched_params_args(cluster_m=layout.cluster_m, cluster_n=layout.cluster_n)})"
                ),
                statement_from_string(
                    f"{sched_var} = cutlass.utils.StaticPersistentTileScheduler.create("
                    f"{sched_params_var}, cute.arch.block_idx(), cute.arch.grid_dim())"
                ),
                statement_from_string(
                    f"{work_tile_var} = {sched_var}.initial_work_tile_info()"
                ),
            ]
        )
        tile_counter_var, increment_tile_counter_per_tile = (
            self._finish_role_local_prelude(
                device_function,
                role_block,
                prelude,
                role_prelude_stmts=role_prelude_stmts,
                initialize_tile_counter=initialize_tile_counter,
            )
        )

        # Per-iteration refresh of role-local work-tile coordinates.
        # The role block's statements reference ``self.virtual_pid_var``
        # transitively (through PID decomposition), so before running
        # the role block we bind virtual_pid_var to the linearized
        # coordinate of THIS role-local work tile. The role-local
        # scheduler shares its cluster shape with the shared scheduler,
        # so the two iterate the same tiles in the same order and the
        # role-local virtual_pid_var matches the shared one tile-by-tile.
        coord_terms: list[str] = []
        axes = self._tcgen05_scheduler_axes(cluster_n=layout.cluster_n)
        for i in range(len(self.pid_info)):
            coord_terms.append(f"{work_tile_var}.tile_idx[{axes.index(i)}]")
        linear_pid_expr = self._tcgen05_linear_virtual_pid_from_coords_expr(
            coord_terms, pair_axis=axes[0]
        )

        per_tile_body: list[ast.stmt] = [
            statement_from_string(f"{self.virtual_pid_var} = {linear_pid_expr}"),
        ]
        if dependency_stmts is not None:
            per_tile_body.extend(dependency_stmts)
        per_tile_body.extend(role_block.stmts)
        if tile_counter_var is not None and increment_tile_counter_per_tile:
            per_tile_body.append(
                statement_from_string(
                    f"{tile_counter_var} = {tile_counter_var} + cutlass.Int32(1)"
                )
            )
        if (plan := self._tcgen05_plan()) is not None and plan.one_shot_role_scheduler:
            prelude.extend(per_tile_body)
        else:
            per_tile_body = self._tcgen05_guard_logical_work(
                work_tile_var, per_tile_body
            )
            per_tile_body.extend(
                [
                    statement_from_string(f"{sched_var}.advance_to_next_work()"),
                    statement_from_string(
                        f"{work_tile_var} = {sched_var}.get_current_work()"
                    ),
                ]
            )
            prelude.append(
                create(
                    ast.While,
                    test=expr_from_string(f"{work_tile_var}.is_valid_tile"),
                    body=per_tile_body,
                    orelse=[],
                )
            )

        return create(
            ast.If,
            test=expr_from_string(role_block.role_predicate),
            body=prelude,
            orelse=[],
        )

    def _finish_role_local_prelude(
        self,
        device_function: DeviceFunction,
        role_block: Tcgen05PersistentProgramIDs._PersistentRoleBlock,
        prelude: list[ast.stmt],
        *,
        role_prelude_stmts: list[ast.stmt] | None,
        initialize_tile_counter: bool,
    ) -> tuple[str | None, bool]:
        tile_counter_var = (
            device_function.cute_state.epi_role_tile_counter_var
            if role_block.role_predicate == self._tcgen05_epi_role_predicate()
            else None
        )
        increment_tile_counter_per_tile = (
            device_function.cute_state.epi_role_tile_counter_increment_per_tile
            if tile_counter_var is not None
            else False
        )
        if tile_counter_var is not None and initialize_tile_counter:
            prelude.append(
                statement_from_string(f"{tile_counter_var} = cutlass.Int32(0)")
            )
        prelude.extend(role_prelude_stmts or ())
        return tile_counter_var, increment_tile_counter_per_tile

    @staticmethod
    def _grouped_static_dependency_stmts(
        dependency_stmts: list[ast.stmt] | None,
    ) -> list[ast.stmt]:
        if dependency_stmts is None:
            return []
        grouped_coord_names = {
            "virtual_pid",
            "pid_0",
            "pid_1",
            "tile_offset_0",
            "tile_offset_1",
        }
        filtered: list[ast.stmt] = []
        for stmt in dependency_stmts:
            _reads, writes = _stmt_name_uses(stmt)
            if not (writes & grouped_coord_names):
                filtered.append(stmt)
                continue
            if (
                isinstance(stmt, ast.Assign)
                and len(stmt.targets) == 1
                and isinstance(stmt.targets[0], ast.Name)
                and writes <= grouped_coord_names
            ):
                continue
            raise AssertionError(
                "tcgen05 grouped static scheduler cannot drop mixed coordinate "
                "dependency statement: " + ast.unparse(stmt)
            )
        return filtered

    def _grouped_worklist_nm_valid_store_m_stmts(
        self,
        device_function: DeviceFunction,
    ) -> list[ast.stmt]:
        plan = self._tcgen05_plan()
        assert plan is not None and plan.accumulator_view == "nm"
        grouped = plan.grouped
        assert grouped is not None
        assert grouped.valid_m is not None and grouped.store_m is not None
        grouped_valid_m = grouped.valid_m
        grouped_store_m = grouped.store_m
        grouped_layout = grouped.layout
        grouped_metadata_idx = grouped.metadata_idx
        grouped_cta_tile_idx_m = grouped.cta_tile_idx_m

        def metadata_load_expr(column: int) -> str:
            return (
                f"({grouped_layout}.iterator + "
                f"{grouped_metadata_idx} * "
                f"cutlass.Int32({grouped_layout}.layout.stride[0]) + "
                f"cutlass.Int32({column}) * "
                f"cutlass.Int32({grouped_layout}.layout.stride[1])).load()"
            )

        tile_start_var = device_function.new_var("tcgen05_grouped_selected_tile_start")
        source_tile_m = plan.source_tile_m
        if grouped.device_split_sizes:
            remaining_m = (
                f"max({grouped.problem_m} - {tile_start_var}, cutlass.Int32(0))"
            )
            return [
                statement_from_string(
                    f"{tile_start_var} = {grouped_cta_tile_idx_m} * "
                    f"cutlass.Int32({source_tile_m})"
                ),
                statement_from_string(
                    f"{grouped_valid_m} = min(cutlass.Int32({source_tile_m}), "
                    f"{remaining_m})"
                ),
                statement_from_string(
                    f"{grouped_store_m} = min(cutlass.Int32({source_tile_m}), "
                    f"{remaining_m})"
                ),
            ]
        return [
            statement_from_string(
                f"{tile_start_var} = {grouped_cta_tile_idx_m} * "
                f"cutlass.Int32({source_tile_m})"
            ),
            statement_from_string(
                f"{grouped_valid_m} = min(cutlass.Int32({source_tile_m}), "
                f"max({metadata_load_expr(2)} - {tile_start_var}, cutlass.Int32(0)))"
            ),
            statement_from_string(
                f"{grouped_store_m} = min(cutlass.Int32({source_tile_m}), "
                f"{metadata_load_expr(3)} - {tile_start_var})"
            ),
        ]

    def _build_specialized_grouped_static_role_local_while(
        self,
        device_function: DeviceFunction,
        role_block: Tcgen05PersistentProgramIDs._PersistentRoleBlock,
        *,
        scheduler_var_prefix: str,
        dependency_stmts: list[ast.stmt] | None,
        role_prelude_stmts: list[ast.stmt] | None,
        initialize_tile_counter: bool,
    ) -> ast.stmt:
        """Emit a constant grouped schedule guarded by runtime metadata checks."""
        assert role_block.role_predicate is not None
        plan = self._tcgen05_plan()
        assert plan is not None and plan.grouped is not None
        grouped = plan.grouped
        shapes = grouped.static_problem_shapes
        assert shapes is not None
        assert grouped.real_groups is None
        assert plan.accumulator_view == "mn"
        assert plan.cluster_m == 1 and plan.cluster_n == 1
        assert plan.l2_swizzle_size == 1

        linear_idx = device_function.new_var(
            f"{scheduler_var_prefix}_static_linear_idx"
        )
        local_idx = device_function.new_var(f"{scheduler_var_prefix}_static_local_idx")
        prelude = [
            statement_from_string(
                f"{linear_idx} = cutlass.Int32(cute.arch.block_idx()[2])"
            ),
            statement_from_string(f"{local_idx} = cutlass.Int32(0)"),
        ]
        tile_counter_var, increment_tile_counter_per_tile = (
            self._finish_role_local_prelude(
                device_function,
                role_block,
                prelude,
                role_prelude_stmts=role_prelude_stmts,
                initialize_tile_counter=initialize_tile_counter,
            )
        )

        source_tile_m = plan.source_tile_m
        source_tile_n = plan.source_tile_n
        global_m_start = 0
        group_specs: list[tuple[int, int, int, int, int, int, int]] = []
        for metadata_idx, (problem_m, problem_n, problem_k) in enumerate(shapes):
            m_tiles = (problem_m + source_tile_m - 1) // source_tile_m
            n_tiles = (problem_n + source_tile_n - 1) // source_tile_n
            group_specs.append(
                (
                    metadata_idx,
                    problem_m,
                    problem_n,
                    problem_k,
                    m_tiles,
                    n_tiles,
                    global_m_start,
                )
            )
            global_m_start += m_tiles * source_tile_m

        tile_counts = [m_tiles * n_tiles for *_, m_tiles, n_tiles, _ in group_specs]
        # Keep every CTA on one group so dynamic TensorMaps are programmed only
        # once. The device-specific wrapper supplies host-computed quotas, so
        # each CTA only performs the group dispatch and tile-stride loop.
        quota_vars = list(grouped.static_group_quota_args)
        assert len(quota_vars) == len(group_specs)

        group_bodies: list[list[ast.stmt]] = []
        quota_prefix: list[str] = []
        for (
            metadata_idx,
            problem_m,
            problem_n,
            problem_k,
            m_tiles,
            _n_tiles,
            group_m_start,
        ), tile_count, quota in zip(group_specs, tile_counts, quota_vars, strict=True):
            block_offset = " + ".join(quota_prefix)
            local_expr = (
                linear_idx if not block_offset else f"{linear_idx} - ({block_offset})"
            )
            group_prelude = [
                f"{grouped.metadata_idx} = cutlass.Int32({metadata_idx})",
                f"{grouped.group_idx} = cutlass.Int32({metadata_idx})",
                f"{grouped.problem_m} = cutlass.Int32({problem_m})",
                f"{grouped.problem_n} = cutlass.Int32({problem_n})",
                f"{grouped.problem_k} = cutlass.Int32({problem_k})",
                f"{grouped.global_m_start} = cutlass.Int32({group_m_start})",
                f"{local_idx} = {local_expr}",
            ]
            per_tile_body = [
                statement_from_string(
                    f"{grouped.cta_tile_idx_m} = {local_idx} % cutlass.Int32({m_tiles})"
                ),
                statement_from_string(
                    f"{grouped.cta_tile_idx_n} = {local_idx} // "
                    f"cutlass.Int32({m_tiles})"
                ),
                statement_from_string(f"pid_0 = {grouped.cta_tile_idx_m}"),
                statement_from_string(f"pid_1 = {grouped.cta_tile_idx_n}"),
                statement_from_string(
                    f"tile_offset_0 = {grouped.global_m_start} + "
                    f"{grouped.cta_tile_idx_m} * cutlass.Int32({source_tile_m})"
                ),
                statement_from_string(
                    f"tile_offset_1 = {grouped.cta_tile_idx_n} * "
                    f"cutlass.Int32({source_tile_n})"
                ),
                *(
                    _clone_stmt(stmt)
                    for stmt in self._grouped_static_dependency_stmts(dependency_stmts)
                ),
                *(_clone_stmt(stmt) for stmt in role_block.stmts),
            ]
            if tile_counter_var is not None and increment_tile_counter_per_tile:
                per_tile_body.append(
                    statement_from_string(
                        f"{tile_counter_var} = {tile_counter_var} + cutlass.Int32(1)"
                    )
                )
            per_tile_body.append(
                statement_from_string(f"{local_idx} = {local_idx} + {quota}")
            )
            group_bodies.append(
                [
                    *(statement_from_string(line) for line in group_prelude),
                    create(
                        ast.While,
                        test=expr_from_string(
                            f"{local_idx} < cutlass.Int32({tile_count})"
                        ),
                        body=per_tile_body,
                        orelse=[],
                    ),
                ]
            )
            quota_prefix.append(quota)

        if len(group_bodies) == 1:
            prelude.extend(group_bodies[0])
        else:
            dispatch: list[ast.stmt] = group_bodies[-1]
            for index in range(len(group_bodies) - 2, -1, -1):
                quota_end = " + ".join(quota_vars[: index + 1])
                dispatch = [
                    create(
                        ast.If,
                        test=expr_from_string(f"{linear_idx} < {quota_end}"),
                        body=group_bodies[index],
                        orelse=dispatch,
                    )
                ]
            prelude.extend(dispatch)

        return create(
            ast.If,
            test=expr_from_string(role_block.role_predicate),
            body=prelude,
            orelse=[],
        )

    def _build_grouped_worklist_nm_role_local_while(
        self,
        device_function: DeviceFunction,
        role_block: Tcgen05PersistentProgramIDs._PersistentRoleBlock,
        *,
        layout: Tcgen05PersistentProgramIDs._Tcgen05PersistentLayout | None = None,
        scheduler_var_prefix: str,
        dependency_stmts: list[ast.stmt] | None,
        role_prelude_stmts: list[ast.stmt] | None,
        initialize_tile_counter: bool,
        emit_pdl_wait: bool,
    ) -> ast.stmt:
        """Consume N,M worklist tiles from the selected runtime scheduler."""
        assert role_block.role_predicate is not None
        plan = self._tcgen05_plan()
        assert plan is not None and plan.grouped is not None
        grouped = plan.grouped
        assert grouped.valid_m is not None and grouped.store_m is not None
        runtime_table = self._tcgen05_uses_grouped_worklist_nm_runtime_table()
        scheduler_mailbox = self._tcgen05_uses_grouped_worklist_nm_scheduler_mailbox()
        runtime_clc = self._tcgen05_uses_grouped_worklist_nm_runtime_clc()
        uses_pipeline = scheduler_mailbox or runtime_clc
        assert runtime_table or scheduler_mailbox
        assert (layout is not None) == uses_pipeline

        local_full = (
            grouped.full_coverage
            if grouped.full_coverage is not None
            and grouped.full_coverage.consumer_local
            else None
        )
        dense_index: str | None = None
        dense_step: str | None = None
        dense_initializers: list[ast.stmt] = []
        if local_full is not None:
            assert scheduler_mailbox and not runtime_table and not plan.is_two_cta
            dense_index = device_function.new_var(f"{scheduler_var_prefix}_dense_index")
            dense_step = device_function.new_var(f"{scheduler_var_prefix}_dense_step")

        linear_idx: str | None = None
        grid_stride: str | None = None
        records = grouped.runtime_tile_records
        total_clusters = grouped.runtime_total_clusters
        if runtime_table:
            assert records is not None and total_clusters is not None
            linear_idx = device_function.new_var(
                f"{scheduler_var_prefix}_runtime_direct_linear_idx"
            )
            if not uses_pipeline:
                grid_stride = device_function.new_var(
                    f"{scheduler_var_prefix}_runtime_direct_grid_stride"
                )

        sched_pipeline: str | None = None
        sched_consumer_state: str | None = None
        valid_var: str | None = None
        work_tile_stage_index: str | None = None
        snapshot: _SchedMailboxSnapshot | None = None
        if uses_pipeline:
            sched_pipeline_plan = self._tcgen05_sched_pipeline_plan()
            assert sched_pipeline_plan is not None
            sched_pipeline = sched_pipeline_plan.pipeline
            sched_consumer_state = sched_pipeline_plan.consumer_state
            valid_var = device_function.new_var(f"{scheduler_var_prefix}_valid")
            work_tile_stage_index = (
                f"{sched_consumer_state}.index"
                if self._tcgen05_uses_staged_work_tile_mailbox()
                else None
            )
            snapshot = _SchedMailboxSnapshot.create(
                device_function,
                scheduler_var_prefix,
                tuple(
                    i
                    for i in range(TCGEN05_GROUPED_WORKLIST_MAILBOX_FIELD_COUNT)
                    if i != _TCGEN05_GROUPED_SELECTED_MAILBOX_VALID
                )
                if scheduler_mailbox
                else (2,),
            )

        def consumer_wait_block() -> list[ast.stmt]:
            assert layout is not None
            assert sched_pipeline is not None and sched_consumer_state is not None
            assert valid_var is not None
            return _build_sched_pipeline_consumer_wait_block(
                sched_pipeline=sched_pipeline,
                sched_consumer_state=sched_consumer_state,
                work_tile_smem=layout.work_tile_smem,
                valid_var=valid_var,
                valid_slot_index=(
                    _TCGEN05_GROUPED_SELECTED_MAILBOX_VALID
                    if scheduler_mailbox
                    else _TCGEN05_WORK_TILE_MAILBOX_VALID
                ),
                work_tile_stage_index=work_tile_stage_index,
                snapshot=snapshot,
            )

        def consumer_release_block() -> list[ast.stmt]:
            assert sched_pipeline is not None and sched_consumer_state is not None
            return _build_sched_pipeline_consumer_release_block(
                sched_pipeline=sched_pipeline,
                sched_consumer_state=sched_consumer_state,
            )

        prelude: list[ast.stmt] = []
        if (
            emit_pdl_wait
            and plan.is_two_cta
            and role_block.role_predicate == self._tcgen05_tma_load_role_predicate()
        ):
            prelude.append(statement_from_string("cute.arch.griddepcontrol_wait()"))
        if not uses_pipeline:
            assert linear_idx is not None and grid_stride is not None
            prelude.extend(
                (
                    statement_from_string(
                        f"{linear_idx} = cutlass.Int32(cute.arch.block_idx()[2])"
                    ),
                    statement_from_string(
                        f"{grid_stride} = cutlass.Int32(cute.arch.grid_dim()[2])"
                    ),
                )
            )
        tile_counter_var, increment_tile_counter_per_tile = (
            self._finish_role_local_prelude(
                device_function,
                role_block,
                prelude,
                role_prelude_stmts=role_prelude_stmts,
                initialize_tile_counter=initialize_tile_counter,
            )
        )
        if uses_pipeline and local_full is None:
            prelude.extend(consumer_wait_block())

        epi_role = role_block.role_predicate == self._tcgen05_epi_role_predicate()
        role_tile_stmts = [
            *(
                _clone_stmt(stmt)
                for stmt in self._grouped_static_dependency_stmts(dependency_stmts)
            ),
            *(_clone_stmt(stmt) for stmt in role_block.stmts),
        ]
        role_reads = {
            name for stmt in role_tile_stmts for name in _stmt_name_uses(stmt)[0]
        }
        metadata_stmts: list[ast.stmt] = []
        if runtime_table:
            assert records is not None and linear_idx is not None
            assert records not in role_reads, (
                "per-tile role statements must use generated runtime-table loads"
            )

            def record_load(field: int) -> str:
                return (
                    f"({records}.iterator + {linear_idx} * "
                    f"cutlass.Int32({records}.layout.stride[0]) + "
                    f"cutlass.Int32({field}) * "
                    f"cutlass.Int32({records}.layout.stride[1])).load()"
                )

            if runtime_clc:
                assert layout is not None
                metadata_stmts.append(
                    statement_from_string(
                        f"{linear_idx} = "
                        f"{snapshot.fields[2] if snapshot is not None else self._tcgen05_work_tile_slot(layout, 2)}"
                    )
                )
                metadata_stmts.extend(consumer_release_block())
            fields = (
                (grouped.cta_tile_idx_m, Tcgen05GroupedRuntimeTileField.CTA_M),
                (grouped.cta_tile_idx_n, Tcgen05GroupedRuntimeTileField.CTA_N),
                (grouped.metadata_idx, Tcgen05GroupedRuntimeTileField.METADATA_IDX),
                (grouped.group_idx, Tcgen05GroupedRuntimeTileField.GROUP_IDX),
                (grouped.problem_m, Tcgen05GroupedRuntimeTileField.PROBLEM_M),
                (grouped.problem_n, Tcgen05GroupedRuntimeTileField.PROBLEM_N),
                (grouped.problem_k, Tcgen05GroupedRuntimeTileField.PROBLEM_K),
                (
                    grouped.global_m_start,
                    Tcgen05GroupedRuntimeTileField.GLOBAL_M_START,
                ),
                (grouped.valid_m, Tcgen05GroupedRuntimeTileField.VALID_M),
                (grouped.store_m, Tcgen05GroupedRuntimeTileField.STORE_M),
            )
            assert {field for _name, field in fields} == set(
                Tcgen05GroupedRuntimeTileField
            )
            derived_metadata_stmts = [
                statement_from_string(f"{name} = {record_load(field)}")
                for name, field in fields
            ]
            derived_metadata_stmts.extend(
                (
                    statement_from_string(f"pid_0 = {grouped.cta_tile_idx_m}"),
                    statement_from_string(f"pid_1 = {grouped.cta_tile_idx_n}"),
                    statement_from_string(
                        f"tile_offset_0 = {grouped.global_m_start} + "
                        f"{grouped.cta_tile_idx_m} * "
                        f"cutlass.Int32({plan.source_tile_m})"
                    ),
                    statement_from_string(
                        f"tile_offset_1 = {grouped.cta_tile_idx_n} * "
                        f"cutlass.Int32({plan.source_tile_n})"
                    ),
                )
            )
            derived_metadata_stmts = _prune_dead_side_effect_free_generated_assignments(
                derived_metadata_stmts, role_reads
            )[0]
            metadata_stmts.extend(derived_metadata_stmts)
        else:
            assert layout is not None

            def slot(field: int) -> str:
                if snapshot is not None:
                    return snapshot.fields[field]
                return self._tcgen05_work_tile_slot(layout, field)

            mailbox_fields = (
                (grouped.cta_tile_idx_m, _TCGEN05_GROUPED_SELECTED_MAILBOX_CTA_M),
                (grouped.cta_tile_idx_n, _TCGEN05_GROUPED_SELECTED_MAILBOX_CTA_N),
                (grouped.metadata_idx, _TCGEN05_GROUPED_SELECTED_MAILBOX_METADATA_IDX),
                (grouped.group_idx, _TCGEN05_GROUPED_SELECTED_MAILBOX_GROUP_IDX),
                (grouped.problem_m, _TCGEN05_GROUPED_SELECTED_MAILBOX_PROBLEM_M),
                (grouped.problem_n, _TCGEN05_GROUPED_SELECTED_MAILBOX_PROBLEM_N),
                (grouped.problem_k, _TCGEN05_GROUPED_SELECTED_MAILBOX_PROBLEM_K),
                (
                    grouped.global_m_start,
                    _TCGEN05_GROUPED_SELECTED_MAILBOX_GLOBAL_M_START,
                ),
            )
            derived_metadata_stmts: list[ast.stmt] = []
            if epi_role:
                derived_metadata_stmts.extend(
                    self._grouped_worklist_nm_valid_store_m_stmts(device_function)
                )
            derived_metadata_stmts.extend(
                (
                    statement_from_string(f"pid_0 = {grouped.cta_tile_idx_m}"),
                    statement_from_string(f"pid_1 = {grouped.cta_tile_idx_n}"),
                )
            )
            derived_metadata_stmts, required_metadata_names = (
                _prune_dead_side_effect_free_generated_assignments(
                    derived_metadata_stmts, role_reads
                )
            )
            mailbox_loads = [
                statement_from_string(f"{name} = {slot(field)}")
                for name, field in mailbox_fields
                if name in required_metadata_names
            ]
            if local_full is None:
                metadata_stmts.extend(mailbox_loads)
            else:
                assert dense_index is not None
                row, column = local_full.tile_coordinates(dense_index)
                dense_values = {
                    _TCGEN05_GROUPED_SELECTED_MAILBOX_CTA_M: row,
                    _TCGEN05_GROUPED_SELECTED_MAILBOX_CTA_N: column,
                    _TCGEN05_GROUPED_SELECTED_MAILBOX_METADATA_IDX: "cutlass.Int32(0)",
                    _TCGEN05_GROUPED_SELECTED_MAILBOX_PROBLEM_M: f"cutlass.Int32({local_full.m})",
                    _TCGEN05_GROUPED_SELECTED_MAILBOX_PROBLEM_N: f"cutlass.Int32({local_full.n})",
                    _TCGEN05_GROUPED_SELECTED_MAILBOX_PROBLEM_K: f"cutlass.Int32({local_full.k})",
                    _TCGEN05_GROUPED_SELECTED_MAILBOX_GLOBAL_M_START: "cutlass.Int32(0)",
                }
                required_fields = [
                    (name, field)
                    for name, field in mailbox_fields
                    if name in required_metadata_names
                ]
                assert all(field in dense_values for _name, field in required_fields)
                # CuTe staging requires typed definitions outside the dynamic
                # branch. Each is overwritten before its first per-tile use.
                dense_initializers.extend(
                    statement_from_string(f"{name} = cutlass.Int32(0)")
                    for name, _field in required_fields
                )
                metadata_stmts.append(
                    create(
                        ast.If,
                        test=expr_from_string(local_full.predicate),
                        body=[
                            statement_from_string(f"{name} = {dense_values[field]}")
                            for name, field in required_fields
                        ],
                        orelse=mailbox_loads,
                    )
                )
            metadata_stmts.extend(derived_metadata_stmts)
            if local_full is None:
                metadata_stmts.extend(consumer_release_block())
            else:
                metadata_stmts.append(
                    create(
                        ast.If,
                        test=expr_from_string(f"not {local_full.predicate}"),
                        body=consumer_release_block(),
                        orelse=[],
                    )
                )

        if local_full is not None:
            assert dense_index is not None and dense_step is not None
            assert valid_var is not None
            prelude.extend(
                [
                    statement_from_string(f"{dense_index} = cutlass.Int32(0)"),
                    statement_from_string(f"{dense_step} = cutlass.Int32(0)"),
                    statement_from_string(f"{valid_var} = cutlass.Boolean(False)"),
                    *dense_initializers,
                    create(
                        ast.If,
                        test=expr_from_string(local_full.predicate),
                        body=[
                            statement_from_string(
                                f"{dense_index} = cutlass.Int32(cute.arch.block_idx()[2])"
                            ),
                            statement_from_string(
                                f"{dense_step} = cutlass.Int32(cute.arch.grid_dim()[2])"
                            ),
                            statement_from_string(
                                f"{valid_var} = {dense_index} < cutlass.Int32({local_full.tiles})"
                            ),
                        ],
                        orelse=consumer_wait_block(),
                    ),
                ]
            )

        per_tile_body = [
            *metadata_stmts,
            *role_tile_stmts,
        ]
        if tile_counter_var is not None and increment_tile_counter_per_tile:
            per_tile_body.append(
                statement_from_string(
                    f"{tile_counter_var} = {tile_counter_var} + cutlass.Int32(1)"
                )
            )
        if uses_pipeline:
            assert valid_var is not None
            if local_full is None:
                per_tile_body.extend(consumer_wait_block())
            else:
                assert dense_index is not None and dense_step is not None
                per_tile_body.append(
                    create(
                        ast.If,
                        test=expr_from_string(local_full.predicate),
                        body=[
                            statement_from_string(
                                f"{dense_index} = {dense_index} + {dense_step}"
                            ),
                            statement_from_string(
                                f"{valid_var} = {dense_index} < cutlass.Int32({local_full.tiles})"
                            ),
                        ],
                        orelse=consumer_wait_block(),
                    )
                )
            loop_test = valid_var
        else:
            assert linear_idx is not None
            assert grid_stride is not None
            assert total_clusters is not None
            per_tile_body.append(
                statement_from_string(f"{linear_idx} = {linear_idx} + {grid_stride}")
            )
            loop_test = f"{linear_idx} < {total_clusters}"
        prelude.append(
            create(
                ast.While,
                test=expr_from_string(loop_test),
                body=per_tile_body,
                orelse=[],
            )
        )
        if uses_pipeline:
            if local_full is None:
                prelude.extend(consumer_release_block())
            else:
                prelude.append(
                    create(
                        ast.If,
                        test=expr_from_string(f"not {local_full.predicate}"),
                        body=consumer_release_block(),
                        orelse=[],
                    )
                )
        return create(
            ast.If,
            test=expr_from_string(role_block.role_predicate),
            body=prelude,
            orelse=[],
        )

    def _build_generic_grouped_static_role_local_while(
        self,
        device_function: DeviceFunction,
        role_block: Tcgen05PersistentProgramIDs._PersistentRoleBlock,
        *,
        scheduler_var_prefix: str,
        dependency_stmts: list[ast.stmt] | None,
        role_prelude_stmts: list[ast.stmt] | None = None,
        initialize_tile_counter: bool = True,
    ) -> ast.stmt:
        assert role_block.role_predicate is not None
        plan = self._tcgen05_plan()
        assert plan is not None and plan.grouped is not None
        grouped = plan.grouped
        assert plan.accumulator_view != "nm"

        sched_var = device_function.new_var(f"{scheduler_var_prefix}_grouped_sched")
        work_tile_var = device_function.new_var(f"{scheduler_var_prefix}_grouped_work")
        group_info_var = device_function.new_var(
            f"{scheduler_var_prefix}_group_search_result"
        )

        prelude: list[ast.stmt] = [
            statement_from_string(
                f"{sched_var} = cutlass.utils.StaticPersistentGroupTileScheduler.create("
                f"{grouped.sched_params}, cute.arch.block_idx(), "
                f"cute.arch.grid_dim(), ({plan.bm}, {plan.bn}, {plan.bk}), "
                "cutlass.utils.create_initial_search_state(), "
                f"{grouped.count}, {grouped.problem_sizes})"
            ),
            statement_from_string(
                f"{work_tile_var} = {sched_var}.initial_work_tile_info()"
            ),
        ]

        tile_counter_var, increment_tile_counter_per_tile = (
            self._finish_role_local_prelude(
                device_function,
                role_block,
                prelude,
                role_prelude_stmts=role_prelude_stmts,
                initialize_tile_counter=initialize_tile_counter,
            )
        )

        grouped_cta_tile_idx_m = self._tcgen05_logical_m_coord_expr(
            f"{group_info_var}.cta_tile_idx_m"
        )
        grouped_cta_tile_idx_n = f"{group_info_var}.cta_tile_idx_n"
        grouped_metadata_stmts = [
            statement_from_string(
                f"{group_info_var} = {work_tile_var}.group_search_result"
            ),
            statement_from_string(
                f"{grouped.metadata_idx} = {group_info_var}.group_idx"
            ),
            *(
                [
                    statement_from_string(
                        f"{grouped.group_idx} = "
                        f"({grouped.real_groups}.iterator + "
                        f"{grouped.metadata_idx} * cutlass.Int32("
                        f"{grouped.real_groups}.layout.stride[0])).load()"
                    )
                ]
                if grouped.real_groups is not None
                else [
                    statement_from_string(
                        f"{grouped.group_idx} = {grouped.metadata_idx}"
                    )
                ]
            ),
            statement_from_string(
                f"{grouped.problem_m} = {group_info_var}.problem_shape_m"
            ),
            statement_from_string(
                f"{grouped.problem_n} = {group_info_var}.problem_shape_n"
            ),
            statement_from_string(
                f"{grouped.problem_k} = {group_info_var}.problem_shape_k"
            ),
            statement_from_string(
                f"{grouped.cta_tile_idx_m} = {grouped_cta_tile_idx_m}"
            ),
            statement_from_string(
                f"{grouped.cta_tile_idx_n} = {grouped_cta_tile_idx_n}"
            ),
            statement_from_string(
                f"{grouped.global_m_start} = "
                f"({grouped.starts}.iterator + {grouped.metadata_idx} "
                f"* cutlass.Int32({grouped.starts}.layout.stride[0])).load()"
            ),
            statement_from_string(f"pid_0 = {grouped.cta_tile_idx_m}"),
            statement_from_string(f"pid_1 = {grouped.cta_tile_idx_n}"),
            statement_from_string(
                f"tile_offset_0 = {grouped.global_m_start} + "
                f"{grouped.cta_tile_idx_m} * "
                f"cutlass.Int32({plan.source_tile_m})"
            ),
            statement_from_string(
                f"tile_offset_1 = {grouped.cta_tile_idx_n} * "
                f"cutlass.Int32({plan.source_tile_n})"
            ),
        ]
        per_tile_body: list[ast.stmt] = grouped_metadata_stmts
        per_tile_body.extend(self._grouped_static_dependency_stmts(dependency_stmts))
        per_tile_body.extend(role_block.stmts)
        if tile_counter_var is not None and increment_tile_counter_per_tile:
            per_tile_body.append(
                statement_from_string(
                    f"{tile_counter_var} = {tile_counter_var} + cutlass.Int32(1)"
                )
            )
        per_tile_body.extend(
            [
                statement_from_string(f"{sched_var}.advance_to_next_work()"),
                statement_from_string(
                    f"{work_tile_var} = {sched_var}.get_current_work()"
                ),
            ]
        )
        prelude.append(
            create(
                ast.While,
                test=expr_from_string(f"{work_tile_var}.is_valid_tile"),
                body=per_tile_body,
                orelse=[],
            )
        )
        return create(
            ast.If,
            test=expr_from_string(role_block.role_predicate),
            body=prelude,
            orelse=[],
        )

    def _build_grouped_static_role_local_while(
        self,
        device_function: DeviceFunction,
        role_block: Tcgen05PersistentProgramIDs._PersistentRoleBlock,
        *,
        scheduler_var_prefix: str,
        dependency_stmts: list[ast.stmt] | None,
        role_prelude_stmts: list[ast.stmt] | None = None,
        emit_pdl_wait: bool = True,
        initialize_tile_counter: bool = True,
    ) -> ast.stmt:
        plan = self._tcgen05_plan()
        assert plan is not None and plan.grouped is not None
        if self._tcgen05_uses_grouped_worklist_nm_runtime_direct():
            return self._build_grouped_worklist_nm_role_local_while(
                device_function,
                role_block,
                scheduler_var_prefix=scheduler_var_prefix,
                dependency_stmts=dependency_stmts,
                role_prelude_stmts=role_prelude_stmts,
                initialize_tile_counter=initialize_tile_counter,
                emit_pdl_wait=emit_pdl_wait,
            )
        shapes = plan.grouped.static_problem_shapes
        if (
            shapes is None
            or len(shapes) > TCGEN05_GROUPED_STATIC_SPECIALIZATION_MAX_GROUPS
        ):
            return self._build_generic_grouped_static_role_local_while(
                device_function,
                role_block,
                scheduler_var_prefix=scheduler_var_prefix,
                dependency_stmts=dependency_stmts,
                role_prelude_stmts=role_prelude_stmts,
                initialize_tile_counter=initialize_tile_counter,
            )

        specialized = self._build_specialized_grouped_static_role_local_while(
            device_function,
            role_block,
            scheduler_var_prefix=scheduler_var_prefix,
            dependency_stmts=dependency_stmts,
            role_prelude_stmts=role_prelude_stmts,
            initialize_tile_counter=initialize_tile_counter,
        )
        generic = self._build_generic_grouped_static_role_local_while(
            device_function,
            role_block,
            scheduler_var_prefix=scheduler_var_prefix,
            dependency_stmts=dependency_stmts,
            role_prelude_stmts=(
                [_clone_stmt(stmt) for stmt in role_prelude_stmts]
                if role_prelude_stmts is not None
                else None
            ),
            initialize_tile_counter=initialize_tile_counter,
        )
        return create(
            ast.If,
            test=expr_from_string(
                f"cute.arch.grid_dim()[2] >= cutlass.Int32({len(shapes)})"
            ),
            body=[specialized],
            orelse=[generic],
        )

    def _build_role_local_while_with_scheduler(
        self,
        device_function: DeviceFunction,
        layout: Tcgen05PersistentProgramIDs._Tcgen05PersistentLayout,
        role_block: Tcgen05PersistentProgramIDs._PersistentRoleBlock,
        *,
        scheduler_var_prefix: str,
        dependency_stmts: list[ast.stmt] | None,
        role_prelude_stmts: list[ast.stmt] | None = None,
        emit_pdl_wait: bool = True,
        initialize_tile_counter: bool = True,
        store_aux_per_tile_stmts: list[ast.stmt] | None = None,
        store_aux_predicate: str | None = None,
    ) -> ast.stmt:
        """``ROLE_LOCAL_WITH_SCHEDULER`` consumer-side role-local while.

        Each consumer role waits on the sched_pipeline, reads the
        published tile metadata from ``layout.work_tile_smem``, releases the
        sched stage, then runs its role block. The scheduler-warp role
        (built by ``_build_scheduler_warp_role_local_while``) owns
        the producer side: it runs ``StaticPersistentTileScheduler``
        and publishes per-tile metadata into the same SMEM mailbox.

        Cross-role producer-consumer synchronization for the *AB*
        and *acc* pipelines stays unchanged — those barriers carry
        the operand / accumulator data dependencies between the
        TMA-load, MMA-exec, and epi roles. The sched_pipeline is
        *only* used to broadcast per-tile coordinates.
        """
        assert role_block.role_predicate is not None
        sched_pipeline_plan = self._tcgen05_sched_pipeline_plan()
        assert sched_pipeline_plan is not None, (
            "ROLE_LOCAL_WITH_SCHEDULER requires a registered "
            "sched_pipeline plan; was cute_state.register_tcgen05_sched_pipeline_plan "
            "called by _codegen_cute_mma?"
        )

        plan = self._tcgen05_plan()
        assert plan is not None and plan.has_scheduler_warp

        # Local handles for sched_pipeline variable names.
        sched_pipeline = sched_pipeline_plan.pipeline
        sched_consumer_state = sched_pipeline_plan.consumer_state
        # Per-role variable for the linearized virtual pid read out
        # of the SMEM mailbox each iteration.
        valid_var = device_function.new_var(f"{scheduler_var_prefix}_valid")

        prelude: list[ast.stmt] = []
        if (
            emit_pdl_wait
            and self._tcgen05_is_two_cta()
            and role_block.role_predicate == self._tcgen05_tma_load_role_predicate()
        ):
            # Same PDL hand-off as the MONOLITHIC path.
            prelude.append(statement_from_string("cute.arch.griddepcontrol_wait()"))

        tile_counter_var, increment_tile_counter_per_tile = (
            self._finish_role_local_prelude(
                device_function,
                role_block,
                prelude,
                role_prelude_stmts=role_prelude_stmts,
                initialize_tile_counter=initialize_tile_counter,
            )
        )

        work_tile_stage_index = (
            f"{sched_consumer_state}.index"
            if self._tcgen05_uses_staged_work_tile_mailbox()
            else None
        )

        # Linear virtual pid expression: the scheduler warp publishes
        # work-tile coordinates into ``layout.work_tile_smem``; we
        # reconstruct the linear pid the same way the MONOLITHIC path
        # does, just sourcing from SMEM coords instead of the
        # work_tile object.
        snapshot = _SchedMailboxSnapshot.create(
            device_function, scheduler_var_prefix, tuple(range(len(self.pid_info)))
        )
        mailbox_slots = [
            snapshot.fields[i]
            if snapshot is not None
            else self._tcgen05_work_tile_slot(layout, i)
            for i in range(len(self.pid_info))
        ]
        coord_terms, pair_axis = self._tcgen05_mailbox_coord_terms(mailbox_slots)
        linear_pid_expr = self._tcgen05_linear_virtual_pid_from_coords_expr(
            coord_terms, pair_axis=pair_axis
        )

        # ``PipelineAsync.consumer_wait`` and ``consumer_release``
        # use the shared sched-pipeline factories at module scope —
        # see ``_build_sched_pipeline_consumer_wait_block`` and
        # ``_build_sched_pipeline_consumer_release_block`` for the
        # per-thread vs per-warp arrival count rationale. The
        # closures here just thread the per-role variables (the
        # role's ``valid_var`` plus the shared pipeline/state) into
        # fresh AST nodes per insertion point.
        def _consumer_wait_block() -> list[ast.stmt]:
            return _build_sched_pipeline_consumer_wait_block(
                sched_pipeline=sched_pipeline,
                sched_consumer_state=sched_consumer_state,
                work_tile_smem=layout.work_tile_smem,
                valid_var=valid_var,
                work_tile_stage_index=work_tile_stage_index,
                snapshot=snapshot,
            )

        def _consumer_release_block() -> list[ast.stmt]:
            return _build_sched_pipeline_consumer_release_block(
                sched_pipeline=sched_pipeline,
                sched_consumer_state=sched_consumer_state,
            )

        # Initial wait + valid-flag read happens in the prelude so the
        # ``while`` test can be a simple condition (CuTe DSL forbids
        # ``break`` inside ``@cute.kernel``).
        prelude.extend(_consumer_wait_block())
        per_tile_body: list[ast.stmt] = [
            statement_from_string(f"{self.virtual_pid_var} = {linear_pid_expr}"),
        ]
        # Match Quack's TileScheduler::get_current_work ordering: after the
        # role reads the published tile metadata, release the scheduler stage
        # immediately so the scheduler warp can publish the next tile while this
        # role processes the current tile.
        per_tile_body.extend(_consumer_release_block())
        if dependency_stmts is not None:
            per_tile_body.extend(dependency_stmts)
        # Cycle-94 merge: inject the store warp's aux GMEM->SMEM residual
        # producer body AFTER the tile coords are materialized and BEFORE the
        # store body (whose epi-warp consumers read the freshly staged aux),
        # gated on the store-warp predicate so only the single producer warp
        # issues the loads. The epi loop already owns the per-warp sched
        # handshake, so the injected body carries no sched wait/release.
        if store_aux_per_tile_stmts is not None:
            assert store_aux_predicate is not None
            per_tile_body.append(
                create(
                    ast.If,
                    test=expr_from_string(store_aux_predicate),
                    body=[_clone_stmt(stmt) for stmt in store_aux_per_tile_stmts],
                    orelse=[],
                )
            )
        per_tile_body.extend(role_block.stmts)
        if tile_counter_var is not None and increment_tile_counter_per_tile:
            per_tile_body.append(
                statement_from_string(
                    f"{tile_counter_var} = {tile_counter_var} + cutlass.Int32(1)"
                )
            )
        per_tile_body.extend(_consumer_wait_block())
        prelude.append(
            create(
                ast.While,
                test=expr_from_string(valid_var),
                body=per_tile_body,
                orelse=[],
            )
        )
        # Every lane releases the sentinel, matching the per-tile handshake.
        prelude.extend(_consumer_release_block())
        # Cycle-94 merge: no post-loop aux producer tail is injected. The store
        # warp's aux producer_state advance lives inside the per-tile store-warp
        # branch of THIS while; a post-loop ``producer_tail(state)`` would
        # reference a loop-carried value defined in that nested region (IR
        # domination error). The boundary drain is unnecessary because the
        # epi-warp consumers release every aux stage by loop exit (see
        # ``_build_c_input_warp_role_local_while(inline_aux_only=...)``).

        return create(
            ast.If,
            test=expr_from_string(role_block.role_predicate),
            body=prelude,
            orelse=[],
        )

    def _build_grouped_worklist_nm_scheduler_warp_role_local_while(
        self,
        device_function: DeviceFunction,
        layout: Tcgen05PersistentProgramIDs._Tcgen05PersistentLayout,
        *,
        required_mailbox_fields: frozenset[int] | None = None,
    ) -> ast.stmt:
        assert self._tcgen05_uses_grouped_worklist_nm_scheduler_mailbox()
        plan = self._tcgen05_plan()
        assert plan is not None and plan.grouped is not None
        grouped = plan.grouped
        source_tile_m = plan.source_tile_m
        source_tile_n = plan.source_tile_n
        grouped_starts = grouped.starts
        grouped_real_groups = grouped.real_groups

        sched_plan = self._tcgen05_sched_pipeline_plan()
        assert sched_plan is not None
        sched_pipeline = sched_plan.pipeline
        sched_producer_state = sched_plan.producer_state

        sched_var = device_function.new_var("tcgen05_grouped_selected_sched")
        work_tile_var = device_function.new_var("tcgen05_grouped_selected_work_tile")
        group_info_var = device_function.new_var(
            "tcgen05_grouped_selected_group_search_result"
        )
        metadata_idx_var = device_function.new_var(
            "tcgen05_grouped_selected_metadata_idx"
        )
        group_idx_var = device_function.new_var("tcgen05_grouped_selected_group_idx")
        cta_tile_idx_m_var = device_function.new_var(
            "tcgen05_grouped_selected_cta_tile_idx_m"
        )
        cta_tile_idx_n_var = device_function.new_var(
            "tcgen05_grouped_selected_cta_tile_idx_n"
        )
        source_n_tiles_var = device_function.new_var(
            "tcgen05_grouped_selected_source_n_tiles"
        )
        source_m_tiles_var = device_function.new_var(
            "tcgen05_grouped_selected_source_m_tiles"
        )
        source_m_fast_linear_var = device_function.new_var(
            "tcgen05_grouped_selected_source_m_fast_linear"
        )
        leader_predicate = "cute.arch.lane_idx() == cutlass.Int32(0)"

        def slot(i: int) -> str:
            return self._tcgen05_work_tile_producer_slot(layout, i)

        mailbox_values = (
            (_TCGEN05_GROUPED_SELECTED_MAILBOX_CTA_M, cta_tile_idx_m_var),
            (_TCGEN05_GROUPED_SELECTED_MAILBOX_CTA_N, cta_tile_idx_n_var),
            (_TCGEN05_GROUPED_SELECTED_MAILBOX_VALID, "cutlass.Int32(1)"),
            (_TCGEN05_GROUPED_SELECTED_MAILBOX_METADATA_IDX, metadata_idx_var),
            (_TCGEN05_GROUPED_SELECTED_MAILBOX_GROUP_IDX, group_idx_var),
            (
                _TCGEN05_GROUPED_SELECTED_MAILBOX_PROBLEM_M,
                f"{group_info_var}.problem_shape_n",
            ),
            (
                _TCGEN05_GROUPED_SELECTED_MAILBOX_PROBLEM_N,
                f"{group_info_var}.problem_shape_m",
            ),
            (
                _TCGEN05_GROUPED_SELECTED_MAILBOX_PROBLEM_K,
                f"{group_info_var}.problem_shape_k",
            ),
            (
                _TCGEN05_GROUPED_SELECTED_MAILBOX_GLOBAL_M_START,
                (
                    f"({grouped_starts}.iterator + {metadata_idx_var} * "
                    f"cutlass.Int32({grouped_starts}.layout.stride[0])).load()"
                ),
            ),
        )
        if required_mailbox_fields is not None:
            assert _TCGEN05_GROUPED_SELECTED_MAILBOX_VALID in required_mailbox_fields
            assert required_mailbox_fields <= {
                field for field, _value in mailbox_values
            }
            mailbox_values = tuple(
                item for item in mailbox_values if item[0] in required_mailbox_fields
            )

        def source_m_fast_raster_stmts() -> list[ast.stmt]:
            backend = CompileEnvironment.current().backend
            source_n_tiles_expr = backend.cdiv_expr(
                f"{group_info_var}.problem_shape_m",
                f"cutlass.Int32({source_tile_n})",
                is_device=True,
            )
            source_m_tiles_expr = (
                backend.cdiv_expr(
                    f"{group_info_var}.problem_shape_n",
                    f"cutlass.Int32({source_tile_m})",
                    is_device=True,
                )
                if grouped.device_split_sizes
                else (
                    f"{group_info_var}.problem_shape_n // "
                    f"cutlass.Int32({source_tile_m})"
                )
            )
            tile_count_stmts = [
                statement_from_string(f"{source_n_tiles_var} = {source_n_tiles_expr}"),
                statement_from_string(f"{source_m_tiles_var} = {source_m_tiles_expr}"),
            ]
            return [
                *tile_count_stmts,
                create(
                    ast.If,
                    test=expr_from_string(
                        f"cutlass.Int32(0) < {source_m_tiles_var} <= "
                        f"{source_n_tiles_var}"
                    ),
                    body=[
                        # The CUTLASS group search excludes zero-tile groups;
                        # retain an explicit positive-divisor guard so that
                        # source-M rasterization cannot regress to modulo zero.
                        # For wide compact rows, walk source-M fastest to keep
                        # adjacent CTAs on nearby packed-A rows.
                        statement_from_string(
                            f"{source_m_fast_linear_var} = "
                            f"{cta_tile_idx_m_var} * {source_n_tiles_var} + "
                            f"{cta_tile_idx_n_var}"
                        ),
                        statement_from_string(
                            f"{cta_tile_idx_m_var} = "
                            f"{source_m_fast_linear_var} % {source_m_tiles_var}"
                        ),
                        statement_from_string(
                            f"{cta_tile_idx_n_var} = "
                            f"{source_m_fast_linear_var} // {source_m_tiles_var}"
                        ),
                    ],
                    orelse=[],
                ),
            ]

        def publish_current_tile_leader_stmts() -> list[ast.stmt]:
            return [
                statement_from_string(
                    f"{sched_pipeline}.producer_acquire({sched_producer_state})"
                ),
                statement_from_string(
                    f"{group_info_var} = {work_tile_var}.group_search_result"
                ),
                statement_from_string(
                    f"{metadata_idx_var} = {group_info_var}.group_idx"
                ),
                *(
                    [
                        statement_from_string(
                            f"{group_idx_var} = "
                            f"({grouped_real_groups}.iterator + "
                            f"{metadata_idx_var} * cutlass.Int32("
                            f"{grouped_real_groups}.layout.stride[0])).load()"
                        )
                    ]
                    if grouped_real_groups
                    else [
                        statement_from_string(f"{group_idx_var} = {metadata_idx_var}")
                    ]
                ),
                statement_from_string(
                    f"{cta_tile_idx_m_var} = {group_info_var}.cta_tile_idx_n"
                ),
                statement_from_string(
                    f"{cta_tile_idx_n_var} = "
                    f"{self._tcgen05_logical_m_coord_expr(f'{group_info_var}.cta_tile_idx_m')}"
                ),
                *source_m_fast_raster_stmts(),
                *[
                    statement_from_string(f"{slot(field)} = {value}")
                    for field, value in mailbox_values
                ],
                statement_from_string(
                    f"{sched_pipeline}.producer_commit({sched_producer_state})"
                ),
            ]

        def publish_current_tile_stmts() -> list[ast.stmt]:
            return [
                create(
                    ast.If,
                    test=expr_from_string(leader_predicate),
                    body=publish_current_tile_leader_stmts(),
                    orelse=[],
                ),
                statement_from_string(emit_pipeline_advance(sched_producer_state)),
                statement_from_string("cute.arch.sync_warp()"),
            ]

        def scheduler_advance_stmts() -> list[ast.stmt]:
            return [
                statement_from_string(f"{sched_var}.advance_to_next_work()"),
                statement_from_string(
                    f"{work_tile_var} = {sched_var}.get_current_work()"
                ),
            ]

        prelude: list[ast.stmt] = [
            statement_from_string(
                f"{sched_var} = cutlass.utils.StaticPersistentGroupTileScheduler.create("
                f"{grouped.sched_params}, cute.arch.block_idx(), "
                f"cute.arch.grid_dim(), ({plan.bm}, {plan.bn}, {plan.bk}), "
                "cutlass.utils.create_initial_search_state(), "
                f"{grouped.count}, {grouped.problem_sizes})"
            ),
            statement_from_string(
                f"{work_tile_var} = {sched_var}.initial_work_tile_info()"
            ),
            create(
                ast.While,
                test=expr_from_string(f"{work_tile_var}.is_valid_tile"),
                body=[*publish_current_tile_stmts(), *scheduler_advance_stmts()],
                orelse=[],
            ),
        ]

        if (
            grouped.full_coverage is not None
            and not grouped.full_coverage.consumer_local
        ):
            full = grouped.full_coverage
            assert source_tile_m == full.tile_m and source_tile_n == full.tile_n
            dense_index = device_function.new_var("tcgen05_grouped_dense_index")
            dense_step = device_function.new_var("tcgen05_grouped_dense_step")
            row, column = full.tile_coordinates(dense_index)
            dense_values = {
                _TCGEN05_GROUPED_SELECTED_MAILBOX_CTA_M: row,
                _TCGEN05_GROUPED_SELECTED_MAILBOX_CTA_N: column,
                _TCGEN05_GROUPED_SELECTED_MAILBOX_VALID: "cutlass.Int32(1)",
                _TCGEN05_GROUPED_SELECTED_MAILBOX_METADATA_IDX: "cutlass.Int32(0)",
                _TCGEN05_GROUPED_SELECTED_MAILBOX_PROBLEM_M: f"cutlass.Int32({full.m})",
                _TCGEN05_GROUPED_SELECTED_MAILBOX_PROBLEM_N: f"cutlass.Int32({full.n})",
                _TCGEN05_GROUPED_SELECTED_MAILBOX_PROBLEM_K: f"cutlass.Int32({full.k})",
                _TCGEN05_GROUPED_SELECTED_MAILBOX_GLOBAL_M_START: "cutlass.Int32(0)",
            }
            # The shared-RHS identity contraction consumes no group-id slot.
            # Retain exactly the fields selected by the ordinary dependency proof.
            assert all(field in dense_values for field, _value in mailbox_values)
            dense = [
                statement_from_string(
                    f"{dense_index} = cutlass.Int32(cute.arch.block_idx()[2])"
                ),
                statement_from_string(
                    f"{dense_step} = cutlass.Int32(cute.arch.grid_dim()[2])"
                ),
                create(
                    ast.While,
                    test=expr_from_string(
                        f"{dense_index} < cutlass.Int32({full.tiles})"
                    ),
                    body=[
                        create(
                            ast.If,
                            test=expr_from_string(leader_predicate),
                            body=[
                                statement_from_string(
                                    f"{sched_pipeline}.producer_acquire({sched_producer_state})"
                                ),
                                *[
                                    statement_from_string(
                                        f"{slot(field)} = {dense_values[field]}"
                                    )
                                    for field, _value in mailbox_values
                                ],
                                statement_from_string(
                                    f"{sched_pipeline}.producer_commit({sched_producer_state})"
                                ),
                            ],
                            orelse=[],
                        ),
                        statement_from_string(
                            emit_pipeline_advance(sched_producer_state)
                        ),
                        statement_from_string("cute.arch.sync_warp()"),
                        statement_from_string(
                            f"{dense_index} = {dense_index} + {dense_step}"
                        ),
                    ],
                    orelse=[],
                ),
            ]
            prelude = [
                create(
                    ast.If,
                    test=expr_from_string(full.predicate),
                    body=dense,
                    orelse=prelude,
                )
            ]

        prelude.extend(
            [
                create(
                    ast.If,
                    test=expr_from_string(leader_predicate),
                    body=[
                        statement_from_string(
                            f"{sched_pipeline}.producer_acquire({sched_producer_state})"
                        ),
                        statement_from_string(
                            f"{slot(_TCGEN05_GROUPED_SELECTED_MAILBOX_VALID)} = "
                            "cutlass.Int32(0)"
                        ),
                        statement_from_string(
                            f"{sched_pipeline}.producer_commit({sched_producer_state})"
                        ),
                    ],
                    orelse=[],
                ),
                statement_from_string(emit_pipeline_advance(sched_producer_state)),
                statement_from_string("cute.arch.sync_warp()"),
            ]
        )
        if grouped.full_coverage is not None and grouped.full_coverage.consumer_local:
            # Dense consumers have no scheduler waiter, including at the final
            # token. Keep the complete original producer/sentinel for fallback.
            prelude = [
                create(
                    ast.If,
                    test=expr_from_string(f"not {grouped.full_coverage.predicate}"),
                    body=prelude,
                    orelse=[],
                )
            ]
        return create(
            ast.If,
            test=expr_from_string(self._tcgen05_scheduler_role_predicate()),
            body=prelude,
            orelse=[],
        )

    def _build_scheduler_warp_role_local_while(
        self,
        device_function: DeviceFunction,
        layout: Tcgen05PersistentProgramIDs._Tcgen05PersistentLayout,
        *,
        required_mailbox_fields: frozenset[int] | None = None,
    ) -> ast.stmt:
        """Build the scheduler-warp's role-local while.

        Active only under ``ROLE_LOCAL_WITH_SCHEDULER``. The scheduler
        warp owns the persistent tile scheduler and publishes
        per-tile metadata + a sentinel via the broadcast pipeline.
        Consumer warps (TMA-load, MMA-exec, epi) wait on the same
        pipeline and read from ``layout.work_tile_smem``.

        The body is constructed *here* rather than extracted from
        device IR because the scheduler-warp work has no source
        statements in the user kernel — it is pure scheduling
        infrastructure.

        Dispatches by persistence model:

        - ``STATIC_PERSISTENT`` (default): emits
          ``StaticPersistentTileScheduler.create`` + the static
          persistent loop.
        - ``CLC_PERSISTENT`` (G2-H, cute_plan.md): emits
          ``nvvm.clusterlaunchcontrol_try_cancel`` per persistent-loop
          iteration; the response decoder unpacks the next cluster's
          CTA id (or a "canceled" sentinel) into the SMEM mailbox the
          consumer warps already read from. Active only on arch >= 100
          per ``validate_tcgen05_strategy_invariants``.
        """
        plan = self._tcgen05_plan()
        assert plan is not None and plan.has_scheduler_warp
        if self._tcgen05_uses_grouped_worklist_nm_runtime_clc():
            return self._build_scheduler_warp_role_local_while_clc(
                device_function, layout
            )
        if self._tcgen05_uses_grouped_worklist_nm_scheduler_mailbox():
            return self._build_grouped_worklist_nm_scheduler_warp_role_local_while(
                device_function,
                layout,
                required_mailbox_fields=required_mailbox_fields,
            )
        if plan.is_clc_persistent:
            return self._build_scheduler_warp_role_local_while_clc(
                device_function, layout
            )
        sched_plan = self._tcgen05_sched_pipeline_plan()
        assert sched_plan is not None
        sched_pipeline = sched_plan.pipeline
        sched_producer_state = sched_plan.producer_state

        sched_params_var = device_function.new_var(
            "tcgen05_scheduler_warp_tile_sched_params"
        )
        sched_var = device_function.new_var("tcgen05_scheduler_warp_tile_sched")
        work_tile_var = device_function.new_var("tcgen05_scheduler_warp_work_tile")

        # ``PipelineAsync`` producer/consumer mbarrier ops are
        # per-thread; with ``producer_arrive_count = 1`` only one
        # thread should arrive on the full barrier per stage.
        # Gate the producer ops + SMEM writes on lane 0 of the
        # scheduler warp. ``mbarrier.wait`` (used by
        # ``producer_acquire``) is fine to call from any thread —
        # PTX semantics stall the thread until the phase flips —
        # but I keep the leader-only gate for it too, paired with
        # a ``sync_warp`` after, so the SMEM write order vs the
        # warp's other 31 lanes is well-defined. The 31 non-leader
        # lanes do nothing per iteration; ``advance_to_next_work``
        # mutates register-resident state that all 32 threads
        # share via warp-uniform reads.
        leader_predicate = "cute.arch.lane_idx() == cutlass.Int32(0)"

        def publish_current_tile_leader_stmts() -> list[ast.stmt]:
            return [
                statement_from_string(
                    f"{sched_pipeline}.producer_acquire({sched_producer_state})"
                ),
                statement_from_string(
                    f"{layout.work_tile_smem}[cutlass.Int32(0)] = {work_tile_var}.tile_idx[0]"
                ),
                statement_from_string(
                    f"{layout.work_tile_smem}[cutlass.Int32(1)] = {work_tile_var}.tile_idx[1]"
                ),
                statement_from_string(
                    f"{layout.work_tile_smem}[cutlass.Int32(2)] = {work_tile_var}.tile_idx[2]"
                ),
                statement_from_string(
                    f"{layout.work_tile_smem}[cutlass.Int32(3)] = "
                    f"(cutlass.Int32(1) if {work_tile_var}.is_valid_tile "
                    f"else cutlass.Int32(0))"
                ),
                statement_from_string(
                    f"{sched_pipeline}.producer_commit({sched_producer_state})"
                ),
            ]

        def publish_current_tile_stmts() -> list[ast.stmt]:
            return [
                create(
                    ast.If,
                    test=expr_from_string(leader_predicate),
                    body=publish_current_tile_leader_stmts(),
                    orelse=[],
                ),
                # Advance state on every lane so all 32 threads stay in
                # sync on the producer state register. Then sync_warp
                # so the leader's SMEM writes are observable to lanes
                # 1-31 (defensive — they don't read this SMEM, but it
                # keeps the warp's view of memory uniform for any
                # future reads).
                statement_from_string(emit_pipeline_advance(sched_producer_state)),
                statement_from_string("cute.arch.sync_warp()"),
            ]

        def scheduler_advance_stmts() -> list[ast.stmt]:
            return [
                statement_from_string(f"{sched_var}.advance_to_next_work()"),
                statement_from_string(
                    f"{work_tile_var} = {sched_var}.get_current_work()"
                ),
            ]

        def per_tile_body(*, publish_if: str | None = None) -> list[ast.stmt]:
            if publish_if is None:
                return [
                    *self._tcgen05_guard_logical_work(
                        work_tile_var, publish_current_tile_stmts()
                    ),
                    *scheduler_advance_stmts(),
                ]
            return [
                *self._tcgen05_guard_logical_work(
                    work_tile_var,
                    [
                        create(
                            ast.If,
                            test=expr_from_string(publish_if),
                            body=publish_current_tile_stmts(),
                            orelse=[],
                        )
                    ],
                ),
                *scheduler_advance_stmts(),
            ]

        # Producer loop: while the current work tile is valid, publish
        # it and advance to the next. The final sentinel publish (with
        # ``is_valid=False``) happens *outside* the loop so the
        # consumer warps see exactly one trailing invalid arrival
        # after the last valid tile. CuTe DSL forbids ``break`` inside
        # ``@cute.kernel`` so the loop test runs on the
        # freshly-fetched ``work_tile_var``.
        prelude: list[ast.stmt] = [
            statement_from_string(
                f"{sched_params_var} = cutlass.utils.PersistentTileSchedulerParams("
                f"{self._tcgen05_persistent_tile_sched_params_args(cluster_m=layout.cluster_m, cluster_n=layout.cluster_n)})"
            ),
        ]

        def scheduler_create_stmts() -> list[ast.stmt]:
            return [
                statement_from_string(
                    f"{sched_var} = cutlass.utils.StaticPersistentTileScheduler.create("
                    f"{sched_params_var}, cute.arch.block_idx(), cute.arch.grid_dim())"
                ),
                statement_from_string(
                    f"{work_tile_var} = {sched_var}.initial_work_tile_info()"
                ),
            ]

        prelude.extend(scheduler_create_stmts())

        # Sentinel publish after the loop exits: producer-only writes
        # gated on lane 0, then the producer arrive on the full
        # barrier (so the last consumer iteration sees an invalid
        # tile and exits the consumer loop).
        def sentinel_leader_stmts() -> list[ast.stmt]:
            return [
                statement_from_string(
                    f"{sched_pipeline}.producer_acquire({sched_producer_state})"
                ),
                statement_from_string(
                    f"{layout.work_tile_smem}[cutlass.Int32(0)] = cutlass.Int32(0)"
                ),
                statement_from_string(
                    f"{layout.work_tile_smem}[cutlass.Int32(1)] = cutlass.Int32(0)"
                ),
                statement_from_string(
                    f"{layout.work_tile_smem}[cutlass.Int32(2)] = cutlass.Int32(0)"
                ),
                statement_from_string(
                    f"{layout.work_tile_smem}[cutlass.Int32(3)] = cutlass.Int32(0)"
                ),
                statement_from_string(
                    f"{sched_pipeline}.producer_commit({sched_producer_state})"
                ),
            ]

        def sentinel_publish_stmts() -> list[ast.stmt]:
            return [
                create(
                    ast.If,
                    test=expr_from_string(leader_predicate),
                    body=sentinel_leader_stmts(),
                    orelse=[],
                ),
                statement_from_string(emit_pipeline_advance(sched_producer_state)),
                statement_from_string("cute.arch.sync_warp()"),
            ]

        full_edge_split = (
            plan.tma_store_full_tiles_only
            and device_function.cute_state.has_tcgen05_epi_role_full_edge_split
        )
        if full_edge_split:
            full_tile_var = device_function.new_var("tcgen05_scheduler_warp_full_tile")
            full_tile_expr = self._tcgen05_output_full_tile_expr_for_work_tile(
                work_tile_var
            )
            # The split scheduler scans the same static tile space twice:
            # first publishing interior full tiles, then publishing fringe
            # edge tiles after a sentinel and scheduler reset.
            for is_full_phase in (True, False):
                publish_if = full_tile_var if is_full_phase else f"not {full_tile_var}"
                prelude.append(
                    create(
                        ast.While,
                        test=expr_from_string(f"{work_tile_var}.is_valid_tile"),
                        body=[
                            statement_from_string(
                                f"{full_tile_var} = {full_tile_expr}"
                            ),
                            *per_tile_body(publish_if=publish_if),
                        ],
                        orelse=[],
                    )
                )
                prelude.extend(sentinel_publish_stmts())
                if is_full_phase:
                    prelude.extend(scheduler_create_stmts())
        else:
            prelude.append(
                create(
                    ast.While,
                    test=expr_from_string(f"{work_tile_var}.is_valid_tile"),
                    body=per_tile_body(),
                    orelse=[],
                )
            )
            prelude.extend(sentinel_publish_stmts())

        return create(
            ast.If,
            test=expr_from_string(self._tcgen05_scheduler_role_predicate()),
            body=prelude,
            orelse=[],
        )

    def _build_scheduler_warp_role_local_while_clc(
        self,
        device_function: DeviceFunction,
        layout: Tcgen05PersistentProgramIDs._Tcgen05PersistentLayout,
    ) -> ast.stmt:
        """G2-H: CLC-driven scheduler-warp body (cute_plan.md).

        Replaces the ``StaticPersistentTileScheduler.create`` +
        ``advance_to_next_work``/``get_current_work`` pattern with a
        ``nvvm.clusterlaunchcontrol_try_cancel`` query per
        persistent-loop iteration. The CLC instruction asynchronously
        writes a 4 × Int32 response to the SMEM buffer allocated by
        ``_emit_clc_smem_setup`` (in ``cute_mma._codegen_cute_mma``);
        each response slot decodes to ``(bidx, bidy, bidz, valid)``
        via ``cute.arch.clc_response``.

        Topology (mirrors Quack's ``_fetch_next_work_idx`` CLC branch
        in ``quack/quack/tile_scheduler.py``):

        - cluster_m == 1: each CTA is its own cluster, so each CTA's
          scheduler warp issues an independent ``nomulticast``
          ``try_cancel`` against its own local SMEM and publishes
          locally.
        - cluster_m > 1: only the cluster leader CTA's scheduler
          warp issues the CLC query (matches Quack's
          ``is_scheduler_warp = block_idx_in_cluster() == 0``).
          Non-leader CTAs receive the response indirectly because
          the leader broadcasts the resulting work tile to every
          peer CTA's SMEM mailbox via ``_cute_store_shared_remote_x4``.
          Each peer CTA's consumer lanes wait on their local full
          barrier and release to the leader's empty barrier. Setup
          therefore counts consumer threads across the whole cluster,
          unlike the static scheduler's per-CTA empty-barrier count.

        cluster_m collapse: the publish writes the per-CTA M
        coordinate into each peer's mailbox by adding
        ``peer_cta_rank_in_cluster_m`` to the CLC response's
        ``bidx`` (which encodes the *first* CTA of the next
        cluster). The consumer's ``// cluster_m`` collapse in
        ``_tcgen05_logical_m_coord_expr`` then converts back to
        the cluster-level virtual_pid for tile distribution.
        """
        plan = self._tcgen05_plan()
        assert plan is not None and plan.has_scheduler_warp and plan.is_clc_persistent
        row_union_clc = plan.row_union is not None and plan.row_union.linear_record_clc
        linear_record_clc = (
            self._tcgen05_uses_grouped_worklist_nm_runtime_clc() or row_union_clc
        )
        sched_plan = self._tcgen05_sched_pipeline_plan()
        assert sched_plan is not None
        sched_pipeline = sched_plan.pipeline
        sched_producer_state = sched_plan.producer_state
        sched_consumer_state = sched_plan.consumer_state
        clc_response_smem_ptr = sched_plan.clc_response_smem_ptr
        clc_mbar_smem_ptr = sched_plan.clc_mbar_smem_ptr
        clc_mbar_phase = sched_plan.clc_mbar_phase
        assert clc_response_smem_ptr and clc_mbar_smem_ptr and clc_mbar_phase, (
            "CLC scheduler-warp body requires sched plan SMEM/mbarrier "
            "names; was _new_tcgen05_sched_pipeline_plan called with "
            "use_clc=True?"
        )

        # Per-iteration response decoded into named locals so the
        # publish writes are linear and easy to read in generated
        # code.
        bidx_var = device_function.new_var("tcgen05_clc_bidx")
        bidy_var = device_function.new_var("tcgen05_clc_bidy")
        bidz_var = device_function.new_var("tcgen05_clc_bidz")
        valid_var = device_function.new_var("tcgen05_clc_valid")
        # Initial work-tile coordinates come from the launcher's
        # ``block_idx()`` so the first iteration runs the cluster
        # the launcher placed this CTA in. Subsequent iterations
        # come from the CLC response, with the per-CTA offset added
        # back in the publish step.
        cluster_bidx_var = device_function.new_var("tcgen05_clc_cluster_bidx")
        cluster_bidy_var = device_function.new_var("tcgen05_clc_cluster_bidy")
        cluster_bidz_var = device_function.new_var("tcgen05_clc_cluster_bidz")

        leader_predicate = "cute.arch.lane_idx() == cutlass.Int32(0)"

        # CLC mbarrier init: ``mbarrier_init(addr, 1)`` arms the
        # barrier with arrival count 1 (only the CLC issuer arrives).
        # Followed by ``mbarrier_init_fence`` + ``sync_warp`` per
        # Quack's ``_init_clc_mbarrier`` pattern. Gate on lane 0 so
        # only one thread runs the init op; the fence/sync make the
        # init visible to the other 31 lanes.
        clc_init_block: list[ast.stmt] = [
            create(
                ast.If,
                test=expr_from_string(leader_predicate),
                body=[
                    statement_from_string(
                        f"cute.arch.mbarrier_init({clc_mbar_smem_ptr}, 1)"
                    ),
                ],
                orelse=[],
            ),
            statement_from_string("cute.arch.mbarrier_init_fence()"),
            statement_from_string("cute.arch.sync_warp()"),
        ]

        # Initial cluster coordinates: decode block_idx[2] -> tile_idx
        # via ``StaticPersistentTileScheduler.create``. This matches
        # the persistent-grid encoding the launch grid uses
        # (``(cluster_m, 1, num_clusters)``) — block_idx[0] is the
        # CTA-in-cluster offset and block_idx[2] is the linear
        # cluster id, so the static scheduler's
        # ``_get_current_work_for_linear_idx`` is the right decoder.
        # CLC's response also returns CTAIDs in this coordinate
        # system (``bidz`` is the cluster id, ``bidx`` is the CTA
        # within cluster), so we can use the same decoder for
        # subsequent CLC responses by setting up a fresh
        # ``StaticPersistentTileScheduler`` from the CLC bidx/bidy/bidz.
        #
        # ``valid_var`` is Int32 because ``cute.arch.clc_response``
        # returns Int32 for the valid flag. The CuTe DSL's while-region
        # type-checker rejects type changes between iterations.
        sched_var: str | None = None
        if linear_record_clc:
            clc_initial_block = [
                # The runtime table has exactly one row per launched cluster.
                # Keep the raw z CTAID as the record index; the x CTAID differs
                # between the two peers and must not participate in table lookup.
                statement_from_string(f"{cluster_bidx_var} = cutlass.Int32(0)"),
                statement_from_string(f"{cluster_bidy_var} = cutlass.Int32(0)"),
                statement_from_string(
                    f"{cluster_bidz_var} = cutlass.Int32(cute.arch.block_idx()[2])"
                ),
                statement_from_string(f"{valid_var} = cutlass.Int32(1)"),
            ]
        else:
            sched_params_var = device_function.new_var(
                "tcgen05_clc_initial_sched_params"
            )
            sched_var = device_function.new_var("tcgen05_clc_initial_sched")
            work_tile_var = device_function.new_var("tcgen05_clc_initial_work_tile")
            clc_initial_block = [
                # Build the persistent tile-scheduler params for the
                # initial decode. ``layout.cluster_m/n`` agrees with the
                # launch grid's cluster shape ``(cluster_m, cluster_n, 1)``.
                statement_from_string(
                    f"{sched_params_var} = cutlass.utils.PersistentTileSchedulerParams("
                    f"{self._tcgen05_persistent_tile_sched_params_args(cluster_m=layout.cluster_m, cluster_n=layout.cluster_n)})"
                ),
                statement_from_string(
                    f"{sched_var} = cutlass.utils.StaticPersistentTileScheduler.create("
                    f"{sched_params_var}, cute.arch.block_idx(), cute.arch.grid_dim())"
                ),
                statement_from_string(
                    f"{work_tile_var} = {sched_var}.initial_work_tile_info()"
                ),
                # Bind the initial cluster coords from the static
                # scheduler's decode. ``tile_idx[0]`` is already the
                # per-CTA M coordinate (= cluster_id_m * cluster_m +
                # cta_in_cluster_m) since the static scheduler folds the
                # cta_in_cluster offset in via
                # ``_get_current_work_for_linear_idx``.
                statement_from_string(
                    f"{cluster_bidx_var} = {work_tile_var}.tile_idx[0]"
                ),
                statement_from_string(
                    f"{cluster_bidy_var} = {work_tile_var}.tile_idx[1]"
                ),
                statement_from_string(
                    f"{cluster_bidz_var} = {work_tile_var}.tile_idx[2]"
                ),
                # Initial valid flag: the scheduler warp only runs if
                # the launcher placed it on a valid cluster. The CLC
                # query handles invalidation for subsequent waves.
                statement_from_string(
                    f"{valid_var} = cutlass.Int32(1) "
                    f"if {work_tile_var}.is_valid_tile else cutlass.Int32(0)"
                ),
            ]

        # Per-tile publish: write (bidx, bidy, bidz, valid) into the
        # work-tile mailbox.
        #
        # cluster_m == 1: leader writes its own local mailbox; consumer
        # waits on local empty mbar (per-CTA pipeline).
        # cluster_m  > 1: leader broadcasts to every peer CTA's mailbox
        # via ``_cute_store_shared_remote_x4`` and arms each peer's
        # full mbar with ``mbarrier_arrive_and_expect_tx``. Consumer
        # arrivals are routed to leader's empty mbar via
        # ``consumer_mask=Int32(0)`` (the cluster-leader topology set
        # up in ``cute_mma._codegen_cute_mma`` for the CLC path).
        #
        # ``producer_acquire`` is **per-thread** (its underlying
        # ``mbarrier.wait`` PTX stalls each issuing thread until the
        # phase flips), so every lane of the scheduler warp must call
        # it; gating it under a ``if lane_idx == 0`` would only stall
        # lane 0 and let the other 31 lanes race ahead, breaking the
        # producer/consumer handshake. Mirrors Quack's
        # ``write_work_tile_to_smem`` in
        # ``quack/quack/tile_scheduler.py`` which calls
        # ``producer_acquire`` on the full warp before the per-lane
        # ``if lane_idx < cluster_size`` branch.
        # Pre-declare the cluster-broadcast variable names so pyrefly
        # sees them defined unconditionally; their usage stays inside
        # ``if layout.cluster_m > 1`` branches below.
        sched_barrier_ptr = ""
        sched_peer_rank = ""
        sched_peer_m = ""
        staged_work_tile_mailbox = self._tcgen05_uses_staged_work_tile_mailbox()
        producer_barrier_state = (
            sched_producer_state if staged_work_tile_mailbox else sched_consumer_state
        )
        producer_smem_ptr = self._tcgen05_work_tile_producer_smem_ptr(layout)
        # Full cluster size for the leader broadcast: with cluster_n > 1 the
        # CLC leader must feed every CTA in the (cluster_m x cluster_n)
        # cluster, publishing each peer's own (M, N) tile coordinates.
        # CUDA cluster ranks are x-fastest, so peer rank r sits at
        # ``(r % cluster_m, r // cluster_m)`` in the cluster.
        sched_cluster_size = layout.cluster_m * layout.cluster_n
        if layout.cluster_m > 1:
            sched_barrier_ptr = device_function.new_var("tcgen05_clc_sched_barrier_ptr")
            sched_peer_rank = device_function.new_var("tcgen05_clc_sched_peer_rank")
            sched_peer_m = device_function.new_var("tcgen05_clc_sched_peer_m")
            if layout.cluster_n > 1:
                sched_peer_n = device_function.new_var("tcgen05_clc_sched_peer_n")
                peer_coord_stmts = [
                    statement_from_string(
                        f"{sched_peer_m} = "
                        f"{sched_peer_rank} % cutlass.Int32({layout.cluster_m})"
                    ),
                    statement_from_string(
                        f"{sched_peer_n} = "
                        f"{sched_peer_rank} // cutlass.Int32({layout.cluster_m})"
                    ),
                ]
                publish_bidy_expr = f"{cluster_bidy_var} + {sched_peer_n}"
            else:
                peer_coord_stmts = [
                    statement_from_string(f"{sched_peer_m} = {sched_peer_rank}")
                ]
                publish_bidy_expr = cluster_bidy_var
            publish_bidx_expr = (
                "cutlass.Int32(0)"
                if row_union_clc
                else f"{cluster_bidx_var} + {sched_peer_m}"
            )
            if row_union_clc:
                publish_bidy_expr = "cutlass.Int32(0)"
            # Whole-warp prelude: every lane runs ``producer_acquire``
            # (mbarrier wait) and computes the warp-uniform barrier
            # pointer + lane id. Lanes ``cluster_size..31`` no-op past
            # the per-peer broadcast branch.
            per_tile_publish_warp = [
                statement_from_string(
                    f"{sched_pipeline}.producer_acquire({sched_producer_state})"
                ),
                # Remote stores arm the current full barrier, matching Quack's
                # PipelineState pairing and the clustered static mailbox bridge.
                statement_from_string(
                    f"{sched_barrier_ptr} = "
                    f"{sched_pipeline}.producer_get_barrier({producer_barrier_state})"
                ),
                statement_from_string(f"{sched_peer_rank} = cute.arch.lane_idx()"),
                create(
                    ast.If,
                    test=expr_from_string(
                        f"{sched_peer_rank} < cutlass.Int32({sched_cluster_size})"
                    ),
                    body=[
                        *peer_coord_stmts,
                        statement_from_string(
                            "cute.arch.mbarrier_arrive_and_expect_tx("
                            f"{sched_barrier_ptr}, 16, {sched_peer_rank})"
                        ),
                        statement_from_string(
                            f"_cute_store_shared_remote_x4("
                            f"{publish_bidx_expr}, "
                            f"{publish_bidy_expr}, "
                            f"{cluster_bidz_var}, "
                            f"{valid_var}, "
                            f"smem_ptr={producer_smem_ptr}, "
                            f"mbar_ptr={sched_barrier_ptr}, "
                            f"peer_cta_rank_in_cluster={sched_peer_rank})"
                        ),
                    ],
                    orelse=[],
                ),
            ]
        else:
            # cluster_m == 1: lane-0-only local publish + commit. Still
            # call ``producer_acquire`` on every lane (the mbarrier wait
            # must stall the whole warp), then the leader gate writes +
            # commits.
            per_tile_publish_warp = [
                statement_from_string(
                    f"{sched_pipeline}.producer_acquire({sched_producer_state})"
                ),
                create(
                    ast.If,
                    test=expr_from_string(leader_predicate),
                    body=[
                        statement_from_string(
                            f"{self._tcgen05_work_tile_producer_slot(layout, 0)} = "
                            f"{cluster_bidx_var}"
                        ),
                        statement_from_string(
                            f"{self._tcgen05_work_tile_producer_slot(layout, 1)} = "
                            f"{cluster_bidy_var}"
                        ),
                        statement_from_string(
                            f"{self._tcgen05_work_tile_producer_slot(layout, 2)} = "
                            f"{cluster_bidz_var}"
                        ),
                        statement_from_string(
                            f"{self._tcgen05_work_tile_producer_slot(layout, 3)} = "
                            f"{valid_var}"
                        ),
                        statement_from_string(
                            f"{sched_pipeline}.producer_commit({sched_producer_state})"
                        ),
                    ],
                    orelse=[],
                ),
            ]

        # CLC query block: arm + issue + wait + decode. Quack's
        # pattern: lane 0 of the leader CTA's scheduler warp issues
        # the query, all 32 lanes of that warp wait, then
        # ``cute.arch.clc_response`` reads back from SMEM. ``try_cancel``
        # cancels exactly one cluster per call, so issuance is gated
        # to leader CTA only for ``cluster_m > 1``.
        # Update cluster coordinate locals so the next iteration's
        # publish uses the just-decoded response.
        #
        # CLC returns the CTAID of the canceled cluster's first CTA
        # in (bidx, bidy, bidz). With Helion's launch grid
        # ``(cluster_m, 1, num_clusters)`` the first CTA of cluster N
        # has CTAID ``(0, 0, N)``, so ``bidz`` IS the cluster id.
        # Reuse the existing ``StaticPersistentTileScheduler`` to
        # decode that cluster id back to per-CTA tile coordinates by
        # writing ``_current_work_linear_idx`` and calling
        # ``get_current_work()``. This matches what the static path
        # would have computed for the same cluster id, so the
        # consumer's ``virtual_pid = work_tile_smem[0] // cluster_m``
        # collapse continues to work.
        clc_helper_call = "_cute_issue_clc_query_nomulticast"
        clc_query_block = [
            statement_from_string("cute.arch.sync_warp()"),
            create(
                ast.If,
                test=expr_from_string(leader_predicate),
                body=[
                    statement_from_string(
                        f"cute.arch.mbarrier_arrive_and_expect_tx("
                        f"{clc_mbar_smem_ptr}, 16)"
                    ),
                    statement_from_string(
                        f"{clc_helper_call}("
                        f"{clc_mbar_smem_ptr}, {clc_response_smem_ptr})"
                    ),
                ],
                orelse=[],
            ),
            statement_from_string("cute.arch.sync_warp()"),
            statement_from_string(
                f"cute.arch.mbarrier_wait({clc_mbar_smem_ptr}, {clc_mbar_phase})"
            ),
            statement_from_string(
                f"{clc_mbar_phase} = {clc_mbar_phase} ^ cutlass.Int32(1)"
            ),
            statement_from_string(
                f"({bidx_var}, {bidy_var}, {bidz_var}, {valid_var}) = "
                f"cute.arch.clc_response({clc_response_smem_ptr})"
            ),
            statement_from_string("cute.arch.fence_view_async_shared()"),
        ]
        if linear_record_clc:
            clc_query_block.extend(
                [
                    statement_from_string(f"{cluster_bidx_var} = {bidx_var}"),
                    statement_from_string(f"{cluster_bidy_var} = {bidy_var}"),
                    statement_from_string(f"{cluster_bidz_var} = {bidz_var}"),
                ]
            )
        else:
            assert sched_var is not None
            next_work_tile_var = device_function.new_var("tcgen05_clc_next_work_tile")
            clc_query_block.extend(
                [
                    statement_from_string(
                        f"{sched_var}._current_work_linear_idx = {bidz_var}"
                    ),
                    statement_from_string(
                        f"{next_work_tile_var} = {sched_var}.get_current_work()"
                    ),
                    statement_from_string(
                        f"{cluster_bidx_var} = {next_work_tile_var}.tile_idx[0]"
                    ),
                    statement_from_string(
                        f"{cluster_bidy_var} = {next_work_tile_var}.tile_idx[1]"
                    ),
                    statement_from_string(
                        f"{cluster_bidz_var} = {next_work_tile_var}.tile_idx[2]"
                    ),
                ]
            )

        # ``per_tile_publish_warp`` already does its own per-lane
        # gating internally (lane-0-only commit for cluster_m=1, the
        # ``lane_idx < cluster_m`` per-peer broadcast for cluster_m>1).
        # Inserting another leader-only ``if`` around it would gate
        # the entire publish to lane 0 and either skip the broadcast
        # to peer CTAs or stall only lane 0 on ``producer_acquire``.
        per_tile_body = [
            *per_tile_publish_warp,
            statement_from_string(emit_pipeline_advance(sched_producer_state)),
            *clc_query_block,
            statement_from_string("cute.arch.sync_warp()"),
        ]

        prelude: list[ast.stmt] = []
        # PDL (programmatic dependent launch) hand-off: the scheduler
        # warp must wait for the prior kernel before reading CLC state.
        # ``cute.arch.clc_response`` returns ``valid=0`` if the
        # ``griddepcontrol`` chain isn't established. Quack calls this
        # in the scheduler-warp body (see
        # ``quack/quack/gemm_sm100.py``: ``if const_expr(self.use_pdl):
        # cute.arch.griddepcontrol_wait()`` inside
        # ``if warp_idx == self.scheduler_warp_id:``). Without this the
        # CLC query reliably returns invalid on the very first call,
        # so the persistent loop terminates after iteration 0 and the
        # kernel produces only the initial-tile output.
        prelude.append(statement_from_string("cute.arch.griddepcontrol_wait()"))
        prelude.extend(clc_init_block)
        prelude.extend(clc_initial_block)
        # Producer loop: publish the current tile and then query the next one.
        # CuTe DSL forbids ``break`` so the loop test is on the
        # dynamically-updated ``valid_var``.
        # ``valid_var`` is Int32 because ``cute.arch.clc_response``
        # returns Int32 for the valid flag — comparing against 0
        # keeps the test type-stable across iterations.
        prelude.append(
            create(
                ast.While,
                test=expr_from_string(f"{valid_var} != cutlass.Int32(0)"),
                body=per_tile_body,
                orelse=[],
            )
        )
        # Sentinel publish after the loop exits so the consumer warps'
        # last-iteration wait sees an invalid tile and exits. The
        # sentinel mirrors the in-loop publish exactly: cluster_m>1
        # broadcasts ``(0, 0, 0, valid=0)`` to every peer CTA via
        # ``_cute_store_shared_remote_x4``; cluster_m=1 writes
        # locally. ``producer_acquire`` runs on every lane.
        if layout.cluster_m > 1:
            sentinel_warp: list[ast.stmt] = [
                statement_from_string(
                    f"{sched_pipeline}.producer_acquire({sched_producer_state})"
                ),
                # Remote stores arm the current full barrier, matching Quack's
                # PipelineState pairing and the clustered static mailbox bridge.
                statement_from_string(
                    f"{sched_barrier_ptr} = "
                    f"{sched_pipeline}.producer_get_barrier({producer_barrier_state})"
                ),
                statement_from_string(f"{sched_peer_rank} = cute.arch.lane_idx()"),
                create(
                    ast.If,
                    test=expr_from_string(
                        f"{sched_peer_rank} < cutlass.Int32({sched_cluster_size})"
                    ),
                    body=[
                        statement_from_string(
                            "cute.arch.mbarrier_arrive_and_expect_tx("
                            f"{sched_barrier_ptr}, 16, {sched_peer_rank})"
                        ),
                        statement_from_string(
                            f"_cute_store_shared_remote_x4("
                            "cutlass.Int32(0), cutlass.Int32(0), "
                            "cutlass.Int32(0), cutlass.Int32(0), "
                            f"smem_ptr={producer_smem_ptr}, "
                            f"mbar_ptr={sched_barrier_ptr}, "
                            f"peer_cta_rank_in_cluster={sched_peer_rank})"
                        ),
                    ],
                    orelse=[],
                ),
            ]
        else:
            sentinel_warp = [
                statement_from_string(
                    f"{sched_pipeline}.producer_acquire({sched_producer_state})"
                ),
                create(
                    ast.If,
                    test=expr_from_string(leader_predicate),
                    body=[
                        statement_from_string(
                            f"{self._tcgen05_work_tile_producer_slot(layout, 0)} = "
                            "cutlass.Int32(0)"
                        ),
                        statement_from_string(
                            f"{self._tcgen05_work_tile_producer_slot(layout, 1)} = "
                            "cutlass.Int32(0)"
                        ),
                        statement_from_string(
                            f"{self._tcgen05_work_tile_producer_slot(layout, 2)} = "
                            "cutlass.Int32(0)"
                        ),
                        statement_from_string(
                            f"{self._tcgen05_work_tile_producer_slot(layout, 3)} = "
                            "cutlass.Int32(0)"
                        ),
                        statement_from_string(
                            f"{sched_pipeline}.producer_commit({sched_producer_state})"
                        ),
                    ],
                    orelse=[],
                ),
            ]
        prelude.extend(
            [
                *sentinel_warp,
                statement_from_string(emit_pipeline_advance(sched_producer_state)),
                # Quack drains the scheduler pipeline from the whole scheduler
                # warp after publishing the invalid work tile. Helion's
                # scheduler warp does not consume its own mailbox, so tail here
                # waits for consumer roles to release the sentinel before the
                # scheduler role exits.
                statement_from_string(
                    f"{sched_pipeline}.producer_tail({sched_producer_state})"
                ),
                statement_from_string("cute.arch.sync_warp()"),
            ]
        )

        # cluster_m>1: gate the CLC body to leader CTA only (Quack
        # pattern). Non-leader CTAs' scheduler warps idle while the
        # leader broadcasts to every peer's mailbox via
        # ``_cute_store_shared_remote_x4``. The non-leader scheduler
        # warps' consumer-side wait/release is unaffected because the
        # leader's broadcast arms each peer's full mbar via cross-CTA
        # ``mbarrier_arrive_and_expect_tx``, and the leader's
        # ``producer_acquire`` waits on the cluster-routed empty mbar
        # (set up via ``consumer_mask_to_leader=True`` in
        # ``cute_mma._codegen_cute_mma`` for the CLC path).
        scheduler_predicate = self._tcgen05_scheduler_role_predicate()
        if layout.cluster_m > 1:
            scheduler_predicate = (
                f"({scheduler_predicate}) "
                "and cute.arch.make_warp_uniform("
                "cute.arch.block_idx_in_cluster()) == cutlass.Int32(0)"
            )
        return create(
            ast.If,
            test=expr_from_string(scheduler_predicate),
            body=prelude,
            orelse=[],
        )

    def _build_c_input_warp_role_local_while(
        self,
        device_function: DeviceFunction,
        layout: Tcgen05PersistentProgramIDs._Tcgen05PersistentLayout,
        *,
        shared_body_extracted: list[ast.stmt] | None = None,
        tile_phase: str = "all",
        inline_aux_only: bool = False,
    ) -> ast.stmt | list[ast.stmt]:
        """Build the C-input warp's role-local while
        (``cute_plan.md`` §7.5.3.2 producer-body split).

        Workstream A Stage 5 (cycle 94, the merge): when ``inline_aux_only`` is
        set, this does NOT build a self-contained role-local while (which would
        be a second sched-pipeline consumer on the warp). Instead it returns the
        per-tile aux GMEM->SMEM producer body (``list[ast.stmt]``) for the
        CALLER to inject into the (widened) epilogue role-local while on the
        STORE warp, which already owns the single per-warp sched-pipeline
        handshake. This is how the store/epi-load warp does BOTH the early
        residual load and the late TMA-D store drain in one loop at 8 warps. No
        post-loop producer tail is returned (the aux producer_state advance is
        inside the shared loop's store-warp branch, so a post-loop tail would
        hit an IR domination error; the boundary drain is unnecessary because
        the consumers release all stages by loop exit). ``inline_aux_only`` uses
        the post-L2 ``tile_offset_0/1`` coords (always present in the epi loop's
        dependency stmts), so it asserts the post-L2 path.

        Active when the matmul plan has ``c_input_warp_count > 0``
        AND the forward FX walker discovered one or more
        auxiliary-tensor descriptors. The C-input warp participates
        in the scheduler-broadcast pipeline as a *consumer* of
        ``sched_pipeline`` (per-tile coord broadcast) and as a
        *producer* of the ``c_pipeline_aux`` SMEM aux ring
        (one cooperative ``cute.copy(GMEM_aux, SMEM_aux[stage])``
        per output tile per descriptor).

        Per-tile body:

        1. ``sched_pipeline.consumer_wait`` + valid-flag read
           (shared with ``_build_role_local_while_with_scheduler``
           via ``_build_sched_pipeline_consumer_{wait,release}_block``).
        2. ``virtual_pid_var`` write decomposed from
           ``work_tile_smem`` (downstream M / N tile coords used
           by the per-descriptor aux GMEM-tile builder).
        3. On the production post-L2 path,
           ``sched_pipeline.consumer_release`` runs after those
           coordinates are materialized, before aux staging, so the
           scheduler warp can run ahead. The defensive no-post-L2
           fallback keeps the release at the bottom because that path
           still reads the scheduler SMEM mailbox in the aux setup.
        4. Per output tile, build the per-CTA aux GMEM region:
           ``cute.local_tile(host_aux, (bm_per_cta, bn),
           (tile_m, tile_n))`` where
           ``bm_per_cta = bm // cluster_m`` under
           ``use_2cta_instrs`` (otherwise ``bm``). For rank-1
           trailing-axis broadcast aux the M extent is also
           ``bm_per_cta``. ``flat_divide(epi_tile)`` +
           ``group_modes(2, rank)`` to expose a flat subtile
           axis whose extent matches the consumer's per-CTA
           subtile count.
        5. Build the SIMT cooperative ``TiledCopy`` once per
           descriptor, deriving a 32-thread ordered layout from the actual
           epilogue tile and dtype (preferring M4/N8 only when it fits), with a
           ``(1, vector_elements)`` value layout (up to 128 bits, reduced
           when the tile requires it) and a
           ``CopyUniversalOp`` atom. ``get_slice(lane_idx)``
           per lane.
        6. Per subtile (``cutlass.range(subtile_count,
           unroll_full=True)``): ``producer_acquire(state)`` →
           per descriptor build the per-subtile GMEM slice and
           SMEM stage slice and issue
           ``cute.copy(tiled_copy, gmem_part, smem_part)`` →
           ``cute.arch.sync_warp()`` → ``cute.arch.fence_acq_rel_cta()``
           (so the consumer's generic SMEM reads after
           ``consumer_wait`` see the producer's stores —
           ``mbarrier.arrive`` from ``AsyncThread`` has relaxed
           memory semantics and does not fence by itself) →
           ``c_pipeline_aux.producer_commit(state)`` →
           ``state.advance()``.
        7. The sentinel-publish wait remains at the bottom. On the
           defensive no-post-L2 fallback, the delayed
           ``sched_pipeline.consumer_release`` runs just before this
           wait.

        The producer-side and consumer-side flip
        (in ``memory_ops._aux_subtile_load_source`` /
        ``_aux_tile_setup_lines``) MUST land in the same commit:
        a partial-handshake state deadlocks once a CTA wraps the
        pipeline depth (an early-2a variant of this builder
        emitted producer barriers without consumer releases; with
        ``num_stages=2`` the third ``producer_acquire`` blocks
        forever — see the cycle-2a docstring in
        ``TestCuteTcgen05AuxPipelineCycle2a``).
        """
        plan = self._tcgen05_plan()
        # The aux producer runs on the C-input warp normally; under the cycle-94
        # merge (``inline_aux_only``) it runs on the store warp instead, so the
        # producer-warp invariant is "C-input OR store warp present".
        assert plan is not None and (plan.has_c_input_warp or plan.has_store_warp), (
            "aux producer body requires a matmul plan with a C-input or store warp"
        )
        c_input_aux_tensor_descriptors = plan.c_input_aux_tensor_descriptors
        assert c_input_aux_tensor_descriptors, (
            "C-input role-local while requires non-empty exact-shape aux "
            "descriptors (producer-body split gate must be open)"
        )
        sched_pipeline_plan = self._tcgen05_sched_pipeline_plan()
        assert sched_pipeline_plan is not None, (
            "C-input role-local while requires a registered "
            "sched_pipeline plan; was cute_state.register_tcgen05_sched_pipeline_plan "
            "called by _codegen_cute_mma?"
        )
        # Aux pipeline plan: the matmul-plan gate that admits this
        # builder also fires the pipeline allocation in
        # ``cute_mma._codegen_cute_mma``, so a non-None plan is
        # the invariant we rely on once the gate is open. The
        # assert catches a future gate-skew between
        # ``has_c_input_warp + c_input_aux_tensor_descriptors`` and the
        # cute_mma allocator rather than producing a half-allocated
        # kernel.
        aux_pipeline_plan = device_function.cute_state.aux_pipeline_plan
        assert aux_pipeline_plan is not None, (
            "C-input role-local while requires a registered "
            "aux pipeline plan; was cute_state.register_tcgen05_aux_pipeline_plan "
            "called by _codegen_cute_mma?"
        )
        assert len(aux_pipeline_plan.rings) == len(c_input_aux_tensor_descriptors), (
            "C-input role-local while: aux pipeline plan must have one "
            "ring per staged matmul-plan aux descriptor"
        )
        aux_use_tma_load = aux_pipeline_plan.use_tma_load
        aux_requires_full_tile = plan.tma_store_full_tiles_only

        valid_var = device_function.new_var("tcgen05_c_input_warp_valid")
        snapshot = (
            None
            if inline_aux_only
            else _SchedMailboxSnapshot.create(
                device_function,
                "tcgen05_c_input_warp",
                ()
                if aux_requires_full_tile and tile_phase == "edge"
                else tuple(range(len(self.pid_info))),
            )
        )
        work_tile_stage_index = (
            f"{sched_pipeline_plan.consumer_state}.index"
            if self._tcgen05_uses_staged_work_tile_mailbox()
            else None
        )

        def _sched_consumer_wait_block() -> list[ast.stmt]:
            return _build_sched_pipeline_consumer_wait_block(
                sched_pipeline=sched_pipeline_plan.pipeline,
                sched_consumer_state=sched_pipeline_plan.consumer_state,
                work_tile_smem=layout.work_tile_smem,
                valid_var=valid_var,
                work_tile_stage_index=work_tile_stage_index,
                snapshot=snapshot,
            )

        def _sched_consumer_release_block() -> list[ast.stmt]:
            return _build_sched_pipeline_consumer_release_block(
                sched_pipeline=sched_pipeline_plan.pipeline,
                sched_consumer_state=sched_pipeline_plan.consumer_state,
            )

        if aux_requires_full_tile and tile_phase == "edge":
            # Edge epilogues use the SIMT direct-GMEM aux path. The C-input
            # warp still participates in the scheduler pipeline so the
            # producer's consumer-arrival count remains balanced, but each
            # edge iteration is purely the sched-pipeline handshake: wait for
            # the broadcast, release it, then wait for the next one.
            prelude: list[ast.stmt] = []
            prelude.extend(_sched_consumer_wait_block())
            per_tile_body: list[ast.stmt] = []
            per_tile_body.extend(_sched_consumer_release_block())
            per_tile_body.extend(_sched_consumer_wait_block())
            prelude.append(
                create(
                    ast.While,
                    test=expr_from_string(valid_var),
                    body=per_tile_body,
                    orelse=[],
                )
            )
            prelude.extend(_sched_consumer_release_block())
            return create(
                ast.If,
                test=expr_from_string(self._tcgen05_c_input_role_predicate()),
                body=prelude,
                orelse=[],
            )

        mailbox_slots = [
            snapshot.fields[i]
            if snapshot is not None
            else self._tcgen05_work_tile_slot(layout, i)
            for i in range(len(self.pid_info))
        ]
        coord_terms, pair_axis = self._tcgen05_mailbox_coord_terms(mailbox_slots)
        linear_pid_expr = self._tcgen05_linear_virtual_pid_from_coords_expr(
            coord_terms, pair_axis=pair_axis
        )
        sched_coord_0 = coord_terms[0] if len(coord_terms) > 0 else "cutlass.Int32(0)"
        sched_coord_1 = coord_terms[1] if len(coord_terms) > 1 else "cutlass.Int32(0)"

        # M / N tile coords for the cooperative copy. Each CTA's
        # C-input warp loads only its own per-CTA portion of the
        # aux region. Under cluster_m=2 ``use_2cta_instrs`` the
        # per-CTA aux tile shape is ``(bm/2, bn)`` and the per-CTA
        # M tile coord is the global M tile (without the cluster
        # ``// 2`` reduction — each CTA in the cluster handles its
        # own row stripe). The N coord is shared across cluster
        # (cluster_n=1 is the only validated runtime).
        #
        # Critical correctness invariant: the consumer-side per-CTA
        # subtile count is
        # ``(bm_per_cta * bn) / (epi_m * epi_n)``; the producer's
        # subtile count must match or the mbar handshake deadlocks
        # once the producer wraps the stage count and the consumer
        # has already exited (cluster_m=2 yields producer=2× the
        # consumer count when the producer mistakenly uses the
        # cluster-level (bm, bn)).
        bm = plan.bm
        bn = plan.bn
        cluster_m = self._tcgen05_cluster_m()
        is_two_cta = self._tcgen05_is_two_cta()
        bm_per_cta = bm // cluster_m if is_two_cta else bm
        tile_m_var = device_function.new_var("tcgen05_aux_tile_m")
        tile_n_var = device_function.new_var("tcgen05_aux_tile_n")
        assert plan.output_offsets is not None
        m_offset_var, n_offset_var = plan.output_offsets
        # Extract the same post-remap coordinates used by the MMA and store
        # roles. Block IDs need not start at zero (independent materialized
        # regions have disjoint IDs), and launch order may interchange M/N.
        # The matmul plan carries the actual names instead of assuming axes 0/1.
        synthetic_reads_for_l2 = [
            statement_from_string(
                f"_tcgen05_aux_l2_anchor = {m_offset_var} + {n_offset_var}"
            )
        ]
        l2_dependency_stmts: list[ast.stmt] = []
        if shared_body_extracted is not None:
            l2_dependency_stmts = self._role_local_dependency_stmts(
                shared_body_extracted, synthetic_reads_for_l2
            )
        l2_dependency_writes: set[str] = set()
        for stmt in l2_dependency_stmts:
            _, writes = _stmt_name_uses(stmt)
            l2_dependency_writes.update(writes)
        has_post_l2_coords = (
            m_offset_var in l2_dependency_writes
            and n_offset_var in l2_dependency_writes
        )
        # ``peer_m`` is this CTA's rank along the M axis of the cluster:
        # ``block_idx_in_cluster() % cluster_m``. The modulo is load-bearing
        # here because consumer CTAs can span the N axis: for ``cluster_m=2 +
        # cluster_n=2 + use_2cta=True`` (a validated 4-CTA cluster shape, see
        # ``cute_mma.py:_TCGEN05_V_LEADER_PREDICATE``) ranks {0, 1, 2, 3}
        # have M peer ranks {0, 1, 0, 1}. Scheduler-warp broadcasts use
        # lane-rank branches restricted to ``peer_rank < cluster_m``, where
        # the raw lane rank is already the M peer rank.
        peer_m_expr = (
            f"(cute.arch.make_warp_uniform(cute.arch.block_idx_in_cluster()) "
            f"% cutlass.Int32({cluster_m}))"
        )
        if has_post_l2_coords:
            # These are logical matrix coordinates after the launch-order
            # and L2-grouping remaps, in the same units as the consumer.
            #
            # Note that under ``cluster_n=1 + l2_groupings=[1]``
            # the post-L2 expression ``pid_0 * cluster_m +
            # peer_m`` is numerically equal to the pre-cycle-2i
            # ``work_tile_smem[0]`` because (a) the L2 remap is
            # identity and (b) the scheduler publishes
            # ``tile_idx[0] + peer_m = pid_0 * cluster_m +
            # peer_m`` into each CTA's slot. Outside that
            # narrow case the two forms diverge: under
            # ``l2_grp=[g>1]`` because L2 remap is non-identity,
            # and under ``cluster_n=2`` because the raw
            # rank-in-cluster ≠ peer_m.
            m_source = f"({m_offset_var} // cutlass.Int32({bm}))"
            n_source = f"({n_offset_var} // cutlass.Int32({bn}))"
            if is_two_cta:
                tile_m_expr = (
                    f"({m_source}) * cutlass.Int32({cluster_m}) + {peer_m_expr}"
                )
            elif self._tcgen05_uses_cluster_m2_one_cta_role_local_bridge():
                # Bridge: cluster has ``cluster_m`` CTAs each
                # handling its own logical M tile (no V-pair
                # striping); add peer_m to step from the
                # cluster-leader CTA's logical tile to this
                # CTA's. Bridge requires ``cluster_n=1`` (see
                # ``cute_mma._tcgen05_cluster_m2_one_cta_role_local_bridge``)
                # so ``peer_m == block_idx_in_cluster()``; using
                # ``peer_m`` form keeps the expression
                # robust if that constraint widens later.
                tile_m_expr = f"({m_source}) + {peer_m_expr}"
            else:
                tile_m_expr = m_source
            tile_n_expr = n_source
        else:
            # Raw scheduler coordinates are only valid for a decomposition
            # that does not emit the requested output offset names. The
            # standard NDTileStrategy always emits those names,
            # which runs for every real kernel binding
            # regardless of ``l2_groupings``. Purely defensive —
            # preserves the pre-cycle-2i correctness baseline
            # if a future strategy emits the role-local while
            # without those names. Under ``is_two_cta`` the
            # scheduler-published ``work_tile_smem[0]`` already
            # carries the per-CTA peer_m baked in (the
            # scheduler publish is
            # ``tile_idx[0] + peer_m`` per CTA); under non-2cta
            # ``_tcgen05_logical_m_coord_expr`` adds the bridge
            # adjustment when applicable. So no extra peer_m
            # is applied here.
            m_source = sched_coord_0
            n_source = sched_coord_1
            if is_two_cta:
                tile_m_expr = m_source
            else:
                tile_m_expr = self._tcgen05_logical_m_coord_expr(m_source)
            tile_n_expr = n_source

        # Cooperative-copy thread layout. Single C-input warp has
        # 32 lanes; lay them out row-major as (M_threads, N_threads)
        # = (4, 8) so each lane reads a contiguous N chunk
        # (innermost dim) and 8 lanes cover the N axis. The val
        # layout pulls 128 bits per copy atom — the largest power
        # of two that divides both ``bn * dtype_bits`` and 128. For
        # bf16 with bn=256 that's 128 bits = 8 elements.
        # ``make_tiled_copy_tv`` lifts the per-lane chunk to a
        # ``(thr_layout × val_layout)`` partition and ``cute.copy``
        # iterates the tile under the lane's get_slice(lane_idx).
        cute_lane_idx_var = device_function.new_var("tcgen05_aux_lane_idx")

        # Pull aux pipeline names from the plan. The plan is the
        # ``_Tcgen05AuxPipelinePlan`` dataclass; access by name
        # without importing the type to avoid a module cycle.
        aux_pipeline_name = aux_pipeline_plan.pipeline
        aux_producer_state_name = aux_pipeline_plan.producer_state
        aux_rings = aux_pipeline_plan.rings
        aux_epi_tile_var = aux_pipeline_plan.epi_tile_var
        aux_tma_barrier_var = (
            device_function.new_var("tcgen05_aux_tma_barrier")
            if aux_use_tma_load
            else None
        )

        aux_full_tile_var = device_function.new_var("tcgen05_aux_full_tile")
        aux_shape = c_input_aux_tensor_descriptors[0].host_tensor_val.shape
        assert len(aux_shape) == 2, (
            "C-input staged aux descriptors must be exact-shape rank-2 tensors"
        )
        aux_m_size = int(aux_shape[0])
        aux_n_size = int(aux_shape[1])
        if has_post_l2_coords:
            aux_m_start_expr = m_offset_var
            aux_n_start_expr = n_offset_var
        else:
            if is_two_cta:
                aux_m_tile_expr = f"({sched_coord_0} // cutlass.Int32({cluster_m}))"
            else:
                aux_m_tile_expr = sched_coord_0
            aux_m_start_expr = f"({aux_m_tile_expr}) * cutlass.Int32({bm})"
            aux_n_start_expr = f"{sched_coord_1} * cutlass.Int32({bn})"
        aux_full_tile_expr = (
            f"{aux_m_start_expr} + cutlass.Int32({bm}) "
            f"<= cutlass.Int32({aux_m_size}) and "
            f"{aux_n_start_expr} + cutlass.Int32({bn}) "
            f"<= cutlass.Int32({aux_n_size})"
        )

        env_backend = CompileEnvironment.current().backend

        # Per-descriptor partitioning that runs once per output tile:
        # builds the source 2-D GMEM tensor, slices the per-output-
        # tile ``(bm, bn)`` region, and flat-divides it into
        # epi-tile-sized subtiles. The subtile-loop body further
        # slices one subtile of GMEM and one stage of SMEM per
        # iteration. Each per-descriptor partition uses fresh AST
        # var names so multiple aux descriptors compose linearly.
        per_descriptor_setup_blocks: list[list[ast.stmt]] = []
        per_descriptor_subtile_blocks: list[list[str]] = []
        per_descriptor_grouped_names: list[str] = []
        for desc_idx, (desc, ring) in enumerate(
            zip(c_input_aux_tensor_descriptors, aux_rings, strict=True)  # type: ignore[arg-type]
        ):
            aux_tensor_name = device_function.tensor_arg(desc.host_tensor_val).name
            aux_dtype_str = env_backend.dtype_str(desc.host_tensor_val.dtype)
            dtype_bits = desc.host_tensor_val.dtype.itemsize * 8
            tma_atom = ring.tma_atom
            tma_tensor = ring.tma_tensor
            if aux_use_tma_load:
                assert tma_atom is not None
                assert tma_tensor is not None
                assert aux_tma_barrier_var is not None
            else:
                assert tma_atom is None
                assert tma_tensor is None
            gmem_aux_view_var = device_function.new_var(
                f"tcgen05_aux_gmem_view_{desc_idx}"
            )
            gmem_aux_tile_var = device_function.new_var(
                f"tcgen05_aux_gmem_tile_{desc_idx}"
            )
            gmem_aux_subtiles_var = device_function.new_var(
                f"tcgen05_aux_gmem_subtiles_{desc_idx}"
            )
            gmem_subtiles_grouped_var = device_function.new_var(
                f"tcgen05_aux_gmem_subtiles_grouped_{desc_idx}"
            )
            tiled_copy_var = device_function.new_var(
                f"tcgen05_aux_tiled_copy_{desc_idx}"
            )
            thr_copy_var = device_function.new_var(f"tcgen05_aux_thr_copy_{desc_idx}")
            gmem_subtile_var = device_function.new_var(
                f"tcgen05_aux_gmem_subtile_{desc_idx}"
            )
            smem_stage_var = device_function.new_var(
                f"tcgen05_aux_smem_stage_{desc_idx}"
            )
            gmem_part_var = device_function.new_var(f"tcgen05_aux_gmem_part_{desc_idx}")
            smem_part_var = device_function.new_var(f"tcgen05_aux_smem_part_{desc_idx}")
            tma_smem_part_var = ""
            tma_gmem_part_var = ""
            setup: list[ast.stmt] = []
            # Build the source 2-D GMEM tensor. Exact-shape rank-2
            # aux passes through ``aux_tensor`` directly; rank-1
            # trailing-axis broadcast aux builds a stride-0-on-M
            # view with M-extent ``bm_per_cta`` and N-extent = the
            # rank-1 size. Under cluster_m=2 ``use_2cta_instrs``
            # the per-CTA aux tile is ``(bm/2, bn)``; the global M
            # tile coord directly indexes per-CTA M stripes (the
            # scheduler publishes 2 global tiles per cluster
            # step). For non-2cta the per-CTA tile shape collapses
            # to the full ``(bm, bn)``.
            if desc.broadcast_axis is None:
                if aux_use_tma_load:
                    gmem_source_var = tma_tensor
                    assert gmem_source_var is not None
                else:
                    gmem_source_var = aux_tensor_name
                setup.extend(
                    [
                        statement_from_string(
                            f"{gmem_aux_view_var} = {gmem_source_var}"
                        ),
                        statement_from_string(
                            f"{gmem_aux_tile_var} = cute.local_tile("
                            f"{gmem_aux_view_var}, ({bm_per_cta}, {bn}), "
                            f"({tile_m_var}, {tile_n_var}))"
                        ),
                    ]
                )
            else:
                assert desc.broadcast_axis == 1, (
                    "C-input warp aux producer expects "
                    "broadcast_axis in {None, 1}; the chain "
                    "analyzer rejects other forms"
                )
                n_global = int(desc.host_tensor_val.shape[0])
                setup.extend(
                    [
                        statement_from_string(
                            f"{gmem_aux_view_var} = cute.make_tensor("
                            f"{aux_tensor_name}.iterator, "
                            f"cute.make_layout(({bm_per_cta}, {n_global}), "
                            "stride=(0, 1)))"
                        ),
                        statement_from_string(
                            f"{gmem_aux_tile_var} = cute.local_tile("
                            f"{gmem_aux_view_var}, ({bm_per_cta}, {bn}), "
                            f"(cutlass.Int32(0), {tile_n_var}))"
                        ),
                    ]
                )
            # Subdivide the per-output-tile aux region into epi-tile-
            # sized subtiles using ``flat_divide(epi_tile)`` —
            # mirrors the consumer-side ``flat_divide`` so the
            # producer and consumer iterate the same subtile
            # ordering. ``group_modes(..., 2, rank)`` collapses the
            # outer (subtile_m, subtile_n) modes into one linear
            # subtile axis so the producer's subtile loop sees a
            # flat ``subtile_count`` extent (matches the consumer's
            # post-``group_modes`` shape used inside
            # ``_aux_subtile_load_source``).
            setup.extend(
                [
                    statement_from_string(
                        f"{gmem_aux_subtiles_var} = cute.flat_divide("
                        f"{gmem_aux_tile_var}, {aux_epi_tile_var})"
                    ),
                    statement_from_string(
                        f"{gmem_subtiles_grouped_var} = cute.group_modes("
                        f"{gmem_aux_subtiles_var}, 2, "
                        f"cute.rank({gmem_aux_subtiles_var}))"
                    ),
                ]
            )
            if aux_use_tma_load:
                tma_smem_part_var = device_function.new_var(
                    f"tcgen05_aux_tma_smem_part_{desc_idx}"
                )
                tma_gmem_part_var = device_function.new_var(
                    f"tcgen05_aux_tma_gmem_part_{desc_idx}"
                )
                setup.append(
                    statement_from_string(
                        f"{tma_smem_part_var}, {tma_gmem_part_var} = "
                        "cute.nvgpu.cpasync.tma_partition("
                        f"{tma_atom}, 0, cute.make_layout(1), "
                        f"cute.group_modes({ring.smem}, 0, "
                        f"cute.rank({ring.smem}) - 1), "
                        f"cute.group_modes({gmem_subtiles_grouped_var}, 0, "
                        f"cute.rank({gmem_subtiles_grouped_var}) - 1))"
                    )
                )
            else:
                # Cooperative-copy ``TiledCopy`` for the C-input warp's
                # 32 lanes. The atom uses ``CopyUniversalOp`` (regular
                # SIMT ld+st): cp.async would impose a 128-bit
                # source-iterator alignment check that the layout-
                # implied stride alignment cannot satisfy at IR-build
                # time (the host pointer is 16-byte aligned, but the
                # minimum row stride is 1 element = 16 bits for bf16).
                # ``CopyUniversalOp`` lowers to a SIMT ld/st pair whose
                # vectorization is driven at runtime by the host
                # pointer's actual alignment.
                # Use the actual shared epilogue subtile, not (bm, bn): a
                # fixed 4x64 BF16 copy over a 128x32 subtile aliases shared
                # destinations and reads beyond the final global N tile.
                # Resolve each descriptor independently because its dtype
                # determines the number of contiguous values in 128 bits.
                m_threads = device_function.new_var(
                    f"tcgen05_aux_copy_m_threads_{desc_idx}"
                )
                n_threads = device_function.new_var(
                    f"tcgen05_aux_copy_n_threads_{desc_idx}"
                )
                num_copy_elems = device_function.new_var(
                    f"tcgen05_aux_copy_values_{desc_idx}"
                )
                setup.extend(
                    [
                        statement_from_string(
                            f"{m_threads}, {n_threads}, {num_copy_elems} = "
                            "cutlass.const_expr(_cute_aux_copy_layout("
                            f"cute.size({aux_epi_tile_var}[0]), "
                            f"cute.size({aux_epi_tile_var}[1]), "
                            f"{dtype_bits}))"
                        ),
                        statement_from_string(
                            f"{tiled_copy_var} = cute.make_tiled_copy_tv("
                            f"cute.make_copy_atom("
                            f"cute.nvgpu.CopyUniversalOp(), {aux_dtype_str}, "
                            f"num_bits_per_copy={num_copy_elems} * {dtype_bits}), "
                            f"cute.make_ordered_layout("
                            f"({m_threads}, {n_threads}), order=(1, 0)), "
                            f"cute.make_layout((1, {num_copy_elems})))"
                        ),
                        statement_from_string(
                            f"{thr_copy_var} = {tiled_copy_var}.get_slice("
                            f"{cute_lane_idx_var})"
                        ),
                    ]
                )
            per_descriptor_setup_blocks.append(setup)
            per_descriptor_grouped_names.append(gmem_subtiles_grouped_var)

            # Per-subtile body source: builds the per-stage GMEM
            # slice + SMEM stage slice and issues one cooperative
            # ``cute.copy``. The loop variable
            # ``_tcgen05_aux_subtile`` indexes the flat subtile
            # axis (collapsed via ``group_modes(..., 2, rank)``);
            # the consumer's per-subtile loop indexes the same
            # axis identically.
            if aux_use_tma_load:
                subtile_lines = [
                    (
                        f"cute.copy({tma_atom}, "
                        f"{tma_gmem_part_var}[None, "
                        f"cutlass.Int32(_tcgen05_aux_subtile)], "
                        f"{tma_smem_part_var}[None, "
                        f"{aux_producer_state_name}.index], "
                        f"tma_bar_ptr={aux_tma_barrier_var})"
                    ),
                ]
            else:
                subtile_lines = [
                    (
                        f"{gmem_subtile_var} = "
                        f"{gmem_subtiles_grouped_var}[None, None, "
                        f"cutlass.Int32(_tcgen05_aux_subtile)]"
                    ),
                    (
                        f"{smem_stage_var} = {ring.smem}[None, None, "
                        f"{aux_producer_state_name}.index]"
                    ),
                    (
                        f"{gmem_part_var} = "
                        f"{thr_copy_var}.partition_S({gmem_subtile_var})"
                    ),
                    (f"{smem_part_var} = {thr_copy_var}.partition_D({smem_stage_var})"),
                    (f"cute.copy({tiled_copy_var}, {gmem_part_var}, {smem_part_var})"),
                ]
            per_descriptor_subtile_blocks.append(subtile_lines)

        def _aux_copy_lines() -> list[ast.stmt]:
            """Emit the per-output-tile producer body.

            The body computes per-output-tile aux GMEM partitions,
            flat-divides each into epi-tile-sized subtiles, then
            loops over the subtile axis. Each subtile iteration
            acquires one SMEM ring stage, cooperative-copies the
            subtile of every descriptor into the stage, fences the
            SMEM proxy, commits the producer barrier, and advances
            the producer state. Iteration order matches the
            consumer's per-subtile loop in
            ``memory_ops._aux_subtile_load_source``.
            """
            lines: list[ast.stmt] = []
            lines.extend(
                [
                    statement_from_string(
                        f"{cute_lane_idx_var} = cute.arch.lane_idx()"
                    ),
                    statement_from_string(f"{tile_m_var} = {tile_m_expr}"),
                    statement_from_string(f"{tile_n_var} = {tile_n_expr}"),
                ]
            )
            # Per-descriptor partition setup runs once per output
            # tile, before the subtile loop. The setup builds the
            # ``flat_divide(epi_tile) → group_modes(2, rank)``
            # tensor whose third mode is the subtile axis the
            # producer iterates against.
            for block in per_descriptor_setup_blocks:
                lines.extend(block)

            # Determine the subtile count from any descriptor's
            # grouped tensor (all descriptors share the same
            # subtile axis because they're all sliced from the
            # same ``(bm, bn)`` region with the same ``epi_tile``).
            # Use the first descriptor's grouped name — pulled
            # from ``per_descriptor_grouped_names`` so the
            # ``device_function.new_var`` namespace suffix
            # (if any) is honored.
            first_grouped = per_descriptor_grouped_names[0]
            subtile_count_var = device_function.new_var(
                "tcgen05_aux_producer_subtile_count"
            )
            lines.append(
                statement_from_string(
                    f"{subtile_count_var} = cutlass.const_expr("
                    f"cute.size({first_grouped}.shape, mode=[2]))"
                )
            )

            # Build the per-subtile loop body. Per iteration:
            # acquire one SMEM stage, copy every descriptor's
            # subtile into the stage, sync the warp + fence the
            # SMEM proxy so the consumer's
            # ``consumer_wait`` sees a fully populated stage,
            # commit, advance. Lane-uniform code throughout (every
            # lane runs the same per-iteration body; the cooperative
            # copy partitions inside).
            # Build the per-iteration body as a single
            # already-indented source string. Each entry in
            # ``inner_chunks`` is a top-level statement (or block)
            # carrying its own ``    `` indent for the surrounding
            # ``for ...:`` loop. ``emit_pipeline_advance`` may
            # return a multi-line ``if True: ...`` block on
            # cutedsl builds without the OpResultList fix; we
            # pass ``indent="    "`` so the whole block is
            # already indented for the loop body and no caller-
            # side reflow is needed (the prior single-line
            # ``\n.join(f"    {line}" ...)`` pattern only
            # indented the first line of the advance block,
            # under-indenting its body and causing a SyntaxError
            # on the fallback path).
            loop_indent = "    "
            inner_chunks: list[str] = []
            inner_chunks.append(
                f"{loop_indent}{aux_pipeline_name}.producer_acquire("
                f"{aux_producer_state_name})"
            )
            if aux_use_tma_load:
                assert aux_tma_barrier_var is not None
                inner_chunks.append(
                    f"{loop_indent}{aux_tma_barrier_var} = "
                    f"{aux_pipeline_name}.producer_get_barrier("
                    f"{aux_producer_state_name})"
                )
            for block in per_descriptor_subtile_blocks:
                inner_chunks.extend(f"{loop_indent}{line}" for line in block)
            # TMA aux loads skip the SIMT warp sync/fence below: they are
            # ordered by the tx-counted PipelineTmaAsync barrier, and the
            # consumer fences the async-shared view after ``consumer_wait`` and
            # before generic SMEM reads.
            if not aux_use_tma_load:
                # ``CopyUniversalOp`` issues regular ld+st pairs that
                # complete in program order per thread; ``sync_warp``
                # ensures all 32 lanes of the producer warp finish
                # their SMEM stores. ``fence_acq_rel_cta`` provides
                # cross-warp visibility through the CTA-scope generic
                # SMEM proxy — the consumer warps' generic SMEM reads
                # after their ``consumer_wait`` would otherwise be
                # free to bypass the producer's writes since the
                # AsyncThread ``mbarrier.arrive`` PTX emission has
                # relaxed memory semantics by default.
                inner_chunks.extend(
                    [
                        f"{loop_indent}cute.arch.sync_warp()",
                        f"{loop_indent}cute.arch.fence_acq_rel_cta()",
                    ]
                )
            inner_chunks.extend(
                [
                    (
                        f"{loop_indent}{aux_pipeline_name}.producer_commit("
                        f"{aux_producer_state_name})"
                    ),
                    emit_pipeline_advance(aux_producer_state_name, indent=loop_indent),
                ]
            )
            inner_body = "\n".join(inner_chunks)
            loop_src = (
                f"for _tcgen05_aux_subtile in cutlass.range("
                f"{subtile_count_var}, unroll_full=True):\n"
                f"{inner_body}"
            )
            lines.append(statement_from_string(loop_src))
            return lines

        if inline_aux_only:
            # Cycle-94 merge: return the per-tile aux producer body for injection
            # into the store warp's branch of the (widened) epilogue role-local
            # while. The epi loop owns the sched handshake and materializes the
            # post-L2 tile coords, so no sched wait/release is emitted here. The
            # full-tile guard mirrors the standalone builder so edge tiles (SIMT
            # aux) commit no aux stages the consumer never releases.
            #
            # No post-loop ``producer_tail`` is returned: the aux producer_state
            # is advanced inside the store-warp branch of the SHARED epilogue
            # while, so a post-loop ``producer_tail(state)`` would reference a
            # loop-carried value defined in that nested region (IR domination
            # error). The tail is only a boundary drain for the TMA-load empty
            # barriers, and the epi-warp consumers have already released every
            # aux stage by loop exit, so it is safely omitted on the merge path.
            assert has_post_l2_coords, (
                "inline_aux_only merge requires post-L2 tile coords "
                "(tile_offset_0/1) from the epilogue loop's dependency stmts"
            )
            inline_per_tile: list[ast.stmt] = []
            aux_copy_lines_inline = _aux_copy_lines()
            if aux_requires_full_tile:
                inline_per_tile.extend(
                    [
                        statement_from_string(
                            f"{aux_full_tile_var} = {aux_full_tile_expr}"
                        ),
                        create(
                            ast.If,
                            test=expr_from_string(aux_full_tile_var),
                            body=aux_copy_lines_inline,
                            orelse=[],
                        ),
                    ]
                )
            else:
                inline_per_tile.extend(aux_copy_lines_inline)
            return inline_per_tile

        prelude: list[ast.stmt] = []
        prelude.extend(_sched_consumer_wait_block())
        per_tile_body: list[ast.stmt] = [
            statement_from_string(f"{self.virtual_pid_var} = {linear_pid_expr}"),
        ]
        # Emit the L2-grouping decomposition chain right after
        # ``virtual_pid`` is bound, so ``_aux_copy_lines()`` can
        # reference the post-L2 ``tile_offset_0`` / ``tile_offset_1``
        # names. Mirrors the consumer role-local while body's
        # placement of ``dependency_stmts`` (see
        # ``_build_role_local_while_with_scheduler``).
        per_tile_body.extend(l2_dependency_stmts)
        early_sched_release = has_post_l2_coords
        if early_sched_release:
            # After the post-L2 coordinate chain has materialized tile_offset_*
            # locals, the aux producer no longer needs the scheduler SMEM
            # mailbox for this tile. Release here so the scheduler warp can run
            # ahead while aux GMEM->SMEM staging is in flight.
            per_tile_body.extend(_sched_consumer_release_block())
        aux_copy_lines = _aux_copy_lines()
        if aux_requires_full_tile and tile_phase == "all":
            # Hybrid full-tile TMA store with a SIMT edge fallback uses the aux
            # SMEM ring only on full tiles. Edge tiles take direct-GMEM aux
            # loads, so the producer must skip them; otherwise it commits aux
            # stages that no consumer will release.
            per_tile_body.extend(
                [
                    statement_from_string(
                        f"{aux_full_tile_var} = {aux_full_tile_expr}"
                    ),
                    create(
                        ast.If,
                        test=expr_from_string(aux_full_tile_var),
                        body=aux_copy_lines,
                        orelse=[],
                    ),
                ]
            )
        else:
            assert tile_phase in ("all", "full"), f"unexpected tile_phase={tile_phase}"
            per_tile_body.extend(aux_copy_lines)
        if not early_sched_release:
            per_tile_body.extend(_sched_consumer_release_block())
        per_tile_body.extend(_sched_consumer_wait_block())
        prelude.append(
            create(
                ast.While,
                test=expr_from_string(valid_var),
                body=per_tile_body,
                orelse=[],
            )
        )
        prelude.extend(_sched_consumer_release_block())
        if aux_use_tma_load:
            prelude.append(
                statement_from_string(
                    f"{aux_pipeline_name}.producer_tail({aux_producer_state_name})"
                )
            )

        return create(
            ast.If,
            test=expr_from_string(self._tcgen05_c_input_role_predicate()),
            body=prelude,
            orelse=[],
        )

    def _role_local_dependency_stmts(
        self, shared_body: list[ast.stmt], role_stmts: list[ast.stmt]
    ) -> list[ast.stmt]:
        """Return shared per-tile statements needed by an extracted role.

        Extracted TMA-load statements still read tile-local names such as
        ``offset_0`` / ``offset_1`` that are normally produced by the shared
        PID-decomposition prefix. Walk the shared body backwards from the
        role's reads and pull in the nearest definitions, adding their reads
        transitively. The returned statements preserve source order and run
        immediately after the role-local ``virtual_pid`` binding.

        This intentionally simple pass assumes the dependency prefix is made
        of flat, unconditional per-tile assignments (PID decomposition,
        offsets, TMA tensor partitions). ``ast.walk`` treats writes inside
        compound statements as unconditional; if conditional prefix defines
        become necessary, this helper needs control-flow-aware dominance.
        """
        needed: set[str] = set()
        internal_writes: set[str] = set()
        for stmt in role_stmts:
            reads, writes = _stmt_name_uses(stmt)
            needed.update(reads)
            internal_writes.update(writes)
        needed.difference_update(internal_writes)

        selected_reversed: list[ast.stmt] = []
        for stmt in reversed(shared_body):
            reads, writes = _stmt_name_uses(stmt)
            if not writes or not (writes & needed):
                continue
            selected_reversed.append(stmt)
            needed.difference_update(writes)
            needed.update(reads)
        selected_reversed.reverse()
        return selected_reversed

    @staticmethod
    def _tcgen05_is_local_assignment_target(target: ast.AST) -> bool:
        if isinstance(target, ast.Name):
            return isinstance(target.ctx, ast.Store)
        if isinstance(target, ast.Tuple | ast.List):
            return all(
                Tcgen05PersistentProgramIDs._tcgen05_is_local_assignment_target(elt)
                for elt in target.elts
            )
        return False

    _TCGEN05_OMIT_SHARED_PURE_CALLS: ClassVar[frozenset[str]] = frozenset(
        {
            "range",
            "max",
            "min",
            "cutlass.BFloat16",
            "cutlass.Boolean",
            "cutlass.Float16",
            "cutlass.Float32",
            "cutlass.Float8E4M3FN",
            "cutlass.Int32",
            "cutlass.Int64",
            "cutlass.Uint8",
            # Scalar fallback loads left behind after all work-producing
            # statements move into role-local tcgen05 loops are side-effect
            # free. They may be discarded when none of their results feed
            # post-loop cleanup; stores and pipeline operations remain unsafe.
            "cute.arch.load",
            # Reading a thread coordinate has no observable side effect.
            "cute.arch.thread_idx",
            # Scalar arithmetic and comparisons the FX lowering spells as
            # ``operator`` calls (``group_id >= 0``) are pure as well.
            "operator.add",
            "operator.sub",
            "operator.mul",
            "operator.floordiv",
            "operator.mod",
            "operator.neg",
            "operator.eq",
            "operator.ne",
            "operator.lt",
            "operator.le",
            "operator.gt",
            "operator.ge",
        }
    )

    @staticmethod
    def _tcgen05_call_path(func: ast.AST) -> str | None:
        if isinstance(func, ast.Name):
            return func.id
        if isinstance(func, ast.Attribute):
            base = Tcgen05PersistentProgramIDs._tcgen05_call_path(func.value)
            if base is None:
                return None
            return f"{base}.{func.attr}"
        return None

    @staticmethod
    def _tcgen05_is_iterator_load(expr: ast.Call) -> bool:
        return (
            isinstance(expr.func, ast.Attribute)
            and expr.func.attr == "load"
            and not expr.args
            and not expr.keywords
            and any(
                isinstance(node, ast.Attribute) and node.attr == "iterator"
                for node in ast.walk(expr.func.value)
            )
        )

    @classmethod
    def _tcgen05_expr_safe_to_omit(cls, expr: ast.AST) -> bool:
        if isinstance(expr, ast.Constant):
            return True
        if isinstance(expr, ast.Name):
            return isinstance(expr.ctx, ast.Load)
        if isinstance(expr, ast.Attribute):
            return cls._tcgen05_expr_safe_to_omit(expr.value)
        if isinstance(expr, ast.BinOp):
            return cls._tcgen05_expr_safe_to_omit(
                expr.left
            ) and cls._tcgen05_expr_safe_to_omit(expr.right)
        if isinstance(expr, ast.UnaryOp):
            return cls._tcgen05_expr_safe_to_omit(expr.operand)
        if isinstance(expr, ast.BoolOp):
            return all(cls._tcgen05_expr_safe_to_omit(value) for value in expr.values)
        if isinstance(expr, ast.Compare):
            return cls._tcgen05_expr_safe_to_omit(expr.left) and all(
                cls._tcgen05_expr_safe_to_omit(comparator)
                for comparator in expr.comparators
            )
        if isinstance(expr, ast.IfExp):
            return (
                cls._tcgen05_expr_safe_to_omit(expr.test)
                and cls._tcgen05_expr_safe_to_omit(expr.body)
                and cls._tcgen05_expr_safe_to_omit(expr.orelse)
            )
        if isinstance(expr, ast.Tuple | ast.List | ast.Set):
            return all(cls._tcgen05_expr_safe_to_omit(elt) for elt in expr.elts)
        if isinstance(expr, ast.Dict):
            return all(
                key is not None and cls._tcgen05_expr_safe_to_omit(key)
                for key in expr.keys
            ) and all(cls._tcgen05_expr_safe_to_omit(value) for value in expr.values)
        if isinstance(expr, ast.Subscript):
            return cls._tcgen05_expr_safe_to_omit(
                expr.value
            ) and cls._tcgen05_expr_safe_to_omit(expr.slice)
        if isinstance(expr, ast.Slice):
            return all(
                part is None or cls._tcgen05_expr_safe_to_omit(part)
                for part in (expr.lower, expr.upper, expr.step)
            )
        if isinstance(expr, ast.Call):
            # Generated scalar fallback loads can appear either as the
            # canonical ``cute.arch.load(...)`` helper or as a zero-argument
            # ``iterator.load()`` method call. Both are side-effect free; the
            # surrounding residual-body and post-loop dependency checks still
            # retain the shared loop whenever the loaded value is observed.
            if cls._tcgen05_is_iterator_load(expr):
                assert isinstance(expr.func, ast.Attribute)
                return cls._tcgen05_expr_safe_to_omit(expr.func.value)
            call_path = cls._tcgen05_call_path(expr.func)
            if call_path in {"max", "min"} and expr.keywords:
                return False
            return (
                call_path in cls._TCGEN05_OMIT_SHARED_PURE_CALLS
                and all(cls._tcgen05_expr_safe_to_omit(arg) for arg in expr.args)
                and all(
                    keyword.arg is not None
                    and cls._tcgen05_expr_safe_to_omit(keyword.value)
                    for keyword in expr.keywords
                )
            )
        return False

    @classmethod
    def _tcgen05_is_bare_sync_threads_call(cls, expr: ast.AST) -> bool:
        return (
            isinstance(expr, ast.Call)
            and cls._tcgen05_call_path(expr.func) == "cute.arch.sync_threads"
            and not expr.args
            and not expr.keywords
        )

    @staticmethod
    def _tcgen05_single_name_assignment(
        stmt: ast.stmt,
    ) -> tuple[str, ast.expr] | None:
        if (
            isinstance(stmt, ast.Assign)
            and len(stmt.targets) == 1
            and isinstance(stmt.targets[0], ast.Name)
        ):
            return stmt.targets[0].id, stmt.value
        return None

    @staticmethod
    def _tcgen05_numbered_name(name: str, base: str) -> bool:
        prefix = f"{base}_"
        return name.startswith(prefix) and name[len(prefix) :].isdecimal()

    @classmethod
    def _tcgen05_grouped_stmt_safe_to_omit(
        cls,
        stmt: ast.stmt,
        *,
        allowed_coord_writes: set[str],
        worklist_metadata: bool,
    ) -> bool:
        if isinstance(stmt, ast.Pass):
            return True
        if isinstance(stmt, ast.Expr):
            return cls._tcgen05_is_bare_sync_threads_call(stmt.value)
        assignment = cls._tcgen05_single_name_assignment(stmt)
        if assignment is not None:
            name, value = assignment
            if (
                name in allowed_coord_writes
                or name == "safe_group_id"
                or cls._tcgen05_numbered_name(name, "tile_begin")
            ):
                # The scalar tile-origin lowering may materialize a separate
                # coordinate assignment before grouped role extraction. It
                # is dependency-only like tile_offset: used definitions are
                # cloned into their roles, and post-loop uses still retain
                # the shared loop. Keep the same expression-effects proof.
                return cls._tcgen05_expr_safe_to_omit(value)
            if name == "group_id":
                return cls._tcgen05_expr_safe_to_omit(value) or (
                    isinstance(value, ast.Call)
                    and isinstance(value.func, ast.Attribute)
                    and value.func.attr == "load"
                    and not value.args
                    and not value.keywords
                    and cls._tcgen05_expr_safe_to_omit(value.func.value)
                )
            return (
                isinstance(value, ast.Call)
                and cls._tcgen05_call_path(value.func) == "operator.ge"
                and len(value.args) == 2
                and not value.keywords
                and isinstance(value.args[0], ast.Name)
                and value.args[0].id == "group_id"
                and cls._tcgen05_expr_safe_to_omit(value.args[1])
            )
        if (
            not isinstance(stmt, ast.For)
            or not isinstance(stmt.target, ast.Name)
            or not cls._tcgen05_numbered_name(stmt.target.id, "tile_offset")
            or stmt.orelse
            or not cls._tcgen05_expr_safe_to_omit(stmt.iter)
        ):
            return False
        allowed_names = {"acc_copy", "safe_group_id_copy"}
        allowed_bases = {"indices", "mask", *allowed_names}
        if worklist_metadata:
            allowed_names.update({"group_id_copy", "v_0_copy", "v_1_copy"})
            allowed_bases.update(allowed_names)
        for child in stmt.body:
            if isinstance(child, ast.Pass):
                continue
            assignment = cls._tcgen05_single_name_assignment(child)
            if assignment is None:
                return False
            name, value = assignment
            if (
                name != stmt.target.id
                and name not in allowed_names
                and not any(
                    cls._tcgen05_numbered_name(name, base) for base in allowed_bases
                )
            ):
                return False
            if not cls._tcgen05_expr_safe_to_omit(value):
                return False
        return True

    @classmethod
    def _tcgen05_shared_stmt_safe_to_omit(cls, stmt: ast.stmt) -> bool:
        """Return whether a removed shared stmt is dependency-only setup.

        Fully role-local codegen intentionally omits the residual shared
        ``while``. The remaining shared view may still contain scalar
        PID/offset/view setup that role-local loops clone through dependency
        extraction, plus legacy bare ``sync_threads`` barriers that no longer
        bracket shared work after every role has moved out. Other observable
        operations such as copies, pipeline calls, or stores must remain
        rejected so future shared-body work is not silently discarded.
        """
        if isinstance(stmt, ast.Assign):
            return all(
                cls._tcgen05_is_local_assignment_target(t) for t in stmt.targets
            ) and cls._tcgen05_expr_safe_to_omit(stmt.value)
        if isinstance(stmt, ast.AnnAssign):
            return cls._tcgen05_is_local_assignment_target(stmt.target) and (
                stmt.value is None or cls._tcgen05_expr_safe_to_omit(stmt.value)
            )
        if isinstance(stmt, ast.For):
            return (
                cls._tcgen05_is_local_assignment_target(stmt.target)
                and cls._tcgen05_expr_safe_to_omit(stmt.iter)
                and all(
                    cls._tcgen05_shared_stmt_safe_to_omit(child) for child in stmt.body
                )
                and all(
                    cls._tcgen05_shared_stmt_safe_to_omit(child)
                    for child in stmt.orelse
                )
            )
        if isinstance(stmt, ast.If):
            return (
                cls._tcgen05_expr_safe_to_omit(stmt.test)
                and all(
                    cls._tcgen05_shared_stmt_safe_to_omit(child) for child in stmt.body
                )
                and all(
                    cls._tcgen05_shared_stmt_safe_to_omit(child)
                    for child in stmt.orelse
                )
            )
        if isinstance(stmt, ast.Expr):
            return cls._tcgen05_is_bare_sync_threads_call(stmt.value)
        return isinstance(stmt, ast.Pass)

    def _assert_tcgen05_omit_shared_loop_safe(
        self,
        partition: Tcgen05PersistentProgramIDs._PartitionedRoleBody,
        post_loop_stmts: list[ast.stmt] | None = None,
    ) -> None:
        unsafe = self._tcgen05_unsafe_shared_stmts(partition)
        assert not unsafe, (
            "tcgen05 fully role-local codegen would discard observable shared "
            "statement(s) while omitting the residual shared loop: "
            + "; ".join(ast.unparse(stmt) for stmt in unsafe)
        )
        dependencies = self._tcgen05_shared_post_loop_dependencies(
            partition, post_loop_stmts
        )
        assert not dependencies, (
            "tcgen05 fully role-local codegen would discard shared definition(s) "
            "used by post-loop cleanup: " + ", ".join(sorted(dependencies))
        )

    def _tcgen05_unsafe_shared_stmts(
        self, partition: Tcgen05PersistentProgramIDs._PartitionedRoleBody
    ) -> list[ast.stmt]:
        return [
            stmt
            for stmt in partition.shared_body_extracted
            if not self._tcgen05_shared_stmt_safe_to_omit(stmt)
        ]

    def _tcgen05_shared_post_loop_dependencies(
        self,
        partition: Tcgen05PersistentProgramIDs._PartitionedRoleBody,
        post_loop_stmts: list[ast.stmt] | None,
    ) -> set[str]:
        shared_writes: set[str] = set()
        for stmt in partition.shared_body_extracted:
            _, writes = _stmt_name_uses(stmt)
            shared_writes.update(writes)
        post_loop_reads: set[str] = set()
        for stmt in post_loop_stmts or ():
            reads, _ = _stmt_name_uses(stmt)
            post_loop_reads.update(reads)
        return shared_writes & post_loop_reads

    def _tcgen05_shared_loop_has_meaningful_work(
        self,
        partition: Tcgen05PersistentProgramIDs._PartitionedRoleBody,
        post_loop_stmts: list[ast.stmt],
    ) -> bool:
        """Return whether the residual shared loop must be emitted.

        This is deliberately fail-closed: any statement outside the narrow
        side-effect-free allowlist, or any definition consumed by post-loop
        cleanup, makes the shared loop meaningful. Kernel-family admission
        only establishes that independent role schedulers are available; the
        actual residual body decides whether codegen may omit the loop.
        """
        unsafe = (
            self._tcgen05_grouped_unsafe_shared_stmts(partition)
            if self._tcgen05_uses_grouped_static_persistent()
            else self._tcgen05_unsafe_shared_stmts(partition)
        )
        return bool(
            unsafe
            or self._tcgen05_shared_post_loop_dependencies(partition, post_loop_stmts)
        )

    def _assert_tcgen05_grouped_omit_shared_loop_safe(
        self, partition: Tcgen05PersistentProgramIDs._PartitionedRoleBody
    ) -> None:
        unsafe = self._tcgen05_grouped_unsafe_shared_stmts(partition)
        assert not unsafe, (
            "tcgen05 grouped static scheduler would discard observable shared "
            "statement(s) while omitting the residual shared loop: "
            + "; ".join(ast.unparse(stmt) for stmt in unsafe)
        )

    def _tcgen05_grouped_unsafe_shared_stmts(
        self, partition: Tcgen05PersistentProgramIDs._PartitionedRoleBody
    ) -> list[ast.stmt]:
        plan = self._tcgen05_plan()
        device_split_sizes = bool(
            plan is not None
            and plan.grouped is not None
            and plan.grouped.device_split_sizes
        )
        if device_split_sizes:
            # Device-split N,M derives group coordinates from the runtime split
            # tensor rather than replacing a host segment-worklist scaffold.
            # Keep the original fail-closed omission allowlist for this path;
            # only host worklists/runtime tables may discard the extra segment
            # coordinate writes below.
            return self._tcgen05_unsafe_shared_stmts(partition)
        worklist_metadata = bool(
            plan is not None
            and plan.grouped is not None
            and plan.accumulator_view == "nm"
        )
        allowed_coord_writes = {
            "virtual_pid",
            "pid_0",
            "pid_1",
            "tile_offset_0",
            "tile_offset_1",
        }
        if worklist_metadata:
            # Generated segment worklists re-express the original
            # parser-order work row as the grouped scheduler's pseudo-group.
            # Once the scheduler metadata statements are injected, the old
            # segment-loop coordinate and scalar scaffolding is dependency-only.
            allowed_coord_writes.update(
                {
                    "pid_2",
                    "tile_offset_2",
                    "tile_offset_3",
                    "indices_2",
                    "indices_3",
                    "mask_2",
                    "mask_3",
                }
            )
        return [
            stmt
            for stmt in partition.shared_body_extracted
            if not self._tcgen05_grouped_stmt_safe_to_omit(
                stmt,
                allowed_coord_writes=allowed_coord_writes,
                worklist_metadata=worklist_metadata,
            )
        ]

    def _build_tcgen05_persistent_tile_body_role_local(
        self,
        device_function: DeviceFunction,
        layout: _Tcgen05PersistentLayout,
        partition: Tcgen05PersistentProgramIDs._PartitionedRoleBody,
        *,
        build_shared_tile_body: bool = True,
        epi_role_prelude_stmts: list[ast.stmt] | None = None,
        post_loop_stmts: list[ast.stmt] | None = None,
    ) -> tuple[list[ast.stmt], list[ast.stmt]]:
        """Build the per-tile body in role-local-while form.

        Returns ``(role_local_whiles, shared_tile_body)`` where:

        - ``role_local_whiles`` is a list of role-local ``while`` siblings
          -- one per unique ``role_predicate`` in
          ``partition.role_blocks_extracted``. Multiple extracted role
          blocks sharing the same predicate are merged into a single
          role-local loop/body with their statements concatenated in the
          order they appear in the source body, so per-tile ordering
          across the role's statements is preserved (otherwise tile 0's
          first chunk would run for every tile before tile 0's second
          chunk ran, breaking the AB-pipeline ordering). Each loop is
          wrapped in ``if {role_predicate}:`` so only the matching
          warps enter.
        - ``shared_tile_body`` is the optional per-tile body for the shared
          ``while`` (the work-tile body without the extracted role blocks).
          Built via :meth:`_build_tcgen05_persistent_tile_body` with existing
          ``cute.arch.sync_threads()`` calls preserved. The caller omits this
          loop only when the residual statements are dependency-only setup or
          legacy barriers that no longer protect shared work.

        Caller wires both into the persistent kernel as siblings of
        each other inside the same setup list when the residual shared loop
        is needed. Each role-local ``while`` runs only on its predicated warps.

        **Current limitation.** The TMA-load, MMA-exec, and TMA-store
        epilogue roles are extracted today. Single-root static full-tile
        multi-tile correctness is validated for ``cluster_m == 1`` and for
        role-local CtaGroup.TWO ``cluster_m == 2`` up to the validated K-tile
        cap, using role-local scheduler loops over the capped persistent grid.
        Partial fallback shapes, CtaGroup.TWO shapes above the K-tile cap, and
        multi-root ForEach kernels remain guarded for runtime execution, and
        autotune keeps cluster_m=2 out of the search until the G3 ownership path
        is benchmarked.
        """
        if build_shared_tile_body:
            # Wrap the shared body's tagged-removed view in the standard
            # per-tile shape. ``shared_role_blocks`` reuses the
            # inline-weave block structure but only over the
            # extracted-shared statements; tagged stmts have been pulled
            # out into ``role_blocks_extracted``.
            shared_role_blocks = [
                self._PersistentRoleBlock(
                    role_predicate=None, stmts=list(partition.shared_body_extracted)
                )
            ]
            shared_tile_body = self._build_tcgen05_persistent_tile_body(
                layout, shared_role_blocks
            )
        else:
            assert post_loop_stmts is not None, (
                "omitting the tcgen05 shared loop requires explicit post-loop "
                "dependency validation"
            )
            if self._tcgen05_uses_grouped_static_persistent():
                self._assert_tcgen05_grouped_omit_shared_loop_safe(partition)
                dependencies = self._tcgen05_shared_post_loop_dependencies(
                    partition, post_loop_stmts
                )
                assert not dependencies, (
                    "tcgen05 grouped static scheduler would discard shared "
                    "definition(s) used by post-loop cleanup: "
                    + ", ".join(sorted(dependencies))
                )
            else:
                self._assert_tcgen05_omit_shared_loop_safe(partition, post_loop_stmts)
            shared_tile_body = []
        # Merge extracted blocks by ``role_predicate`` so each predicate
        # gets one role-local loop carrying all of its per-tile
        # statements in source order. Emit the loops in explicit role
        # order instead of first-seen source order: TMA-load publishes
        # operands, MMA-exec consumes them and publishes accumulator stages,
        # then epi consumes those stages. Adding another role must update
        # ``role_order`` so omitted predicates fail loudly.
        merged: dict[str, list[ast.stmt]] = {}
        for role_block in partition.role_blocks_extracted:
            assert role_block.role_predicate is not None
            merged.setdefault(role_block.role_predicate, []).extend(role_block.stmts)
        role_local_whiles: list[ast.stmt] = []
        role_order = {
            self._tcgen05_tma_load_role_predicate(): 0,
            self._tcgen05_mma_exec_role_predicate(): 1,
            self._tcgen05_epi_role_predicate(): 2,
        }
        unknown_predicates = set(merged) - set(role_order)
        assert not unknown_predicates, (
            "tcgen05 role-local order missing predicate(s): "
            + ", ".join(sorted(unknown_predicates))
        )
        ordered_predicates = sorted(merged, key=lambda predicate: role_order[predicate])
        cute_state = device_function.cute_state
        uses_grouped_scheduler_mailbox = (
            self._tcgen05_uses_grouped_worklist_nm_scheduler_mailbox()
        )
        use_full_edge_scheduler_split = (
            self._tcgen05_has_scheduler_warp()
            and cute_state.has_tcgen05_epi_role_full_edge_split
        )
        # Cycle-94 merge gate: the store warp is the aux residual producer when
        # there is a store warp, NO C-input warp, and a single-store-value
        # exact-shape aux ring exists. In that case the aux GMEM->SMEM producer
        # body is injected into the (widened) epilogue role-local while on the
        # store warp rather than emitted as a standalone C-input role-local
        # while (which would be a second per-warp sched consumer). The standalone
        # C-input while below stays gated on ``has_c_input_warp`` and does not
        # fire in the merge.
        #
        # TMA-ONLY: the merge injects a TMA bulk producer body; there is no SIMT
        # store-warp producer. ``cute_mma._emit_mma_pipeline`` only allocates the
        # aux pipeline for the store warp when ``aux_load_mode=tma``, so for
        # ``store_warps=1 + SIMT aux`` the pipeline plan is absent and the gate
        # closes (the kernel falls back to direct-GMEM aux). The
        # ``use_tma_load`` check below makes that requirement explicit and
        # defends against a future SIMT-producing aux plan reaching this path.
        store_merge_plan = self._tcgen05_plan()
        aux_plan_for_merge = device_function.cute_state.aux_pipeline_plan
        store_aux_merge_active = (
            store_merge_plan is not None
            and store_merge_plan.has_store_warp
            and not store_merge_plan.has_c_input_warp
            and bool(store_merge_plan.c_input_aux_tensor_descriptors)
            and len(
                {
                    d.store_value_node
                    for d in store_merge_plan.c_input_aux_tensor_descriptors
                }
            )
            <= 1
            and aux_plan_for_merge is not None
            and aux_plan_for_merge.use_tma_load
        )
        for i, predicate in enumerate(ordered_predicates):
            stmts = merged[predicate]
            split_epi_role = (
                use_full_edge_scheduler_split
                and predicate == self._tcgen05_epi_role_predicate()
            )
            if split_epi_role:
                unclassified = [
                    stmt
                    for stmt in stmts
                    if not cute_state.is_tcgen05_epi_role_full_tile(stmt)
                    and not cute_state.is_tcgen05_epi_role_edge_tile(stmt)
                ]
                assert not unclassified, (
                    "scheduler full/edge split found unclassified epilogue "
                    "role statement(s): "
                    + "; ".join(ast.unparse(stmt) for stmt in unclassified)
                )

            # Under a scheduler full/edge split, non-epi roles keep the same
            # body for both phases so they consume both scheduler streams in
            # order; only the epi role swaps in phase-specific store bodies.
            phase_names = ("full", "edge") if use_full_edge_scheduler_split else ("",)
            for phase in phase_names:
                if not split_epi_role:
                    current_stmts = stmts
                elif phase == "full":
                    current_stmts = [
                        stmt
                        for stmt in stmts
                        if cute_state.is_tcgen05_epi_role_full_tile(stmt)
                    ]
                else:
                    current_stmts = [
                        stmt
                        for stmt in stmts
                        if cute_state.is_tcgen05_epi_role_edge_tile(stmt)
                    ]
                if not current_stmts:
                    continue
                if use_full_edge_scheduler_split:
                    # Each phase needs a distinct AST body; reusing nodes would
                    # let later dependency extraction mutate shared structure.
                    current_stmts = [_clone_stmt(stmt) for stmt in current_stmts]
                merged_block = self._PersistentRoleBlock(
                    role_predicate=predicate, stmts=current_stmts
                )
                dependency_stmts = self._role_local_dependency_stmts(
                    partition.shared_body_extracted, current_stmts
                )
                if use_full_edge_scheduler_split:
                    dependency_stmts = [_clone_stmt(stmt) for stmt in dependency_stmts]
                role_prelude_stmts: list[ast.stmt] | None = None
                if (
                    predicate == self._tcgen05_epi_role_predicate()
                    and phase != "edge"
                    and epi_role_prelude_stmts
                ):
                    role_prelude_stmts = [
                        _clone_stmt(stmt) for stmt in epi_role_prelude_stmts
                    ]
                if (
                    predicate == self._tcgen05_tma_load_role_predicate()
                    and cute_state.ab_startup_prefill is not None
                ):
                    assert role_prelude_stmts is None and not phase
                    role_prelude_stmts = ast.parse(
                        cute_state.ab_startup_prefill.role_prelude()
                    ).body
                suffix = f"_{phase}" if phase else ""
                # Cycle-94 merge: build the store warp's aux producer body for
                # injection into the epilogue role-local while. Only on the epi
                # predicate, and (under a full/edge split) only the full-tile
                # phase stages the aux ring — the edge phase uses SIMT direct
                # GMEM aux, like the standalone C-input builder.
                store_aux_per_tile_stmts: list[ast.stmt] | None = None
                store_aux_predicate: str | None = None
                if (
                    store_aux_merge_active
                    and predicate == self._tcgen05_epi_role_predicate()
                    and phase != "edge"
                ):
                    aux_inline = self._build_c_input_warp_role_local_while(
                        device_function,
                        layout,
                        shared_body_extracted=partition.shared_body_extracted,
                        tile_phase="all",
                        inline_aux_only=True,
                    )
                    assert isinstance(aux_inline, list)
                    store_aux_per_tile_stmts = aux_inline
                    assert store_merge_plan is not None
                    store_aux_predicate = (
                        "cute.arch.make_warp_uniform(cute.arch.warp_idx()) "
                        f"== cutlass.Int32({store_merge_plan.store_warp_id})"
                    )
                role_local_whiles.append(
                    self._build_role_local_while(
                        device_function,
                        layout,
                        merged_block,
                        scheduler_var_prefix=f"tcgen05_role_local_{i}{suffix}",
                        dependency_stmts=dependency_stmts,
                        role_prelude_stmts=role_prelude_stmts,
                        emit_pdl_wait=phase != "edge",
                        initialize_tile_counter=phase != "edge",
                        store_aux_per_tile_stmts=store_aux_per_tile_stmts,
                        store_aux_predicate=store_aux_predicate,
                    )
                )
        # Analyze after building every consumer, then restore the producer's
        # original position before any optional C-input role.
        scheduler_insert_index = len(role_local_whiles)
        if self._tcgen05_has_scheduler_warp() and not uses_grouped_scheduler_mailbox:
            role_local_whiles.append(
                self._build_scheduler_warp_role_local_while(device_function, layout)
            )
        # ``c_input_warp_count > 0`` AND a non-empty
        # ``aux_tensor_descriptors`` adds a fifth role-local while for
        # the C-input warp (``cute_plan.md`` §7.5.3.2 producer-body
        # split). Post-cycle-2a the role body has the
        # consumer_wait / valid-read / release machinery so the
        # warp participates as a sched-pipeline consumer and
        # publishes ``virtual_pid_var`` for cycle 2b. The aux
        # pipeline storage (SMEM ring + ``c_pipeline_aux``) is
        # allocated alongside but the
        # producer/consumer barrier handshake stays dormant until
        # cycle 2b (producer side + cooperative copy) and cycle 3
        # (consumer-side SMEM read flip) land together. Gating on
        # the descriptors being non-empty preserves byte identity
        # for every ``c_input_warps=0`` config (today's default)
        # and for ``c_input_warps=1`` configs that don't have a
        # residual epilogue (the walker returns an empty tuple in
        # that case).
        plan = self._tcgen05_plan()
        # Multi-store fan-out guard mirrors the same check in
        # ``cute_mma._emit_mma_pipeline``: the productive body
        # only emits when every aux descriptor for this matmul
        # comes from a single ``store_value_node``. The
        # cute_mma path uses the same predicate to gate the
        # ``c_pipeline_aux`` allocation; both must agree or the
        # role-local while will try to access a missing
        # pipeline plan.
        if (
            plan is not None
            and plan.has_c_input_warp
            and plan.c_input_aux_tensor_descriptors
            and len({d.store_value_node for d in plan.c_input_aux_tensor_descriptors})
            <= 1
        ):
            c_input_phases = (
                ("full", "edge") if use_full_edge_scheduler_split else ("all",)
            )
            for c_input_phase in c_input_phases:
                c_input_while = self._build_c_input_warp_role_local_while(
                    device_function,
                    layout,
                    # ``shared_body_extracted`` carries the post-PID-
                    # decomposition statements (incl. the L2-grouping
                    # ``pid_0`` / ``pid_1`` / ``tile_offset_0`` /
                    # ``tile_offset_1`` chain). The C-input producer
                    # body needs the same chain so its per-CTA aux
                    # GMEM tile coords match the consumer's
                    # post-L2-remapped tile coords — without this
                    # the producer fetches a misaligned aux tile
                    # under ``l2_groupings=[g>1]`` and the residual
                    # add reads wrong rows / columns of the
                    # auxiliary tensor (cycle 2i: 60-69% mismatched
                    # elements vs eager).
                    shared_body_extracted=partition.shared_body_extracted,
                    tile_phase=c_input_phase,
                )
                # ``inline_aux_only`` is False here, so the builder returns the
                # full role-local while statement (not the merge tuple).
                assert isinstance(c_input_while, ast.stmt)
                role_local_whiles.append(c_input_while)
        if uses_grouped_scheduler_mailbox:
            required_mailbox_fields, mailbox_writes = _literal_mailbox_access_fields(
                ast.Module(body=role_local_whiles, type_ignores=[]),
                layout.work_tile_smem,
            )
            assert not mailbox_writes
            role_local_whiles.insert(
                scheduler_insert_index,
                self._build_scheduler_warp_role_local_while(
                    device_function,
                    layout,
                    required_mailbox_fields=frozenset(required_mailbox_fields),
                ),
            )
        return role_local_whiles, shared_tile_body

    def setup_persistent_kernel(
        self, device_function: DeviceFunction, total_pids_expr: str | None = None
    ) -> list[ast.stmt] | None:
        return self._setup_tcgen05_persistent_kernel(device_function)
