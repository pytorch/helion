from __future__ import annotations

from collections import defaultdict
import dataclasses
import enum

from .attention_plan import flash_head_dims_supported


class FlashScheduleError(ValueError):
    """A structural flash schedule is unsafe or exceeds device resources."""


class FlashNodeKind(enum.Enum):
    Q_LOAD = "q_load"
    K_LOAD = "k_load"
    V_LOAD = "v_load"
    DIAGONAL_LOAD = "diagonal_load"
    QK_MMA = "qk_mma"
    SOFTMAX = "softmax"
    STAT_PUBLISH = "stat_publish"
    FINAL_STAT_PUBLISH = "final_stat_publish"
    FINAL_STAT_CONSUME = "final_stat_consume"
    CORRECTION = "correction"
    PV_MMA = "pv_mma"
    OUTPUT_STAGE = "output_stage"
    OUTPUT_STORE = "output_store"


class FlashMemorySpace(enum.Enum):
    SMEM = "smem"
    TMEM = "tmem"


class FlashVisibility(enum.Enum):
    CTA_PRIVATE = "cta_private"
    CLUSTER_VISIBLE = "cluster_visible"


class FlashSyncScope(enum.Enum):
    CTA = "cta"
    CLUSTER = "cluster"
    CLUSTER_LEADER = "cluster_leader"


class FlashOutputOrder(enum.Enum):
    INTERLEAVED = "interleaved"
    CTA_CONTIGUOUS = "cta_contiguous"


class FlashStatReleaseMapping(enum.Enum):
    CROSS_SLOT = "cross_slot"
    SAME_SLOT = "same_slot"


@dataclasses.dataclass(frozen=True)
class FlashScheduleSpec:
    head_dim: int
    kv_depth: int
    cta_count: int = 1
    query_slots_per_cta: int = 2
    separate_kv: bool = False
    causal: bool = False
    multicast_kv: bool = False
    persistent: bool = False
    kv_iterations: int | None = None
    stage_output: bool = True
    dtype_bytes: int = 2
    private_causal_tail: bool = False
    output_order: FlashOutputOrder = FlashOutputOrder.INTERLEAVED
    cooperative_mma: bool = False
    split_p_arrive: bool = True
    # One P arrival per 32-column chunk (pfor, pforc0, pforc1, pfor2) instead of
    # the 3/4 + 1/4 split; needs ``split_p_arrive``.
    p_chunk_arrive: bool = False
    stat_depth: int = 2
    pipelined_stat_handoff: bool = False
    final_only_stat_handoff: bool = False
    stat_release_mapping: FlashStatReleaseMapping = FlashStatReleaseMapping.CROSS_SLOT
    query_slots_have_equal_kv_iterations: bool = False
    # KV tile width. Only the K/V staging rings scale with it; the query and
    # output tiles stay 128 rows wide.
    kv_tile_n: int = 128
    # Shared memory the body adds outside the tiles and rings (the flex
    # hook's warp-cooperative table staging, ``flex_coalesce_smem_bytes``):
    # part of the base the K/V depth is fitted against.
    aux_smem_bytes: int = 0
    # V/O head dim when it differs from the Q/K ``head_dim`` (the (192, 128)
    # MLA pair): sQ and the K tile follow ``head_dim``, the aliased ring slot
    # the wider operand, the output tile and TMEM accumulators the V width.
    head_dim_v: int | None = None
    # Alternating-warpgroup family: one query tile per work item, the two
    # softmax warpgroups own alternating KV steps on their own score and
    # probability buffers, separate K and V rings (``kv_depth`` is the K ring,
    # ``v_depth`` the V ring), and the output tile is staged in the finished
    # item's dead Q stage. ``query_slots_per_cta`` is one.
    alternating_warpgroups: bool = False
    v_depth: int | None = None
    # FA4's uneven aliased ring for the asymmetric pair: three slots laid out
    # [K-wide, V-wide, K-wide] with a stage stride of half a K plus half a V
    # tile, so a third stage fits where three K-wide slots would not. The odd
    # slot is shifted by half the width difference toward whichever operand
    # it holds (K and V alternate through the ring, so every slot sees both),
    # and a K load into slot 0 also waits for slot 1 to drain (its wider
    # tile reaches into the previous round's K bytes there).
    uneven_kv_ring: bool = False
    # Stage the output tiles in the Q stages instead of a separate ``sO``
    # (FA4's overlap_sO_sQ): the output stage is written after the work
    # item's last PV, whose completion barrier also covers every QK that read
    # Q, and a non-persistent CTA loads no further Q tile, so both Q stages
    # are dead by then. Needs ``stage_output``; no bytes for the staged tiles.
    output_over_query: bool = False


@dataclasses.dataclass(frozen=True)
class FlashNode:
    name: str
    kind: FlashNodeKind
    cta_rank: int | None = None
    query_slot: int | None = None


@dataclasses.dataclass(frozen=True)
class FlashEdge:
    source: str
    target: str
    iteration_delta: int = 0
    barrier: str | None = None
    arrival_count: int = 0
    scope: FlashSyncScope = FlashSyncScope.CTA
    resource_scope: FlashSyncScope = FlashSyncScope.CTA
    resource: str | None = None
    multicast: bool = False


@dataclasses.dataclass(frozen=True)
class FlashBarrier:
    name: str
    expected_arrivals: int
    scope: FlashSyncScope


@dataclasses.dataclass(frozen=True)
class FlashMemoryRegion:
    name: str
    space: FlashMemorySpace
    offset: int
    extent: int
    alignment: int
    visibility: FlashVisibility
    writer: str
    consumers: tuple[str, ...]
    reuse_distance: int | None = None
    reuse_barrier: str | None = None
    alias_group: str | None = None
    cta_rank: int | None = None
    physical: bool = True


@dataclasses.dataclass(frozen=True)
class FlashOutputOwner:
    output_tile: int
    cta_rank: int
    query_slot: int


@dataclasses.dataclass(frozen=True)
class FlashPhaseCycle:
    barrier: str
    phases: tuple[int, ...]
    uses_per_work: int = 1


@dataclasses.dataclass(frozen=True)
class FlashSchedule:
    spec: FlashScheduleSpec
    nodes: tuple[FlashNode, ...]
    edges: tuple[FlashEdge, ...]
    barriers: tuple[FlashBarrier, ...]
    memory_regions: tuple[FlashMemoryRegion, ...]
    output_owners: tuple[FlashOutputOwner, ...]
    phase_cycles: tuple[FlashPhaseCycle, ...]
    shared_memory_bytes: int
    tmem_columns: int


# The uneven aliased ring is FA4's fixed three-slot layout.
UNEVEN_KV_RING_DEPTH = 3


@dataclasses.dataclass(frozen=True)
class FlashScheduleLimits:
    shared_memory_bytes: int = 232448
    tmem_columns: int = 512


@dataclasses.dataclass(frozen=True)
class VerifiedFlashSchedule:
    schedule: FlashSchedule

    @property
    def spec(self) -> FlashScheduleSpec:
        return self.schedule.spec


def _node_name(kind: str, cta_rank: int, query_slot: int) -> str:
    return f"{kind}_r{cta_rank}_q{query_slot}"


def _kv_node_name(kind: str, cta_rank: int, multicast: bool) -> str:
    if multicast:
        return f"{kind}_multicast"
    return f"{kind}_r{cta_rank}"


def _value_head_dim(spec: FlashScheduleSpec) -> int:
    """V/O head dim: ``head_dim`` unless the spec names the asymmetric pair."""
    return spec.head_dim if spec.head_dim_v is None else spec.head_dim_v


def _kv_cta_group_size(spec: FlashScheduleSpec) -> int:
    # CtaGroup.TWO partitions the MMA B operand across CTAs. Merely clustering
    # two local-MMAs does not reduce their independently resident K/V tiles.
    return 2 if spec.cooperative_mma else 1


def _k_tile_bytes(spec: FlashScheduleSpec) -> int:
    """Per-CTA bytes of one K tile."""
    return spec.kv_tile_n * spec.head_dim * spec.dtype_bytes // _kv_cta_group_size(spec)


def _v_tile_bytes(spec: FlashScheduleSpec) -> int:
    """Per-CTA bytes of one V tile (the V width of the asymmetric pair)."""
    return (
        spec.kv_tile_n
        * _value_head_dim(spec)
        * spec.dtype_bytes
        // _kv_cta_group_size(spec)
    )


def _kv_slot_bytes(spec: FlashScheduleSpec) -> int:
    """Per-CTA bytes of one aliased K/V ring slot (the wider of the two tiles)."""
    slot_dim = max(spec.head_dim, _value_head_dim(spec))
    return spec.kv_tile_n * slot_dim * spec.dtype_bytes // _kv_cta_group_size(spec)


def uneven_kv_ring_stage_stride_bytes(spec: FlashScheduleSpec) -> int:
    """Stage stride of the uneven ring: half a K tile plus half a V tile."""
    k_tile_bytes = spec.kv_tile_n * spec.head_dim * spec.dtype_bytes
    v_tile_bytes = spec.kv_tile_n * _value_head_dim(spec) * spec.dtype_bytes
    return (k_tile_bytes + v_tile_bytes) // 2


def uneven_kv_ring_shift_bytes(spec: FlashScheduleSpec) -> int:
    """Shift of the odd uneven-ring slot: half the K/V tile width difference."""
    k_tile_bytes = spec.kv_tile_n * spec.head_dim * spec.dtype_bytes
    v_tile_bytes = spec.kv_tile_n * _value_head_dim(spec) * spec.dtype_bytes
    return abs(k_tile_bytes - v_tile_bytes) // 2


def _aliased_kv_ring_bytes(spec: FlashScheduleSpec) -> int:
    """Bytes of the aliased K/V ring: ``kv_depth`` wide slots, or FA4's uneven
    [wide, narrow, wide] layout whose last slot starts at two stage strides."""
    if spec.uneven_kv_ring:
        return (spec.kv_depth - 1) * uneven_kv_ring_stage_stride_bytes(
            spec
        ) + _kv_slot_bytes(spec)
    return spec.kv_depth * _kv_slot_bytes(spec)


def _shared_memory_bytes(spec: FlashScheduleSpec) -> int:
    tile_bytes = 128 * spec.head_dim * spec.dtype_bytes
    k_tile_bytes = _k_tile_bytes(spec)
    v_tile_bytes = _v_tile_bytes(spec)
    if spec.alternating_warpgroups:
        # Two Q stages (the next item's tile is prefetched), the K ring, the V
        # ring, and the stat/barrier overhead; the output tile aliases a Q stage.
        assert spec.v_depth is not None
        return (
            2 * tile_bytes
            + spec.kv_depth * k_tile_bytes
            + spec.v_depth * v_tile_bytes
            + _ALT_OVERHEAD_BYTES
        )
    q_bytes = spec.query_slots_per_cta * tile_bytes
    if spec.separate_kv:
        kv_bytes = spec.kv_depth * (k_tile_bytes + v_tile_bytes)
    else:
        # K and V alternate through one ring, so every slot is the wider tile
        # (or the uneven ring's two wide slots around one narrow slot).
        kv_bytes = _aliased_kv_ring_bytes(spec)
    output_tile_bytes = 128 * _value_head_dim(spec) * spec.dtype_bytes
    output_bytes = (
        spec.query_slots_per_cta * output_tile_bytes
        if spec.stage_output and not spec.output_over_query
        else 0
    )
    # Scale/stat transport plus aligned barrier storage in the current FA4 layout.
    return q_bytes + kv_bytes + output_bytes + 3072 + spec.aux_smem_bytes


_ALT_OVERHEAD_BYTES = 3072


def _alt_tmem_columns(spec: FlashScheduleSpec) -> int:
    # S_a, S_b (128 each), O (head_dim), P_a, P_b (64 each: fp16 pairs).
    return 256 + spec.head_dim + 128


def build_fa4_alt_schedule(spec: FlashScheduleSpec) -> FlashSchedule:
    """Build the structural graph of the alternating-warpgroup family.

    One iteration of the graph is a pair of KV steps: the even step (``_a``
    nodes, softmax warpgroup A, buffers S_a/P_a) and the odd step (``_b``).
    The QK warp issues QK(i) once K(i) landed and S_x was read into registers;
    the PV warp issues PV(i) once P(i) is published and O rescaled. The running
    max is handed A -> B inside the pair and B -> A into the next pair; alpha
    goes to the correction warps per step; the even warpgroup hands its partial
    row sum to the odd one once per work item. K and V have separate rings whose
    slots are reused by the tile ``depth`` positions later, which is
    ``depth // 2`` pairs after an even step and ``(depth + 1) // 2`` after an
    odd one.
    """
    if not spec.alternating_warpgroups:
        raise FlashScheduleError("the alternating schedule needs its spec flag")
    if spec.head_dim not in (64, 128):
        raise FlashScheduleError("the alternating schedule requires head_dim 64 or 128")
    if spec.kv_depth < 2:
        raise FlashScheduleError(
            "the alternating schedule needs a K ring of depth >= 2"
        )
    if spec.v_depth is None or spec.v_depth < 2:
        raise FlashScheduleError(
            "the alternating schedule needs a V ring of depth >= 2"
        )
    if spec.cta_count != 1 or spec.query_slots_per_cta != 1:
        raise FlashScheduleError(
            "the alternating schedule is one CTA with one query slot"
        )
    if spec.causal or spec.multicast_kv or spec.cooperative_mma:
        raise FlashScheduleError("the alternating schedule is dense and one-CTA")
    if not spec.stage_output or not spec.split_p_arrive or spec.p_chunk_arrive:
        raise FlashScheduleError(
            "the alternating schedule stages its output and uses the split "
            "probability publication"
        )
    if spec.kv_tile_n != 128:
        raise FlashScheduleError("the alternating schedule uses 128-wide KV tiles")
    if spec.persistent and (spec.kv_iterations is None or spec.kv_iterations <= 0):
        raise FlashScheduleError(
            "persistent schedules require a positive K/V iteration count"
        )
    if spec.kv_iterations is not None and (
        spec.kv_iterations < 2 or spec.kv_iterations % 2
    ):
        raise FlashScheduleError(
            "the alternating schedule needs an even K/V iteration count of at least two"
        )
    # The even warpgroup hands alpha over at its steps after the first; a
    # two-step item has one even step, so that barrier, edge and slot exist
    # only for longer items.
    alpha_a_live = spec.kv_iterations is None or spec.kv_iterations > 2

    cta = FlashSyncScope.CTA
    tile_bytes = 128 * spec.head_dim * spec.dtype_bytes
    k_offset = 2 * tile_bytes
    v_offset = k_offset + spec.kv_depth * tile_bytes
    overhead_offset = v_offset + spec.v_depth * tile_bytes
    q_load, k_load, v_load = "q_load_r0_q0", "k_load_r0", "v_load_r0"
    output_stage, output_store = "output_stage_r0_q0", "output_store_r0_q0"
    nodes = [
        FlashNode(q_load, FlashNodeKind.Q_LOAD, 0, 0),
        FlashNode(k_load, FlashNodeKind.K_LOAD, 0),
        FlashNode(v_load, FlashNodeKind.V_LOAD, 0),
        FlashNode(output_stage, FlashNodeKind.OUTPUT_STAGE, 0, 0),
        FlashNode(output_store, FlashNodeKind.OUTPUT_STORE, 0, 0),
    ]
    for tag in "ab":
        nodes.extend(
            [
                FlashNode(f"qk_{tag}", FlashNodeKind.QK_MMA, 0, 0),
                FlashNode(f"softmax_{tag}", FlashNodeKind.SOFTMAX, 0, 0),
                FlashNode(f"stat_{tag}", FlashNodeKind.STAT_PUBLISH, 0, 0),
                FlashNode(f"correction_{tag}", FlashNodeKind.CORRECTION, 0, 0),
                FlashNode(f"pv_{tag}", FlashNodeKind.PV_MMA, 0, 0),
            ]
        )
    barriers = [
        FlashBarrier("q_ready_r0_q0", 1, cta),
        FlashBarrier("q_reuse_r0_q0", 1, cta),
        FlashBarrier("k_ready_r0", 1, cta),
        FlashBarrier("v_ready_r0", 1, cta),
        FlashBarrier("k_reuse_r0", 2, cta),
        FlashBarrier("v_reuse_r0", 2, cta),
        FlashBarrier("o_full_r0_q0", 1, cta),
        FlashBarrier("corr_epi_full_r0", 128, cta),
        FlashBarrier("part_sum_r0", 128, cta),
        FlashBarrier("part_sum_consumed_r0", 128, cta),
        FlashBarrier("row_sum_consumed_r0", 128, cta),
    ]
    for tag in "ab":
        barriers.extend(
            [
                FlashBarrier(f"s_full_{tag}", 1, cta),
                FlashBarrier(f"s_empty_{tag}", 4, cta),
                FlashBarrier(f"pfor_{tag}", 256, cta),
                FlashBarrier(f"pfor2_{tag}", 128, cta),
                FlashBarrier(f"pv_done_{tag}", 1, cta),
                FlashBarrier(f"max_{tag}", 128, cta),
            ]
        )
        if tag == "b" or alpha_a_live:
            barriers.append(FlashBarrier(f"alpha_{tag}", 128, cta))
    edges = [
        FlashEdge(
            q_load, "qk_a", barrier="q_ready_r0_q0", arrival_count=1, resource="Q_r0_q0"
        ),
        FlashEdge(q_load, "qk_b", resource="Q_r0_q0"),
        FlashEdge(
            k_load, "qk_a", barrier="k_ready_r0", arrival_count=1, resource="K_r0"
        ),
        FlashEdge(k_load, "qk_b", resource="K_r0"),
        FlashEdge(
            v_load, "pv_a", barrier="v_ready_r0", arrival_count=1, resource="V_r0"
        ),
        FlashEdge(v_load, "pv_b", resource="V_r0"),
        # K(i)'s slot is refilled ``kv_depth`` tiles later; V likewise.
        FlashEdge(
            "qk_a",
            k_load,
            iteration_delta=spec.kv_depth // 2,
            barrier="k_reuse_r0",
            arrival_count=1,
        ),
        FlashEdge(
            "qk_b",
            k_load,
            iteration_delta=(spec.kv_depth + 1) // 2,
            barrier="k_reuse_r0",
            arrival_count=1,
        ),
        FlashEdge(
            "pv_a",
            v_load,
            iteration_delta=spec.v_depth // 2,
            barrier="v_reuse_r0",
            arrival_count=1,
        ),
        FlashEdge(
            "pv_b",
            v_load,
            iteration_delta=(spec.v_depth + 1) // 2,
            barrier="v_reuse_r0",
            arrival_count=1,
        ),
        # running max A -> B inside the pair, B -> A into the next pair
        FlashEdge(
            "stat_a", "softmax_b", barrier="max_a", arrival_count=128, resource="MAX_a"
        ),
        FlashEdge(
            "stat_b",
            "softmax_a",
            iteration_delta=1,
            barrier="max_b",
            arrival_count=128,
            resource="MAX_b",
        ),
        # the even partial row sum reaches the odd warpgroup once per work item
        FlashEdge(
            "softmax_a",
            "softmax_b",
            barrier="part_sum_r0",
            arrival_count=128,
            resource="PARTSUM_r0",
        ),
        # ... and its slot is rewritten only after that read: the named barrier
        # of the handoff must never see two even-side arrivals per odd sync
        # (with one KV pair per item nothing else orders the next item's write)
        FlashEdge(
            "softmax_b",
            "softmax_a",
            iteration_delta=1,
            barrier="part_sum_consumed_r0",
            arrival_count=128,
        ),
        # the odd warpgroup's alpha slot carries the item's row sum to the
        # correction warps; the next item's first alpha is written only after
        # they read it (the PV chain orders the in-item alpha writes behind the
        # previous read, but not this write across the item boundary)
        FlashEdge(
            "correction_b",
            "stat_b",
            iteration_delta=1,
            barrier="row_sum_consumed_r0",
            arrival_count=128,
        ),
        # the odd step's rescale of O waits for the even step's PV; O is drained once per item
        FlashEdge("pv_a", "correction_b"),
        FlashEdge("pv_a", output_stage),
        FlashEdge(
            "pv_b",
            output_stage,
            barrier="o_full_r0_q0",
            arrival_count=1,
            resource="O_r0_q0",
        ),
        FlashEdge("pv_b", "correction_a", iteration_delta=1, resource="O_r0_q0"),
        FlashEdge(
            output_stage,
            output_store,
            barrier="corr_epi_full_r0",
            arrival_count=128,
            resource="O_stage_r0_q0",
        ),
        # the Q stage goes back to the loader once the output store read it
        FlashEdge(
            output_store,
            q_load,
            iteration_delta=1,
            barrier="q_reuse_r0_q0",
            arrival_count=1,
        ),
    ]
    for tag in "ab":
        qk, softmax, stat = f"qk_{tag}", f"softmax_{tag}", f"stat_{tag}"
        correction, pv = f"correction_{tag}", f"pv_{tag}"
        edges.extend(
            [
                FlashEdge(
                    qk,
                    softmax,
                    barrier=f"s_full_{tag}",
                    arrival_count=1,
                    resource=f"S_{tag}",
                ),
                # the score buffer is free once its row is in registers
                FlashEdge(
                    softmax,
                    qk,
                    iteration_delta=1,
                    barrier=f"s_empty_{tag}",
                    arrival_count=4,
                ),
                FlashEdge(softmax, stat),
                FlashEdge(
                    softmax,
                    pv,
                    barrier=f"pfor_{tag}",
                    arrival_count=128,
                    resource=f"P_{tag}",
                ),
                FlashEdge(softmax, pv, barrier=f"pfor2_{tag}", arrival_count=128),
                FlashEdge(correction, pv, barrier=f"pfor_{tag}", arrival_count=128),
                # the probability buffer is free once its PV completed
                FlashEdge(
                    pv,
                    softmax,
                    iteration_delta=1,
                    barrier=f"pv_done_{tag}",
                    arrival_count=1,
                ),
            ]
        )
        if tag == "b" or alpha_a_live:
            edges.append(
                FlashEdge(
                    stat,
                    correction,
                    barrier=f"alpha_{tag}",
                    arrival_count=128,
                    resource=f"STAT_{tag}",
                )
            )
    private = FlashVisibility.CTA_PRIVATE
    regions = [
        FlashMemoryRegion(
            "Q_r0_q0",
            FlashMemorySpace.SMEM,
            0,
            tile_bytes,
            1024,
            private,
            q_load,
            ("qk_a", "qk_b"),
            alias_group="q_stage_r0",
            cta_rank=0,
        ),
        FlashMemoryRegion(
            "O_stage_r0_q0",
            FlashMemorySpace.SMEM,
            0,
            tile_bytes,
            1024,
            private,
            output_stage,
            (output_store,),
            alias_group="q_stage_r0",
            cta_rank=0,
        ),
        FlashMemoryRegion(
            "K_r0",
            FlashMemorySpace.SMEM,
            k_offset,
            spec.kv_depth * tile_bytes,
            1024,
            private,
            k_load,
            ("qk_a", "qk_b"),
            cta_rank=0,
        ),
        FlashMemoryRegion(
            "V_r0",
            FlashMemorySpace.SMEM,
            v_offset,
            spec.v_depth * tile_bytes,
            1024,
            private,
            v_load,
            ("pv_a", "pv_b"),
            cta_rank=0,
        ),
        FlashMemoryRegion(
            "PARTSUM_r0",
            FlashMemorySpace.SMEM,
            overhead_offset + 2048,
            512,
            16,
            private,
            "softmax_a",
            ("softmax_b",),
            cta_rank=0,
        ),
        FlashMemoryRegion(
            "S_a",
            FlashMemorySpace.TMEM,
            0,
            128,
            1,
            private,
            "qk_a",
            ("softmax_a",),
            reuse_distance=1,
            cta_rank=0,
        ),
        FlashMemoryRegion(
            "S_b",
            FlashMemorySpace.TMEM,
            128,
            128,
            1,
            private,
            "qk_b",
            ("softmax_b",),
            reuse_distance=1,
            cta_rank=0,
        ),
        FlashMemoryRegion(
            "O_r0_q0",
            FlashMemorySpace.TMEM,
            256,
            spec.head_dim,
            1,
            private,
            "pv_b",
            ("correction_a", output_stage),
            cta_rank=0,
        ),
        FlashMemoryRegion(
            "P_a",
            FlashMemorySpace.TMEM,
            256 + spec.head_dim,
            64,
            1,
            private,
            "softmax_a",
            ("pv_a",),
            reuse_distance=1,
            cta_rank=0,
        ),
        FlashMemoryRegion(
            "P_b",
            FlashMemorySpace.TMEM,
            256 + spec.head_dim + 64,
            64,
            1,
            private,
            "softmax_b",
            ("pv_b",),
            reuse_distance=1,
            cta_rank=0,
        ),
    ]
    for index, (tag, other) in enumerate((("a", "b"), ("b", "a"))):
        if tag == "b" or alpha_a_live:
            regions.append(
                FlashMemoryRegion(
                    f"STAT_{tag}",
                    FlashMemorySpace.SMEM,
                    overhead_offset + index * 512,
                    512,
                    16,
                    private,
                    f"stat_{tag}",
                    (f"correction_{tag}",),
                    cta_rank=0,
                )
            )
        regions.append(
            FlashMemoryRegion(
                f"MAX_{tag}",
                FlashMemorySpace.SMEM,
                overhead_offset + 1024 + index * 512,
                512,
                16,
                private,
                f"stat_{tag}",
                (f"softmax_{other}",),
                cta_rank=0,
            )
        )
    phase_cycles: tuple[FlashPhaseCycle, ...] = ()
    if spec.persistent:
        assert spec.kv_iterations is not None
        steps = spec.kv_iterations
        per_item = {
            "k_ready_r0": steps,
            "k_reuse_r0": steps,
            "v_ready_r0": steps,
            "v_reuse_r0": steps,
            # the even warpgroup hands alpha over at its steps after the first,
            # the odd one at every step plus the final row sum
            "alpha_a": steps // 2 - 1,
            "alpha_b": steps // 2 + 1,
        }
        cycles = []
        for barrier in barriers:
            uses = per_item.get(barrier.name)
            if uses is None:
                uses = (
                    steps // 2
                    if barrier.name.startswith(
                        ("s_full", "s_empty", "pfor", "pv_done", "max_")
                    )
                    else 1
                )
            cycles.append(FlashPhaseCycle(barrier.name, (0, uses & 1, 0), uses))
        phase_cycles = tuple(cycles)
    return FlashSchedule(
        spec=spec,
        nodes=tuple(nodes),
        edges=tuple(edges),
        barriers=tuple(barriers),
        memory_regions=tuple(regions),
        output_owners=(FlashOutputOwner(0, 0, 0),),
        phase_cycles=phase_cycles,
        shared_memory_bytes=_shared_memory_bytes(spec),
        tmem_columns=_alt_tmem_columns(spec),
    )


def fa4_schedule_fits(
    spec: FlashScheduleSpec, limits: FlashScheduleLimits | None = None
) -> bool:
    """Whether the schedule's SMEM layout fits at ``spec.kv_depth``."""
    if limits is None:
        limits = FlashScheduleLimits()
    return _shared_memory_bytes(spec) <= limits.shared_memory_bytes


def max_fa4_kv_depth(
    spec: FlashScheduleSpec, limits: FlashScheduleLimits | None = None
) -> int:
    """Return the largest K/V depth allowed by the schedule's SMEM layout."""
    if limits is None:
        limits = FlashScheduleLimits()
    if spec.uneven_kv_ring:
        # The uneven layout is FA4's three-slot ring; it is either the depth
        # that fits or the ordinary aliased ring's depth.
        if fa4_schedule_fits(
            dataclasses.replace(spec, kv_depth=UNEVEN_KV_RING_DEPTH), limits
        ):
            return UNEVEN_KV_RING_DEPTH
        return max_fa4_kv_depth(dataclasses.replace(spec, uneven_kv_ring=False), limits)
    base_bytes = _shared_memory_bytes(dataclasses.replace(spec, kv_depth=0))
    # A staging slot holds one KV tile, which is ``kv_tile_n`` wide; separate
    # rings pay for a K and a V tile per stage, the aliased ring for the wider
    # (each the per-CTA extent of a cooperative two-CTA MMA).
    if spec.separate_kv:
        bytes_per_stage = _k_tile_bytes(spec) + _v_tile_bytes(spec)
    else:
        bytes_per_stage = _kv_slot_bytes(spec)
    return max(0, (limits.shared_memory_bytes - base_bytes) // bytes_per_stage)


def _output_tile(spec: FlashScheduleSpec, cta_rank: int, query_slot: int) -> int:
    if spec.output_order is FlashOutputOrder.CTA_CONTIGUOUS:
        return cta_rank * spec.query_slots_per_cta + query_slot
    return query_slot * spec.cta_count + cta_rank


def _pipelined_stat_release(
    spec: FlashScheduleSpec, source_slot: int
) -> tuple[int, int]:
    if spec.stat_release_mapping is FlashStatReleaseMapping.SAME_SLOT:
        return source_slot, 1
    # The acknowledged correction loop visits slot 0 before slot 1. Slot 0
    # releases slot 1's held prologue value in the current loop iteration;
    # slot 1 then releases slot 0 for the next iteration.
    return source_slot ^ 1, source_slot


def _pipelined_stat_releaser(
    spec: FlashScheduleSpec, target_slot: int
) -> tuple[int, int]:
    source_slot = (
        target_slot
        if spec.stat_release_mapping is FlashStatReleaseMapping.SAME_SLOT
        else target_slot ^ 1
    )
    mapped_target, iteration_delta = _pipelined_stat_release(spec, source_slot)
    assert mapped_target == target_slot
    return source_slot, iteration_delta


def build_fa4_schedule(spec: FlashScheduleSpec) -> FlashSchedule:
    """Build the structural graph for an FA4-style local schedule.

    Score storage is always two local query slots. With two CTAs this becomes
    four aggregate CTA-local slices; it is not a temporal four-stage score ring.
    """
    if not flash_head_dims_supported(spec.head_dim, _value_head_dim(spec)):
        raise FlashScheduleError(
            "FA4 schedule requires head_dim 64 or 128, or the 192/128 pair"
        )
    if spec.head_dim_v is not None and spec.head_dim_v != spec.head_dim:
        if spec.separate_kv or spec.cta_count != 1 or spec.alternating_warpgroups:
            raise FlashScheduleError(
                "asymmetric head dims need the one-CTA aliased K/V ring"
            )
    if spec.uneven_kv_ring:
        if spec.head_dim_v is None or spec.head_dim_v == spec.head_dim:
            raise FlashScheduleError("the uneven K/V ring needs asymmetric head dims")
        if spec.kv_depth != UNEVEN_KV_RING_DEPTH:
            raise FlashScheduleError("the uneven K/V ring has exactly three slots")
        if uneven_kv_ring_shift_bytes(spec) % 1024 != 0:
            raise FlashScheduleError(
                "the uneven K/V ring shift must keep the 1024-byte swizzle period"
            )
    if spec.output_over_query:
        if not spec.stage_output:
            raise FlashScheduleError("output over the Q stages needs a staged output")
        if spec.persistent:
            raise FlashScheduleError(
                "output over the Q stages needs a non-persistent schedule: a "
                "persistent CTA loads the next item's Q tile while the output drains"
            )
        if spec.separate_kv or spec.cta_count != 1 or spec.alternating_warpgroups:
            raise FlashScheduleError(
                "output over the Q stages needs the one-CTA aliased K/V ring"
            )
        if _value_head_dim(spec) > spec.head_dim:
            raise FlashScheduleError(
                "output over the Q stages needs output tiles no wider than Q"
            )
    if spec.kv_depth < 2:
        raise FlashScheduleError("FA4 schedule requires at least two K/V stages")
    if spec.cta_count not in (1, 2):
        raise FlashScheduleError("FA4 schedule supports one or two CTAs")
    if spec.query_slots_per_cta != 2:
        raise FlashScheduleError("FA4 schedule requires two local score slots")
    if spec.multicast_kv and spec.cta_count != 2:
        raise FlashScheduleError("K/V multicast requires a two-CTA schedule")
    if spec.cooperative_mma and spec.cta_count != 2:
        raise FlashScheduleError("a cooperative MMA requires two CTAs")
    if spec.cooperative_mma and spec.output_order is not FlashOutputOrder.INTERLEAVED:
        raise FlashScheduleError("a cooperative MMA requires interleaved output")
    if spec.private_causal_tail and not (spec.causal and spec.multicast_kv):
        raise FlashScheduleError("a private causal tail requires causal K/V multicast")
    if not isinstance(spec.output_order, FlashOutputOrder):
        raise FlashScheduleError("output order is invalid")
    if not isinstance(spec.stat_release_mapping, FlashStatReleaseMapping):
        raise FlashScheduleError("stat release mapping is invalid")
    if spec.dtype_bytes <= 0:
        raise FlashScheduleError("dtype size must be positive")
    if spec.stat_depth not in (1, 2):
        raise FlashScheduleError("stat transport depth must be one or two")
    if spec.pipelined_stat_handoff and spec.stat_depth != 1:
        raise FlashScheduleError("pipelined stat handoff requires depth one")
    if (
        spec.pipelined_stat_handoff
        and spec.causal
        and spec.stat_release_mapping is FlashStatReleaseMapping.CROSS_SLOT
        and not spec.query_slots_have_equal_kv_iterations
    ):
        raise FlashScheduleError(
            "causal cross-slot stat releases require proof of equal query-slot "
            "K/V iteration counts"
        )
    if (
        not spec.pipelined_stat_handoff
        and spec.stat_release_mapping is FlashStatReleaseMapping.SAME_SLOT
    ):
        raise FlashScheduleError(
            "same-slot stat releases require pipelined stat handoff"
        )
    if spec.final_only_stat_handoff and (spec.stat_depth != 1 or spec.causal):
        raise FlashScheduleError(
            "final-only stat handoff requires depth one and a noncausal schedule"
        )
    if spec.pipelined_stat_handoff and spec.final_only_stat_handoff:
        raise FlashScheduleError("stat handoff modes are mutually exclusive")

    nodes: list[FlashNode] = []
    edges: list[FlashEdge] = []
    barriers: list[FlashBarrier] = []
    regions: list[FlashMemoryRegion] = []
    owners: list[FlashOutputOwner] = []

    kv_visibility = (
        FlashVisibility.CLUSTER_VISIBLE
        if spec.multicast_kv
        else FlashVisibility.CTA_PRIVATE
    )
    kv_scope = FlashSyncScope.CLUSTER if spec.multicast_kv else FlashSyncScope.CTA
    kv_reuse_arrivals = (
        1 if spec.cooperative_mma else spec.cta_count if spec.multicast_kv else 1
    )
    tile_bytes = 128 * spec.head_dim * spec.dtype_bytes
    output_tile_bytes = 128 * _value_head_dim(spec) * spec.dtype_bytes
    q_bytes = spec.query_slots_per_cta * tile_bytes
    kv_ring_bytes = _aliased_kv_ring_bytes(spec)
    k_offset = q_bytes
    v_offset = k_offset + (kv_ring_bytes if spec.separate_kv else 0)
    output_offset = q_bytes + (2 if spec.separate_kv else 1) * kv_ring_bytes
    overhead_offset = output_offset + (
        spec.query_slots_per_cta * output_tile_bytes
        if spec.stage_output and not spec.output_over_query
        else 0
    )
    if spec.output_over_query:
        # The staged output tiles alias the (dead) Q stages from offset 0.
        output_offset = 0
    q_alias_group = "q_stages_r{rank}" if spec.output_over_query else None
    stat_bytes_per_query = spec.stat_depth * 128 * 4

    load_nodes: set[str] = set()
    for rank in range(spec.cta_count):
        k_load = _kv_node_name("k_load", rank, spec.multicast_kv)
        v_load = _kv_node_name("v_load", rank, spec.multicast_kv)
        for name, kind in (
            (k_load, FlashNodeKind.K_LOAD),
            (v_load, FlashNodeKind.V_LOAD),
        ):
            if name not in load_nodes:
                nodes.append(FlashNode(name, kind, None if spec.multicast_kv else rank))
                load_nodes.add(name)

        barriers.extend(
            [
                FlashBarrier(f"k_ready_r{rank}", 1, kv_scope),
                FlashBarrier(f"v_ready_r{rank}", 1, kv_scope),
                FlashBarrier(
                    f"k_reuse_r{rank}",
                    kv_reuse_arrivals,
                    kv_scope,
                ),
                FlashBarrier(
                    f"v_reuse_r{rank}",
                    kv_reuse_arrivals,
                    kv_scope,
                ),
            ]
        )
        # Legacy FA4 alternates K and V acquisitions through one physical
        # pipeline ring. K names that backing allocation and V is a logical
        # view; only the separate-ring family has per-operand depth proofs.
        regions.extend(
            [
                FlashMemoryRegion(
                    f"K_r{rank}",
                    FlashMemorySpace.SMEM,
                    k_offset,
                    kv_ring_bytes,
                    1024,
                    kv_visibility,
                    k_load,
                    tuple(
                        _node_name("qk", rank, slot)
                        for slot in range(spec.query_slots_per_cta)
                    ),
                    reuse_distance=spec.kv_depth if spec.separate_kv else None,
                    alias_group=(
                        None if spec.separate_kv else f"shared_kv_ring_r{rank}"
                    ),
                    cta_rank=rank,
                ),
                FlashMemoryRegion(
                    f"V_r{rank}",
                    FlashMemorySpace.SMEM,
                    v_offset,
                    kv_ring_bytes,
                    1024,
                    kv_visibility,
                    v_load,
                    tuple(
                        _node_name("pv", rank, slot)
                        for slot in range(spec.query_slots_per_cta)
                    ),
                    reuse_distance=spec.kv_depth if spec.separate_kv else None,
                    alias_group=(
                        None if spec.separate_kv else f"shared_kv_ring_r{rank}"
                    ),
                    cta_rank=rank,
                    physical=spec.separate_kv,
                ),
            ]
        )

        if spec.private_causal_tail:
            diagonal_k = f"diagonal_k_load_r{rank}"
            diagonal_v = f"diagonal_v_load_r{rank}"
            nodes.extend(
                [
                    FlashNode(diagonal_k, FlashNodeKind.DIAGONAL_LOAD, rank),
                    FlashNode(diagonal_v, FlashNodeKind.DIAGONAL_LOAD, rank),
                ]
            )
            regions.extend(
                [
                    FlashMemoryRegion(
                        f"causal_diagonal_K_r{rank}",
                        FlashMemorySpace.SMEM,
                        0,
                        tile_bytes,
                        1024,
                        FlashVisibility.CTA_PRIVATE,
                        diagonal_k,
                        tuple(
                            _node_name("qk", rank, slot)
                            for slot in range(spec.query_slots_per_cta)
                        ),
                        cta_rank=rank,
                        physical=False,
                    ),
                    FlashMemoryRegion(
                        f"causal_diagonal_V_r{rank}",
                        FlashMemorySpace.SMEM,
                        0,
                        tile_bytes,
                        1024,
                        FlashVisibility.CTA_PRIVATE,
                        diagonal_v,
                        tuple(
                            _node_name("pv", rank, slot)
                            for slot in range(spec.query_slots_per_cta)
                        ),
                        cta_rank=rank,
                        physical=False,
                    ),
                ]
            )

    for rank in range(spec.cta_count):
        k_load = _kv_node_name("k_load", rank, spec.multicast_kv)
        v_load = _kv_node_name("v_load", rank, spec.multicast_kv)
        for slot in range(spec.query_slots_per_cta):
            q_load = _node_name("q_load", rank, slot)
            qk = _node_name("qk", rank, slot)
            softmax = _node_name("softmax", rank, slot)
            stat = _node_name("stat", rank, slot)
            final_stat_publish = _node_name("final_stat_publish", rank, slot)
            final_stat_consume = _node_name("final_stat_consume", rank, slot)
            correction = _node_name("correction", rank, slot)
            pv = _node_name("pv", rank, slot)
            output_stage = _node_name("output_stage", rank, slot)
            output_store = _node_name("output_store", rank, slot)
            nodes.extend(
                [
                    FlashNode(q_load, FlashNodeKind.Q_LOAD, rank, slot),
                    FlashNode(qk, FlashNodeKind.QK_MMA, rank, slot),
                    FlashNode(softmax, FlashNodeKind.SOFTMAX, rank, slot),
                    FlashNode(stat, FlashNodeKind.STAT_PUBLISH, rank, slot),
                    FlashNode(correction, FlashNodeKind.CORRECTION, rank, slot),
                    FlashNode(pv, FlashNodeKind.PV_MMA, rank, slot),
                    FlashNode(output_stage, FlashNodeKind.OUTPUT_STAGE, rank, slot),
                    FlashNode(output_store, FlashNodeKind.OUTPUT_STORE, rank, slot),
                ]
            )
            if spec.final_only_stat_handoff:
                nodes.extend(
                    [
                        FlashNode(
                            final_stat_publish,
                            FlashNodeKind.FINAL_STAT_PUBLISH,
                            rank,
                            slot,
                        ),
                        FlashNode(
                            final_stat_consume,
                            FlashNodeKind.FINAL_STAT_CONSUME,
                            rank,
                            slot,
                        ),
                    ]
                )

            q_ready = f"q_ready_r{rank}_q{slot}"
            s_full = f"s_full_r{rank}_q{slot}"
            stat_ready = f"stat_ready_r{rank}_q{slot}"
            stat_empty = f"stat_empty_r{rank}_q{slot}"
            o_full = f"o_full_r{rank}_q{slot}"
            barriers.extend(
                [
                    FlashBarrier(q_ready, 1, FlashSyncScope.CTA),
                    FlashBarrier(s_full, 1, FlashSyncScope.CTA),
                    FlashBarrier(stat_ready, 1, FlashSyncScope.CTA),
                    FlashBarrier(stat_empty, 1, FlashSyncScope.CTA),
                    FlashBarrier(o_full, 1, FlashSyncScope.CTA),
                ]
            )
            edges.extend(
                [
                    FlashEdge(
                        q_load,
                        qk,
                        barrier=q_ready,
                        arrival_count=1,
                        resource=f"Q_r{rank}_q{slot}",
                    ),
                    FlashEdge(
                        k_load,
                        qk,
                        barrier=f"k_ready_r{rank}" if slot == 0 else None,
                        arrival_count=1 if slot == 0 else 0,
                        scope=kv_scope,
                        resource_scope=kv_scope,
                        resource=f"K_r{rank}",
                        multicast=spec.multicast_kv,
                    ),
                    FlashEdge(
                        qk,
                        softmax,
                        barrier=s_full,
                        arrival_count=1,
                        resource=f"S_r{rank}_q{slot}",
                    ),
                    FlashEdge(softmax, stat),
                    FlashEdge(
                        stat,
                        correction,
                        barrier=stat_ready,
                        arrival_count=1,
                        resource=f"STAT_r{rank}_q{slot}",
                    ),
                    FlashEdge(
                        v_load,
                        pv,
                        barrier=f"v_ready_r{rank}" if slot == 0 else None,
                        arrival_count=1 if slot == 0 else 0,
                        scope=kv_scope,
                        resource_scope=kv_scope,
                        resource=f"V_r{rank}",
                        multicast=spec.multicast_kv,
                    ),
                    FlashEdge(
                        pv,
                        output_stage,
                        barrier=o_full,
                        arrival_count=1,
                        resource=f"O_r{rank}_q{slot}",
                    ),
                    FlashEdge(
                        output_stage,
                        output_store,
                        resource=(
                            f"O_stage_r{rank}_q{slot}" if spec.stage_output else None
                        ),
                    ),
                    FlashEdge(pv, qk, iteration_delta=1),
                    FlashEdge(
                        pv,
                        correction,
                        iteration_delta=1,
                        resource=f"O_r{rank}_q{slot}",
                    ),
                ]
            )
            if not spec.final_only_stat_handoff:
                stat_release_slot = slot
                stat_release_delta = spec.stat_depth
                if spec.pipelined_stat_handoff:
                    stat_release_slot, stat_release_delta = _pipelined_stat_release(
                        spec, slot
                    )
                edges.append(
                    FlashEdge(
                        correction,
                        _node_name("stat", rank, stat_release_slot),
                        iteration_delta=stat_release_delta,
                        barrier=f"stat_empty_r{rank}_q{stat_release_slot}",
                        arrival_count=1,
                    )
                )
            else:
                edges.extend(
                    [
                        FlashEdge(
                            correction,
                            final_stat_publish,
                            barrier=stat_empty,
                            arrival_count=1,
                        ),
                        FlashEdge(
                            final_stat_publish,
                            final_stat_consume,
                            resource=f"FINAL_STAT_r{rank}_q{slot}",
                        ),
                    ]
                )
                if spec.persistent:
                    edges.append(
                        FlashEdge(
                            final_stat_consume,
                            stat,
                            iteration_delta=1,
                        )
                    )
            if slot + 1 == spec.query_slots_per_cta:
                if spec.cooperative_mma and rank != 0:
                    reuse_ranks: tuple[int, ...] | range = ()
                elif spec.multicast_kv:
                    reuse_ranks = range(spec.cta_count)
                else:
                    reuse_ranks = (rank,)
                for reuse_rank in reuse_ranks:
                    edges.extend(
                        [
                            FlashEdge(
                                qk,
                                k_load,
                                iteration_delta=spec.kv_depth,
                                barrier=f"k_reuse_r{reuse_rank}",
                                arrival_count=1,
                                scope=kv_scope,
                            ),
                            FlashEdge(
                                pv,
                                v_load,
                                iteration_delta=spec.kv_depth,
                                barrier=f"v_reuse_r{reuse_rank}",
                                arrival_count=1,
                                scope=kv_scope,
                            ),
                        ]
                    )
            else:
                edges.extend(
                    [
                        FlashEdge(
                            qk,
                            _node_name("qk", rank, slot + 1),
                        ),
                        FlashEdge(
                            pv,
                            _node_name("pv", rank, slot + 1),
                        ),
                    ]
                )
            if spec.private_causal_tail:
                edges.extend(
                    [
                        FlashEdge(
                            f"diagonal_k_load_r{rank}",
                            qk,
                            resource=f"causal_diagonal_K_r{rank}",
                        ),
                        FlashEdge(
                            f"diagonal_v_load_r{rank}",
                            pv,
                            resource=f"causal_diagonal_V_r{rank}",
                        ),
                    ]
                )

            owners.append(FlashOutputOwner(_output_tile(spec, rank, slot), rank, slot))
            regions.append(
                FlashMemoryRegion(
                    f"Q_r{rank}_q{slot}",
                    FlashMemorySpace.SMEM,
                    slot * tile_bytes,
                    tile_bytes,
                    1024,
                    FlashVisibility.CTA_PRIVATE,
                    q_load,
                    (qk,),
                    alias_group=(
                        None
                        if q_alias_group is None
                        else q_alias_group.format(rank=rank)
                    ),
                    cta_rank=rank,
                )
            )
            score_offset = slot * 128
            regions.extend(
                [
                    FlashMemoryRegion(
                        f"S_r{rank}_q{slot}",
                        FlashMemorySpace.TMEM,
                        score_offset,
                        128,
                        1,
                        FlashVisibility.CTA_PRIVATE,
                        qk,
                        (softmax,),
                        alias_group=f"score_p_r{rank}_q{slot}",
                        cta_rank=rank,
                    ),
                    FlashMemoryRegion(
                        f"P_r{rank}_q{slot}",
                        FlashMemorySpace.TMEM,
                        score_offset,
                        128,
                        1,
                        FlashVisibility.CTA_PRIVATE,
                        softmax,
                        (pv,),
                        reuse_distance=1,
                        alias_group=f"score_p_r{rank}_q{slot}",
                        cta_rank=rank,
                    ),
                    FlashMemoryRegion(
                        f"O_r{rank}_q{slot}",
                        FlashMemorySpace.TMEM,
                        256 + slot * _value_head_dim(spec),
                        _value_head_dim(spec),
                        1,
                        FlashVisibility.CTA_PRIVATE,
                        pv,
                        (correction, output_stage),
                        cta_rank=rank,
                    ),
                ]
            )
            regions.append(
                FlashMemoryRegion(
                    f"STAT_r{rank}_q{slot}",
                    FlashMemorySpace.SMEM,
                    overhead_offset + slot * stat_bytes_per_query,
                    stat_bytes_per_query,
                    16,
                    FlashVisibility.CTA_PRIVATE,
                    stat,
                    (correction,),
                    reuse_distance=(
                        1 if spec.final_only_stat_handoff else spec.stat_depth
                    ),
                    reuse_barrier=(
                        None if spec.final_only_stat_handoff else stat_empty
                    ),
                    alias_group=(
                        f"stat_terminal_r{rank}_q{slot}"
                        if spec.final_only_stat_handoff
                        else None
                    ),
                    cta_rank=rank,
                )
            )
            if spec.final_only_stat_handoff:
                regions.append(
                    FlashMemoryRegion(
                        f"FINAL_STAT_r{rank}_q{slot}",
                        FlashMemorySpace.SMEM,
                        overhead_offset + slot * stat_bytes_per_query,
                        stat_bytes_per_query,
                        16,
                        FlashVisibility.CTA_PRIVATE,
                        final_stat_publish,
                        (final_stat_consume,),
                        reuse_distance=1 if spec.persistent else None,
                        alias_group=f"stat_terminal_r{rank}_q{slot}",
                        cta_rank=rank,
                    )
                )
            if spec.stage_output:
                regions.append(
                    FlashMemoryRegion(
                        f"O_stage_r{rank}_q{slot}",
                        FlashMemorySpace.SMEM,
                        output_offset + slot * output_tile_bytes,
                        output_tile_bytes,
                        1024,
                        FlashVisibility.CTA_PRIVATE,
                        output_stage,
                        (output_store,),
                        alias_group=(
                            None
                            if q_alias_group is None
                            else q_alias_group.format(rank=rank)
                        ),
                        cta_rank=rank,
                    )
                )

    if spec.p_chunk_arrive and not spec.split_p_arrive:
        raise FlashScheduleError(
            "the per-chunk probability release needs the split publication"
        )
    for slot in range(spec.query_slots_per_cta):
        for rank in range(spec.cta_count):
            if spec.cooperative_mma:
                pfor = f"pfor_q{slot}"
                pfor2 = f"pfor2_q{slot}"
                pfor_chunks = tuple(f"pforc{index}_q{slot}" for index in range(2))
                pfor_scope = FlashSyncScope.CLUSTER_LEADER
                if rank == 0:
                    barriers.append(
                        FlashBarrier(pfor, 256 * spec.cta_count, pfor_scope)
                    )
                    if spec.split_p_arrive:
                        barriers.append(
                            FlashBarrier(pfor2, 128 * spec.cta_count, pfor_scope)
                        )
                    if spec.p_chunk_arrive:
                        barriers.extend(
                            FlashBarrier(name, 128 * spec.cta_count, pfor_scope)
                            for name in pfor_chunks
                        )
            else:
                rank_suffix = f"_r{rank}" if spec.cta_count > 1 else ""
                pfor = f"pfor{rank_suffix}_q{slot}"
                pfor2 = f"pfor2{rank_suffix}_q{slot}"
                pfor_chunks = tuple(
                    f"pforc{index}{rank_suffix}_q{slot}" for index in range(2)
                )
                pfor_scope = FlashSyncScope.CTA
                barriers.append(FlashBarrier(pfor, 256, pfor_scope))
                if spec.split_p_arrive:
                    barriers.append(FlashBarrier(pfor2, 128, pfor_scope))
                if spec.p_chunk_arrive:
                    barriers.extend(
                        FlashBarrier(name, 128, pfor_scope) for name in pfor_chunks
                    )
            softmax = _node_name("softmax", rank, slot)
            correction = _node_name("correction", rank, slot)
            pv = _node_name("pv", rank, slot)
            edges.extend(
                [
                    FlashEdge(
                        softmax,
                        pv,
                        barrier=pfor,
                        arrival_count=128,
                        scope=pfor_scope,
                        resource=f"P_r{rank}_q{slot}",
                    ),
                    FlashEdge(
                        correction,
                        pv,
                        barrier=pfor,
                        arrival_count=128,
                        scope=pfor_scope,
                    ),
                ]
            )
            if spec.split_p_arrive:
                edges.append(
                    FlashEdge(
                        softmax,
                        pv,
                        barrier=pfor2,
                        arrival_count=128,
                        scope=pfor_scope,
                    )
                )
            if spec.p_chunk_arrive:
                edges.extend(
                    FlashEdge(
                        softmax,
                        pv,
                        barrier=name,
                        arrival_count=128,
                        scope=pfor_scope,
                    )
                    for name in pfor_chunks
                )

    phase_cycles: tuple[FlashPhaseCycle, ...] = ()
    if spec.persistent:
        if spec.kv_iterations is None or spec.kv_iterations <= 0:
            raise FlashScheduleError(
                "persistent schedules require a positive K/V iteration count"
            )
        cycles = []
        for barrier in barriers:
            stat_barrier = barrier.name.startswith(("stat_ready", "stat_empty"))
            uses_per_work = (
                1
                if spec.final_only_stat_handoff
                and barrier.name.startswith("stat_empty")
                else spec.kv_iterations + 1
                if stat_barrier and spec.pipelined_stat_handoff
                else spec.kv_iterations
                if barrier.name.startswith(
                    (
                        "k_ready",
                        "v_ready",
                        "k_reuse",
                        "v_reuse",
                        "s_full",
                        "stat_ready",
                        "stat_empty",
                        "pfor",
                    )
                )
                else 1
            )
            initial_phase = (
                1
                if spec.pipelined_stat_handoff and barrier.name.startswith("stat_empty")
                else 0
            )
            cycles.append(
                FlashPhaseCycle(
                    barrier.name,
                    (
                        initial_phase,
                        initial_phase ^ (uses_per_work & 1),
                        initial_phase,
                    ),
                    uses_per_work,
                )
            )
        phase_cycles = tuple(cycles)
    tmem_columns = 256 + spec.query_slots_per_cta * _value_head_dim(spec)
    return FlashSchedule(
        spec=spec,
        nodes=tuple(nodes),
        edges=tuple(edges),
        barriers=tuple(barriers),
        memory_regions=tuple(regions),
        output_owners=tuple(owners),
        phase_cycles=phase_cycles,
        shared_memory_bytes=_shared_memory_bytes(spec),
        tmem_columns=tmem_columns,
    )


def _reachable(
    edges_by_source: dict[str, list[FlashEdge]],
    source: str,
    target: str,
    iteration_delta: int,
) -> bool:
    pending = [(source, 0)]
    seen: set[tuple[str, int]] = set()
    while pending:
        node, delta = pending.pop()
        state = (node, delta)
        if state in seen or delta > iteration_delta:
            continue
        seen.add(state)
        if node == target and delta == iteration_delta:
            return True
        pending.extend(
            (edge.target, delta + edge.iteration_delta)
            for edge in edges_by_source.get(node, ())
        )
    return False


def _validate_zero_delta_acyclic(
    node_names: set[str], edges: tuple[FlashEdge, ...]
) -> None:
    adjacency: dict[str, list[str]] = defaultdict(list)
    indegree = dict.fromkeys(node_names, 0)
    for edge in edges:
        if edge.iteration_delta == 0:
            adjacency[edge.source].append(edge.target)
            indegree[edge.target] += 1
    pending = [name for name, degree in indegree.items() if degree == 0]
    visited = 0
    while pending:
        source = pending.pop()
        visited += 1
        for target in adjacency.get(source, ()):
            indegree[target] -= 1
            if indegree[target] == 0:
                pending.append(target)
    if visited != len(node_names):
        raise FlashScheduleError("same-iteration schedule contains a cycle")


def verify_flash_schedule(
    schedule: FlashSchedule,
    limits: FlashScheduleLimits | None = None,
) -> VerifiedFlashSchedule:
    if limits is None:
        limits = FlashScheduleLimits()
    if limits.shared_memory_bytes <= 0 or limits.tmem_columns <= 0:
        raise FlashScheduleError("schedule limits must be positive")

    node_by_name = {node.name: node for node in schedule.nodes}
    node_names = set(node_by_name)
    if len(node_names) != len(schedule.nodes):
        raise FlashScheduleError("schedule node names must be unique")
    for node in schedule.nodes:
        if (
            node.cta_rank is not None
            and not 0 <= node.cta_rank < schedule.spec.cta_count
        ):
            raise FlashScheduleError(f"node {node.name} has an invalid CTA rank")
        if node.query_slot is not None:
            if node.cta_rank is None or not (
                0 <= node.query_slot < schedule.spec.query_slots_per_cta
            ):
                raise FlashScheduleError(f"node {node.name} has an invalid query slot")
    for edge in schedule.edges:
        if edge.source not in node_names or edge.target not in node_names:
            raise FlashScheduleError("schedule edge references an unknown node")
        if edge.iteration_delta < 0:
            raise FlashScheduleError("iteration deltas must be nonnegative")
    _validate_zero_delta_acyclic(node_names, schedule.edges)

    barrier_by_name = {barrier.name: barrier for barrier in schedule.barriers}
    if len(barrier_by_name) != len(schedule.barriers):
        raise FlashScheduleError("barrier names must be unique")
    if any(barrier.expected_arrivals <= 0 for barrier in schedule.barriers):
        raise FlashScheduleError("barrier arrivals must be positive")
    arrivals: dict[str, int] = defaultdict(int)
    for edge in schedule.edges:
        if edge.barrier is None:
            if edge.arrival_count != 0:
                raise FlashScheduleError("arrival count requires a barrier")
            continue
        barrier = barrier_by_name.get(edge.barrier)
        if barrier is None:
            raise FlashScheduleError("edge references an unknown barrier")
        if edge.scope is not barrier.scope:
            raise FlashScheduleError(f"barrier scope mismatch for {barrier.name}")
        if edge.arrival_count <= 0:
            raise FlashScheduleError("barrier arrivals must be positive")
        arrivals[barrier.name] += edge.arrival_count
    for barrier in schedule.barriers:
        if arrivals[barrier.name] != barrier.expected_arrivals:
            raise FlashScheduleError(
                f"barrier {barrier.name} expected {barrier.expected_arrivals} "
                f"arrivals, got {arrivals[barrier.name]}"
            )
    if schedule.spec.pipelined_stat_handoff:
        expected_releases = {
            FlashEdge(
                _node_name("correction", rank, source_slot),
                _node_name("stat", rank, target_slot),
                iteration_delta,
                f"stat_empty_r{rank}_q{target_slot}",
                1,
            )
            for rank in range(schedule.spec.cta_count)
            for source_slot in range(schedule.spec.query_slots_per_cta)
            for target_slot, iteration_delta in (
                (_pipelined_stat_release(schedule.spec, source_slot),)
            )
        }
        release_edges = [
            edge
            for edge in schedule.edges
            if edge.barrier is not None and edge.barrier.startswith("stat_empty_")
        ]
        if (
            len(release_edges) != len(expected_releases)
            or set(release_edges) != expected_releases
        ):
            raise FlashScheduleError(
                "pipelined stat releases do not match the selected "
                f"{schedule.spec.stat_release_mapping.value} mapping"
            )
    if schedule.spec.final_only_stat_handoff:
        edge_keys = {
            (edge.source, edge.target, edge.iteration_delta, edge.barrier)
            for edge in schedule.edges
        }
        for rank in range(schedule.spec.cta_count):
            for slot in range(schedule.spec.query_slots_per_cta):
                correction = _node_name("correction", rank, slot)
                stat = _node_name("stat", rank, slot)
                publish = _node_name("final_stat_publish", rank, slot)
                consume = _node_name("final_stat_consume", rank, slot)
                if (
                    (correction, publish, 0, f"stat_empty_r{rank}_q{slot}")
                    not in edge_keys
                    or (publish, consume, 0, None) not in edge_keys
                    or (
                        schedule.spec.persistent
                        and (consume, stat, 1, None) not in edge_keys
                    )
                ):
                    raise FlashScheduleError(
                        "final-only stat handoff is missing terminal ordering"
                    )
    if schedule.spec.multicast_kv:
        for rank in range(schedule.spec.cta_count):
            for operand, consumer_kind in (("k", "qk"), ("v", "pv")):
                barrier_name = f"{operand}_reuse_r{rank}"
                release_edges = [
                    edge for edge in schedule.edges if edge.barrier == barrier_name
                ]
                source_ranks = (
                    (0,)
                    if schedule.spec.cooperative_mma
                    else range(schedule.spec.cta_count)
                )
                expected_sources = {
                    _node_name(
                        consumer_kind,
                        source_rank,
                        schedule.spec.query_slots_per_cta - 1,
                    )
                    for source_rank in source_ranks
                }
                if (
                    len(release_edges) != len(expected_sources)
                    or {edge.source for edge in release_edges} != expected_sources
                    or any(
                        edge.target != f"{operand}_load_multicast"
                        or edge.iteration_delta != schedule.spec.kv_depth
                        or edge.arrival_count != 1
                        or edge.scope is not FlashSyncScope.CLUSTER
                        for edge in release_edges
                    )
                ):
                    raise FlashScheduleError(
                        "multicast K/V reuse has the wrong consumer releases"
                    )

    region_by_name = {region.name: region for region in schedule.memory_regions}
    if len(region_by_name) != len(schedule.memory_regions):
        raise FlashScheduleError("memory-region names must be unique")
    edges_by_source: dict[str, list[FlashEdge]] = defaultdict(list)
    resource_edges: dict[str, set[tuple[str, str]]] = defaultdict(set)
    for edge in schedule.edges:
        edges_by_source[edge.source].append(edge)
        if edge.multicast and edge.resource is None:
            raise FlashScheduleError("multicast edge requires a memory resource")
        if edge.resource is None:
            continue
        region = region_by_name.get(edge.resource)
        if region is None:
            raise FlashScheduleError("edge references an unknown memory region")
        if edge.source != region.writer or edge.target not in region.consumers:
            raise FlashScheduleError(
                f"edge does not match the lifetime of memory region {region.name}"
            )
        resource_edges[region.name].add((edge.source, edge.target))
        if region.visibility is FlashVisibility.CLUSTER_VISIBLE:
            if edge.resource_scope not in (
                FlashSyncScope.CLUSTER,
                FlashSyncScope.CLUSTER_LEADER,
            ):
                raise FlashScheduleError("cluster-visible data uses a CTA-local edge")
            if not edge.multicast:
                raise FlashScheduleError("cluster-visible load is not multicast")
        elif edge.resource_scope is not FlashSyncScope.CTA:
            raise FlashScheduleError("CTA-private data uses a cluster-scoped edge")
        if edge.multicast and region.visibility is FlashVisibility.CTA_PRIVATE:
            raise FlashScheduleError("CTA-private data cannot be multicast")
        if edge.multicast and not schedule.spec.multicast_kv:
            raise FlashScheduleError("multicast edge is disabled by the schedule")
        if region.visibility is FlashVisibility.CTA_PRIVATE:
            source_rank = node_by_name[edge.source].cta_rank
            target_rank = node_by_name[edge.target].cta_rank
            if region.cta_rank is None:
                raise FlashScheduleError(
                    f"CTA-private memory region {region.name} has no owner"
                )
            if any(
                rank is not None and rank != region.cta_rank
                for rank in (source_rank, target_rank)
            ):
                raise FlashScheduleError(
                    f"CTA-private memory region {region.name} crosses CTA ranks"
                )

    for region in schedule.memory_regions:
        if region.offset < 0 or region.extent <= 0:
            raise FlashScheduleError("memory regions require positive bounds")
        if region.alignment <= 0 or region.offset % region.alignment != 0:
            raise FlashScheduleError(f"memory region {region.name} is misaligned")
        if region.writer not in node_names or any(
            consumer not in node_names for consumer in region.consumers
        ):
            raise FlashScheduleError("memory lifetime references an unknown node")
        if not region.consumers:
            raise FlashScheduleError(f"memory region {region.name} has no consumer")
        if region.cta_rank is not None and not (
            0 <= region.cta_rank < schedule.spec.cta_count
        ):
            raise FlashScheduleError(
                f"memory region {region.name} has an invalid CTA rank"
            )
        expected_edges = {(region.writer, consumer) for consumer in region.consumers}
        if not expected_edges.issubset(resource_edges[region.name]):
            raise FlashScheduleError(
                f"memory region {region.name} has an uncovered consumer"
            )
        if region.reuse_distance is not None:
            if region.reuse_distance <= 0:
                raise FlashScheduleError("reuse distance must be positive")
            for consumer in region.consumers:
                if not _reachable(
                    edges_by_source,
                    consumer,
                    region.writer,
                    region.reuse_distance,
                ):
                    raise FlashScheduleError(
                        f"memory region {region.name} is reused before all consumers"
                    )
            if region.reuse_barrier is not None:
                reuse_releases = tuple(
                    (consumer, region.reuse_distance) for consumer in region.consumers
                )
                writer = node_by_name[region.writer]
                if (
                    schedule.spec.pipelined_stat_handoff
                    and writer.kind is FlashNodeKind.STAT_PUBLISH
                ):
                    assert writer.cta_rank is not None
                    assert writer.query_slot is not None
                    source_slot, iteration_delta = _pipelined_stat_releaser(
                        schedule.spec, writer.query_slot
                    )
                    reuse_releases = (
                        (
                            _node_name(
                                "correction",
                                writer.cta_rank,
                                source_slot,
                            ),
                            iteration_delta,
                        ),
                    )
                for release_source, iteration_delta in reuse_releases:
                    if not any(
                        edge.source == release_source
                        and edge.target == region.writer
                        and edge.iteration_delta == iteration_delta
                        and edge.barrier == region.reuse_barrier
                        for edge in schedule.edges
                    ):
                        raise FlashScheduleError(
                            f"memory region {region.name} is reused before all consumers"
                        )
        elif region.reuse_barrier is not None:
            raise FlashScheduleError("reuse barrier requires a reuse distance")

    for rank in range(schedule.spec.cta_count):
        k_region = region_by_name.get(f"K_r{rank}")
        v_region = region_by_name.get(f"V_r{rank}")
        if k_region is None or v_region is None:
            raise FlashScheduleError("K/V ring representation is incomplete")
        if schedule.spec.alternating_warpgroups:
            if (
                not k_region.physical
                or not v_region.physical
                or k_region.offset + k_region.extent > v_region.offset
                or barrier_by_name.get(f"k_reuse_r{rank}") is None
                or barrier_by_name.get(f"v_reuse_r{rank}") is None
            ):
                raise FlashScheduleError(
                    "alternating K/V rings must be distinct physical rings with "
                    "reuse barriers"
                )

            # A slot one softmax warpgroup hands to the other over a named
            # barrier (bar.arrive by the writer, bar.sync by the reader) is only
            # safe when the writer cannot arrive twice before one sync. The
            # graph's node granularity cannot show that order (the reader's
            # other publications in the same step reach the writer earlier
            # than its read does), so the slot needs an explicit consumption
            # guard: a barrier edge from the reader back to the writer one
            # iteration later, with every reader thread arriving.
            def require_consumption_guard(region: FlashMemoryRegion) -> None:
                for consumer in region.consumers:
                    guard_barriers: list[FlashBarrier] = []
                    for edge in schedule.edges:
                        barrier_name = edge.barrier
                        if (
                            barrier_name is None
                            or edge.source != consumer
                            or edge.target != region.writer
                            or edge.iteration_delta < 1
                        ):
                            continue
                        guard_barrier = barrier_by_name.get(barrier_name)
                        if guard_barrier is not None:
                            guard_barriers.append(guard_barrier)
                    if not guard_barriers or any(
                        barrier.expected_arrivals != 128 for barrier in guard_barriers
                    ):
                        raise FlashScheduleError(
                            f"handoff slot {region.name} needs a consumption guard: "
                            f"a barrier edge from {consumer} back to {region.writer} "
                            "one iteration later with 128 arrivals"
                        )

            for region in schedule.memory_regions:
                if (
                    region.space is not FlashMemorySpace.SMEM
                    or not region.writer.startswith("softmax_")
                    or not all(c.startswith("softmax_") for c in region.consumers)
                ):
                    continue
                require_consumption_guard(region)
            # The odd warpgroup's alpha slot doubles as its row-sum slot at the
            # end of every item. Inside an item each alpha write follows the
            # correction warps' read of the previous one through the PV chain;
            # the next item's first alpha has no such order against the
            # row-sum read, so this slot needs the same guard from the
            # correction warps back to its writer.
            for region in schedule.memory_regions:
                if region.name == "STAT_b":
                    require_consumption_guard(region)
        elif schedule.spec.separate_kv:
            if (
                not k_region.physical
                or not v_region.physical
                or k_region.reuse_distance != schedule.spec.kv_depth
                or v_region.reuse_distance != schedule.spec.kv_depth
            ):
                raise FlashScheduleError(
                    "separate K/V rings must retain independent depth"
                )
        elif (
            not k_region.physical
            or v_region.physical
            or k_region.offset != v_region.offset
            or k_region.extent != v_region.extent
            or k_region.alias_group is None
            or k_region.alias_group != v_region.alias_group
            or k_region.reuse_distance is not None
            or v_region.reuse_distance is not None
        ):
            raise FlashScheduleError(
                "aliased K/V must use one physical shared ring without "
                "independent reuse claims"
            )

    for index, lhs in enumerate(schedule.memory_regions):
        for rhs in schedule.memory_regions[index + 1 :]:
            if (
                not lhs.physical
                or not rhs.physical
                or lhs.space is not rhs.space
                or lhs.cta_rank != rhs.cta_rank
            ):
                continue
            overlaps = lhs.offset < rhs.offset + rhs.extent and rhs.offset < (
                lhs.offset + lhs.extent
            )
            if not overlaps:
                continue
            if lhs.alias_group is None or lhs.alias_group != rhs.alias_group:
                raise FlashScheduleError(
                    f"memory regions {lhs.name} and {rhs.name} overlap illegally"
                )
            lhs_before_rhs = all(
                _reachable(edges_by_source, consumer, rhs.writer, 0)
                for consumer in lhs.consumers
            )
            rhs_before_lhs = all(
                _reachable(edges_by_source, consumer, lhs.writer, 0)
                for consumer in rhs.consumers
            )
            if not lhs_before_rhs and not rhs_before_lhs:
                raise FlashScheduleError(
                    f"aliased regions {lhs.name} and {rhs.name} have live overlap"
                )

    output_count = schedule.spec.cta_count * schedule.spec.query_slots_per_cta
    output_tiles = [owner.output_tile for owner in schedule.output_owners]
    if len(output_tiles) != len(set(output_tiles)):
        raise FlashScheduleError("an output tile has multiple owners")
    if set(output_tiles) != set(range(output_count)):
        raise FlashScheduleError("output ownership is incomplete")
    for owner in schedule.output_owners:
        if not 0 <= owner.cta_rank < schedule.spec.cta_count:
            raise FlashScheduleError("output owner has an invalid CTA rank")
        if not 0 <= owner.query_slot < schedule.spec.query_slots_per_cta:
            raise FlashScheduleError("output owner has an invalid query slot")
        expected_tile = _output_tile(
            schedule.spec,
            owner.cta_rank,
            owner.query_slot,
        )
        if owner.output_tile != expected_tile:
            raise FlashScheduleError("output owner has an invalid tile mapping")
        output_store = _node_name("output_store", owner.cta_rank, owner.query_slot)
        if output_store not in node_names:
            raise FlashScheduleError("output owner has no output-store node")

    if schedule.spec.private_causal_tail:
        for rank in range(schedule.spec.cta_count):
            for kind, consumer_kind in (("K", "qk"), ("V", "pv")):
                name = f"causal_diagonal_{kind}_r{rank}"
                region = region_by_name.get(name)
                if (
                    region is None
                    or region.visibility is not FlashVisibility.CTA_PRIVATE
                    or region.cta_rank != rank
                    or region.physical
                ):
                    raise FlashScheduleError(
                        "causal multicast requires a private diagonal path"
                    )
                for slot in range(schedule.spec.query_slots_per_cta):
                    consumer = _node_name(consumer_kind, rank, slot)
                    if (region.writer, consumer) not in resource_edges[name]:
                        raise FlashScheduleError(
                            "causal multicast diagonal dependency is incomplete"
                        )

    expected_shared_memory = _shared_memory_bytes(schedule.spec)
    if schedule.shared_memory_bytes != expected_shared_memory:
        raise FlashScheduleError("shared-memory accounting does not match the schedule")
    expected_tmem_columns = (
        _alt_tmem_columns(schedule.spec)
        if schedule.spec.alternating_warpgroups
        else 256 + schedule.spec.query_slots_per_cta * _value_head_dim(schedule.spec)
    )
    if schedule.tmem_columns != expected_tmem_columns:
        raise FlashScheduleError("TMEM accounting does not match the schedule")
    if schedule.shared_memory_bytes > limits.shared_memory_bytes:
        raise FlashScheduleError("schedule exceeds shared-memory capacity")
    if schedule.tmem_columns > limits.tmem_columns:
        raise FlashScheduleError("schedule exceeds TMEM column capacity")
    for region in schedule.memory_regions:
        if not region.physical:
            continue
        capacity = (
            schedule.shared_memory_bytes
            if region.space is FlashMemorySpace.SMEM
            else schedule.tmem_columns
        )
        if region.offset + region.extent > capacity:
            raise FlashScheduleError(f"memory region {region.name} exceeds capacity")

    phase_by_barrier = {cycle.barrier: cycle for cycle in schedule.phase_cycles}
    if len(phase_by_barrier) != len(schedule.phase_cycles):
        raise FlashScheduleError("barrier phase cycles must be unique")
    if schedule.spec.persistent:
        if set(phase_by_barrier) != set(barrier_by_name):
            raise FlashScheduleError("persistent barrier phase coverage is incomplete")
        for cycle in schedule.phase_cycles:
            if cycle.uses_per_work <= 0:
                raise FlashScheduleError("barrier use count must be positive")
            if len(cycle.phases) < 2:
                raise FlashScheduleError("barrier phase cycle has the wrong length")
            if any(phase not in (0, 1) for phase in cycle.phases):
                raise FlashScheduleError("barrier phases must be binary")
            for current, following in zip(
                cycle.phases[:-1],
                cycle.phases[1:],
                strict=True,
            ):
                if following != (current ^ (cycle.uses_per_work & 1)):
                    raise FlashScheduleError(
                        "persistent barrier phase is discontinuous across work items"
                    )
    elif schedule.phase_cycles:
        raise FlashScheduleError("nonpersistent schedule has barrier phase cycles")

    return VerifiedFlashSchedule(schedule)
