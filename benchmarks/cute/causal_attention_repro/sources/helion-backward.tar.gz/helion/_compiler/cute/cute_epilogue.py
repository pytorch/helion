"""Whitelisted chain detector for tcgen05 fused epilogues.

A user-level epilogue lambda over a tcgen05 matmul result, e.g.

    out[tile_m, tile_n] = relu(acc).to(x.dtype)
    out[tile_m, tile_n] = (acc + residual[tile_m, tile_n]).to(x.dtype)

is structurally an *identity-style* store the role-local tcgen05 epilogue
*could* emit if we splice the chain inline at the per-thread T2R
register. The reachability check
(``reach_tcgen05_matmul_anchors`` in :mod:`cute_fx_walk`) only proves
*reachability* — that the value depends on a tcgen05-registered matmul
fx_node — and is the loud-failure backstop. This module owns the
*narrower* whitelist-based classifier that produces a renderable inline
expression for two cases:

- Unary chains: ``matmul -> [whitelisted unary op]* ->
  [convert_element_type] -> store``, where the terminal cast is omitted for
  same-dtype stores and every op in the chain has
  exactly one tensor input (the prior tensor result) and zero or more
  compile-time scalar arguments.
- Auxiliary-tensor binary ops: same shape as above, but one or more
  steps are ``add/sub/mul/div`` with the chain carrier as one
  operand and an elementwise expression rooted in one or more
  ``helion.language.load(aux_tensor, [...])`` calls as the other.
  Auxiliary expressions may use the same whitelisted unary and
  scalar-binary operations as the carrier chain without flattening
  their floating-point association. Explicit FP16/BF16/FP32 conversions are
  explicit steps in auxiliary expressions and on the accumulator carrier;
  each converts through the requested type and back to FP32 so every
  rounding boundary is preserved.
  Two aux load shapes are accepted: the
  exact-shape rank-2 form (``residual[tile_m, tile_n]``) and the
  rank-1 trailing-axis (rowvec) broadcast form (``bias[tile_n]``).
  See :class:`_AuxiliaryTensorLoadExpr` for the canonical contract.
- Tile-uniform scalars: a host scalar lifted into the kernel
  (``alpha * acc`` with a captured Python float) or a rank-0 aux load
  (``acc * scale[()]``) is a :class:`_RuntimeScalarExpr` leaf rendered
  inline as one ``cutlass.Float32`` value.
  Forms outside these two — 3-D underlying tensors with a static
  collapse, mismatched indices, leading-axis rank-1
  (``bias[tile_m]``), kwargs — are rejected to the loud-failure
  backstop.

Any op outside the whitelist (reductions, shape changes,
auxiliary-tensor loads with unsupported indexing, etc.) bails to
``None`` so the loud-failure diagnostic keeps firing for those shapes.

The classifier is intentionally side-effect-free; the splice site in
``_codegen_cute_store_tcgen05_tile`` is responsible for substituting the
rendered expression in place of the existing
``tRS_rAcc.load().to(target_dtype)`` line. Auxiliary-tensor steps carry
the FX node of their ``load`` call so the splice site can recover the
auxiliary tensor + index expressions and emit the per-thread GMEM read
inline.
"""

from __future__ import annotations

import dataclasses
import math
import operator
from typing import TYPE_CHECKING

import sympy
import torch

from ...language import _tracing_ops
from ...language._gelu_tanh_approx import _gelu_erf
from ...language._gelu_tanh_approx import _gelu_tanh_approx
from ...language._gelu_tanh_approx import epilogue_unary_step_template
from ...language._gelu_tanh_approx import gelu_erf_epilogue_unary_step_template
from ...language._tracing_ops import _get_symnode
from .cute_fx_walk import aux_tensor_load_kind
from .cute_fx_walk import build_inner_outputs_index
from .cute_fx_walk import build_inner_outputs_index_from_graphs
from .cute_fx_walk import walk_carrier_to_tcgen05_matmul
from .math_templates import SIGMOID_TEMPLATE

if TYPE_CHECKING:
    from collections.abc import Iterable

    from ..device_ir import GraphInfo
    from ..inductor_lowering import CodegenState


# Whitelist semantics: every accepted op must (a) have exactly one tensor
# input (the chain's carrier), (b) read no global memory, (c) produce a
# tensor of the same shape and same dtype as the input. This rules out
# broadcast, reductions, and ops that read auxiliary tensors.
# Compile-time scalar arguments (e.g., ``aten.add.Tensor(x, 1.0)``) are
# folded into the rendered Python expression as numeric literals.


@dataclasses.dataclass(frozen=True)
class _UnaryOp:
    """A single accepted op rendered as ``template.format(inner=...)``.

    ``op_name`` is the human-readable op name used in ``__repr__`` for
    test diagnostics (e.g. ``"relu"``). ``template`` contains one or
    more ``{inner}`` placeholders and is the Python source the splice
    substitutes for the prior carrier local. The renderer keeps carriers
    bound at every step, so multi-reference templates can reuse the existing
    local directly without a second alias.
    """

    op_name: str
    template: str


_FLOAT_CAST_TYPES = {
    torch.float16: "cutlass.Float16",
    torch.bfloat16: "cutlass.BFloat16",
    torch.float32: "cutlass.Float32",
}


def _round_epilogue_expression(template: str, dtype: torch.dtype | None) -> str:
    """Keep each low-precision FX result's rounding before later FP32 math."""
    if dtype not in (torch.float16, torch.bfloat16):
        return template
    assert dtype is not None
    return f"({template}).to({_FLOAT_CAST_TYPES[dtype]}).to(cutlass.Float32)"


def _round_unary_step(step: _UnaryOp, node: torch.fx.Node) -> _UnaryOp:
    return dataclasses.replace(
        step,
        template=_round_epilogue_expression(step.template, _node_tensor_dtype(node)),
    )


def _floating_cast_step(
    node: torch.fx.Node,
) -> tuple[_UnaryOp, torch.fx.Node] | None:
    """Return the explicit FP16/BF16/FP32 conversion step and its operand."""
    cast_operand = _auxiliary_cast_operand(node)
    if cast_operand is None:
        return None
    operand, _source_dtype, dtype = cast_operand
    # Tensor-core epilogues compute in FP32. A conversion through the requested
    # type retains the explicit rounding without changing subsequent math's
    # compute type. The final store still performs its own target conversion.
    template = (
        "{inner}.to(cutlass.Float32)"
        if dtype is torch.float32
        else _round_epilogue_expression("{inner}", dtype)
    )
    return _UnaryOp(op_name=f"to_{dtype}", template=template), operand


@dataclasses.dataclass(frozen=True)
class Tcgen05GroupedTailEpilogueMatch:
    """Exact grouped preserve-output M/N tail source match."""

    anchor: torch.fx.Node
    store_node: torch.fx.Node
    producer_nodes: tuple[torch.fx.Node, ...]
    n_sizes_tensor: torch.Tensor | None
    safe_group_node: torch.fx.Node
    has_m_tail_mask: bool
    has_n_tail_mask: bool
    store_mask: torch.fx.Node | None = None


@dataclasses.dataclass(frozen=True)
class _RuntimeScalarExpr:
    """A tile-uniform scalar, never a per-lane coordinate.

    ``source`` is the sympy expression of a host scalar lifted into the
    kernel (``alpha * acc`` with a float kernel argument) or the rank-0
    ``helion.language.load`` node of a device scalar (``acc * scale[()]``).
    Either renders inline as one ``cutlass.Float32`` value shared by the
    whole output tile; the splice site never binds or partitions it.
    """

    source: sympy.Expr | torch.fx.Node

    @property
    def is_host_scalar(self) -> bool:
        return isinstance(self.source, sympy.Expr)


@dataclasses.dataclass(frozen=True)
class _CurrentTensorExpr:
    """The current accumulator-derived value at one chain step."""


@dataclasses.dataclass(frozen=True, eq=False)
class _AuxiliaryTensorLoadExpr:
    """One identity-keyed aux-load leaf, including scalar/cast wrappers."""

    load_node: torch.fx.Node
    broadcast_axis: int | None
    template: str


@dataclasses.dataclass(frozen=True)
class _UnaryTensorExpr:
    """A whitelisted elementwise unary operation over an auxiliary expression."""

    step: _UnaryOp
    operand: _TensorExpr


@dataclasses.dataclass(frozen=True)
class _BinaryTensorExpr:
    """A binary operation preserving the auxiliary FX tree's association."""

    op_name: str
    op_template: str
    lhs: _TensorExpr
    rhs: _TensorExpr


_TensorExpr = (
    _CurrentTensorExpr
    | _AuxiliaryTensorLoadExpr
    | _UnaryTensorExpr
    | _BinaryTensorExpr
    | _RuntimeScalarExpr
)


def aux_leaf_promoted_by_f32_root(
    chain: Tcgen05UnaryEpilogueChain, leaf: _AuxiliaryTensorLoadExpr
) -> bool:
    """Whether ``leaf`` is consumed only by the FP32 root ``acc <op> aux`` step.

    True when the chain is that single step, the leaf carries no cast wrapper
    and the step's result dtype is FP32 (``_round_epilogue_expression`` left
    the template unrounded), i.e. the DSL promotes the loaded operand to FP32
    before the op. A 16-bit leaf may then be staged already converted: the
    fp16/bf16 -> fp32 conversion is exact, so the result is bit-identical.
    """
    if leaf.template != "{aux}" or len(chain.steps) != 1:
        return False
    root = chain.steps[0].expr
    if not isinstance(root, _BinaryTensorExpr) or ".to(" in root.op_template:
        return False
    return (isinstance(root.lhs, _CurrentTensorExpr) and root.rhs is leaf) or (
        isinstance(root.rhs, _CurrentTensorExpr) and root.lhs is leaf
    )


def tcgen05_rowvec_stage_copy_shape(
    *, epi_warp_count: int, bn: int, aux_extent: int | None
) -> tuple[int, int] | None:
    """``(threads, elems)`` of the one cooperative copy filling a promoted
    FP32 row stage of width ``bn``.

    Rows at least as wide as the epilogue warps' thread count spread one or
    more elements per thread; narrower rows (bn=64 or 32) use whole warps of
    one element each, so every ``bn`` that is a multiple of 32 gets the stage
    instead of the per-subtile GMEM path. ``None`` when the row's static
    extent is unknown or does not split into whole copies.
    """
    max_threads = epi_warp_count * 32
    if aux_extent is None or max_threads <= 0 or bn % 32 != 0:
        return None
    copy_elems = max(1, bn // max_threads)
    if bn % copy_elems != 0 or aux_extent % copy_elems != 0:
        return None
    threads = bn // copy_elems
    if threads % 32 != 0 or threads > max_threads:
        return None
    return threads, copy_elems


def aux_leaf_takes_promoted_f32_stage(
    chain: Tcgen05UnaryEpilogueChain,
    leaf: _AuxiliaryTensorLoadExpr,
    *,
    aux_dtype_bits: int,
    epi_warp_count: int,
    bn: int,
    aux_extent: int | None,
) -> bool:
    """Whether the store lowering stages ``leaf`` as a promoted FP32 row.

    One predicate for the matmul plan (which picks the (128, 32) subtile for
    such epilogues) and the store lowering (which allocates the stage): a
    16-bit N-broadcast row consumed only by the FP32 root op
    (:func:`aux_leaf_promoted_by_f32_root`) whose width splits into whole
    cooperative copies (:func:`tcgen05_rowvec_stage_copy_shape`). The
    store-site conditions both sides also require -- ``pre_acc_wait``, a
    full-tile TMA-store epilogue into a row-major output, an epilogue subtile
    at least 128 rows tall and no whole-fragment register hoist -- are
    checked by the callers.
    """
    return (
        aux_dtype_bits == 16
        and leaf.broadcast_axis == 1
        and aux_leaf_promoted_by_f32_root(chain, leaf)
        and tcgen05_rowvec_stage_copy_shape(
            epi_warp_count=epi_warp_count, bn=bn, aux_extent=aux_extent
        )
        is not None
    )


@dataclasses.dataclass(frozen=True)
class _AuxiliaryTensorExprStep:
    """One expression over the current carrier, scalars, and auxiliary loads."""

    expr: _TensorExpr

    @property
    def operands(self) -> tuple[_AuxiliaryTensorLoadExpr, ...]:
        return _auxiliary_tensor_expr_operands(self.expr)

    @property
    def hoistable_aux_expr(self) -> _TensorExpr | None:
        """Return a nontrivial aux-only side of the root carrier binary op."""
        if not isinstance(self.expr, _BinaryTensorExpr):
            return None
        if isinstance(self.expr.lhs, _CurrentTensorExpr) and not isinstance(
            self.expr.rhs, _AuxiliaryTensorLoadExpr
        ):
            return self.expr.rhs
        if isinstance(self.expr.rhs, _CurrentTensorExpr) and not isinstance(
            self.expr.lhs, _AuxiliaryTensorLoadExpr
        ):
            return self.expr.lhs
        return None

    def render_hoistable_aux_prelude_and_expr(
        self,
        aux_locals_by_expr: dict[_AuxiliaryTensorLoadExpr, str],
        local_name_factory: object,
        prelude_indent: str,
    ) -> tuple[str, str]:
        aux_expr = self.hoistable_aux_expr
        assert aux_expr is not None
        assert len(aux_locals_by_expr) == len(self.operands)
        assert all(operand in aux_locals_by_expr for operand in self.operands)
        return _render_auxiliary_tensor_expr(
            aux_expr,
            "",
            aux_locals_by_expr,
            local_name_factory,
            prelude_indent,
        )

    def render_with_hoisted_aux(self, carrier_name: str, aux_name: str) -> str:
        assert isinstance(self.expr, _BinaryTensorExpr)
        if isinstance(self.expr.lhs, _CurrentTensorExpr):
            lhs, rhs = carrier_name, aux_name
        else:
            assert isinstance(self.expr.rhs, _CurrentTensorExpr)
            lhs, rhs = aux_name, carrier_name
        return self.expr.op_template.format(lhs=lhs, rhs=rhs)

    def render_prelude_and_expr(
        self,
        carrier_name: str,
        aux_locals_by_expr: dict[_AuxiliaryTensorLoadExpr, str],
        local_name_factory: object,
        prelude_indent: str,
    ) -> tuple[str, str]:
        """Render this step with an explicit local binding for each load leaf."""
        assert all(operand in aux_locals_by_expr for operand in self.operands)
        return _render_auxiliary_tensor_expr(
            self.expr,
            carrier_name,
            aux_locals_by_expr,
            local_name_factory,
            prelude_indent,
        )


# The cute DSL surface for whitelisted unary operations. Renderings are
# inline Python expressions on a TensorSSA value. All renderings
# preserve dtype (we only operate on float accumulators here), so the
# trailing ``.to(target_dtype)`` downcast in the existing splice site
# stays correct.

# `relu` must propagate NaN (`torch.relu(NaN) = NaN`) and zero out
# negative inputs including `-inf` (`torch.relu(-inf) = 0`). Naive
# `where(x > 0, x, 0)` returns 0 for NaN (`NaN > 0` is False), so we
# guard with `x != x` (the canonical NaN-detection idiom on TensorSSA;
# `cute` does not expose a generic `isnan` for it) and feed NaN through
# unchanged. The `(x + abs(x)) * 0.5` shortcut would be one expression
# but produces NaN for `-inf` (`-inf + inf = NaN`), which mismatches
# `torch.relu(-inf) = 0`; the explicit double-where is the only inline
# rendering that matches torch on the full IEEE float input range.
_RELU_TEMPLATE = (
    "cute.where(({inner}) != ({inner}), ({inner}),"
    " cute.where(({inner}) > 0.0, ({inner}), 0.0))"
)
_ABS_TEMPLATE = "cute.math.absf({inner})"
_NEG_TEMPLATE = "(-({inner}))"
_TANH_TEMPLATE = "cute.math.tanh({inner})"
_EXP_TEMPLATE = "cute.math.exp({inner})"
_LOG_TEMPLATE = "cute.math.log({inner})"
_SQRT_TEMPLATE = "cute.math.sqrt({inner})"
_ERF_TEMPLATE = "cute.math.erf({inner})"
# Use the same FP32 expression as the default pointwise sigmoid lowering.
# The chain renderer retains each result's dtype rounding separately.
_SIGMOID_TEMPLATE = SIGMOID_TEMPLATE.format(x="{inner}")

# SiLU also accepts an explicit division-based decomposition. Keep its
# existing arithmetic form separate from the standalone sigmoid contract.
_LOG2_E = 1.4426950408889634
# ``silu(x) = x * sigmoid(x)``. The chain renderer always binds
# ``{inner}`` to a fresh local before formatting, so the two
# references to ``{inner}`` here resolve to a single SSA name (no
# source-size blowup).
_SILU_TEMPLATE = (
    f"(({{inner}}) * (1.0 / (1.0 + cute.math.exp2(-({{inner}}) * {_LOG2_E!r}))))"
)


def _add_const_template(scalar: float) -> str:
    return f"(({{inner}}) + {scalar!r})"


def _sub_const_template(scalar: float) -> str:
    return f"(({{inner}}) - {scalar!r})"


def _rsub_const_template(scalar: float) -> str:
    # `scalar - x`. aten.sub.Tensor with a tensor as second arg can
    # appear via `c - acc`; the lambda walks the FX user side and only
    # accepts the form where the carrier is one of the two args.
    return f"({scalar!r} - ({{inner}}))"


def _mul_const_template(scalar: float) -> str:
    return f"(({{inner}}) * {scalar!r})"


def _div_const_template(scalar: float) -> str:
    return f"(({{inner}}) / {scalar!r})"


def _rdiv_const_template(scalar: float) -> str:
    return f"({scalar!r} / ({{inner}}))"


def _scalar_binary_template(
    target: object,
    scalar: float,
    *,
    forward_form: bool,
) -> str | None:
    if target is torch.ops.aten.add.Tensor:
        return _add_const_template(scalar)
    if target is torch.ops.aten.mul.Tensor:
        return _mul_const_template(scalar)
    if target is torch.ops.aten.sub.Tensor:
        return (
            _sub_const_template(scalar)
            if forward_form
            else _rsub_const_template(scalar)
        )
    if target is torch.ops.aten.div.Tensor:
        return (
            _div_const_template(scalar)
            if forward_form
            else _rdiv_const_template(scalar)
        )
    return None


# Mapping of accepted aten/prims targets to ``_UnaryOp`` rows. The
# classifier looks the row up at match time and emits it directly;
# binary scalar ops are handled separately below since their template
# depends on the extracted constant.
#
# ``_gelu_tanh_approx`` is keyed on the helion-API wrapper itself
# (the FX target the ``aten.gelu.default`` decomp materializes for
# the ``approximate="tanh"`` overload), not an aten op. The wrapper
# is the same object every FX traced kernel sees, so identity-keying
# off it is stable across kernels. The template renders the standard
# tanh-approximation GELU polynomial inline (``0.5 * x * (1 +
# cute.math.tanh(kappa * (x + 0.044715 * (x * x * x))))``); see
# ``helion/language/_gelu_tanh_approx.py`` for constants and
# motivation. The renderer always passes a bound local for ``{inner}``,
# so the five occurrences of ``x`` do not duplicate a complex expression.
_ZERO_ARG_TARGETS: dict[object, _UnaryOp] = {
    torch.ops.aten.relu.default: _UnaryOp(
        op_name="relu",
        template=_RELU_TEMPLATE,
    ),
    torch.ops.aten.abs.default: _UnaryOp(op_name="abs", template=_ABS_TEMPLATE),
    torch.ops.aten.neg.default: _UnaryOp(op_name="neg", template=_NEG_TEMPLATE),
    torch.ops.aten.tanh.default: _UnaryOp(op_name="tanh", template=_TANH_TEMPLATE),
    torch.ops.aten.exp.default: _UnaryOp(op_name="exp", template=_EXP_TEMPLATE),
    torch.ops.aten.log.default: _UnaryOp(op_name="log", template=_LOG_TEMPLATE),
    torch.ops.aten.sqrt.default: _UnaryOp(op_name="sqrt", template=_SQRT_TEMPLATE),
    torch.ops.aten.erf.default: _UnaryOp(op_name="erf", template=_ERF_TEMPLATE),
    # ``aten.sigmoid.default`` is accepted as a standalone unary step so
    # ``out[tile] = sigmoid(acc).to(...)`` fuses end-to-end. Its FP32
    # expression matches the default pointwise sigmoid lowering;
    # low-precision results retain their separate rounding step.
    torch.ops.aten.sigmoid.default: _UnaryOp(
        op_name="sigmoid",
        template=_SIGMOID_TEMPLATE,
    ),
    _gelu_erf: _UnaryOp(
        op_name="gelu_erf",
        template=gelu_erf_epilogue_unary_step_template(),
    ),
    # ``F.gelu(x, approximate="tanh")`` (mapped to ``_gelu_tanh_approx``
    # by the device_ir decomp) — single FX node folding the polynomial
    # which references ``x`` 4 times. The chain renderer already has a
    # bound carrier local, so the polynomial can reuse that local directly.
    _gelu_tanh_approx: _UnaryOp(
        op_name="gelu_tanh_approx",
        template=epilogue_unary_step_template(),
    ),
    # Conversions require their dtype argument and are handled separately by
    # _floating_cast_step so intermediate rounding is retained explicitly.
}


# Binary ops that the chain analyzer accepts. Both scalar (the
# other operand is a compile-time literal int/float) and
# auxiliary-tensor (the other operand is a
# ``helion.language.load`` of a 2-D auxiliary GMEM tensor matching
# the output tile shape) forms are routed through ``_classify_binary``
# below. Both arg positions are checked so ``acc <op> other`` and
# ``other <op> acc`` both fuse; for non-commutative ops
# (``sub``, ``div``) the renderer picks the correct direction. These
# targets are also rejected if any unexpected ``kwargs`` are present
# (e.g. ``aten.add.Tensor`` accepts ``alpha=k`` which would silently
# change the rendered expression — see the kwarg-rejection branch in
# ``_classify_binary``).
_SCALAR_BINARY_TARGETS: frozenset[object] = frozenset(
    {
        torch.ops.aten.add.Tensor,
        torch.ops.aten.mul.Tensor,
        torch.ops.aten.sub.Tensor,
        torch.ops.aten.div.Tensor,
    }
)


_AUX_EXPR_BINARY_TEMPLATES: dict[object, str] = {
    torch.ops.aten.add.Tensor: "{lhs} + {rhs}",
    torch.ops.aten.mul.Tensor: "{lhs} * {rhs}",
    torch.ops.aten.sub.Tensor: "{lhs} - {rhs}",
    torch.ops.aten.div.Tensor: "{lhs} / {rhs}",
}

_BINARY_OP_NAMES: dict[object, str] = {
    torch.ops.aten.add.Tensor: "add",
    torch.ops.aten.mul.Tensor: "mul",
    torch.ops.aten.sub.Tensor: "sub",
    torch.ops.aten.div.Tensor: "div",
}


def _extract_scalar(arg: object) -> float | None:
    """Return ``float(arg)`` if ``arg`` is a finite Python int/float;
    else ``None``. Booleans intentionally return ``None`` (the scalar
    binary whitelist does not accept boolean arithmetic, which has
    different semantics than the float arithmetic the templates
    render). Non-finite floats (``inf``, ``-inf``, ``nan``) are also
    rejected because they ``repr`` to bare identifiers (``inf``,
    ``nan``) that are not valid Python expressions in the rendered
    cute DSL source — a whitelisted ``acc + float("inf")`` would
    splice into invalid code. Users wanting non-finite arithmetic
    can pass it through an aux-tensor lambda where the value is
    materialized as a tensor element.

    Lifted ``SymFloat`` / ``SymInt`` kernel arguments and rank-0 aux
    loads (``scale[()]``) are not literals: they are classified as
    :class:`_RuntimeScalarExpr` leaves and rendered inline.
    Helion's host-tensor guard (:class:`exc.HostTensorDirectUsage`)
    still rejects ``acc + scalar_t`` against a bare 0-d host tensor
    upstream of this analyzer.
    """
    if isinstance(arg, bool):
        return None  # Boolean scalars are not whitelisted.
    if isinstance(arg, (int, float)):
        val = float(arg)
        if not math.isfinite(val):
            # ``repr(float("inf")) == "inf"`` is a bare identifier
            # in Python; rendering it as a literal in the splice
            # site emits invalid source. Bail to the loud-failure
            # backstop so the user sees a structured error.
            return None
        return val
    return None


def _is_helion_load_node(node: torch.fx.Node) -> bool:
    from ...language.memory_ops import load as helion_load

    return node.op == "call_function" and node.target is helion_load


def _unmasked_helion_load_args(
    node: torch.fx.Node,
) -> tuple[object, object] | None:
    if not _is_helion_load_node(node) or node.kwargs or len(node.args) < 2:
        return None
    if len(node.args) >= 3 and node.args[2] is not None:
        return None
    if len(node.args) >= 4 and node.args[3] is not None:
        return None
    return node.args[0], node.args[1]


def _auxiliary_cast_operand(
    node: torch.fx.Node,
) -> tuple[torch.fx.Node, torch.dtype, torch.dtype] | None:
    """Validate a shape-preserving numeric cast using the traced tensor metadata.

    Auxiliary conversions are separate from the accumulator-chain whitelist.
    Integer, boolean, float8/float64, bitcasts and device/layout conversions
    remain outside this narrow floating-point expression contract.
    """
    if (
        node.op != "call_function"
        or node.target is not torch.ops.prims.convert_element_type.default
        or node.kwargs
        or len(node.args) != 2
    ):
        return None
    operand, target_dtype = node.args
    if not isinstance(operand, torch.fx.Node) or not isinstance(
        target_dtype, torch.dtype
    ):
        return None
    source = operand.meta.get("val")
    result = node.meta.get("val")
    if (
        not isinstance(source, torch.Tensor)
        or not isinstance(result, torch.Tensor)
        or source.dtype not in _FLOAT_CAST_TYPES
        or target_dtype not in _FLOAT_CAST_TYPES
        or result.dtype != target_dtype
        or tuple(source.shape) != tuple(result.shape)
    ):
        return None
    return operand, source.dtype, target_dtype


def _canonical_aux_load_operand(node: torch.fx.Node) -> tuple[torch.fx.Node, str]:
    """Return the underlying aux load plus its local-value template.

    Preserve the existing raw-load/fp32-load source and hoisting fast paths.
    Other supported conversions are explicit nodes in the auxiliary tree.
    """
    if _is_helion_load_node(node):
        return node, "{aux}"
    if (
        node.op == "call_function"
        and node.target is torch.ops.prims.convert_element_type.default
        and not node.kwargs
        and len(node.args) == 2
        and node.args[1] is torch.float32
        and isinstance(node.args[0], torch.fx.Node)
        and _auxiliary_cast_operand(node) is not None
    ):
        inner = node.args[0]
        if _is_helion_load_node(inner):
            return inner, "({aux}).to(cutlass.Float32)"
    return node, "{aux}"


def _aux_load_operand(node: torch.fx.Node) -> tuple[torch.fx.Node, str]:
    """Return ``(load_node, aux_template)`` for accepted aux operands.

    ``aux_template`` is a ``{aux}``-keyed expression applied to the loaded
    per-thread aux local before the outer binary op. This covers wrapped
    residual terms such as ``0.5 * residual[tile_m, tile_n].to(torch.float32)``
    without broadening the general chain model to arbitrary non-scalar binary
    reuse.
    """
    load_node, aux_template = _canonical_aux_load_operand(node)
    if load_node is not node:
        return load_node, aux_template
    if node.op != "call_function" or node.target is not torch.ops.aten.mul.Tensor:
        return node, "{aux}"
    if node.kwargs or len(node.args) < 2:
        return node, "{aux}"
    lhs = node.args[0]
    rhs = node.args[1]
    if isinstance(lhs, torch.fx.Node):
        scalar = _extract_scalar(rhs)
        inner = lhs
    elif isinstance(rhs, torch.fx.Node):
        scalar = _extract_scalar(lhs)
        inner = rhs
    else:
        return node, "{aux}"
    if scalar is None:
        return node, "{aux}"
    load_node, inner_template = _canonical_aux_load_operand(inner)
    if load_node is inner and not _is_helion_load_node(load_node):
        return node, "{aux}"
    load_dtype = _node_tensor_dtype(load_node)
    if load_dtype is None or not load_dtype.is_floating_point:
        return node, "{aux}"
    return load_node, _round_epilogue_expression(
        f"(({inner_template}) * {scalar!r})", _node_tensor_dtype(node)
    )


def _runtime_scalar(node: torch.fx.Node) -> _RuntimeScalarExpr | None:
    if node.op != "call_function" or node.target is not _get_symnode:
        return None
    value = node.meta.get("val")
    if not isinstance(value, (torch.SymInt, torch.SymFloat)):
        return None
    if not node.meta.get("helion_host_scalar", False):
        return None
    expr = value.node.expr
    if not isinstance(expr, sympy.Expr):
        return None
    return _RuntimeScalarExpr(expr)


def _is_host_scalar_expr(expr: _TensorExpr) -> bool:
    return isinstance(expr, _RuntimeScalarExpr) and expr.is_host_scalar


def _is_auxiliary_tensor_expr_node(node: torch.fx.Node, depth: int = 0) -> bool:
    """Return whether ``node`` is structurally an aux-only expression."""
    if depth >= 32:
        return False
    if _runtime_scalar(node) is not None:
        return True
    load_node, _ = _aux_load_operand(node)
    if _is_helion_load_node(load_node):
        return True
    if node.op != "call_function" or node.kwargs:
        return False
    cast_step = _floating_cast_step(node)
    if cast_step is not None:
        return _is_auxiliary_tensor_expr_node(cast_step[1], depth + 1)
    unary_step = _ZERO_ARG_TARGETS.get(node.target)
    unary_operand: torch.fx.Node | None = None
    if unary_step is not None:
        if len(node.args) != 1 or not isinstance(node.args[0], torch.fx.Node):
            return False
        unary_operand = node.args[0]
    else:
        silu = _classify_silu(node)
        if silu is not None:
            _, unary_operand = silu
    if unary_operand is not None:
        return _is_auxiliary_tensor_expr_node(unary_operand, depth + 1)
    if node.target not in _SCALAR_BINARY_TARGETS or len(node.args) != 2:
        return False
    lhs, rhs = node.args
    lhs_is_expr = isinstance(lhs, torch.fx.Node) and _is_auxiliary_tensor_expr_node(
        lhs, depth + 1
    )
    rhs_is_expr = isinstance(rhs, torch.fx.Node) and _is_auxiliary_tensor_expr_node(
        rhs, depth + 1
    )
    if lhs_is_expr and rhs_is_expr:
        return True
    if lhs_is_expr:
        return _extract_scalar(rhs) is not None
    if rhs_is_expr:
        return _extract_scalar(lhs) is not None
    return False


def _auxiliary_tensor_expr_operands(
    expr: _TensorExpr,
) -> tuple[_AuxiliaryTensorLoadExpr, ...]:
    if isinstance(expr, (_CurrentTensorExpr, _RuntimeScalarExpr)):
        return ()
    if isinstance(expr, _AuxiliaryTensorLoadExpr):
        return (expr,)
    if isinstance(expr, _UnaryTensorExpr):
        return _auxiliary_tensor_expr_operands(expr.operand)
    if isinstance(expr, _BinaryTensorExpr):
        return (
            *_auxiliary_tensor_expr_operands(expr.lhs),
            *_auxiliary_tensor_expr_operands(expr.rhs),
        )
    raise AssertionError(f"unexpected tensor expression: {type(expr).__name__}")


def _runtime_scalar_operands(
    expr: _TensorExpr,
) -> tuple[_RuntimeScalarExpr, ...]:
    if isinstance(expr, (_CurrentTensorExpr, _AuxiliaryTensorLoadExpr)):
        return ()
    if isinstance(expr, _RuntimeScalarExpr):
        return (expr,)
    if isinstance(expr, _UnaryTensorExpr):
        return _runtime_scalar_operands(expr.operand)
    if isinstance(expr, _BinaryTensorExpr):
        return (
            *_runtime_scalar_operands(expr.lhs),
            *_runtime_scalar_operands(expr.rhs),
        )
    raise AssertionError(f"unexpected tensor expression: {type(expr).__name__}")


def _tensor_expr_contains_current(expr: _TensorExpr) -> bool:
    if isinstance(expr, _CurrentTensorExpr):
        return True
    if isinstance(expr, (_AuxiliaryTensorLoadExpr, _RuntimeScalarExpr)):
        return False
    if isinstance(expr, _UnaryTensorExpr):
        return _tensor_expr_contains_current(expr.operand)
    if isinstance(expr, _BinaryTensorExpr):
        return _tensor_expr_contains_current(expr.lhs) or _tensor_expr_contains_current(
            expr.rhs
        )
    raise AssertionError(f"unexpected tensor expression: {type(expr).__name__}")


def _render_runtime_scalar(expr: _RuntimeScalarExpr) -> str:
    """Render one tile-uniform scalar as an inline ``cutlass.Float32`` value."""
    from ..device_function import DeviceFunction

    df = DeviceFunction.current()
    if isinstance(expr.source, torch.fx.Node):
        from ...language.memory_ops import _cute_scalar_load_expr

        tensor_node = expr.source.args[0]
        assert isinstance(tensor_node, torch.fx.Node)
        tensor = tensor_node.meta["val"]
        assert isinstance(tensor, torch.Tensor)
        tensor_name = df.tensor_arg(tensor).name
        # The chain is spliced as source text, so the argument pruner never
        # sees this read; pin the tensor like the per-subtile aux operands.
        df.placeholder_args.add(tensor_name)
        value = _cute_scalar_load_expr(tensor_name, [], tensor.dtype)
    else:
        value = df.sympy_expr(expr.source)
    return f"cutlass.Float32({value})"


def _render_auxiliary_tensor_expr(
    expr: _TensorExpr,
    carrier_name: str,
    aux_locals_by_expr: dict[_AuxiliaryTensorLoadExpr, str],
    local_name_factory: object,
    prelude_indent: str,
) -> tuple[str, str]:
    """Render an expression tree into bound TensorSSA locals."""
    if isinstance(expr, _RuntimeScalarExpr):
        return "", _render_runtime_scalar(expr)
    if isinstance(expr, _CurrentTensorExpr):
        return "", carrier_name
    if isinstance(expr, _AuxiliaryTensorLoadExpr):
        assert expr in aux_locals_by_expr, "auxiliary load leaf has no local binding"
        aux_local = aux_locals_by_expr[expr]
        if expr.template == "{aux}":
            return "", aux_local
        local = local_name_factory("tcgen05_aux_expr")  # type: ignore[operator]
        assert isinstance(local, str)
        rendered = expr.template.format(aux=aux_local)
        return f"{prelude_indent}{local} = {rendered}\n", local
    if isinstance(expr, _UnaryTensorExpr):
        prelude, operand = _render_auxiliary_tensor_expr(
            expr.operand,
            carrier_name,
            aux_locals_by_expr,
            local_name_factory,
            prelude_indent,
        )
        local_prefix = (
            "tcgen05_chain_step"
            if _tensor_expr_contains_current(expr)
            else "tcgen05_aux_expr"
        )
        local = local_name_factory(local_prefix)  # type: ignore[operator]
        assert isinstance(local, str)
        rendered = expr.step.template.format(inner=operand)
        return prelude + f"{prelude_indent}{local} = {rendered}\n", local
    if isinstance(expr, _BinaryTensorExpr):
        lhs_prelude, lhs = _render_auxiliary_tensor_expr(
            expr.lhs,
            carrier_name,
            aux_locals_by_expr,
            local_name_factory,
            prelude_indent,
        )
        rhs_prelude, rhs = _render_auxiliary_tensor_expr(
            expr.rhs,
            carrier_name,
            aux_locals_by_expr,
            local_name_factory,
            prelude_indent,
        )
        if _tensor_expr_contains_current(expr):
            local_prefix = "tcgen05_chain_step"
        elif expr.op_name == "mul":
            local_prefix = "tcgen05_aux_product"
        else:
            local_prefix = "tcgen05_aux_expr"
        local = local_name_factory(local_prefix)  # type: ignore[operator]
        assert isinstance(local, str)
        rendered = expr.op_template.format(lhs=lhs, rhs=rhs)
        return (
            lhs_prelude + rhs_prelude + f"{prelude_indent}{local} = {rendered}\n",
            local,
        )
    raise AssertionError(f"unexpected tensor expression: {type(expr).__name__}")


@dataclasses.dataclass(frozen=True)
class Tcgen05UnaryEpilogueChain:
    """A renderable whitelisted chain rooted at a tcgen05 matmul.

    ``steps`` is in *application order*: ``steps[0]`` is the op closest
    to the matmul; ``steps[-1]`` is the op closest to the optional store cast.
    Every step is an ``_AuxiliaryTensorExprStep`` whose expression can
    reference the current carrier, scalar constants, and auxiliary loads. The
    classname (``Tcgen05UnaryEpilogueChain``) is preserved from the
    earlier unary-only implementation for byte-identity in goldens;
    conceptually the type is now a "tcgen05 epilogue chain" that
    may include auxiliary-tensor steps.

    :meth:`render_prelude_and_expr` emits one bound local per step so
    chain composition uses single-name references at each level. This
    avoids quadratic-or-worse source blowup from templates that
    duplicate ``{inner}`` (the relu template substitutes ``{inner}`` 5
    times, so a 3-deep chain of relus would otherwise be 125x; with
    per-step binding it stays linear). CuTe CSEs identical reads at
    compile time, but the source-side blowup pessimizes Python parse
    time and the cute-DSL JIT IR build, both of which scan the source
    text linearly. Per-step locals keep generated source size O(N) in
    the chain depth without adding a second alias for multi-reference
    templates.

    For auxiliary-tensor steps, the renderer expects the splice site
    to provide pre-bound locals for the auxiliary load leaves. It
    renders any aux-only expression before emitting ``carrier <op>
    aux_expr``. The aux load
    code (cute partition + per-thread read) is the splice site's
    responsibility because it depends on the per-subtile loop layout
    and the partitioned tile, neither of which this module knows about.
    """

    steps: tuple[_AuxiliaryTensorExprStep, ...]

    @property
    def auxiliary_tensor_loads(self) -> tuple[_AuxiliaryTensorLoadExpr, ...]:
        """All auxiliary-tensor steps in application order.

        Used by the splice site to request per-step ``aux_local``
        locals before calling :meth:`render_prelude_and_expr` so the
        per-thread aux load setup runs once per output tile (outside
        the per-subtile chain rendering).
        """
        return tuple(operand for step in self.steps for operand in step.operands)

    @property
    def runtime_scalars(self) -> tuple[_RuntimeScalarExpr, ...]:
        """All tile-uniform scalar leaves in application order.

        Each renders inline from the current device function, so epilogue
        layouts that emit the chain into a separate helper module must reject
        chains that have any. Planners that enumerate memory operands (TMA aux
        descriptors, fanout aliasing, SMEM staging) use
        :attr:`auxiliary_tensor_loads`, which never includes these leaves.
        """
        return tuple(
            leaf for step in self.steps for leaf in _runtime_scalar_operands(step.expr)
        )

    def render_prelude_and_expr(
        self,
        carrier_name: str,
        local_name_factory: object,
        prelude_indent: str,
        aux_locals_by_expr: dict[_AuxiliaryTensorLoadExpr, str] | None = None,
    ) -> tuple[str, str]:
        """Return ``(prelude, final_expr)``.

        - ``prelude`` is one-or-more ``<local> = <step_expr>\\n`` lines
          (each indented with ``prelude_indent``).
        - ``final_expr`` is the carrier-name reference for the last
          step.

        ``local_name_factory`` must be a callable taking a single
        prefix string and returning a fresh AST variable name; in
        practice the splice site passes ``df.new_var`` so each chain
        step gets a unique name even across multiple kernels.

        ``aux_locals_by_expr`` is required when the chain has auxiliary-load
        leaves and maps each identity-keyed leaf to the splice-side pre-bound
        local carrying its per-thread value. Pure unary chains pass ``None``.

        Identity epilogues do not reach this method: the analyzer returns an
        empty chain for that case, and the splice site leaves it to the
        existing ``ast.Name`` fast path. Empty chains here would indicate a
        caller bug.
        """
        assert self.steps, (
            "render_prelude_and_expr is only valid for chains with at "
            "least one step; identity epilogues should never reach the "
            "splice site (the ast.Name fast path handles them)"
        )
        aux_steps = self.auxiliary_tensor_loads
        if aux_steps:
            assert aux_locals_by_expr is not None and len(aux_locals_by_expr) == len(
                aux_steps
            ), (
                "auxiliary-tensor chains require one local binding per load leaf; "
                f"got {len(aux_locals_by_expr) if aux_locals_by_expr is not None else None} "
                f"bindings for {len(aux_steps)} leaves"
            )
            assert all(step in aux_locals_by_expr for step in aux_steps)
        else:
            assert aux_locals_by_expr is None or not aux_locals_by_expr, (
                "non-auxiliary chains must not be passed aux_locals_by_expr"
            )
        local_bindings = aux_locals_by_expr or {}
        prelude_lines: list[str] = []
        cur_expr = carrier_name
        local = carrier_name
        for step in self.steps:
            step_prelude, local = step.render_prelude_and_expr(
                cur_expr,
                local_bindings,
                local_name_factory,
                prelude_indent,
            )
            prelude_lines.append(step_prelude)
            cur_expr = local
        return ("".join(prelude_lines), local)


def _is_sigmoid_of(node: object, carrier: torch.fx.Node) -> bool:
    """Return True if ``node`` is ``aten.sigmoid.default(carrier)``.

    Identity-keying on ``args[0]`` is sound because Helion's FX graph
    deduplicates equal-expression nodes: any ``sigmoid(x)`` and
    ``x * sigmoid(x)`` traced from the same ``x`` proxy share the same
    underlying FX node for ``x``.
    """
    return (
        isinstance(node, torch.fx.Node)
        and node.op == "call_function"
        and node.target is torch.ops.aten.sigmoid.default
        and not node.kwargs
        and len(node.args) == 1
        and node.args[0] is carrier
    )


def _is_one_plus_exp_neg_of(node: object, carrier: torch.fx.Node) -> bool:
    """Return True if ``node`` is ``add(exp(neg(carrier)), 1)`` (with the
    scalar ``1`` on either side of the ``add``).

    Matches the inductor-specific silu decomposition (see
    ``torch/_inductor/decomposition.py``::``silu``) which expands
    ``aten.silu.default`` as ``x / (1 + x.neg().exp())`` for exact eager
    matching. That decomposition expands the silu denominator into
    ``add(exp(neg(carrier)), 1)`` where the literal ``1`` is the Python
    int ``1`` after the FX ``1 + tensor`` desugars to
    ``tensor.__radd__(1)``. ``_classify_silu`` consumes this helper to
    confirm a ``div`` node has the silu shape.
    """
    if not isinstance(node, torch.fx.Node):
        return False
    if node.op != "call_function" or node.kwargs:
        return False
    if node.target is not torch.ops.aten.add.Tensor:
        return False
    if len(node.args) != 2:
        return False
    a0, a1 = node.args
    # ``1`` literal on either side. ``isinstance(True, int)`` is True in
    # Python; explicitly reject booleans so an unlikely
    # ``add(exp_node, True)`` is not misread as silu.
    if (
        isinstance(a0, torch.fx.Node)
        and isinstance(a1, int)
        and not isinstance(a1, bool)
    ):
        exp_node, scalar = a0, a1
    elif (
        isinstance(a1, torch.fx.Node)
        and isinstance(a0, int)
        and not isinstance(a0, bool)
    ):
        exp_node, scalar = a1, a0
    else:
        return False
    if scalar != 1:
        return False
    if (
        exp_node.op != "call_function"
        or exp_node.target is not torch.ops.aten.exp.default
        or exp_node.kwargs
        or len(exp_node.args) != 1
    ):
        return False
    neg_node = exp_node.args[0]
    if not isinstance(neg_node, torch.fx.Node):
        return False
    return (
        neg_node.op == "call_function"
        and neg_node.target is torch.ops.aten.neg.default
        and not neg_node.kwargs
        and len(neg_node.args) == 1
        and neg_node.args[0] is carrier
    )


def _classify_silu(
    cur: torch.fx.Node,
) -> tuple[_UnaryOp, torch.fx.Node] | None:
    """Fold a decomposed silu activation into one chain step.

    Two FX shapes are accepted:

    - ``mul(carrier, sigmoid(carrier))`` / ``mul(sigmoid(carrier), carrier)``
      — the core ``torch._decomp`` decomposition for ``aten.silu``
      (``torch/_decomp/decompositions.py``::``silu``) is
      ``self * torch.sigmoid(self)``. That FX shape is a non-scalar
      binary multiply whose two operands point at the same carrier
      node, so ``_classify_binary`` rejects it.

    - ``div(carrier, add(exp(neg(carrier)), 1))`` — the
      inductor-specific decomposition
      (``torch/_inductor/decomposition.py``::``silu``) uses
      ``x / (1 + x.neg().exp())`` for exact eager matching. The
      ``aten.silu`` decomp registered into Helion's FX trace comes
      from this inductor-specific entry (it shadows the core
      decomposition because ``select_decomp_table`` is built from the
      inductor lowering tables in ``helion._compiler.device_ir``).
      This is the shape T13 / T17 / T26 hit in practice.

    The same ``_SILU_TEMPLATE`` (``x * (1 / (1 + exp2(-x * log2_e)))``)
    renders both forms. The pattern only matches when the inner
    references point at the *same* carrier FX node — divergent
    operands fall through to the generic binary classifier.

    Returns ``None`` if ``cur`` is not a silu shape so the caller can
    fall through to ``_classify_binary`` for ordinary scalar /
    aux-tensor binaries.
    """
    if cur.kwargs or _node_tensor_dtype(cur) in (torch.float16, torch.bfloat16):
        return None
    if len(cur.args) < 2:
        return None
    target = cur.target
    lhs = cur.args[0]
    rhs = cur.args[1]
    # ``mul(carrier, sigmoid(carrier))`` form — core decomposition.
    if target is torch.ops.aten.mul.Tensor:
        if not (isinstance(lhs, torch.fx.Node) and isinstance(rhs, torch.fx.Node)):
            return None
        if _is_sigmoid_of(rhs, lhs):
            return _UnaryOp(op_name="silu", template=_SILU_TEMPLATE), lhs
        if _is_sigmoid_of(lhs, rhs):
            return _UnaryOp(op_name="silu", template=_SILU_TEMPLATE), rhs
        return None
    # ``div(carrier, add(exp(neg(carrier)), 1))`` form — inductor decomp.
    if target is torch.ops.aten.div.Tensor:
        if not isinstance(lhs, torch.fx.Node):
            return None
        if _is_one_plus_exp_neg_of(rhs, lhs):
            return _UnaryOp(op_name="silu", template=_SILU_TEMPLATE), lhs
        return None
    return None


def _classify_binary(
    cur: torch.fx.Node,
    *,
    carrier_tile_shape: tuple[object, ...] | None,
    carrier_tile_index_nodes: tuple[torch.fx.Node, ...] | None = None,
    carrier_global_shape: tuple[object, ...] | None = None,
) -> tuple[_AuxiliaryTensorExprStep, torch.fx.Node] | None:
    """Classify ``cur`` (a ``call_function`` node whose target is on the
    binary whitelist) as a single chain step plus its FX carrier node.

    Returns ``None`` if the node cannot be folded — unexpected
    kwargs, multiple chain inputs, both args are scalars, both args
    are tensors but neither is a recognized auxiliary load, etc. The
    ``_AuxiliaryTensorLoadExpr`` branch is gated on ``carrier_tile_shape``
    being available *and* matching the auxiliary load's tile shape;
    pass ``None`` when no carrier tile shape is known (e.g. the
    chain entry point) and the auxiliary branch will be skipped.

    Reject any non-empty kwargs: ``aten.add.Tensor`` and
    ``aten.sub.Tensor`` accept an ``alpha`` kwarg whose default is ``1``
    and that scales the second argument; silently rendering
    ``carrier + other`` when the FX node is ``add(carrier, other,
    alpha=2.0)`` would emit incorrect arithmetic. The conservative
    response is to bail to ``None`` so the loud-failure backstop
    fires. Pinned for both scalar and auxiliary-tensor forms by
    ``test_tcgen05_fused_chain_rejects_alpha_kwarg``.
    """
    if cur.kwargs:
        return None
    if len(cur.args) < 2:
        return None
    target = cur.target
    lhs = cur.args[0]
    rhs = cur.args[1]
    # Determine which arg is the chain carrier. The carrier is the
    # FX node that walks back to the matmul anchor; the other is
    # either a Python scalar literal or a recognized aux load FX
    # node. We branch on the arg shapes here and let the caller's
    # subsequent ``walk_carrier_to_tcgen05_matmul`` confirm the
    # chosen carrier reaches the matmul.
    lhs_is_node = isinstance(lhs, torch.fx.Node)
    rhs_is_node = isinstance(rhs, torch.fx.Node)
    if lhs_is_node and rhs_is_node:
        assert isinstance(lhs, torch.fx.Node) and isinstance(rhs, torch.fx.Node)
        lhs_expr = _classify_auxiliary_tensor_expr(
            lhs,
            carrier_tile_shape=carrier_tile_shape,
            carrier_tile_index_nodes=carrier_tile_index_nodes,
            carrier_global_shape=carrier_global_shape,
        )
        rhs_expr = _classify_auxiliary_tensor_expr(
            rhs,
            carrier_tile_shape=carrier_tile_shape,
            carrier_tile_index_nodes=carrier_tile_index_nodes,
            carrier_global_shape=carrier_global_shape,
        )
        aux_expr: _TensorExpr
        carrier: torch.fx.Node
        forward_form: bool
        if lhs_expr is not None and rhs_expr is None:
            aux_expr = lhs_expr
            carrier = rhs
            forward_form = False  # carrier is the right operand
        elif rhs_expr is not None and lhs_expr is None:
            aux_expr = rhs_expr
            carrier = lhs
            forward_form = True  # carrier is the left operand
        else:
            return None
        op_name = _BINARY_OP_NAMES[target]
        current_expr = _CurrentTensorExpr()
        return (
            _AuxiliaryTensorExprStep(
                expr=_BinaryTensorExpr(
                    op_name=op_name,
                    op_template=_round_epilogue_expression(
                        _AUX_EXPR_BINARY_TEMPLATES[target], _node_tensor_dtype(cur)
                    ),
                    lhs=current_expr if forward_form else aux_expr,
                    rhs=aux_expr if forward_form else current_expr,
                )
            ),
            carrier,
        )
    # One arg is a tensor and the other a scalar literal. Extract
    # the scalar and render a unary expression over the current carrier.
    scalar: float | None
    forward_form_scalar: bool  # True => `carrier <op> scalar`
    scalar_carrier: torch.fx.Node
    if lhs_is_node and not rhs_is_node:
        assert isinstance(lhs, torch.fx.Node)
        scalar = _extract_scalar(rhs)
        scalar_carrier = lhs
        forward_form_scalar = True
    elif rhs_is_node and not lhs_is_node:
        assert isinstance(rhs, torch.fx.Node)
        scalar = _extract_scalar(lhs)
        scalar_carrier = rhs
        forward_form_scalar = False
    else:
        # Neither is an FX node — would mean a constant binary op
        # that should have been folded upstream. Bail.
        return None
    if scalar is None:
        return None
    template = _scalar_binary_template(
        target,
        scalar,
        forward_form=forward_form_scalar,
    )
    if template is None:
        return None
    return (
        _AuxiliaryTensorExprStep(
            expr=_UnaryTensorExpr(
                step=_UnaryOp(
                    op_name=_BINARY_OP_NAMES[target],
                    template=_round_epilogue_expression(
                        template, _node_tensor_dtype(cur)
                    ),
                ),
                operand=_CurrentTensorExpr(),
            )
        ),
        scalar_carrier,
    )


def _classify_auxiliary_tensor_expr(
    node: torch.fx.Node,
    *,
    carrier_tile_shape: tuple[object, ...] | None,
    carrier_tile_index_nodes: tuple[torch.fx.Node, ...] | None,
    carrier_global_shape: tuple[object, ...] | None,
) -> _TensorExpr | None:
    """Recognize a whitelisted elementwise tree rooted in auxiliary loads."""
    return _classify_auxiliary_tensor_expr_impl(
        node,
        carrier_tile_shape=carrier_tile_shape,
        carrier_tile_index_nodes=carrier_tile_index_nodes,
        carrier_global_shape=carrier_global_shape,
        depth=0,
    )


def _node_tensor_dtype(node: torch.fx.Node) -> torch.dtype | None:
    val = node.meta.get("val")
    return val.dtype if isinstance(val, torch.Tensor) else None


def _classify_auxiliary_tensor_expr_impl(
    node: torch.fx.Node,
    *,
    carrier_tile_shape: tuple[object, ...] | None,
    carrier_tile_index_nodes: tuple[torch.fx.Node, ...] | None,
    carrier_global_shape: tuple[object, ...] | None,
    depth: int,
) -> _TensorExpr | None:
    if depth >= 32:
        return None
    if (scalar := _runtime_scalar(node)) is not None:
        return scalar

    load_node, aux_template = _aux_load_operand(node)
    kind = aux_tensor_load_kind(
        load_node,
        carrier_tile_shape=carrier_tile_shape,
        carrier_tile_index_nodes=carrier_tile_index_nodes,
        carrier_global_shape=carrier_global_shape,
    )
    if kind == ("scalar", None):
        # Rank-0 aux (``scale[()]``) is one tile-uniform device scalar. Only
        # the bare load is a leaf; casts and literal factors around it stay
        # ordinary chain steps, so the dtype must be one whose rounding the
        # chain models.
        if load_node is node and _node_tensor_dtype(node) in _FLOAT_CAST_TYPES:
            return _RuntimeScalarExpr(node)
    elif kind is not None:
        broadcast_axis = kind[1] if kind[0] == "broadcast" else None
        return _AuxiliaryTensorLoadExpr(
            load_node=load_node,
            broadcast_axis=broadcast_axis,
            template=aux_template,
        )

    if node.op != "call_function" or node.kwargs:
        return None
    cast_step = _floating_cast_step(node)
    if cast_step is not None:
        unary_step, unary_operand = cast_step
        operand_expr = _classify_auxiliary_tensor_expr_impl(
            unary_operand,
            carrier_tile_shape=carrier_tile_shape,
            carrier_tile_index_nodes=carrier_tile_index_nodes,
            carrier_global_shape=carrier_global_shape,
            depth=depth + 1,
        )
        if operand_expr is None:
            return None
        return _UnaryTensorExpr(step=unary_step, operand=operand_expr)
    unary_step = _ZERO_ARG_TARGETS.get(node.target)
    unary_operand: torch.fx.Node | None = None
    if unary_step is not None:
        if len(node.args) != 1 or not isinstance(node.args[0], torch.fx.Node):
            return None
        unary_operand = node.args[0]
    else:
        silu = _classify_silu(node)
        if silu is not None:
            unary_step, unary_operand = silu
    if unary_step is not None and unary_operand is not None:
        operand_dtype = _node_tensor_dtype(unary_operand)
        if (
            operand_dtype is None
            or not operand_dtype.is_floating_point
            or _node_tensor_dtype(node) != operand_dtype
        ):
            return None
        operand_expr = _classify_auxiliary_tensor_expr_impl(
            unary_operand,
            carrier_tile_shape=carrier_tile_shape,
            carrier_tile_index_nodes=carrier_tile_index_nodes,
            carrier_global_shape=carrier_global_shape,
            depth=depth + 1,
        )
        if operand_expr is None:
            return None
        return _UnaryTensorExpr(
            step=_round_unary_step(unary_step, node), operand=operand_expr
        )

    if node.target not in _SCALAR_BINARY_TARGETS or len(node.args) != 2:
        return None
    lhs = node.args[0]
    rhs = node.args[1]
    lhs_expr = (
        _classify_auxiliary_tensor_expr_impl(
            lhs,
            carrier_tile_shape=carrier_tile_shape,
            carrier_tile_index_nodes=carrier_tile_index_nodes,
            carrier_global_shape=carrier_global_shape,
            depth=depth + 1,
        )
        if isinstance(lhs, torch.fx.Node)
        else None
    )
    rhs_expr = (
        _classify_auxiliary_tensor_expr_impl(
            rhs,
            carrier_tile_shape=carrier_tile_shape,
            carrier_tile_index_nodes=carrier_tile_index_nodes,
            carrier_global_shape=carrier_global_shape,
            depth=depth + 1,
        )
        if isinstance(rhs, torch.fx.Node)
        else None
    )
    if lhs_expr is not None and rhs_expr is not None:
        assert isinstance(lhs, torch.fx.Node) and isinstance(rhs, torch.fx.Node)
        result_dtype = _node_tensor_dtype(node)
        # A host scalar is weakly typed: torch promotes it to the tensor
        # operand's dtype like a literal. A rank-0 load is a tensor operand
        # and must already carry the result dtype.
        if (
            result_dtype is None
            or (
                not _is_host_scalar_expr(lhs_expr)
                and _node_tensor_dtype(lhs) != result_dtype
            )
            or (
                not _is_host_scalar_expr(rhs_expr)
                and _node_tensor_dtype(rhs) != result_dtype
            )
        ):
            return None
        return _BinaryTensorExpr(
            op_name=_BINARY_OP_NAMES[node.target],
            op_template=_round_epilogue_expression(
                _AUX_EXPR_BINARY_TEMPLATES[node.target], result_dtype
            ),
            lhs=lhs_expr,
            rhs=rhs_expr,
        )
    if lhs_expr is not None:
        assert isinstance(lhs, torch.fx.Node)
        scalar = _extract_scalar(rhs)
        lhs_dtype = _node_tensor_dtype(lhs)
        if (
            scalar is None
            or lhs_dtype is None
            or not lhs_dtype.is_floating_point
            or _node_tensor_dtype(node) != lhs_dtype
        ):
            return None
        template = _scalar_binary_template(node.target, scalar, forward_form=True)
        assert template is not None
        return _UnaryTensorExpr(
            step=_UnaryOp(
                op_name=_BINARY_OP_NAMES[node.target],
                template=_round_epilogue_expression(template, lhs_dtype),
            ),
            operand=lhs_expr,
        )
    if rhs_expr is not None:
        assert isinstance(rhs, torch.fx.Node)
        scalar = _extract_scalar(lhs)
        rhs_dtype = _node_tensor_dtype(rhs)
        if (
            scalar is None
            or rhs_dtype is None
            or not rhs_dtype.is_floating_point
            or _node_tensor_dtype(node) != rhs_dtype
        ):
            return None
        template = _scalar_binary_template(node.target, scalar, forward_form=False)
        assert template is not None
        return _UnaryTensorExpr(
            step=_UnaryOp(
                op_name=_BINARY_OP_NAMES[node.target],
                template=_round_epilogue_expression(template, rhs_dtype),
            ),
            operand=rhs_expr,
        )
    return None


def _carrier_tile_shape(node: torch.fx.Node) -> tuple[object, ...] | None:
    """Extract the carrier's tile shape from ``meta['val'].shape``.

    Returns ``None`` when the meta is missing. The classifier uses
    this shape to decide whether an auxiliary-tensor load matches
    the carrier's rank/extents — only exact-shape aux loads are
    accepted; broadcast / rank mismatches drop to the loud-failure
    backstop.
    """
    val = node.meta.get("val")
    if val is None:
        return None
    return tuple(val.shape)


def _carrier_tile_index_nodes(
    cast_input: torch.fx.Node,
) -> tuple[torch.fx.Node, ...] | None:
    """Extract the tile-id symbol FX nodes that index the chain carrier.

    Walks back from the post-matmul chain entry to the ``hl.zeros``
    initial-value node and reads its tile-shape list. Returns the
    tuple of FX symint nodes (one per tile axis), or ``None`` when
    the walk cannot recover them — the classifier then falls back
    to the looser shape-only check.

    For binary chain steps the walk picks the first
    ``all_input_nodes`` entry that is not an accepted aux-load
    operand. The chain analyzer accepts both ``add(carrier,
    aux_load)`` and ``add(aux_load, carrier)``; descending into the
    aux load side breaks the walk-back to ``hl.zeros``. Skipping the
    same wrapped/scaled aux operands accepted by the classifier keeps
    the walk on the carrier side regardless of operand order, so the
    reverse-form chain recovers the tile index symbols just like the
    forward form.

    Invariant: any ``hl.load`` input encountered during the walk is
    necessarily an aux load (never a carrier passthrough), because
    the carrier always originates at ``hl.zeros`` and is propagated
    through ``_phi`` / ``_new_var`` / ``getitem`` plus the accepted
    chain ops — none of which produces a load node along the
    carrier side.
    """
    cur: torch.fx.Node | None = cast_input
    visited: set[torch.fx.Node] = set()
    # Walk through identity-shape passthroughs to the loop entry,
    # then take the ``_phi`` initial-value branch to the
    # ``hl.zeros`` (``full``) node whose ``args[0]`` is the tile-
    # shape list.
    while cur is not None and cur not in visited:
        visited.add(cur)
        if cur.op != "call_function":
            return None
        target = cur.target
        if target is _tracing_ops._phi:
            init = cur.args[0] if cur.args else None
            if not isinstance(init, torch.fx.Node):
                return None
            shape_arg = init.args[0] if init.args else None
            if not isinstance(shape_arg, (list, tuple)):
                return None
            nodes = tuple(e for e in shape_arg if isinstance(e, torch.fx.Node))
            return nodes if len(nodes) == len(shape_arg) else None
        if target is _tracing_ops._new_var or target is operator.getitem:
            arg = cur.args[0] if cur.args else None
            if not isinstance(arg, torch.fx.Node):
                return None
            cur = arg
            continue
        # The chain may carry a binary op whose carrier we want to
        # follow back. Pick the first ``all_input_nodes`` entry that
        # is not an accepted aux-load operand so we descend into
        # the carrier side regardless of operand order. Reverse-form
        # binaries (``aux_load <op> carrier``) put the aux load
        # first; without this skip the walk would descend into the
        # aux tensor and never find ``hl.zeros``.
        chosen: torch.fx.Node | None = None
        for inp in cur.all_input_nodes:
            if _is_auxiliary_tensor_expr_node(inp):
                continue
            chosen = inp
            break
        if chosen is None:
            return None
        cur = chosen
    return None


def analyze_tcgen05_unary_epilogue_chain(
    state: CodegenState | None,
    value_node: torch.fx.Node,
    *,
    output_global_shape: tuple[object, ...] | None = None,
    target_fx_nodes: set[torch.fx.Node] | None = None,
    inner_outputs_by_graph_id: dict[int, tuple[torch.fx.Node | None, ...]]
    | None = None,
) -> tuple[Tcgen05UnaryEpilogueChain, torch.fx.Node] | None:
    """Classify ``value_node``'s producer chain as a whitelisted
    epilogue rooted at a tcgen05 matmul.

    ``value_node`` is the user-side store value. Helion normally wraps it in an
    implicit ``convert_element_type`` to the store-target dtype, but elides that
    no-op when the value already has the target dtype. The chain we accept is,
    walking upstream from ``value_node``:

        [convert_element_type (the optional implicit cast)] ->
        [whitelisted op]* ->
        accumulator carrier (phi / getitem on for_loop output ->
        registered tcgen05 matmul fx_node).

    Whitelisted ops are zero-arg unary (``relu`` / ``tanh`` / ``exp``
    / ``log`` / ``sqrt`` / ``abs`` / ``neg``), scalar binary
    (``add`` / ``sub`` / ``mul`` / ``div`` against a compile-time
    Python literal), and carrier binary ops whose other operand is
    a whitelisted elementwise expression over auxiliary loads and
    tile-uniform scalars (lifted ``SymFloat`` / ``SymInt`` kernel
    arguments and rank-0 ``scale[()]`` loads). The
    auxiliary leaves accept exact-shape
    (``residual[tile_m, tile_n]``, rank-2 matching the carrier tile)
    and rank-1 trailing-axis (rowvec) broadcast forms
    (``bias[tile_n]``, where the single load index symbol matches
    the carrier's trailing tile-id symbol). Other
    shapes — 3-D collapsed loads, indices that are not exactly the
    carrier trailing tile-id symbol, leading-axis rank-1
    (``bias[tile_m]``), kwargs — are rejected so the loud-failure
    backstop fires.

    Intermediate FP16/BF16/FP32 casts remain explicit steps. The rendered
    value converts through the requested type and back to FP32; later
    low-precision arithmetic also rounds after each FX step. The final
    store conversion is separate, including stores with a different dtype.

    Returns ``(chain, matmul_anchor)`` on success — the rendered chain
    excludes the optional trailing ``convert_element_type`` (the splice site
    emits ``.to(target_dtype)`` where ``target_dtype`` is the store-target
    tensor's dtype), and the anchor is the unique
    tcgen05 matmul fx_node whose ``result_var`` the splice should
    target. Returns ``None`` if the chain is not in the whitelist or
    multiple matmul anchors are reachable along the carrier path
    (multi-input epilogues are deferred). The caller falls back
    to the loud-failure ``BackendUnsupported`` raise on ``None`` so
    the diagnostic keeps firing for non-whitelisted shapes.

    The chain may have ``steps == ()`` — i.e. ``out[tile] = acc`` or
    ``out[tile] = acc.to(x.dtype)`` — in which case the splice site emits the
    existing identity ``.to(target_dtype)`` line unchanged. The fast-
    path ``ast.Name``-matching code in ``store_codegen`` handles the
    identity case earlier; the empty-chain return from this function
    is a defensive belt-and-suspenders.

    ``output_global_shape`` is the user-side store target tensor's
    full (non-tile) shape, threaded into the rank-1 broadcast aux
    classifier so an aux whose extent only happens to match the
    tile but not the global axis is rejected at classify time.
    """
    if target_fx_nodes is None:
        if state is None:
            return None
        df = state.device_function
        target_fx_nodes = df.cute_state.matmul_fx_nodes
    if not target_fx_nodes:
        return None

    chain_input: object = value_node
    if (
        value_node.op == "call_function"
        and value_node.target is torch.ops.prims.convert_element_type.default
    ):
        if value_node.kwargs:
            # ``convert_element_type`` takes ``(input, dtype)`` positionally in
            # the FX forms we trace; reject anything unexpected.
            return None
        chain_input = value_node.args[0] if value_node.args else None
    if not isinstance(chain_input, torch.fx.Node):
        return None

    if inner_outputs_by_graph_id is None:
        if state is None:
            return None
        inner_outputs_by_graph_id = build_inner_outputs_index(state)

    matmul_anchor = walk_carrier_to_tcgen05_matmul(
        chain_input, target_fx_nodes, inner_outputs_by_graph_id
    )
    if matmul_anchor is not None:
        # Preserve the distinction between a valid identity store and an
        # unsupported chain. Store codegen leaves the empty-chain case to its
        # existing ast.Name fast path, while preflight callers can admit it.
        return Tcgen05UnaryEpilogueChain(steps=()), matmul_anchor

    # The chain carrier's expected tile shape and tile-id symbol
    # nodes, used to validate auxiliary-tensor loads. Read once at
    # the top — both are invariant along the chain because every
    # accepted op preserves shape (zero-arg unary, scalar-binary,
    # and exact-shape aux-binary all produce the same shape as
    # their input).
    carrier_tile_shape = _carrier_tile_shape(chain_input)
    carrier_tile_index_nodes = _carrier_tile_index_nodes(chain_input)

    steps: list[_AuxiliaryTensorExprStep] = []
    cur: torch.fx.Node = chain_input
    # Bound the walk so a pathological FX graph cannot loop forever.
    # 32 unary ops between the matmul and the store is an absurd upper
    # bound for any realistic activation chain.
    for _ in range(32):
        if cur.op != "call_function":
            return None
        target = cur.target
        cast_step = _floating_cast_step(cur)
        if cast_step is not None:
            step, arg = cast_step
            steps.append(
                _AuxiliaryTensorExprStep(
                    expr=_UnaryTensorExpr(step=step, operand=_CurrentTensorExpr())
                )
            )
            anchor = walk_carrier_to_tcgen05_matmul(
                arg, target_fx_nodes, inner_outputs_by_graph_id
            )
            if anchor is not None:
                steps.reverse()
                return Tcgen05UnaryEpilogueChain(steps=tuple(steps)), anchor
            cur = arg
            continue
        # Zero-arg unary ops.
        if target in _ZERO_ARG_TARGETS:
            if cur.kwargs:
                return None  # Reject unexpected kwargs.
            arg = cur.args[0] if cur.args else None
            if not isinstance(arg, torch.fx.Node):
                return None
            steps.append(
                _AuxiliaryTensorExprStep(
                    expr=_UnaryTensorExpr(
                        step=_round_unary_step(_ZERO_ARG_TARGETS[target], cur),
                        operand=_CurrentTensorExpr(),
                    )
                )
            )
            anchor = walk_carrier_to_tcgen05_matmul(
                arg, target_fx_nodes, inner_outputs_by_graph_id
            )
            if anchor is not None:
                steps.reverse()
                return Tcgen05UnaryEpilogueChain(steps=tuple(steps)), anchor
            cur = arg
            continue
        # Decomposed silu — collapse multi-node silu shapes
        # (``mul(x, sigmoid(x))`` and the inductor-form
        # ``div(x, 1 + exp(-x))``) into a single chain step. Run before
        # the generic binary classifier: the silu shape's two operands
        # both reach back to the same carrier, neither is a scalar
        # literal nor an aux-tensor load, so the generic classifier
        # would reject it. See :func:`_classify_silu` for the accepted
        # FX shapes and the rationale for matching the inductor form.
        silu = _classify_silu(cur)
        if silu is not None:
            unary_op, carrier = silu
            steps.append(
                _AuxiliaryTensorExprStep(
                    expr=_UnaryTensorExpr(
                        step=unary_op,
                        operand=_CurrentTensorExpr(),
                    )
                )
            )
            anchor = walk_carrier_to_tcgen05_matmul(
                carrier, target_fx_nodes, inner_outputs_by_graph_id
            )
            if anchor is not None:
                steps.reverse()
                return Tcgen05UnaryEpilogueChain(steps=tuple(steps)), anchor
            cur = carrier
            continue
        # Binary ops (scalar literal *or* aux-tensor load on the
        # other side). The classifier rejects multi-tensor cases
        # where neither operand is a recognized aux load and any
        # kwarg-bearing form (``alpha=k``, etc.).
        if target in _SCALAR_BINARY_TARGETS:
            classified = _classify_binary(
                cur,
                carrier_tile_shape=carrier_tile_shape,
                carrier_tile_index_nodes=carrier_tile_index_nodes,
                carrier_global_shape=output_global_shape,
            )
            if classified is None:
                return None
            step, carrier = classified
            steps.append(step)
            anchor = walk_carrier_to_tcgen05_matmul(
                carrier, target_fx_nodes, inner_outputs_by_graph_id
            )
            if anchor is not None:
                steps.reverse()
                return Tcgen05UnaryEpilogueChain(steps=tuple(steps)), anchor
            cur = carrier
            continue
        # Op not on the whitelist. Surfacing None lets the
        # loud-failure diagnostic raise so the user sees the
        # actionable message.
        return None
    return None


def _convert_input_and_dtype(
    node: torch.fx.Node,
) -> tuple[torch.fx.Node, torch.dtype] | None:
    if (
        node.op != "call_function"
        or node.target is not torch.ops.prims.convert_element_type.default
        or node.kwargs
        or len(node.args) != 2
        or not isinstance(node.args[0], torch.fx.Node)
        or not isinstance(node.args[1], torch.dtype)
    ):
        return None
    return node.args[0], node.args[1]


def _mask_base_from_broadcast(
    condition: torch.fx.Node,
    *,
    data_axis: int,
) -> torch.fx.Node | None:
    """Return the rank-1 mask broadcast along the other 2-D axis."""
    from ...language import view_ops

    if condition.op != "call_function" or condition.kwargs:
        return None
    if condition.target is view_ops.subscript:
        if len(condition.args) != 2:
            return None
        base, index = condition.args
        if (
            isinstance(base, torch.fx.Node)
            and isinstance(index, (list, tuple))
            and len(index) == 2
            and isinstance(index[data_axis], slice)
            and index[data_axis] == slice(None)
            and index[1 - data_axis] is None
        ):
            return base
        return None
    if condition.target is torch.ops.aten.unsqueeze.default:
        if len(condition.args) != 2:
            return None
        base, dim = condition.args
        if isinstance(base, torch.fx.Node) and dim in (
            1 - data_axis,
            -1 - data_axis,
        ):
            return base
    return None


def _rank1_mask_from_broadcast(
    condition: torch.fx.Node,
    *,
    carrier_tile_shape: tuple[object, ...] | None,
    data_axis: int,
) -> tuple[torch.fx.Node, torch.Tensor] | None:
    cond_val = condition.meta.get("val")
    if (
        not isinstance(cond_val, torch.Tensor)
        or cond_val.dtype is not torch.bool
        or cond_val.ndim != 2
        or cond_val.shape[1 - data_axis] != 1
    ):
        return None
    mask = _mask_base_from_broadcast(condition, data_axis=data_axis)
    if mask is None:
        return None
    mask_val = mask.meta.get("val")
    if (
        not isinstance(mask_val, torch.Tensor)
        or mask_val.dtype is not torch.bool
        or mask_val.ndim != 1
        or carrier_tile_shape is None
        or len(carrier_tile_shape) != 2
        or mask_val.shape[0] != carrier_tile_shape[data_axis]
        or cond_val.shape[data_axis] != carrier_tile_shape[data_axis]
    ):
        return None
    return mask, mask_val


def _argument_sequence_matches_nodes(
    candidate: object,
    expected: tuple[torch.fx.Node, ...],
) -> bool:
    return (
        isinstance(candidate, (list, tuple))
        and len(candidate) == len(expected)
        and all(candidate[index] is expected[index] for index in range(len(expected)))
    )


def _argument_sequence_indices_of(
    candidate: object,
    target: torch.fx.Node,
) -> list[int] | None:
    if not isinstance(candidate, (list, tuple)):
        return None
    return [index for index in range(len(candidate)) if candidate[index] is target]


def _matches_grouped_n_col_mask(
    condition: torch.fx.Node,
    *,
    carrier_tile_shape: tuple[object, ...] | None,
    carrier_tile_index_nodes: tuple[torch.fx.Node, ...] | None,
    safe_group_node: torch.fx.Node,
) -> (
    tuple[
        torch.Tensor,
        torch.fx.Node,
        torch.fx.Node,
        torch.fx.Node,
        torch.fx.Node,
    ]
    | None
):
    """Return exact ``(n_sizes, n_load, col_mask, broadcast, tile_n.index)``."""

    mask_info = _rank1_mask_from_broadcast(
        condition,
        carrier_tile_shape=carrier_tile_shape,
        data_axis=1,
    )
    if mask_info is None:
        return None
    col_mask, col_mask_val = mask_info
    if (
        col_mask.op != "call_function"
        or col_mask.target is not torch.ops.aten.lt.Tensor
        or col_mask.kwargs
        or len(col_mask.args) != 2
        or not isinstance(col_mask.args[0], torch.fx.Node)
        or not isinstance(col_mask.args[1], torch.fx.Node)
    ):
        return None
    tile_index, n_load = col_mask.args
    assert isinstance(tile_index, torch.fx.Node)
    assert isinstance(n_load, torch.fx.Node)
    tile_index_val = tile_index.meta.get("val")
    if (
        not isinstance(tile_index_val, torch.Tensor)
        or tile_index_val.ndim != 1
        or tuple(tile_index_val.shape) != tuple(col_mask_val.shape)
    ):
        return None
    from ...language import tile_ops

    if (
        carrier_tile_index_nodes is None
        or len(carrier_tile_index_nodes) != 2
        or tile_index.op != "call_function"
        or tile_index.target is not tile_ops.tile_index
        or tile_index.kwargs
        or len(tile_index.args) != 1
        or tile_index.args[0] is not carrier_tile_index_nodes[1]
    ):
        return None
    load_args = _unmasked_helion_load_args(n_load)
    if load_args is None:
        return None
    tensor_node, index_list = load_args
    if (
        not isinstance(tensor_node, torch.fx.Node)
        or not isinstance(index_list, (list, tuple))
        or len(index_list) != 1
        or not isinstance(index_list[0], torch.fx.Node)
    ):
        return None
    if index_list[0] is not safe_group_node:
        return None
    n_sizes = tensor_node.meta.get("val")
    loaded_n = n_load.meta.get("val")
    if (
        not isinstance(n_sizes, torch.Tensor)
        or n_sizes.ndim != 1
        or n_sizes.dtype not in (torch.int32, torch.int64)
        or not isinstance(loaded_n, torch.Tensor)
        or loaded_n.ndim != 0
    ):
        return None
    return n_sizes, n_load, col_mask, condition, tile_index


def _matches_grouped_m_row_mask(
    condition: torch.fx.Node,
    *,
    carrier_tile_shape: tuple[object, ...] | None,
    carrier_tile_index_nodes: tuple[torch.fx.Node, ...] | None,
    safe_group_node: torch.fx.Node,
    safe_group_layout_load_node: torch.fx.Node,
) -> tuple[torch.fx.Node, torch.fx.Node, torch.fx.Node] | None:
    """Return exact ``(row_load, row_eq, row_mask)`` metadata."""

    mask_info = _rank1_mask_from_broadcast(
        condition,
        carrier_tile_shape=carrier_tile_shape,
        data_axis=0,
    )
    if mask_info is None:
        return None
    row_mask, row_mask_val = mask_info
    if (
        row_mask.op != "call_function"
        or row_mask.target is not torch.ops.aten.eq.Tensor
        or row_mask.kwargs
        or len(row_mask.args) != 2
    ):
        return None
    lhs, rhs = row_mask.args
    if lhs is safe_group_node and isinstance(rhs, torch.fx.Node):
        row_load = rhs
    elif rhs is safe_group_node and isinstance(lhs, torch.fx.Node):
        row_load = lhs
    else:
        return None
    load_args = _unmasked_helion_load_args(row_load)
    if load_args is None:
        return None
    row_tensor_node, index_list = load_args
    safe_tensor_node = (
        safe_group_layout_load_node.args[0]
        if safe_group_layout_load_node.args
        else None
    )
    load_val = row_load.meta.get("val")
    if (
        row_tensor_node is not safe_tensor_node
        or not isinstance(load_val, torch.Tensor)
        or load_val.ndim != 1
        or tuple(load_val.shape) != tuple(row_mask_val.shape)
        or not isinstance(index_list, (list, tuple))
        or len(index_list) != 1
        or not isinstance(index_list[0], torch.fx.Node)
    ):
        return None
    if carrier_tile_index_nodes is None or len(carrier_tile_index_nodes) != 2:
        return None
    if index_list[0] is not carrier_tile_index_nodes[0]:
        return None
    return row_load, row_mask, condition


def _split_grouped_tail_condition(
    condition: torch.fx.Node,
    *,
    carrier_tile_shape: tuple[object, ...] | None,
    carrier_tile_index_nodes: tuple[torch.fx.Node, ...] | None,
    safe_group_node: torch.fx.Node,
    safe_group_layout_load_node: torch.fx.Node,
) -> (
    tuple[
        tuple[torch.fx.Node, torch.fx.Node, torch.fx.Node] | None,
        tuple[
            torch.Tensor,
            torch.fx.Node,
            torch.fx.Node,
            torch.fx.Node,
            torch.fx.Node,
        ]
        | None,
        tuple[torch.fx.Node, ...],
    ]
    | None
):
    """Classify row-only, column-only, or row-and-column preserve masks."""

    row_info = _matches_grouped_m_row_mask(
        condition,
        carrier_tile_shape=carrier_tile_shape,
        carrier_tile_index_nodes=carrier_tile_index_nodes,
        safe_group_node=safe_group_node,
        safe_group_layout_load_node=safe_group_layout_load_node,
    )
    if row_info is not None:
        return row_info, None, ()
    col_info = _matches_grouped_n_col_mask(
        condition,
        carrier_tile_shape=carrier_tile_shape,
        carrier_tile_index_nodes=carrier_tile_index_nodes,
        safe_group_node=safe_group_node,
    )
    if col_info is not None:
        return None, col_info, ()
    if (
        condition.op != "call_function"
        or condition.target
        not in (
            operator.and_,
            torch.ops.aten.bitwise_and.Tensor,
            torch.ops.aten.logical_and.default,
        )
        or condition.kwargs
        or len(condition.args) != 2
        or not isinstance(condition.args[0], torch.fx.Node)
        or not isinstance(condition.args[1], torch.fx.Node)
    ):
        return None
    cond_val = condition.meta.get("val")
    if (
        not isinstance(cond_val, torch.Tensor)
        or cond_val.dtype is not torch.bool
        or carrier_tile_shape is None
        or tuple(cond_val.shape) != tuple(carrier_tile_shape)
    ):
        return None
    left = condition.args[0]
    right = condition.args[1]
    assert isinstance(left, torch.fx.Node)
    assert isinstance(right, torch.fx.Node)
    left_row = _matches_grouped_m_row_mask(
        left,
        carrier_tile_shape=carrier_tile_shape,
        carrier_tile_index_nodes=carrier_tile_index_nodes,
        safe_group_node=safe_group_node,
        safe_group_layout_load_node=safe_group_layout_load_node,
    )
    left_col = _matches_grouped_n_col_mask(
        left,
        carrier_tile_shape=carrier_tile_shape,
        carrier_tile_index_nodes=carrier_tile_index_nodes,
        safe_group_node=safe_group_node,
    )
    right_row = _matches_grouped_m_row_mask(
        right,
        carrier_tile_shape=carrier_tile_shape,
        carrier_tile_index_nodes=carrier_tile_index_nodes,
        safe_group_node=safe_group_node,
        safe_group_layout_load_node=safe_group_layout_load_node,
    )
    right_col = _matches_grouped_n_col_mask(
        right,
        carrier_tile_shape=carrier_tile_shape,
        carrier_tile_index_nodes=carrier_tile_index_nodes,
        safe_group_node=safe_group_node,
    )
    if left_row is not None and right_col is not None:
        return left_row, right_col, (condition,)
    if left_col is not None and right_row is not None:
        return right_row, left_col, (condition,)
    return None


def _matches_output_tile_load(
    candidate: torch.fx.Node,
    *,
    store_node: torch.fx.Node,
    output_dtype: torch.dtype,
    carrier_tile_shape: tuple[object, ...] | None,
    carrier_index_nodes: tuple[torch.fx.Node, ...] | None,
) -> bool:
    load_args = _unmasked_helion_load_args(candidate)
    if load_args is None:
        return False
    false_tensor_node, false_index = load_args
    if not isinstance(false_tensor_node, torch.fx.Node):
        return False
    store_tensor_node = store_node.args[0] if store_node.args else None
    if not isinstance(store_tensor_node, torch.fx.Node):
        return False
    if false_tensor_node is not store_tensor_node:
        return False
    false_tensor = false_tensor_node.meta.get("val")
    false_val = candidate.meta.get("val")
    if (
        not isinstance(false_tensor, torch.Tensor)
        or not isinstance(false_val, torch.Tensor)
        or carrier_tile_shape is None
        or tuple(false_val.shape) != tuple(carrier_tile_shape)
    ):
        return False
    if false_tensor.dtype is not output_dtype:
        return False
    return carrier_index_nodes is not None and _argument_sequence_matches_nodes(
        false_index,
        carrier_index_nodes,
    )


def analyze_tcgen05_grouped_tail_epilogue(
    value_node: torch.fx.Node,
    *,
    safe_group_node: torch.fx.Node,
    safe_group_layout_load_node: torch.fx.Node,
    store_node: torch.fx.Node,
    target_fx_node: torch.fx.Node,
    inner_outputs_by_graph_id: dict[int, tuple[torch.fx.Node | None, ...]],
) -> Tcgen05GroupedTailEpilogueMatch | None:
    """Classify grouped preserve-output tails before or after store folding."""

    # fold_noop_stores replaces the old-output where branch with an explicit
    # store mask. Prove that exact mask here; the store renderer may consume
    # only the mask attached to this matched store node.
    store_mask = store_node.args[3] if len(store_node.args) == 4 else None
    if store_mask is not None:
        if (
            store_node.kwargs
            or not isinstance(store_mask, torch.fx.Node)
            or store_node.args[2] is not value_node
        ):
            return None
        condition, true_branch, false_branch = store_mask, value_node, None
    else:
        if (
            value_node.op != "call_function"
            or value_node.target is not torch.ops.aten.where.self
            or value_node.kwargs
            or len(value_node.args) != 3
        ):
            return None
        condition, true_branch, false_branch = value_node.args
        if not (
            isinstance(condition, torch.fx.Node)
            and isinstance(true_branch, torch.fx.Node)
            and isinstance(false_branch, torch.fx.Node)
        ):
            return None

    true_convert = _convert_input_and_dtype(true_branch)
    if true_convert is None:
        return None
    carrier, true_dtype = true_convert
    carrier_tile_shape = _carrier_tile_shape(carrier)
    carrier_index_nodes = _carrier_tile_index_nodes(carrier)
    grouped_tail_info = _split_grouped_tail_condition(
        condition,
        carrier_tile_shape=carrier_tile_shape,
        carrier_tile_index_nodes=carrier_index_nodes,
        safe_group_node=safe_group_node,
        safe_group_layout_load_node=safe_group_layout_load_node,
    )
    if grouped_tail_info is None:
        return None
    row_info, grouped_n_info, and_nodes = grouped_tail_info
    if false_branch is not None:
        if not _matches_output_tile_load(
            false_branch,
            store_node=store_node,
            output_dtype=true_dtype,
            carrier_tile_shape=carrier_tile_shape,
            carrier_index_nodes=carrier_index_nodes,
        ):
            return None
    else:
        target = store_node.args[0]
        target_val = (
            target.meta.get("val") if isinstance(target, torch.fx.Node) else None
        )
        value_val = value_node.meta.get("val")
        if (
            not isinstance(target_val, torch.Tensor)
            or target_val.ndim != 2
            or target_val.dtype is not true_dtype
            or not isinstance(value_val, torch.Tensor)
            or value_val.dtype is not true_dtype
            or carrier_tile_shape is None
            or tuple(value_val.shape) != tuple(carrier_tile_shape)
        ):
            return None
    if carrier_index_nodes is None:
        return None
    store_index = store_node.args[1] if len(store_node.args) >= 2 else None
    if not _argument_sequence_matches_nodes(store_index, carrier_index_nodes):
        return None

    anchor = walk_carrier_to_tcgen05_matmul(
        carrier,
        {target_fx_node},
        inner_outputs_by_graph_id,
    )
    if anchor is None:
        return None

    expected_users: list[tuple[torch.fx.Node, set[torch.fx.Node]]] = []
    producer_nodes: list[torch.fx.Node] = []
    mask_user = store_node if store_mask is not None else value_node
    if row_info is not None:
        row_load, row_mask, row_broadcast = row_info
        row_mask_user = and_nodes[0] if and_nodes else mask_user
        expected_users.extend(
            [
                (row_load, {row_mask}),
                (row_mask, {row_broadcast}),
                (row_broadcast, {row_mask_user}),
            ]
        )
        producer_nodes.extend([row_load, row_mask, row_broadcast])
    n_sizes: torch.Tensor | None = None
    n_load: torch.fx.Node | None = None
    tile_index: torch.fx.Node | None = None
    if grouped_n_info is not None:
        n_sizes, n_load, col_mask, col_broadcast, tile_index = grouped_n_info
        expected_users.extend(
            [
                (tile_index, {col_mask}),
                (n_load, {col_mask}),
                (col_mask, {col_broadcast}),
                (
                    col_broadcast,
                    {and_nodes[0]} if and_nodes else {mask_user},
                ),
            ]
        )
        producer_nodes.extend([tile_index, n_load, col_mask, col_broadcast])
    if and_nodes:
        expected_users.append((and_nodes[0], {mask_user}))
        producer_nodes.extend(and_nodes)
    else:
        expected_users.append((condition, {mask_user}))
        if condition not in producer_nodes:
            producer_nodes.append(condition)
    if false_branch is not None:
        expected_users.append((false_branch, {value_node}))
    expected_users.append((value_node, {store_node}))
    for node, users in expected_users:
        if set(node.users) != users:
            return None
    if false_branch is not None:
        producer_nodes.append(false_branch)
    producer_nodes.append(value_node)
    return Tcgen05GroupedTailEpilogueMatch(
        anchor=anchor,
        store_node=store_node,
        producer_nodes=tuple(producer_nodes),
        n_sizes_tensor=n_sizes,
        safe_group_node=safe_group_node,
        has_m_tail_mask=row_info is not None,
        has_n_tail_mask=grouped_n_info is not None,
        store_mask=store_mask,
    )


def find_tcgen05_grouped_tail_epilogue_for_mma(
    mma_node: torch.fx.Node,
    graphs: Iterable[GraphInfo],
    *,
    safe_group_node: torch.fx.Node,
    safe_group_layout_load_node: torch.fx.Node,
) -> Tcgen05GroupedTailEpilogueMatch | None:
    """Find the unique semantic grouped tail preserve-output store."""

    from ...language import memory_ops

    graph_infos = list(graphs)
    graph_id_of: dict[torch.fx.Graph, int] = {}
    for_loop_calls_by_graph_id: dict[int, list[torch.fx.Node]] = {}
    for graph_info in graph_infos:
        graph_id_of[graph_info.graph] = graph_info.graph_id
        for node in graph_info.graph.nodes:
            if (
                node.op == "call_function"
                and _tracing_ops.is_for_loop_target(node.target)
                and node.args
                and isinstance(node.args[0], int)
            ):
                for_loop_calls_by_graph_id.setdefault(node.args[0], []).append(node)

    inner_outputs_by_graph_id = build_inner_outputs_index_from_graphs(graph_infos)
    found: list[Tcgen05GroupedTailEpilogueMatch] = []
    visited: set[torch.fx.Node] = set()
    stack: list[torch.fx.Node] = [mma_node]
    while stack:
        cur = stack.pop()
        if cur in visited:
            continue
        visited.add(cur)
        for user in cur.users:
            if user.op == "output":
                graph_id = graph_id_of.get(cur.graph)
                if graph_id is None:
                    return None
                output_args = user.args[0] if user.args else None
                out_indices = _argument_sequence_indices_of(output_args, cur)
                if out_indices is None:
                    return None
                if not out_indices:
                    return None
                for outer_call in for_loop_calls_by_graph_id.get(graph_id, []):
                    for outer_user in outer_call.users:
                        if (
                            outer_user.op == "call_function"
                            and outer_user.target is operator.getitem
                            and len(outer_user.args) >= 2
                            and outer_user.args[1] in out_indices
                            and outer_user not in visited
                        ):
                            stack.append(outer_user)
                continue
            if user.op != "call_function":
                return None
            if user.target is memory_ops.store:
                value = user.args[2] if len(user.args) > 2 else None
                if not isinstance(value, torch.fx.Node):
                    return None
                grouped_tail = analyze_tcgen05_grouped_tail_epilogue(
                    value,
                    safe_group_node=safe_group_node,
                    safe_group_layout_load_node=safe_group_layout_load_node,
                    store_node=user,
                    target_fx_node=mma_node,
                    inner_outputs_by_graph_id=inner_outputs_by_graph_id,
                )
                if grouped_tail is None:
                    return None
                found.append(grouped_tail)
                continue
            if user.target in (
                _tracing_ops._phi,
                _tracing_ops._new_var,
                operator.getitem,
                torch.ops.prims.convert_element_type.default,
                torch.ops.aten.where.self,
            ):
                stack.append(user)
                continue
            return None

    if len(found) != 1:
        return None
    return found[0]
