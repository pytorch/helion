"""CuTe-backend codegen for the atomic ops defined in ``helion.language.atomic_ops``.

Backend-specific codegen bodies live here (not in the backend-neutral language
module).  Importing this module runs the ``@_decorators.codegen(op, "cute")``
registrations; ``atomic_ops`` imports it at the bottom so registration keeps the
same eager timing as before.
"""

from __future__ import annotations

import ast
import math
from typing import TYPE_CHECKING

import torch
from torch.utils import _pytree as pytree

from ... import exc
from ...language import _decorators
from ...language import _tracing_ops
from ...language.atomic_ops import ATOMIC_OPS
from ...language.atomic_ops import _to_ast_values
from ...language.atomic_ops import atomic_add
from ...language.atomic_ops import atomic_and
from ...language.atomic_ops import atomic_cas
from ...language.atomic_ops import atomic_max
from ...language.atomic_ops import atomic_min
from ...language.atomic_ops import atomic_or
from ...language.atomic_ops import atomic_xchg
from ...language.atomic_ops import atomic_xor
from ..ast_extension import expr_from_string
from ..ast_extension import statement_from_string
from ..ast_read_writes import HELION_ATOMIC_UNIFORM_LANES_ATTR
from ..ast_read_writes import HELION_FENCE_BARRIER_ATTR
from ..ast_read_writes import ReadWrites
from ..compile_environment import _symint_expr
from ..host_function import HostFunction
from ..variable_origin import GridOrigin
from ..variable_origin import NameOrigin
from .cute_reshape import cute_lane_loops_active
from .cute_reshape import describe_rebound_block_dims
from .cute_reshape import subscript_rebound_block_dims
from .thread_budget import MAX_THREADS_PER_BLOCK

if TYPE_CHECKING:
    from collections.abc import Iterable

    from ..inductor_lowering import CodegenState
    from ..tile_strategy import DeviceLoopOrGridState

# Lane counts of the ``red.global.add.v{N}.f32`` forms (8 and 16 bytes).
_CUTE_VECTOR_ATOMIC_WIDTHS = (2, 4)
# ``red.global.add.v{2,4}.f32`` is an sm_90+ PTX form.
_CUTE_VECTOR_ATOMIC_MIN_CAPABILITY = (9, 0)


def _cute_coord_pointer_expr(name: str, index_exprs: list[str]) -> str:
    coord = (
        f"({index_exprs[0]},)"
        if len(index_exprs) == 1
        else f"({', '.join(index_exprs)})"
    )
    return f"({name}.iterator + cute.crd2idx({coord}, {name}.layout)).llvm_ptr"


def _resolve_cute_atomic_kwargs(cute_func: str, requested: list[str]) -> list[str]:
    """Map our intended ``cute.arch.<cute_func>`` kwarg names onto whatever
    the live signature actually exposes.

    Helion's emitted code refers to ``cute.arch.atomic_*`` parameters by
    name (``val``, ``cmp``). Some nvidia-cutlass-dsl wheels have shipped
    with these renamed (e.g. ``val`` -> ``value``); the old emission
    style then trips a ``TypeError`` deep inside CUTLASS at run time.
    Probe the signature at codegen time and rewrite the kwarg names to
    match what the live wrapper accepts. Falls back to the requested
    name when none of the rename candidates appears, so healthy installs
    are unaffected.
    """
    import inspect

    try:
        import cutlass.cute as cute  # type: ignore[import-not-found]
    except ImportError:
        return list(requested)
    func = getattr(getattr(cute, "arch", None), cute_func, None)
    if func is None:
        return list(requested)
    try:
        params = set(inspect.signature(func).parameters)
    except (TypeError, ValueError):
        return list(requested)
    rename_candidates: dict[str, tuple[str, ...]] = {
        "val": ("val", "value", "rhs", "src", "a"),
        "cmp": ("cmp", "compare", "expected", "exp"),
    }
    resolved: list[str] = []
    for name in requested:
        candidates = rename_candidates.get(name, (name,))
        chosen = next((c for c in candidates if c in params), name)
        resolved.append(chosen)
    return resolved


_CUTE_BLOCK_BARRIER = "cute.arch.sync_threads()"

_CUTE_FLOAT_ATOMIC_HELPERS: dict[str, str] = {
    "atomic_max": "_cute_atomic_max_float32",
    "atomic_min": "_cute_atomic_min_float32",
}


def _cute_atomic_callee(cute_func: str, target_dtype_torch: torch.dtype) -> str:
    """Pick the callee for a CuTe atomic op.

    NVVM/PTX has no native ``atom.max``/``atom.min`` for floating point, so
    float ``atomic_max``/``atomic_min`` are routed through runtime helpers that
    emulate them with integer atomics (registered in
    ``CuteBackend.library_imports``). All other ops, and integer max/min, use
    the native ``cute.arch.<func>`` directly.
    """
    helper = _CUTE_FLOAT_ATOMIC_HELPERS.get(cute_func)
    if helper is None or not target_dtype_torch.is_floating_point:
        return f"cute.arch.{cute_func}"
    if target_dtype_torch is not torch.float32:
        raise exc.BackendUnsupported(
            "cute",
            f"{cute_func} on floating-point dtype {target_dtype_torch} "
            "(only float32 is supported)",
        )
    return helper


def _codegen_common_cute(
    cute_func: str,
    state: CodegenState,
    *,
    value_exprs: list[ast.AST],
    keyword_names: list[str],
) -> ast.AST:
    # A thread's release / acquire orders only that thread's accesses, while
    # Helion's memory orders act for the whole program, as the Triton backend
    # implements them: a bar.sync before every release (``tl.debug_barrier``
    # in ``_sync_before_release``) and after every acquire whose result is not
    # broadcast behind one already (``_sync_after_acquire``), per-element
    # atomics included.  So a CTA barrier puts every thread's earlier
    # accesses before the release, whether each thread issues the RMW for its
    # own elements or one leader thread issues it for the elements a tile axis
    # shares, and every thread's later accesses after the acquire.  Every
    # thread reaches it: the atomics' guards wrap single accesses, never the
    # statement structure, and lane loops run the same trip counts on every
    # thread (the lane-loop placement moves the barrier with the atomic,
    # ``HELION_FENCE_BARRIER_ATTR``).  A branch or while loop may not: its
    # condition can differ between SIMT threads.  Warp-specialized tcgen05
    # bodies, whose roles no CTA barrier may separate, refuse such atomics
    # (``reject_atomics_beside_warp_roles``).
    from .memory_ops import reject_reads_of_collective_placeholders

    sem = state.proxy_arg(len(state.ast_args) - 1)
    reject_reads_of_collective_placeholders(state, "an atomic")
    statements = state.codegen.statements_stack[-1]
    start = len(statements)
    result = _codegen_cute_atomic_rmw(
        cute_func, state, value_exprs=value_exprs, keyword_names=keyword_names
    )
    if sem == "relaxed":
        return result
    if state.codegen.divergent_control_flow_depth > 0:
        raise exc.BackendUnsupported(
            "cute",
            f"a {sem} {cute_func} inside a branch or while loop: the "
            "block-wide barrier ordering the other threads' accesses around "
            "it cannot be placed where a thread may skip it",
        )
    if sem in ("release", "acq_rel"):
        # Recorded like any statement of the atomic's, then moved before it.
        barrier = _cute_fence_barrier("release")
        state.add_statement(barrier)
        statements.insert(start, statements.pop())
    if sem in ("acquire", "acq_rel"):
        if not (isinstance(result, ast.Constant) and result.value is None):
            result = state.codegen.lift(result, prefix="atomic_old")
        # A broadcast of the leader's result already ends in a barrier.
        if ast.unparse(statements[-1]) != _CUTE_BLOCK_BARRIER:
            state.add_statement(_cute_fence_barrier("acquire"))
    return result


def reject_atomics_beside_warp_roles(*, ctas_per_tile: str | None) -> None:
    """Refuse the kernel's atomics a warp-specialized tcgen05 matmul would misplace.

    Its warp roles (TMA producer, MMA issuer, epilogue) each walk the tiles in
    their own loop, and the body's other statements stay outside those loops,
    run once per CTA.  A release / acquire atomic there needs a block-wide
    barrier (``_codegen_common_cute``), which would separate roles that wait
    on each other through their pipelines: a deadlock.  A relaxed atomic adds
    once per CTA, which is once per tile only when every tile has exactly one
    CTA; ``ctas_per_tile`` says why it has not (CTAs walking several tiles, or
    a two-CTA pair sharing one), None when it has.
    """
    from ..host_function import HostFunction

    for graph in HostFunction.current().device_ir.graphs:
        for node in graph.graph.nodes:
            if node.op != "call_function" or node.target not in ATOMIC_OPS:
                continue
            name = node.target.__name__
            sem = node.args[-1]
            if sem != "relaxed":
                raise exc.BackendUnsupported(
                    "cute",
                    f"a {sem} hl.{name} in a warp-specialized tcgen05 matmul: the "
                    "block-wide barrier ordering it would separate the warp roles",
                )
            if ctas_per_tile is not None:
                raise exc.BackendUnsupported(
                    "cute",
                    f"hl.{name} in a tcgen05 matmul whose {ctas_per_tile}: it "
                    "would run once per CTA, not once per tile",
                )


def _cute_fence_barrier(role: str) -> ast.stmt:
    """A release (before the atomic) or acquire (after it) block barrier."""
    barrier = statement_from_string(_CUTE_BLOCK_BARRIER)
    setattr(barrier, HELION_FENCE_BARRIER_ATTR, role)
    return barrier


def _codegen_cute_atomic_rmw(
    cute_func: str,
    state: CodegenState,
    *,
    value_exprs: list[ast.AST],
    keyword_names: list[str],
) -> ast.AST:
    from ..compile_environment import CompileEnvironment

    target = state.proxy_arg(0)
    index = state.proxy_arg(1)
    sem = expr_from_string(repr(state.proxy_arg(len(state.ast_args) - 1)))

    assert isinstance(target, torch.Tensor)
    assert isinstance(index, list)

    host_function = HostFunction.current()
    if target not in host_function.tensor_to_origin:
        raise exc.AtomicOnDeviceTensor(cute_func)
    # The established slice / axis diagnostics first ("atomic slice and
    # update value use distinct tile axes"), then the operands between the
    # index and the memory order: ``val`` (and ``expected`` for atomic_cas).
    # A tile whose dim the subscript binds to another block id
    # (``hl.atomic_add(out, [tile_m, tile_n], x[...].T)``, or a lower-rank
    # value right-aligned to the index as ``tl.atomic_*`` receives it) would
    # need another thread's element; the per-thread RMW has no exchange.
    indexed_block_ids = _cute_atomic_indexed_blocks(state, index)
    for position in range(2, len(state.ast_args) - 1):
        operand = state.proxy_arg(position)
        if not isinstance(operand, torch.Tensor) or operand.ndim == 0:
            continue
        rebound = subscript_rebound_block_dims(
            state, target, index, operand, value_index=position, what=cute_func
        )
        if rebound:
            raise exc.BackendUnsupported(
                "cute",
                f"{cute_func} of {list(operand.shape)} re-binds "
                f"{describe_rebound_block_dims(rebound)}; the value must be "
                "held by the thread that owns the destination lane",
            )

    backend = CompileEnvironment.current().backend
    target_dtype = backend.dtype_str(target.dtype)
    callee = _cute_atomic_callee(cute_func, target.dtype)
    cast_value_exprs = [
        expr_from_string(
            backend.ast_to_dtype_expr("{value}", target_dtype),
            value=value_expr,
        )
        for value_expr in value_exprs
    ]
    extra_predicates: list[str] = []
    relaxed = state.proxy_arg(len(state.ast_args) - 1) == "relaxed"
    # The single-tensor-index forms below index their values per element and
    # keep their own guards; the elision applies to the relaxed pointer form
    # only (a release / acquire RMW is a fence-carrying write in the cell's
    # modification order and is never skipped).
    elision = (
        _cute_where_zero_elision(state, target)
        if cute_func == "atomic_add" and relaxed and len(index) > 1
        else None
    )
    if elision is not None:
        # ``atomic_add(t, i, where(c, x, 0))``: add ``x`` under ``c`` and skip
        # the exact zeros (see ``_cute_where_zero_elision`` for the proof).
        predicate, kept = elision
        extra_predicates.append(predicate)
        cast_value_exprs = [
            expr_from_string(
                backend.ast_to_dtype_expr("{value}", target_dtype), value=kept
            )
        ]
    tensor_index_stmt = _codegen_tensor_index_common_cute(
        cute_func,
        state,
        target,
        index,
        sem,
        cast_value_exprs,
        keyword_names,
        callee,
        extra_predicates=extra_predicates,
    )
    if tensor_index_stmt is not None:
        return tensor_index_stmt
    from ...language.memory_ops import _cute_access_regions
    from ...language.memory_ops import _cute_index_exprs
    from ...language.memory_ops import _cute_tag_access_regions

    ast_index = state.ast_args[1]
    assert isinstance(ast_index, (list, tuple))
    index_exprs = _cute_index_exprs(
        state, index, ast_index, tensor=target, for_store=True
    )
    tensor_name = state.device_function.tensor_arg(target).name
    pointer = _cute_coord_pointer_expr(tensor_name, index_exprs)
    resolved_kwargs = _resolve_cute_atomic_kwargs(cute_func, keyword_names)
    values_section = ", ".join(
        f"{actual}={{{intent}}}"
        for intent, actual in zip(keyword_names, resolved_kwargs, strict=True)
    )
    placeholders = dict(zip(keyword_names, cast_value_exprs, strict=True))
    atomic_expr = expr_from_string(
        f"{callee}({{ptr}}, {values_section}, sem={{sem}})",
        ptr=expr_from_string(pointer),
        sem=sem,
        **placeholders,
    )
    # The elements the atomic touches, for the barrier analysis
    # (``lane_loop_distribution``), like a store's.
    _cute_tag_access_regions(
        atomic_expr, tensor_name, _cute_access_regions(state, index, target)
    )
    if (
        cute_func == "atomic_add"
        and relaxed
        and _cute_vector_atomic_site(
            state,
            target,
            index,
            index_exprs,
            cast_value_exprs[0],
            atomic_expr,
            _cute_atomic_predicates(
                state,
                index,
                extra_predicates,
                atomic_expr,
                indexed_block_ids=indexed_block_ids,
            )[0],
        )
    ):
        return ast.Constant(value=None)
    return _guard_cute_atomic_expr(
        state,
        index,
        target_dtype,
        atomic_expr,
        extra_predicates=extra_predicates,
        indexed_block_ids=indexed_block_ids,
    )


def _cute_atomic_predicates(
    state: CodegenState,
    index: list[object],
    extra_predicates: list[str] | None,
    atomic_expr: ast.AST | None = None,
    *,
    indexed_block_ids: set[int] | None,
) -> tuple[list[str], set[int]]:
    """The guards of an atomic at this site (bounds masks of the covered
    axes, leader threads of the uncovered ones, and any caller-supplied
    predicate) and the leader axes; records the lanes the atomic is uniform
    along on ``atomic_expr`` for the lane-loop placement.
    ``indexed_block_ids`` is the caller's ``_cute_atomic_indexed_blocks(state,
    index)`` (``None`` when the coverage is unknown)."""
    leader_axes = _cute_unindexed_leader_axes(state, indexed_block_ids)
    if indexed_block_ids is None:
        # Without a known coverage, a tile attribute in the index
        # (``tile.begin``) still names the thread axis of its block as one
        # the atomic does not vary along.
        leader_axes |= _cute_leader_thread_axes(state, index)
    if atomic_expr is not None:
        setattr(
            atomic_expr,
            HELION_ATOMIC_UNIFORM_LANES_ATTR,
            _cute_uniform_lane_vars(state, indexed_block_ids),
        )
    return [
        predicate
        for predicate in (
            _cute_active_mask_predicate(state, indexed_block_ids),
            _cute_leader_predicate(leader_axes),
            *(extra_predicates or []),
        )
        if predicate is not None
    ], leader_axes


def _cute_literal_positive_zero(node: object) -> bool:
    """Whether ``node`` is a literal ``+0`` operand of a ``where``: a Python
    ``0`` / ``0.0`` (not ``-0.0``, not a bool) or a ``scalar_tensor`` of one.
    A computed zero never qualifies."""
    from torch.fx.node import Node

    value: object = node
    if isinstance(node, Node):
        if node.target is not torch.ops.aten.scalar_tensor.default or not node.args:
            return False
        value = node.args[0]
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        return False
    return value == 0 and math.copysign(1.0, float(value)) > 0


def _cute_where_zero_elision(
    state: CodegenState, target: torch.Tensor
) -> tuple[str, ast.AST] | None:
    """``(predicate, x)`` when the relaxed ``atomic_add(t, i, where(c, x, 0))``
    may skip the zero lanes and add ``x`` under ``c`` alone; ``None`` fails
    closed.  The caller admits relaxed atomics only.

    (a) The ``where``'s other operand is the literal ``+0`` (a Python zero or
        a ``scalar_tensor`` of one); ``-0.0`` and computed zeros never
        qualify.
    (b) The atomic's old value is unused.
    (c) ``x`` already has the ``where``'s dtype and both ``where`` operands
        are generated names (``state.env``), so the predicate and the addend
        can be spelled at the site.
    (d) Integer target: nothing else.  Adding ``0`` to an integer is exact,
        so the elision is always on.
    (e) Floating target: only under the ``fast_math`` setting, and only into
        a private zero-filled sum
        (``_cute_atomic_target_is_private_zero_filled_sum``).  There is no
        bit-exact proof for floats: ``atom/red.global.add.f32`` flushes
        subnormal inputs and results to a signed zero and canonicalises NaNs
        (measured on sm_100; the Triton backend emits the same op), so adding
        ``+0.0`` rewrites a ``-0.0`` cell to ``+0.0``, a subnormal cell to a
        signed zero and a NaN payload to the canonical NaN, and a zeros-filled
        cell written only by atomic adds CAN hold ``-0.0`` (a negative result
        that underflows is flushed to ``-0.0``).  The private-sum proof buys
        admissibility instead: the target starts at ``+0.0`` and every write
        is an atomic add.  Across threads the interleaving of a kernel's
        atomics is unspecified, so scheduling every skipped ``+0.0`` add
        first (``+0.0 + +0.0 = +0.0``, exact) shows the elided result is one
        the unelided kernel may produce.  Within one thread the skipped add
        stays program-ordered after that thread's earlier adds to the cell
        (PTX orders one thread's accesses to one location), so when those
        adds have underflowed to ``-0.0`` the unelided kernel flushes the
        cell to ``+0.0`` and the elided one leaves ``-0.0``.  That sign of a
        zero reached by underflow is the residual, and it is what
        ``fast_math`` accepts.

    The non-zero adds and their interleaving are unchanged.  When the atomic
    is the ``where``'s only user the dead select is removed from the body.
    """
    from torch.fx.node import Node

    from ..compile_environment import CompileEnvironment

    fx_node = state.fx_node
    if fx_node is None or len(fx_node.args) < 3 or len(fx_node.users) != 0:
        return None
    value_node = fx_node.args[2]
    if (
        not isinstance(value_node, Node)
        or value_node.target is not torch.ops.aten.where.self
        or len(value_node.args) != 3
    ):
        return None
    condition, on_true, on_false = value_node.args
    if not isinstance(condition, Node):
        return None
    kept, negate = on_true, False
    if not _cute_literal_positive_zero(on_false):
        kept, negate = on_false, True
        if not _cute_literal_positive_zero(on_true):
            return None
    if not isinstance(kept, Node):
        return None
    if target.dtype is torch.bool or target.dtype.is_complex:
        return None
    where_value = value_node.meta.get("val")
    kept_value = kept.meta.get("val")
    if (
        not isinstance(where_value, torch.Tensor)
        or not isinstance(kept_value, torch.Tensor)
        or where_value.dtype != kept_value.dtype
    ):
        return None
    if target.dtype.is_floating_point and not (
        CompileEnvironment.current().settings.fast_math
        and _cute_atomic_target_is_private_zero_filled_sum(state, target)
    ):
        return None
    condition_ast = state.env.get(condition)
    kept_ast = state.env.get(kept)
    if not isinstance(condition_ast, ast.AST) or not isinstance(kept_ast, ast.AST):
        return None
    if len(value_node.users) == 1:
        state.codegen.remove_statements_owned_by_nodes((value_node,))
    predicate = ast.unparse(condition_ast)
    if negate:
        predicate = f"not ({predicate})"
    return predicate, kept_ast


def _cute_atomic_target_is_private_zero_filled_sum(
    state: CodegenState, target: torch.Tensor
) -> bool:
    """Whether ``target`` is a private sum that starts at ``+0.0`` and is only
    ever written by atomic adds while the kernel runs.

    The storage is a wrapper allocation filled with ``+0``
    (``CompileEnvironment.tensor_storage_is_zero_filled_allocation``), its
    host binding is private until the launch (``private_fresh_host_bindings``:
    bound once, never aliased, only metadata reads, the atomic destination and
    the return), and every device use of that storage is a load or the
    destination of an ``atomic_add``.  This is the premise of the
    admissible-interleaving argument in ``_cute_where_zero_elision``; it does
    not (and under flush-to-zero atomics cannot) exclude ``-0.0`` cells.
    """
    from ...language.memory_ops import load as language_load
    from ..compile_environment import CompileEnvironment
    from .atomic_output_promotions import private_fresh_host_bindings

    env = CompileEnvironment.current()
    if not env.tensor_storage_is_zero_filled_allocation(target):
        return False
    host_fn = HostFunction.current()
    origin = host_fn.tensor_to_origin.get(target)
    if type(origin) is not NameOrigin:
        return False
    if origin.name not in private_fresh_host_bindings(host_fn.body, {origin.name}):
        return False
    storages = {target.untyped_storage()}
    for graph_info in host_fn.device_ir.graphs:
        for node in graph_info.graph.nodes:
            if (
                node.op != "call_function"
                or node.target is not _tracing_ops._host_tensor
            ):
                continue
            value = node.meta.get("val")
            if (
                not isinstance(value, torch.Tensor)
                or value.untyped_storage() not in storages
            ):
                continue
            for user in node.users:
                if (
                    user.op != "call_function"
                    or not user.args
                    or user.args[0] is not node
                ):
                    return False
                if user.target is language_load:
                    continue
                if user.target is atomic_add and not any(
                    leaf is node for leaf in pytree.tree_leaves(user.args[1:])
                ):
                    continue
                return False
    return True


def _cute_lane_varying_names(
    statements: Iterable[ast.AST], seeds: Iterable[str]
) -> set[str]:
    """Names whose values may differ between the lanes of a constexpr vector
    loop: ``seeds`` (its lane variable, the per-element index) and everything
    defined from them, transitively through the given statements."""
    varying = set(seeds)
    analysed = [ReadWrites.from_ast(stmt) for stmt in statements]
    changed = True
    while changed:
        changed = False
        for rw in analysed:
            if set(rw.reads) & varying and not set(rw.writes) <= varying:
                varying |= set(rw.writes)
                changed = True
    return varying


def _cute_vector_atomic_site(
    state: CodegenState,
    target: torch.Tensor,
    index: list[object],
    index_exprs: list[str],
    value_expr: ast.AST,
    atomic_expr: ast.AST,
    predicates: list[str],
) -> bool:
    """Defer a per-lane fp32 ``atomic_add`` along a vectorized tile axis to one
    ``red.global.add.v{V}.f32`` after the constexpr V-loop.

    The site follows the vector store protocol
    (``_cute_register_tile_unroll_vec_store``): the scalar atomic is emitted
    now and, when ``DeviceGridState.wrap_body`` confirms the V-loop is the
    innermost live lane loop with no barrier in the body, replaced by an
    append onto a trace-time list that one flush after the V-loop reduces.
    Admitted only on sm_90+ targets (the PTX form's minimum; unknown or lower
    capabilities keep the scalar atomic), when the atomic's old value is
    unused, the lane axis is the target's stride-1 dim indexed by the plain
    per-element index of a grid block with a vector partition, the packet is
    naturally aligned (``cute_reduction_vector_layout_aligned`` plus a
    zero-origin tile whose extent is a multiple of ``V``), and every other
    coordinate and every guard is uniform across the V lanes.  Returns whether
    the site was deferred (the caller then emits nothing else).
    """
    from ...language.memory_ops import _cute_active_index_var
    from ...language.memory_ops import _cute_lane_vloop_insert_pos
    from ..compile_environment import CompileEnvironment
    from ..tile_strategy import DeviceGridState
    from .memory_ops import _cute_defer_grid_vector_op
    from .memory_ops import _cute_lane_strategy
    from .memory_ops import _cute_tile_axis_block_id
    from .memory_ops import cute_reduction_vector_layout_aligned

    fx_node = state.fx_node
    if (
        fx_node is None
        or len(fx_node.users) != 0
        or target.dtype is not torch.float32
        or len(index) != target.ndim
        or len(index_exprs) != target.ndim
        or "None" in index_exprs
    ):
        return False
    # Fail closed to the scalar atomic when the target capability is unknown
    # or below sm_90.
    env = CompileEnvironment.current()
    capability = env.config_spec.target_device_capability
    if capability is None or capability < _CUTE_VECTOR_ATOMIC_MIN_CAPABILITY:
        return False
    # An atomic that is uniform along a live lane loop must stay a scalar
    # atomic: the lane-loop placement pass pins that form to the loop's
    # first lane (or rejects it), whereas the flush protocol below would
    # re-issue the reduction once per iteration of that loop.  So does one
    # adding a lane-split matmul's per-lane partials, whose K lane loop is
    # not the vectorized axis's.
    if _cute_per_lane_atomic_lane_vars(state) or _cute_uniform_lane_vars(
        state, _cute_atomic_indexed_blocks(state, index)
    ):
        return False
    lane_axes = [
        (pos, block_id)
        for pos, idx in enumerate(index)
        if isinstance(idx, torch.SymInt)
        and (block_id := _cute_tile_axis_block_id(idx)) is not None
        # A dynamic stride (another dim's size) must not be guarded to 1
        and env.known_equal(target.stride(pos), 1)
    ]
    if len(lane_axes) != 1:
        return False
    pos, block_id = lane_axes[0]
    strategy = _cute_lane_strategy(state, block_id)
    vec_by_block = getattr(strategy, "_cute_lane_vec_width_by_block", None)
    if not isinstance(vec_by_block, dict):
        return False
    vec_width = vec_by_block.get(block_id, 1)
    if vec_width not in _CUTE_VECTOR_ATOMIC_WIDTHS:
        return False
    base_index_var = getattr(strategy, "_cute_lane_base_index_var_by_block", {}).get(
        block_id
    )
    lane_body = getattr(strategy, "_cute_lane_body_by_block", {}).get(block_id)
    vec_lane_var = getattr(strategy, "_cute_vec_lane_var_by_block", {}).get(block_id)
    vloop = getattr(strategy, "_cute_lane_vloop_by_block", {}).get(block_id)
    if (
        not isinstance(base_index_var, str)
        or not isinstance(lane_body, list)
        or not isinstance(vec_lane_var, str)
        or not isinstance(vloop, ast.For)
    ):
        return False
    if index_exprs[pos] != _cute_active_index_var(state, block_id):
        return False
    loops = state.codegen.active_device_loops.get(block_id)
    owner = loops[-1] if loops else None
    stack = state.codegen.statements_stack
    if (
        not isinstance(owner, DeviceGridState)
        or len(stack) < 2
        or stack[-2] is not owner.hoist_parent_statements
        or not any(
            wrapper.vloop is vloop for wrapper in owner.vec_lane_wrappers.values()
        )
    ):
        return False
    fact = state.device_function.cute_state.vloop_sink_wrappers.get(vec_lane_var)
    if fact is None or fact.block_id != block_id or not fact.uniform_vector_mask:
        return False
    env = CompileEnvironment.current()
    if not cute_reduction_vector_layout_aligned(env, target, pos, vec_width):
        return False
    varying = _cute_lane_varying_names(
        [*owner.lane_setup_statements, *stack[-1]], {vec_lane_var, fact.index_var}
    )
    # The block's own bounds mask is uniform across the chunk (proven above).
    varying.discard(fact.mask_var or "")
    uniform_texts = [
        expr for axis, expr in enumerate(index_exprs) if axis != pos
    ] + predicates
    for text in uniform_texts:
        if set(ReadWrites.from_ast(ast.parse(text, mode="eval")).reads) & varying:
            return False
    tensor_name = state.device_function.tensor_arg(target).name
    base_exprs = list(index_exprs)
    base_exprs[pos] = base_index_var
    base_pointer = _cute_coord_pointer_expr(tensor_name, base_exprs)
    sites_by_block = getattr(strategy, "_cute_lane_vec_stores_by_block", None)
    if sites_by_block is None:
        sites_by_block = {}
        # pyrefly: ignore [missing-attribute]
        strategy._cute_lane_vec_stores_by_block = sites_by_block
    guard = " and ".join(predicates)
    body = stack[-1]

    def emit() -> ast.AST | None:
        from ...language.memory_ops import CuteTileVecStoreSite
        from .lane_loop_distribution import _tensor_mentions

        # The flush runs after the whole V-loop: a later statement of the
        # body that touches the target would see the atomic out of order.
        site = next((i for i, stmt in enumerate(body) if stmt is scalar), len(body))
        if any(tensor_name in _tensor_mentions(stmt) for stmt in body[site + 1 :]):
            return None
        # Shares the store flush numbering so flushes keep source order, and
        # the store site record so the memory-effect checks see the append as
        # a write of the target (``_cute_statement_written_tensors``) and the
        # flush is restored to the scalar atomic like a store's would be.
        sites = sites_by_block.setdefault(block_id, [])
        site_index = len(sites)
        list_var = state.device_function.new_var(
            f"_tile_atomic_vals_{block_id}_{site_index}", dce=False
        )
        init_stmt = statement_from_string(f"{list_var} = []")
        lane_body.insert(
            _cute_lane_vloop_insert_pos(strategy, block_id, lane_body), init_stmt
        )
        flush = f"_cute_red_add_f32_vec({base_pointer}, {list_var})"
        if guard:
            flush = f"if {guard}:\n    {flush}"
        flush_stmt = statement_from_string(flush)
        lane_body.insert(
            _cute_lane_vloop_insert_pos(strategy, block_id, lane_body) + 1 + site_index,
            flush_stmt,
        )
        body_stmt = statement_from_string(
            f"{list_var}.append({{value}})", value=value_expr
        )
        sites.append(
            CuteTileVecStoreSite(
                list_var, tensor_name, body_stmt, scalar, init_stmt, flush_stmt
            )
        )
        return body_stmt

    assert isinstance(atomic_expr, ast.expr)
    scalar: ast.stmt = ast.Expr(value=atomic_expr)
    if guard:
        guard_expr = expr_from_string(guard)
        assert isinstance(guard_expr, ast.expr)
        scalar = ast.If(test=guard_expr, body=[scalar], orelse=[])
    scalar = ast.fix_missing_locations(scalar)
    if not _cute_defer_grid_vector_op(state, strategy, block_id, scalar, emit):
        return False
    state.codegen.add_statement(scalar)
    return True


def _guard_cute_atomic_expr(
    state: CodegenState,
    index: list[object],
    target_dtype: str,
    atomic_expr: ast.AST,
    *,
    extra_predicates: list[str] | None = None,
    indexed_block_ids: set[int] | None,
) -> ast.AST:
    predicates, leader_axes = _cute_atomic_predicates(
        state,
        index,
        extra_predicates,
        atomic_expr,
        indexed_block_ids=indexed_block_ids,
    )
    if not predicates:
        return atomic_expr
    has_users = state.fx_node is not None and len(state.fx_node.users) > 0
    broadcast = bool(leader_axes) and has_users
    if has_users and (broadcast or extra_predicates):
        # Only the leader thread of a collapsed axis performs the atomic, so
        # only it holds the previous value; it shares the value through shared
        # memory behind block-wide barriers, which every thread must reach.
        hazard = (
            "under an extra predicate"
            if extra_predicates
            else _cute_leader_broadcast_hazard(state)
        )
        if hazard is not None:
            raise exc.BackendUnsupported(
                "cute",
                "the result of an atomic issued by one leader thread is not "
                f"shared with the other threads of its tile axis {hazard}",
            )
    predicate_expr = expr_from_string(" and ".join(predicates))
    assert isinstance(predicate_expr, ast.expr)
    assert isinstance(atomic_expr, ast.expr)
    if state.fx_node is not None and len(state.fx_node.users) == 0:
        state.codegen.add_statement(
            ast.fix_missing_locations(
                ast.If(
                    test=predicate_expr,
                    body=[ast.Expr(value=atomic_expr)],
                    orelse=[],
                )
            )
        )
        return ast.Constant(value=None)

    result_var = state.device_function.new_var("_atomic_prev", dce=True)
    zero_value = expr_from_string(f"{target_dtype}(0)")
    assert isinstance(zero_value, ast.expr)
    state.codegen.add_statement(
        ast.fix_missing_locations(
            ast.Assign(
                targets=[ast.Name(id=result_var, ctx=ast.Store())],
                value=zero_value,
            )
        )
    )
    state.codegen.add_statement(
        ast.fix_missing_locations(
            ast.If(
                test=predicate_expr,
                body=[
                    ast.Assign(
                        targets=[ast.Name(id=result_var, ctx=ast.Store())],
                        value=atomic_expr,
                    )
                ],
                orelse=[],
            )
        )
    )
    if broadcast:
        _cute_broadcast_leader_value(state, result_var, target_dtype, leader_axes)
    return expr_from_string(result_var)


def _cute_leader_broadcast_hazard(state: CodegenState) -> str | None:
    """Why the leader's atomic result cannot be broadcast here, or None.

    The broadcast (``_cute_broadcast_leader_value``) needs block-wide
    barriers next to the atomic.  A branch or while loop may skip them on
    some threads (its condition can differ between SIMT threads), and the
    lane-loop placement (``cute/lane_loop_distribution.py``) pins a barrier
    inside every lane loop while it moves a lane-invariant atomic out of
    them, which would split the broadcast from its atomic.
    """
    if state.codegen.divergent_control_flow_depth > 0:
        return "inside a branch or while loop"
    if cute_lane_loops_active(state.codegen):
        return "inside a lane loop"
    return None


def _cute_broadcast_leader_value(
    state: CodegenState, value_var: str, dtype: str, leader_axes: set[int]
) -> None:
    """Give every thread the ``value_var`` of its leader along ``leader_axes``.

    The leader writes the value into a shared-memory slot indexed by its
    linear thread id (its own coordinates, zero along the leader axes), a
    barrier publishes it, and every thread reads its leader's slot.  The
    buffer holds one slot per possible thread, so the slot is in range for
    any launch shape.  A second barrier keeps a later write (the next
    iteration of a loop around the atomic) after every thread's read.
    """
    terms: list[str] = []
    stride = ""
    for axis in range(3):
        if axis not in leader_axes:
            coord = f"cutlass.Int32(cute.arch.thread_idx()[{axis}])"
            terms.append(f"{coord}{stride}")
        stride += f" * cutlass.Int32(cute.arch.block_dim()[{axis}])"
    slot = " + ".join(terms) or "cutlass.Int32(0)"
    buffer = state.device_function.new_var("_atomic_prev_smem")
    leader = _cute_leader_predicate(leader_axes)
    size = MAX_THREADS_PER_BLOCK
    for statement in (
        f"{buffer} = cute.make_tensor(cute.arch.alloc_smem({dtype}, {size}), ({size},))",
        f"if {leader}:\n    {buffer}[{slot}] = {value_var}",
        _CUTE_BLOCK_BARRIER,
        f"{value_var} = {buffer}[{slot}]",
        _CUTE_BLOCK_BARRIER,
    ):
        state.codegen.add_statement(statement_from_string(statement))


def _cute_tensor_index_leader_predicate(
    state: CodegenState,
    tensor_index: torch.Tensor,
) -> str | None:
    from ..compile_environment import CompileEnvironment

    env = CompileEnvironment.current()
    block_id = env.resolve_block_id(tensor_index.shape[0])
    if block_id is None:
        return None
    assert state.fx_node is not None
    block_id = env.resolve_codegen_block_id(
        block_id, state.codegen, state.fx_node.graph
    )
    # The gather index covers its own tile axis; the update value's tile axes
    # are varied along as well (see ``_cute_atomic_value_tile_blocks``).
    covered_block_ids = {block_id, *_cute_atomic_value_tile_blocks(state)}

    index_axes: set[int] = set()
    other_axes: set[int] = set()

    grid_state = state.codegen.current_grid_state
    if grid_state is not None:
        for candidate_block_id, thread_axis in grid_state.block_thread_axes.items():
            if candidate_block_id in covered_block_ids:
                index_axes.add(thread_axis)
            else:
                other_axes.add(thread_axis)
    for loops in state.codegen.active_device_loops.values():
        for loop_state in loops:
            for candidate_block_id, thread_axis in loop_state.block_thread_axes.items():
                if candidate_block_id in covered_block_ids:
                    index_axes.add(thread_axis)
                else:
                    other_axes.add(thread_axis)

    leader_axes = sorted(axis for axis in other_axes if axis not in index_axes)
    if not leader_axes:
        return None
    return " and ".join(
        f"(cute.arch.thread_idx()[{axis}] == 0)" for axis in leader_axes
    )


def _cute_leader_thread_axes(state: CodegenState, index: list[object]) -> set[int]:
    """Thread axes of the tile attributes (``tile.begin``, ``tile.id``) in ``index``."""
    scalar_origin_block_ids: set[int] = set()
    for idx in index:
        if not isinstance(idx, torch.SymInt):
            continue
        expr = _symint_expr(idx)
        if expr is None:
            continue
        origin_info = HostFunction.current().expr_to_origin.get(expr)
        if origin_info is None or not isinstance(origin_info.origin, GridOrigin):
            continue
        if type(origin_info.origin) is GridOrigin:
            continue
        scalar_origin_block_ids.add(origin_info.origin.block_id)
    axes: set[int] = set()
    if not scalar_origin_block_ids:
        return axes

    grid_state = state.codegen.current_grid_state
    if grid_state is not None:
        for block_id in scalar_origin_block_ids:
            thread_axis = grid_state.block_thread_axes.get(block_id)
            if thread_axis is not None:
                axes.add(thread_axis)
    for loops in state.codegen.active_device_loops.values():
        for loop_state in loops:
            for block_id in scalar_origin_block_ids:
                thread_axis = loop_state.block_thread_axes.get(block_id)
                if thread_axis is not None:
                    axes.add(thread_axis)
    return axes


def _cute_uniform_index_value_blocks(
    state: CodegenState, index: list[object]
) -> set[int] | None:
    """Tile axes a tile-uniform atomic varies along, or None when not uniform.

    A constant index, or one made of tile attributes (``tile.begin``,
    ``tile.id``), ``hl.grid`` indices (one value per program, as a block of one
    has no thread axis) and 0-d tensors (a scalar the body loaded or reduced,
    ``idx[tile.begin]``), addresses one element for the whole tile.  Such an atomic
    varies only along the tile axes of a tensor update value
    (``hl.atomic_add(total, [0], x[tile])``): along those axes every element
    is applied to that address; along the others the leader thread issues it
    once, outside the axis's lane loop or pinned to that loop's first lane
    (:func:`_cute_uniform_lane_vars`).  ``None`` when the index has any other
    component or a value's shape is not made of tile axes and ones.
    """
    from ..compile_environment import CompileEnvironment

    host_function = HostFunction.current()
    for idx in index:
        if idx is None or isinstance(idx, int):
            continue
        if isinstance(idx, torch.Tensor) and idx.ndim == 0:
            continue
        if isinstance(idx, torch.SymInt):
            expr = _symint_expr(idx)
            origin_info = (
                host_function.expr_to_origin.get(expr) if expr is not None else None
            )
            origin = origin_info.origin if origin_info is not None else None
            if isinstance(origin, GridOrigin):
                continue
        return None
    fx_node = state.fx_node
    if fx_node is None:
        return None
    env = CompileEnvironment.current()
    block_ids: set[int] = set()
    for position in _cute_atomic_value_positions(state):
        value = state.proxy_arg(position)
        if isinstance(value, (bool, int, float)):
            continue
        if not isinstance(value, torch.Tensor):
            return None
        for size in value.shape:
            if isinstance(size, int):
                if size == 1:
                    continue
                return None
            expr = _symint_expr(size)
            if expr is None or not expr.free_symbols:
                return None
            for symbol in expr.free_symbols:
                block_id = env.get_block_id(symbol)
                if block_id is None:
                    return None
                block_ids.add(
                    env.resolve_codegen_block_id(block_id, state.codegen, fx_node.graph)
                )
    return block_ids


def _cute_atomic_value_positions(state: CodegenState) -> tuple[int, ...]:
    assert state.fx_node is not None
    return (2, 3) if state.fx_node.target is atomic_cas else (2,)


def _cute_atomic_indexed_blocks(
    state: CodegenState,
    index: list[object],
) -> set[int] | None:
    """Resolved ids of the tile axes the atomic varies along; None when unknown.

    A ``BlockSizeOrigin`` index covers its tile axis, a gather index every
    non-broadcast tile axis of its tensor and a slice the axis the pointer
    lowering assigns it.
    A tile-uniform index (a constant, a tile attribute, a 0-d tensor) covers
    nothing by itself; the atomic then varies along the tile axes of its
    update value (:func:`_cute_uniform_index_value_blocks`).  ``None`` when
    no component has a known coverage: the atomic then runs on every thread,
    as it always has.
    """
    from ..compile_environment import CompileEnvironment
    from ..variable_origin import BlockSizeOrigin

    env = CompileEnvironment.current()
    indexed_block_ids: set[int] = set()
    has_block_size_index = False
    for idx in index:
        if isinstance(idx, torch.Tensor):
            # Every non-broadcast tensor-index dimension contributes, even
            # when repeated indices intentionally collide. Restricting coverage
            # to the first dimension would collapse other logical contributions
            # to their leader threads.
            for size in idx.shape:
                tensor_block_id = env.resolve_block_id(size)
                if tensor_block_id is not None and state.fx_node is not None:
                    has_block_size_index = True
                    indexed_block_ids.add(
                        env.resolve_codegen_block_id(
                            tensor_block_id,
                            state.codegen,
                            state.fx_node.graph,
                        )
                    )
            continue
        if not isinstance(idx, torch.SymInt):
            continue
        expr = _symint_expr(idx)
        if expr is None:
            continue
        origin_info = HostFunction.current().expr_to_origin.get(expr)
        if origin_info is None or not isinstance(origin_info.origin, BlockSizeOrigin):
            continue
        has_block_size_index = True
        assert state.fx_node is not None
        indexed_block_ids.add(
            env.resolve_codegen_block_id(
                origin_info.origin.block_id,
                state.codegen,
                state.fx_node.graph,
            )
        )

    fx_graph = state.fx_node.graph if state.fx_node is not None else None

    if any(isinstance(idx, slice) for idx in index):
        from ...language.memory_ops import _cute_resolve_active_slice_block_id
        from ..utils import compute_slice_size

        target = state.proxy_arg(0)
        assert isinstance(target, torch.Tensor)
        assert state.fx_node is not None
        assert fx_graph is not None
        # Match pointer lowering's choice of slice axis, including equal-sized
        # tile dimensions. A slice indexes that axis; it is not a broadcast
        # atomic that should run only on the axis's leader thread.
        used_block_ids = {
            block_id
            for idx in index
            if isinstance(idx, torch.SymInt)
            if (block_id := env.get_block_id(idx)) is not None
        }
        tensor_dim = 0
        for idx in index:
            if idx is None:
                continue
            if isinstance(idx, slice) and idx.step in (None, 1):
                size = compute_slice_size(idx, target.shape[tensor_dim])
                block_id = _cute_resolve_active_slice_block_id(
                    state, size, used_block_ids
                )
                if block_id is not None:
                    used_block_ids.add(block_id)
                    indexed_block_ids.add(
                        env.resolve_codegen_block_id(block_id, state.codegen, fx_graph)
                    )
                    has_block_size_index = True
            tensor_dim += 1

        for position in _cute_atomic_value_positions(state):
            value = state.proxy_arg(position)
            if not isinstance(value, torch.Tensor):
                continue
            # A full slice can introduce a new persistent axis even when an
            # equally sized explicit tile already supplies the update value.
            # Until those coordinate systems can be remapped, do not collapse
            # the value's distinct axis to its leader and replicate one lane.
            for size in value.shape:
                if not isinstance(size, torch.SymInt):
                    continue
                expr = _symint_expr(size)
                if expr is None:
                    continue
                for symbol in expr.free_symbols:
                    value_block = env.get_block_id(symbol)
                    if (
                        value_block is not None
                        and env.resolve_codegen_block_id(
                            value_block, state.codegen, fx_graph
                        )
                        not in indexed_block_ids
                    ):
                        raise exc.BackendUnsupported(
                            "cute",
                            "atomic slice and update value use distinct tile axes",
                        )

    uniform_value_blocks = _cute_uniform_index_value_blocks(state, index)
    if uniform_value_blocks is not None:
        has_block_size_index = True
        indexed_block_ids |= uniform_value_blocks
    if not has_block_size_index:
        return None
    # The atomic varies along every tile axis of its update value, whatever
    # the index covers: ``hl.atomic_add(out, [tile_m], x[tile_b, tile_m])``
    # applies each row's element to ``out[m]``.  Collapsing such an axis to
    # its leader thread kept the first row of every tile only.
    return indexed_block_ids | _cute_atomic_value_tile_blocks(state)


def _cute_atomic_value_tile_blocks(state: CodegenState) -> set[int]:
    """Resolved ids of the tile axes the update value(s) of an atomic span.

    Dims that are not a tile axis (ones, static sizes, symbols without a
    block) are left out; unlike :func:`_cute_uniform_index_value_blocks` this
    never gives up, because it only widens the axes the atomic varies along.
    """
    from ..compile_environment import CompileEnvironment

    fx_node = state.fx_node
    if fx_node is None:
        return set()
    env = CompileEnvironment.current()
    block_ids: set[int] = set()
    for position in _cute_atomic_value_positions(state):
        value = state.proxy_arg(position)
        if not isinstance(value, torch.Tensor):
            continue
        for size in value.shape:
            if not isinstance(size, torch.SymInt):
                continue
            expr = _symint_expr(size)
            if expr is None:
                continue
            for symbol in expr.free_symbols:
                block_id = env.get_block_id(symbol)
                if block_id is not None:
                    block_ids.add(
                        env.resolve_codegen_block_id(
                            block_id, state.codegen, fx_node.graph
                        )
                    )
    return block_ids


def _cute_unindexed_leader_axes(
    state: CodegenState,
    indexed_block_ids: set[int] | None,
) -> set[int]:
    """Return the thread axes whose leader alone issues the atomic.

    Two complementary mechanisms:

    1. **Active-axis leaders (known coverage):** When an atomic op is
       invoked inside ``hl.tile([m, n])`` but varies along only a subset of
       the tile dimensions (e.g. ``hl.atomic_add(dy, [tile_i], reduced)``
       after a reduction across ``tile_j``, or ``hl.atomic_add(count, [0],
       1)``), every thread on an uncovered axis would otherwise re-issue the
       atomic with the same value.  This mechanism uses the covered tile axes
       (:func:`_cute_atomic_indexed_blocks`) to decide which currently-active
       thread axes the atomic varies along, and restricts the rest to
       ``thread_idx[axis] == 0``.

    2. **Ghost-axis leaders (any index form):** A CTA-resident thread
       axis whose owning device loop has exited cannot be referenced by
       any current expression — including gather (``idxs[tile]``) or
       offset-constant (``[tile.begin]``) index forms whose index does
       not flow through a ``BlockSizeOrigin``. Threads on a ghost axis
       still exist (the CUDA ``blockDim`` is fixed for the kernel) and
       would re-issue the atomic with whatever value the surviving
       expression resolved to, multiplying the result by the ghost
       axis's size. Predicate the ghost axis to leader unconditionally.
       The canonical case is ``examples.matmul_split_k`` under
       autotune-picked configs that pack the inner-K loop onto a CTA
       thread axis.
    """
    from ..compile_environment import CompileEnvironment

    env = CompileEnvironment.current()
    fx_graph = state.fx_node.graph if state.fx_node is not None else None
    leader_axes: set[int] = set()
    active_thread_axes: set[int] = set()
    loop_states = _cute_loop_states(state)

    def collect(thread_axes: dict[int, int]) -> None:
        for candidate_block_id, thread_axis in thread_axes.items():
            if (
                _cute_block_thread_extent(loop_states, candidate_block_id, thread_axis)
                == 1
            ):
                # The block spans one thread along the axis (a slice walked
                # entirely by its per-thread lane loop, recorded on the grid
                # state as well as on its own): the axis's threads are
                # another block's elements, and that block decides whether
                # the atomic varies along them, so it neither claims nor
                # decides the axis.  The lane loop is the lane placement's
                # business (``_cute_uniform_lane_vars``).
                continue
            active_thread_axes.add(thread_axis)
            if indexed_block_ids is None or fx_graph is None:
                # Without a known coverage there is no reliable mapping from
                # "tile axis the atomic varies along" to a thread axis, so
                # skip the active-axis mechanism. Ghost-axis predicates
                # below still fire.
                continue
            resolved = env.resolve_codegen_block_id(
                candidate_block_id, state.codegen, fx_graph
            )
            if resolved in indexed_block_ids:
                continue
            leader_axes.add(thread_axis)

    for loop_state in loop_states:
        collect(loop_state.block_thread_axes)

    # Ghost-axis leaders: any CTA-resident thread axis (size > 1) that
    # no active loop currently owns. ``max_thread_block_dims`` tracks the
    # per-axis CTA size accumulated as device loops are entered and is
    # never decremented on exit, so it correctly captures axes whose
    # owning loop has finished but whose threads remain live.
    for axis, size in enumerate(state.codegen.max_thread_block_dims):
        if size > 1 and axis not in active_thread_axes:
            leader_axes.add(axis)
    # A launch axis sized by a kernel argument has no size here (its block is
    # recorded without one, ``ThreadAxisTracker.record_symbolic_axis``), yet
    # its threads are as resident as a static ghost axis's: with its loop
    # exited or not yet entered, the atomic still runs on the axis's leader.
    # Exact at every value of the argument; an axis the body never reads
    # keeps one thread, where the guard holds.
    for axis in state.device_function.tile_strategy.symbolic_thread_axes():
        if axis not in active_thread_axes:
            leader_axes.add(axis)
    return leader_axes


def _cute_loop_states(state: CodegenState) -> list[DeviceLoopOrGridState]:
    """The grid state and every active device loop state, each once."""
    states: list[DeviceLoopOrGridState] = []
    grid_state = state.codegen.current_grid_state
    if grid_state is not None:
        states.append(grid_state)
    for loops in state.codegen.active_device_loops.values():
        for loop_state in loops:
            if not any(loop_state is seen for seen in states):
                states.append(loop_state)
    return states


def _cute_block_thread_extent(
    loop_states: list[DeviceLoopOrGridState], block_id: int, thread_axis: int
) -> int | None:
    """The threads ``block_id`` spans along ``thread_axis``, or None when no
    state records a size for the axis.

    A state's ``thread_axis_sizes`` is the widest block on the axis among
    those it records: a persistent reduction records its block on the grid
    state too, where the axis may belong to a tile block, so the smallest
    size any state recording the block gives is the block's own.
    """
    sizes = [
        size
        for loop_state in loop_states
        if loop_state.block_thread_axes.get(block_id) == thread_axis
        and (size := loop_state.thread_axis_sizes.get(thread_axis)) is not None
    ]
    return min(sizes, default=None)


def _cute_leader_predicate(axes: set[int]) -> str | None:
    if not axes:
        return None
    return " and ".join(
        f"(cute.arch.thread_idx()[{axis}] == 0)" for axis in sorted(axes)
    )


def _cute_uniform_lane_vars(
    state: CodegenState, indexed_block_ids: set[int] | None
) -> frozenset[str]:
    """The lane loops (by lane variable) along whose tile axes the atomic is uniform.

    The leader thread of an uncovered axis issues the atomic, but a lane loop
    walks that thread through several elements of the axis, and the generated
    statement may still depend on the loop: a partial tile's mask guards a
    tensor value's load, or the loop structure nests the atomic's own loop
    inside it.  Recorded on the atomic call for the lane-loop distribution of
    the grid body and the full-nest check of an enclosing device loop's body
    (``cute/lane_loop_distribution.py``), which pin the atomic to the loop's
    first lane, where the thread holds the tile's first element along the
    axis under every lane layout, instead of repeating it once per iteration.
    Empty when the coverage is unknown: the atomic then runs on every thread
    under every mask, as it always has.

    An atomic whose value is the per-K-lane partial sum of a lane-split
    scalar matmul (``cute/matmul_fallback.py``) varies along that K lane
    loop although its index does not cover the K block: each lane adds its
    own partial, and the loop is left out
    (``CuteDeviceFunctionState.per_lane_atomic_lane_vars``).
    """
    from ..compile_environment import CompileEnvironment
    from ..tile_strategy import DeviceLoopState

    if indexed_block_ids is None:
        return frozenset()
    per_lane_vars = _cute_per_lane_atomic_lane_vars(state)
    lane_loop_block_ids: dict[str, frozenset[int]] = {}
    grid_state = state.codegen.current_grid_state
    if grid_state is not None:
        lane_loop_block_ids.update(grid_state.lane_loop_block_ids)
    for loops in state.codegen.active_device_loops.values():
        for loop_state in loops:
            if isinstance(loop_state, DeviceLoopState):
                lane_loop_block_ids.update(loop_state.lane_loop_block_ids)
    env = CompileEnvironment.current()
    fx_graph = state.fx_node.graph if state.fx_node is not None else None
    return frozenset(
        lane_var
        for lane_var, block_ids in lane_loop_block_ids.items()
        if lane_var not in per_lane_vars
        and not any(
            block_id >= 0
            and env.resolve_codegen_block_id(block_id, state.codegen, fx_graph)
            in indexed_block_ids
            for block_id in block_ids
        )
    )


def _cute_per_lane_atomic_lane_vars(state: CodegenState) -> set[str]:
    """The K lane loops whose per-lane matmul partials this atomic adds."""
    if state.fx_node is None:
        return set()
    return state.device_function.cute_state.per_lane_atomic_lane_vars.get(
        state.fx_node, set()
    )


def _cute_active_mask_predicate(
    state: CodegenState, indexed_block_ids: set[int] | None = None
) -> str | None:
    """The tile masks the atomic is subject to.

    With a known coverage only the covered axes' masks apply: the atomic
    runs on the leader thread of every other axis, whose element is the
    tile's first along that axis and always in range, and a mask of an
    uncovered lane-looped axis would tie the atomic to that loop.
    """
    from ..compile_environment import CompileEnvironment

    env = CompileEnvironment.current()
    fx_graph = state.fx_node.graph if state.fx_node is not None else None

    def covered(block_id: int) -> bool:
        return (
            indexed_block_ids is None
            or env.resolve_codegen_block_id(block_id, state.codegen, fx_graph)
            in indexed_block_ids
        )

    masks: list[str] = []
    seen_blocks: set[int] = set()

    for block_id, loops in state.codegen.active_device_loops.items():
        if block_id in seen_blocks or not loops:
            continue
        seen_blocks.add(block_id)
        if not covered(block_id):
            continue
        mask_var = loops[-1].strategy.mask_var(block_id)
        if mask_var is not None:
            masks.append(f"({mask_var})")

    grid_state = state.codegen.current_grid_state
    if grid_state is not None:
        for block_id in grid_state.block_ids:
            if block_id in seen_blocks:
                continue
            seen_blocks.add(block_id)
            if not covered(block_id):
                continue
            mask_var = grid_state.strategy.mask_var(block_id)
            if mask_var is not None:
                masks.append(f"({mask_var})")

    if not masks:
        return None
    return " and ".join(masks)


def _resolve_tensor_index_iota_node(
    state: CodegenState, index_node: torch.fx.Node
) -> torch.fx.Node | None:
    from ..device_ir import NodeArgsGraphInfo

    current = index_node
    visited: set[torch.fx.Node] = set()
    while True:
        if current in visited:
            return None
        visited.add(current)
        if current.target is torch.ops.prims.iota.default:
            return current
        if current.op == "call_function" and current.target in {
            _tracing_ops._new_var,
            _tracing_ops._phi,
            torch.ops.aten.clone.default,
            torch.ops.aten.detach.default,
            torch.ops.prims.convert_element_type.default,
        }:
            arg = current.args[0] if current.args else None
            if not isinstance(arg, torch.fx.Node):
                return None
            current = arg
            continue
        if current.op != "placeholder":
            return None
        graph_infos = [
            graph_info
            for graph_info in state.codegen.codegen_graphs
            if graph_info.graph is current.graph
        ]
        if len(graph_infos) != 1:
            return None
        graph_info = graph_infos[0]
        if not isinstance(graph_info, NodeArgsGraphInfo):
            return None
        outer_node = graph_info.placeholder_to_outer_arg(current)
        if not isinstance(outer_node, torch.fx.Node):
            return None
        current = outer_node


_DERIVED_ARANGE_INDEX = (
    "an atomic index computed from hl.arange (arithmetic on it, a gather by "
    "it, or a second index component beside it) is not lowered: the per-thread "
    "form would repeat the atomic across the tile; index with the bare "
    "hl.arange(start, end, step)"
)
_USED_ARANGE_ATOMIC_RESULT = (
    "an atomic indexed by hl.arange whose result is used is not lowered: the "
    "leader-thread loop issues one atomic per entry and carries no per-thread "
    "result; drop the result or index the atomic with a tile"
)
_SYMBOLIC_ARANGE_INDEX = (
    "an atomic indexed by an hl.arange with a symbolic length, start or step is "
    "not lowered: the leader-thread loop needs static entries and the per-thread "
    "form would repeat the atomic across the tile; use literal arange bounds"
)
_IOTA_TARGETS = frozenset(
    {
        torch.ops.prims.iota.default,
        torch.ops.aten.arange.default,
        torch.ops.aten.arange.start,
        torch.ops.aten.arange.start_step,
    }
)


def _index_derives_from_iota(state: CodegenState, node: torch.fx.Node) -> bool:
    """Whether ``node``'s value is computed from an ``hl.arange`` (an iota).

    Walks the inputs in this graph and, through a placeholder, the enclosing
    graph's argument, as :func:`_resolve_tensor_index_iota_node` does for the
    bare chain; bounded, so an unrelated deep expression is not an iota.
    """
    from ..device_ir import NodeArgsGraphInfo

    pending = [node]
    seen: set[torch.fx.Node] = set()
    while pending and len(seen) < 64:
        current = pending.pop()
        if current in seen:
            continue
        seen.add(current)
        if current.target in _IOTA_TARGETS:
            return True
        if current.op == "placeholder":
            graph_infos = [
                graph_info
                for graph_info in state.codegen.codegen_graphs
                if graph_info.graph is current.graph
            ]
            if len(graph_infos) == 1 and isinstance(graph_infos[0], NodeArgsGraphInfo):
                outer = graph_infos[0].placeholder_to_outer_arg(current)
                if isinstance(outer, torch.fx.Node):
                    pending.append(outer)
            continue
        pending.extend(current.all_input_nodes)
    return False


def _active_reduction_axis_of_iota(
    state: CodegenState, node: torch.fx.Node
) -> int | None:
    """The active reduction axis a bare ``hl.arange`` index spans, if any.

    Such a range is allocated its own reduction axis, and every thread holds
    its coordinate along that axis: the index addresses one element per
    thread, as the slice it spans does (``hl.arange(0, k)`` is ``[:k]``), and
    the atomic varies along that axis rather than repeating across it.
    """
    from ...language.memory_ops import _cute_active_index_var
    from ..compile_environment import CompileEnvironment

    iota_node = _resolve_tensor_index_iota_node(state, node)
    if iota_node is None or state.fx_node is None:
        return None
    iota_val = iota_node.meta.get("val")
    if not isinstance(iota_val, torch.Tensor) or iota_val.ndim != 1:
        return None
    env = CompileEnvironment.current()
    block_id = env.resolve_block_id(iota_val.shape[0])
    if block_id is None or not env.block_sizes[block_id].reduction:
        return None
    block_id = env.resolve_codegen_block_id(
        block_id, state.codegen, state.fx_node.graph
    )
    if _cute_active_index_var(state, block_id) is None:
        return None
    return block_id


def _codegen_tensor_index_common_cute(
    cute_func: str,
    state: CodegenState,
    target: torch.Tensor,
    index: list[object],
    sem: ast.AST,
    value_exprs: list[ast.AST],
    keyword_names: list[str],
    callee: str,
    *,
    extra_predicates: list[str] | None = None,
) -> ast.AST | None:
    from ...language.memory_ops import _cute_active_index_var
    from ..compile_environment import CompileEnvironment

    fx_node = state.fx_node
    if fx_node is None or len(fx_node.args) < 2:
        return None
    fx_index = fx_node.args[1]
    if not isinstance(fx_index, (list, tuple)):
        return None
    if len(index) != 1 or len(fx_index) != 1:
        # A second component beside an arange keeps the generic per-thread
        # form from here, whose iota is the matcher's per-thread fold: not a
        # lowering of the tile-uniform index, unless each arange spans its
        # own active reduction axis (``_active_reduction_axis_of_iota``).
        axis_blocks: list[int] = []
        for component in fx_index:
            if not isinstance(component, torch.fx.Node) or not _index_derives_from_iota(
                state, component
            ):
                continue
            block_id = _active_reduction_axis_of_iota(state, component)
            if block_id is None or block_id in axis_blocks:
                raise exc.BackendUnsupported("cute", _DERIVED_ARANGE_INDEX)
            axis_blocks.append(block_id)
        return None
    tensor_index = index[0] if isinstance(index[0], torch.Tensor) else None
    index_node = fx_index[0]
    if not isinstance(index_node, torch.fx.Node):
        return None
    iota_node = _resolve_tensor_index_iota_node(state, index_node)
    if iota_node is None:
        if _index_derives_from_iota(state, index_node):
            raise exc.BackendUnsupported("cute", _DERIVED_ARANGE_INDEX)
        return None
    iota_val = iota_node.meta.get("val")
    if isinstance(iota_val, torch.Tensor) and iota_val.ndim == 1:
        tensor_index = iota_val
    if tensor_index is None or tensor_index.ndim != 1:
        return None
    iota_start = iota_node.kwargs.get("start", 0)
    iota_step = iota_node.kwargs.get("step", 1)
    if iota_step != 1 or not isinstance(iota_start, int):
        return _codegen_tensor_index_loop_common_cute(
            cute_func,
            state,
            target,
            tensor_index,
            index_node,
            sem,
            value_exprs,
            keyword_names,
            callee,
        )

    env = CompileEnvironment.current()
    block_id = env.resolve_block_id(tensor_index.shape[0])
    if block_id is None:
        return _codegen_tensor_index_loop_common_cute(
            cute_func,
            state,
            target,
            tensor_index,
            index_node,
            sem,
            value_exprs,
            keyword_names,
            callee,
        )
    block_id = env.resolve_codegen_block_id(block_id, state.codegen, fx_node.graph)
    if (index_var := _cute_active_index_var(state, block_id)) is None:
        return _codegen_tensor_index_loop_common_cute(
            cute_func,
            state,
            target,
            tensor_index,
            index_node,
            sem,
            value_exprs,
            keyword_names,
            callee,
        )

    tensor_name = state.device_function.tensor_arg(target).name
    resolved_kwargs = _resolve_cute_atomic_kwargs(cute_func, keyword_names)
    values_section = ", ".join(
        f"{actual}={{{intent}}}"
        for intent, actual in zip(keyword_names, resolved_kwargs, strict=True)
    )
    placeholders = dict(zip(keyword_names, value_exprs, strict=True))
    atomic_expr = expr_from_string(
        callee
        + "("
        + f"({tensor_name}.iterator + "
        + f"cute.crd2idx((cutlass.Int32({iota_start}) + {index_var},), {tensor_name}.layout)).llvm_ptr, "
        + values_section
        + ", sem={sem})",
        sem=sem,
        **placeholders,
    )
    target_dtype = env.backend.dtype_str(target.dtype)
    site_predicates = [
        predicate
        for predicate in (
            _cute_tensor_index_leader_predicate(state, tensor_index),
            *(extra_predicates or []),
        )
        if predicate is not None
    ]
    return _guard_cute_atomic_expr(
        state,
        index,
        target_dtype,
        atomic_expr,
        extra_predicates=site_predicates,
        indexed_block_ids=_cute_atomic_indexed_blocks(state, index),
    )


def _codegen_tensor_index_loop_common_cute(
    cute_func: str,
    state: CodegenState,
    target: torch.Tensor,
    tensor_index: torch.Tensor,
    index_node: torch.fx.Node,
    sem: ast.AST,
    value_exprs: list[ast.AST],
    keyword_names: list[str],
    callee: str,
) -> ast.AST | None:
    from ..ast_extension import statement_from_string

    iota_node = _resolve_tensor_index_iota_node(state, index_node)
    if iota_node is None:
        return None
    # The index is an hl.arange from here on and the leader loop below is its
    # only lowering: a shape the loop cannot take declines instead of falling
    # through to the per-thread form, which repeats the atomic across the tile.
    fx_node = state.fx_node
    if fx_node is None or len(fx_node.users) > 0:
        raise exc.BackendUnsupported("cute", _USED_ARANGE_ATOMIC_RESULT)
    if tensor_index.ndim != 1:
        raise exc.BackendUnsupported("cute", _DERIVED_ARANGE_INDEX)
    extent = tensor_index.shape[0]
    start = iota_node.kwargs.get("start", 0)
    step = iota_node.kwargs.get("step", 1)
    if not all(isinstance(value, int) for value in (extent, start, step)):
        raise exc.BackendUnsupported("cute", _SYMBOLIC_ARANGE_INDEX)

    # The index is the same ``extent`` entries on every thread, so the loop
    # below is the tile program: one thread of the tile walks the entries
    # (``hl.arange(k)`` as an index).  The iota matcher's per-thread
    # coordinate (``indices_0 // 8`` for ``hl.arange(4)`` under a 32-row tile)
    # is not a lowering of it: every row thread would add, 8 per entry per
    # tile, and a partial tile past the buffer.
    from ..compile_environment import CompileEnvironment

    env = CompileEnvironment.current()
    host_function = HostFunction.current()
    indexed_values: list[ast.AST] = []
    value_arg_offset = 2
    for value_expr, _keyword_name in zip(value_exprs, keyword_names, strict=True):
        value_proxy = state.proxy_arg(value_arg_offset)
        value_arg_offset += 1
        if isinstance(value_proxy, torch.Tensor) and value_proxy.ndim == 1:
            # A host tensor is read per entry (or once, when it has one entry:
            # torch broadcasts it); a register tensor's elements live one per
            # thread and have no per-entry element here.
            if value_proxy not in host_function.tensor_to_origin:
                raise exc.BackendUnsupported(
                    "cute",
                    "an atomic indexed by hl.arange with a device tensor value: the "
                    "index is the same on every thread while the value's elements "
                    "live one per thread",
                )
            length = value_proxy.shape[0]
            if isinstance(length, int) and length == 1:
                entry = "0"
            elif (isinstance(length, int) and length == extent) or (
                isinstance(length, torch.SymInt) and env.known_equal(length, extent)
            ):
                entry = "_tensor_index_i"
            elif isinstance(length, torch.SymInt):
                # A dynamic length (every size is one under
                # ``static_shapes=False``) is read per entry, or once when the
                # call passes one entry: the select is a real branch in the
                # DSL, so the one-entry value is never read past its end.
                size_expr = state.device_function.tensor_size(value_proxy, 0).name
                entry = f"(_tensor_index_i if {size_expr} > 1 else 0)"
            else:
                raise exc.BackendUnsupported(
                    "cute",
                    f"an atomic indexed by hl.arange of {extent} entries with a "
                    f"value of length {length}: the value is read per entry, or "
                    "once when it has one",
                )
            tensor_arg = state.device_function.tensor_arg(value_proxy)
            indexed_values.append(
                expr_from_string(
                    "{value}[{idx}]",
                    value=expr_from_string(tensor_arg.name),
                    idx=expr_from_string(entry),
                )
            )
            continue
        # A scalar (a Python or symbolic number) or a 0-d tensor is the one
        # value of every entry.
        if not (
            extent == 1
            or isinstance(
                value_proxy,
                (bool, int, float, torch.SymInt, torch.SymFloat, torch.SymBool),
            )
            or (isinstance(value_proxy, torch.Tensor) and value_proxy.ndim == 0)
        ):
            raise exc.BackendUnsupported(
                "cute",
                "an atomic indexed by hl.arange with a value of rank "
                f"{getattr(value_proxy, 'ndim', type(value_proxy).__name__)}: one "
                "value per entry or one for all is lowered",
            )
        indexed_values.append(value_expr)

    index_expr = expr_from_string(
        f"cutlass.Int32({start}) + cutlass.Int32({step}) * cutlass.Int32(_tensor_index_i)"
    )

    tensor_name = state.device_function.tensor_arg(target).name
    resolved_kwargs = _resolve_cute_atomic_kwargs(cute_func, keyword_names)
    values_section = ", ".join(
        f"{actual}={{{intent}}}"
        for intent, actual in zip(keyword_names, resolved_kwargs, strict=True)
    )
    placeholders = dict(zip(keyword_names, indexed_values, strict=True))
    atomic_expr = expr_from_string(
        callee
        + "("
        + f"({tensor_name}.iterator + "
        + f"cute.crd2idx(({{index}},), {tensor_name}.layout)).llvm_ptr, "
        + values_section
        + ", sem={sem})",
        index=index_expr,
        sem=sem,
        **placeholders,
    )
    assert isinstance(atomic_expr, ast.expr)
    # The tile-uniform index covers no tile axis; the value's tile axes (a
    # host tensor has none) are the only ones the atomic varies along, so the
    # leader of every other launch axis issues the loop: the active ones, the
    # ghosts of exited loops and the argument-sized axes alike
    # (``_cute_unindexed_leader_axes``), pinned to the first lane of the
    # lane loops it does not vary along (``_cute_uniform_lane_vars``).
    covered_block_ids = _cute_atomic_value_tile_blocks(state)
    setattr(
        atomic_expr,
        HELION_ATOMIC_UNIFORM_LANES_ATTR,
        _cute_uniform_lane_vars(state, covered_block_ids),
    )
    predicate_terms = [
        predicate
        for predicate in (
            _cute_active_mask_predicate(state, covered_block_ids),
            _cute_leader_predicate(
                _cute_unindexed_leader_axes(state, covered_block_ids)
            ),
        )
        if predicate is not None
    ]
    predicate_expr = (
        ast.parse(" and ".join(predicate_terms), mode="eval").body
        if predicate_terms
        else None
    )
    inner = (
        ast.fix_missing_locations(
            ast.If(
                test=predicate_expr,
                body=[ast.Expr(value=atomic_expr)],
                orelse=[],
            )
        )
        if predicate_expr is not None
        else ast.Expr(value=atomic_expr)
    )
    loop = statement_from_string(f"for _tensor_index_i in range({extent}):\n    pass")
    assert isinstance(loop, ast.For)
    loop.body = [inner]
    state.codegen.add_statement(loop)
    return ast.Constant(value=None)


@_decorators.codegen(atomic_add, "cute")
def _(state: CodegenState) -> ast.AST:
    value_expr = state.ast_args[2]
    return _codegen_common_cute(
        "atomic_add",
        state,
        value_exprs=_to_ast_values([value_expr]),
        keyword_names=["val"],
    )


@_decorators.codegen(atomic_xchg, "cute")
def _(state: CodegenState) -> ast.AST:
    value_expr = state.ast_args[2]
    return _codegen_common_cute(
        "atomic_exch",
        state,
        value_exprs=_to_ast_values([value_expr]),
        keyword_names=["val"],
    )


@_decorators.codegen(atomic_and, "cute")
def _(state: CodegenState) -> ast.AST:
    value_expr = state.ast_args[2]
    return _codegen_common_cute(
        "atomic_and",
        state,
        value_exprs=_to_ast_values([value_expr]),
        keyword_names=["val"],
    )


@_decorators.codegen(atomic_or, "cute")
def _(state: CodegenState) -> ast.AST:
    value_expr = state.ast_args[2]
    return _codegen_common_cute(
        "atomic_or",
        state,
        value_exprs=_to_ast_values([value_expr]),
        keyword_names=["val"],
    )


@_decorators.codegen(atomic_xor, "cute")
def _(state: CodegenState) -> ast.AST:
    value_expr = state.ast_args[2]
    return _codegen_common_cute(
        "atomic_xor",
        state,
        value_exprs=_to_ast_values([value_expr]),
        keyword_names=["val"],
    )


@_decorators.codegen(atomic_max, "cute")
def _(state: CodegenState) -> ast.AST:
    value_expr = state.ast_args[2]
    return _codegen_common_cute(
        "atomic_max",
        state,
        value_exprs=_to_ast_values([value_expr]),
        keyword_names=["val"],
    )


@_decorators.codegen(atomic_min, "cute")
def _(state: CodegenState) -> ast.AST:
    value_expr = state.ast_args[2]
    return _codegen_common_cute(
        "atomic_min",
        state,
        value_exprs=_to_ast_values([value_expr]),
        keyword_names=["val"],
    )


@_decorators.codegen(atomic_cas, "cute")
def _(state: CodegenState) -> ast.AST:
    return _codegen_common_cute(
        "atomic_cas",
        state,
        value_exprs=_to_ast_values([state.ast_args[2], state.ast_args[3]]),
        keyword_names=["cmp", "val"],
    )
