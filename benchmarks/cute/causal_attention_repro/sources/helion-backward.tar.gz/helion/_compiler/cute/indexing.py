from __future__ import annotations

import dataclasses
import operator
from typing import TYPE_CHECKING
from typing import cast

import torch
from torch.fx import Node

from ...language.tile_ops import tile_begin
from ...language.tile_ops import tile_index

if TYPE_CHECKING:
    import ast


@dataclasses.dataclass(frozen=True)
class CuteAffineRangeIndex:
    base: object
    factor: int
    step: object
    dtype: torch.dtype


@dataclasses.dataclass(frozen=True)
class CutePackedAffineLoad:
    terms: tuple[ast.AST, ...]


@dataclasses.dataclass(frozen=True)
class CuteSortableLoad:
    expr: ast.AST
    tensor: torch.Tensor
    value: torch.Tensor
    extra_mask: torch.Tensor | None
    tensor_name: str
    index_exprs: tuple[str, ...]
    mask_expr: str | None
    dtype: torch.dtype


@dataclasses.dataclass(frozen=True)
class CuteScalarLoadSite:
    """Address pieces of a lowered scalar load.

    Recorded on the load's fx node so ``hl.split`` can re-read the same tile
    at other block-local coordinates instead of staging it in shared memory.
    """

    tensor_name: str
    index_exprs: tuple[str, ...]
    mask_expr: str | None
    # ``mask_expr`` folds in ``hl.load(..., extra_mask=...)`` evaluated at this
    # thread's own coordinates; it cannot be re-evaluated at another element.
    has_extra_mask: bool
    eviction_suffix: str
    # Per load-output dim: ``(tensor_dim, block_id)``; ``None`` for a new unit
    # axis from a ``None`` subscript. ``block_id`` is ``None`` when the dim's
    # address is not a block index (partial slice, size-1 tensor dim, ...).
    output_dims: tuple[tuple[int, int | None] | None, ...]


CUTE_SCALAR_LOAD_SITE_META = "cute_scalar_load_site"


@dataclasses.dataclass(frozen=True)
class CutePackedTerms:
    terms: tuple[ast.AST, ...]


@dataclasses.dataclass(frozen=True)
class CuteShapeChainView:
    node: Node


_CUTE_SHAPE_CHAIN_TARGETS = frozenset(
    {
        torch.ops.aten.reshape.default,
        torch.ops.aten._unsafe_view.default,
        torch.ops.aten.view.default,
        torch.ops.aten.expand.default,
        torch.ops.aten.permute.default,
        torch.ops.aten.unsqueeze.default,
        torch.ops.aten.squeeze.dim,
        torch.ops.aten.clone.default,
    }
)


def is_cute_shape_chain_target(target: object) -> bool:
    return target in _CUTE_SHAPE_CHAIN_TARGETS


def is_cute_direct_iota_index(node: object) -> bool:
    """Whether *node* is the zero-based, unit-stride iota for a tile axis."""
    if not isinstance(node, Node) or node.op != "call_function":
        return False
    if node.target is not torch.ops.prims.iota.default:
        return False
    start = node.kwargs.get("start", 0)
    step = node.kwargs.get("step", 1)
    return isinstance(start, int) and start == 0 and isinstance(step, int) and step == 1


def is_cute_unit_stride_iota_index(node: object) -> bool:
    """Whether *node* is a unit-stride iota with only a scalar offset applied."""
    if not isinstance(node, Node) or node.op != "call_function":
        return False
    if node.target is torch.ops.prims.iota.default:
        step = node.kwargs.get("step", 1)
        return isinstance(step, int) and step == 1
    if node.target not in {
        operator.add,
        operator.sub,
        torch.ops.aten.add.Tensor,
        torch.ops.aten.sub.Tensor,
    }:
        return False
    lhs, rhs = node.args[:2]

    def is_scalar(value: object) -> bool:
        if isinstance(value, Node):
            value = value.meta.get("val")
        return isinstance(value, (int, torch.SymInt))

    if node.target is torch.ops.aten.add.Tensor:
        alpha = node.kwargs.get("alpha", 1)
        return (
            is_cute_unit_stride_iota_index(lhs)
            and is_scalar(rhs)
            or (
                isinstance(alpha, int)
                and alpha == 1
                and is_scalar(lhs)
                and is_cute_unit_stride_iota_index(rhs)
            )
        )
    if node.target is operator.add:
        return (
            is_cute_unit_stride_iota_index(lhs)
            and is_scalar(rhs)
            or (is_scalar(lhs) and is_cute_unit_stride_iota_index(rhs))
        )
    return is_cute_unit_stride_iota_index(lhs) and is_scalar(rhs)


def match_cute_shifted_tile_index(
    node: object,
) -> tuple[Node, tuple[int | torch.SymInt, ...]] | None:
    """Match ``tile.index`` shifted by scalars: ``(tile_index node, shifts)``.

    ``tile.index - c`` reaches indexing as ``sub(tile_index(block), c)``; its
    lane coordinate is the block's own index shifted by the sum of the
    returned terms (added scalars, negated subtracted scalars; empty for a
    bare ``tile.index``).  ``None`` for anything else, including ``alpha != 1``
    scaled adds and shifts by tensors.
    """
    terms: list[int | torch.SymInt] = []

    def scalar(value: object) -> int | torch.SymInt | None:
        if isinstance(value, Node):
            value = value.meta.get("val")
        return value if isinstance(value, (int, torch.SymInt)) else None

    current = node
    while True:
        if not isinstance(current, Node) or current.op != "call_function":
            return None
        if current.target is tile_index:
            return current, tuple(terms)
        if current.kwargs.get("alpha", 1) != 1 or len(current.args) < 2:
            return None
        lhs, rhs = current.args[:2]
        if current.target in (operator.sub, torch.ops.aten.sub.Tensor):
            shift = scalar(rhs)
            if shift is None:
                return None
            terms.append(-shift)
            current = lhs
        elif current.target in (operator.add, torch.ops.aten.add.Tensor):
            if (shift := scalar(rhs)) is not None:
                terms.append(shift)
                current = lhs
            elif (shift := scalar(lhs)) is not None:
                terms.append(shift)
                current = rhs
            else:
                return None
        else:
            return None


def _match_constant_multiple(value: object) -> tuple[object, int]:
    if (
        isinstance(value, Node)
        and value.op == "call_function"
        and value.target in (operator.mul, torch.ops.aten.mul.Tensor)
    ):
        lhs, rhs = value.args
        if isinstance(lhs, int) and lhs > 0:
            return rhs, lhs
        if isinstance(rhs, int) and rhs > 0:
            return lhs, rhs
    return value, 1


def match_cute_affine_range_iota(node: Node) -> CuteAffineRangeIndex | None:
    if node.op != "call_function" or node.target is not torch.ops.prims.iota.default:
        return None

    start = node.kwargs.get("start", 0)
    step = node.kwargs.get("step", 1)
    dtype = node.kwargs.get("dtype")
    if not isinstance(dtype, torch.dtype):
        return None
    if step != 1:
        return None

    (length_arg,) = node.args
    length_base, length_factor = _match_constant_multiple(length_arg)
    start_base, start_factor = _match_constant_multiple(start)
    if length_factor <= 1 or length_factor != start_factor:
        return None
    if not (
        isinstance(start_base, Node)
        and start_base.op == "call_function"
        and start_base.target is tile_begin
        and len(start_base.args) == 1
        and start_base.args[0] == length_base
    ):
        return None

    return CuteAffineRangeIndex(
        base=length_base,
        factor=length_factor,
        step=step,
        dtype=dtype,
    )


def match_cute_stack_reshape_rhs(node: Node) -> tuple[tuple[Node, ...], int] | None:
    current = node
    while current.op == "call_function" and current.target in (
        torch.ops.aten.reshape.default,
        torch.ops.aten._unsafe_view.default,
        torch.ops.aten.view.default,
    ):
        source = current.args[0]
        if not isinstance(source, Node):
            return None
        current = source

    if (
        current.op != "call_function"
        or current.target is not torch.ops.aten.stack.default
    ):
        return None

    tensors = current.args[0]
    dim = current.args[1] if len(current.args) > 1 else current.kwargs.get("dim", 0)
    if not isinstance(tensors, (list, tuple)) or not isinstance(dim, int):
        return None
    if len(tensors) <= 1 or not all(isinstance(tensor, Node) for tensor in tensors):
        return None

    first = cast("Node", tensors[0])
    first_val = first.meta.get("val")
    expected_dim = 1
    if isinstance(first_val, torch.Tensor):
        expected_dim = first_val.ndim - 1
        dim %= first_val.ndim + 1
    if dim != expected_dim:
        return None
    return tuple(cast("Node", tensor) for tensor in tensors), len(tensors)


def match_cute_duplicate_stack_reshape_rhs(node: Node) -> tuple[Node, int] | None:
    matched = match_cute_stack_reshape_rhs(node)
    if matched is None:
        return None
    tensors, factor = matched
    first = tensors[0]
    if not all(tensor == first for tensor in tensors[1:]):
        return None
    return first, factor
