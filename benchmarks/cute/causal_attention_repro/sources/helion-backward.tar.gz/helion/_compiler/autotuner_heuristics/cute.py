from __future__ import annotations

import contextlib
from copy import deepcopy
from itertools import zip_longest
from typing import TYPE_CHECKING
from typing import Any
from typing import cast

import sympy
import torch
from torch._inductor.runtime.runtime_utils import next_power_of_2
from torch._inductor.runtime.triton_heuristics import (
    get_max_y_grid,  # type: ignore[import-untyped]
)

from ...autotuner.config_spec import _CUTE_LANE_UNROLL_CHOICES
from ...autotuner.config_spec import CUTE_AFFINE_SCAN_SCHEDULE_KEY
from ...autotuner.config_spec import CUTE_CHUNK_PREPARE_SCHEDULE_KEY
from ...autotuner.config_spec import CUTE_CHUNK_RECURRENCE_DV_PARTITIONS_KEY
from ...autotuner.config_spec import CUTE_CHUNK_RECURRENCE_REGISTER_CAP_KEY
from ...autotuner.config_spec import CUTE_GDN_RECURRENCE_EPILOGUE_WARPS_KEY
from ...autotuner.config_spec import CUTE_GDN_RECURRENCE_MMA_M_KEY
from ...autotuner.config_spec import CUTE_GDN_RECURRENCE_STAGES_KEY
from ...autotuner.config_spec import CUTE_GDN_RECURRENCE_TOKEN_GROUPS_KEY
from ...autotuner.config_spec import _cute_chunk_recurrence_config_is_safe
from ...autotuner.config_spec import get_valid_eviction_policies
from ...language.memory_ops import _CUTE_VECTOR_MAX_BYTES
from ...language.memory_ops import load as language_load
from ...language.scan_ops import _associative_scan
from ...runtime.config import Config
from ..compile_environment import ConfigValueExpression
from ..compile_environment import FixedBlockSizeSource
from ..compile_environment import _symint_sympy_expr
from ..cute.cutedsl_compat import cp_async_supported
from ..cute.cutedsl_compat import tcgen05_runtime_n_ptx_compatible
from ..cute.cutedsl_compat import warn_tcgen05_runtime_n_ptx_fallback
from ..cute.grouped_full_coverage import FULL_COVERAGE_PIPELINES
from ..cute.grouped_full_coverage import full_coverage_index_domain
from ..cute.grouped_full_coverage import full_coverage_pipeline_supported
from ..cute.grouped_full_coverage import full_coverage_smem_upper_bound
from ..cute.grouped_row_union import PAIRED_CLC
from ..cute.grouped_row_union import PAIRED_CLC_SCHEDULE
from ..cute.grouped_row_union import SCHEDULE_KEY as GROUPED_ROW_UNION_SCHEDULE_KEY
from ..cute.grouped_row_union import TRANSPOSED
from ..cute.grouped_row_union import TRANSPOSED_SCHEDULE
from ..cute.grouped_row_union import index_domain as row_union_index_domain
from ..cute.grouped_row_union import resident_ctas_supported
from ..cute.grouped_worklist_policy import GroupedBMajor
from ..cute.grouped_worklist_policy import GroupedWorklistHardwareIdentity
from ..cute.grouped_worklist_policy import get_grouped_worklist_target_policy
from ..cute.grouped_worklist_policy import grouped_worklist_target_identities
from ..cute.loop_nesting import sibling_row_loop_blocks
from ..cute.loop_nesting import tile_loop_paths
from ..cute.matmul_utils import cute_matmul_root_placements
from ..cute.mma_support import cute_fp32_dot_uses_tf32
from ..cute.packed_matmul import packed_axis_for_fact
from ..cute.strategies import TCGEN05_L2_SWIZZLE_SIZE_CONFIG_KEY
from ..cute.strategies import TCGEN05_PERSISTENCE_MODEL_CONFIG_KEY
from ..cute.strategies import TCGEN05_STRATEGY_CONFIG_KEY
from ..cute.strategies import TCGEN05_WARP_SPEC_SCHEDULER_WARPS_KEY
from ..cute.strategies import Tcgen05PersistenceModel
from ..cute.strategies import Tcgen05Strategy
from ..cute.tcgen05_config import TCGEN05_GROUPED_DYNAMIC_AB4_STAGE
from ..cute.tcgen05_config import CuteTcgen05Config
from ..cute.tcgen05_constants import TCGEN05_CONSUMER_REGS_CONFIG_KEY
from ..cute.tcgen05_constants import TCGEN05_CONSUMER_REGS_DEFAULT
from ..cute.tcgen05_constants import TCGEN05_GROUPED_FULL_COVERAGE_CONFIG_KEY
from ..cute.tcgen05_constants import TCGEN05_GROUPED_FULL_COVERAGE_DENSE
from ..cute.tcgen05_constants import TCGEN05_GROUPED_FULL_COVERAGE_DENSE_LOCAL
from ..cute.tcgen05_constants import TCGEN05_GROUPED_MODE_CONFIG_KEY
from ..cute.tcgen05_constants import TCGEN05_GROUPED_MODE_DYNAMIC
from ..cute.tcgen05_constants import TCGEN05_GROUPED_MODE_STATIC
from ..cute.tcgen05_constants import TCGEN05_GROUPED_MODE_WORKLIST_NM
from ..cute.tcgen05_constants import TCGEN05_GROUPED_RUNTIME_DIRECT_CLC_MAX_CLUSTERS
from ..cute.tcgen05_constants import TCGEN05_GROUPED_RUNTIME_DIRECT_CONFIG_KEY
from ..cute.tcgen05_constants import TCGEN05_GROUPED_STATIC_COMMON_K_BLOCK_PAIRS
from ..cute.tcgen05_constants import TCGEN05_GROUPED_STATIC_RESERVED_SMS_CONFIG_KEY
from ..cute.tcgen05_constants import TCGEN05_GROUPED_STATIC_RESERVED_SMS_MAX
from ..cute.tcgen05_constants import TCGEN05_GROUPED_WORKLIST_BLOCK_K_CHOICES
from ..cute.tcgen05_constants import TCGEN05_GROUPED_WORKLIST_LARGE_SOURCE_M_TILE
from ..cute.tcgen05_constants import (
    TCGEN05_GROUPED_WORKLIST_ONE_CTA_SOURCE_M_TILE_CHOICES,
)
from ..cute.tcgen05_constants import TCGEN05_GROUPED_WORKLIST_SMALL_SOURCE_M_TILE
from ..cute.tcgen05_constants import TCGEN05_GROUPED_WORKLIST_SOURCE_M_TILE_CHOICES
from ..cute.tcgen05_constants import TCGEN05_GROUPED_WORKLIST_SOURCE_M_TILE_CONFIG_KEY
from ..cute.tcgen05_constants import TCGEN05_GROUPED_WORKLIST_SOURCE_M_TILE_DEFAULT
from ..cute.tcgen05_constants import TCGEN05_SCHED_STAGE_COUNT_CONFIG_KEY
from ..cute.tcgen05_constants import TCGEN05_TWO_CTA_BLOCK_M
from ..cute.tcgen05_constants import TCGEN05_TWO_CTA_BLOCK_N
from ..cute.tcgen05_constants import TCGEN05_TWO_CTA_EDGE_K_TAIL_BLOCK_K
from ..cute.tcgen05_constants import TCGEN05_TWO_CTA_FP8_SMALL_GRID_BLOCK_M
from ..cute.tcgen05_constants import TCGEN05_TWO_CTA_FP8_SMALL_GRID_BLOCK_N
from ..cute.tcgen05_constants import TCGEN05_TWO_CTA_SEED_L2_GROUPING
from ..cute.tcgen05_constants import TCGEN05_TWO_CTA_SEED_PID_TYPE
from ..cute.tcgen05_constants import resolve_tcgen05_grouped_worklist_mma_profile
from ..cute.tcgen05_constants import tcgen05_grouped_worklist_smem_bytes
from ..cute.tcgen05_constants import tcgen05_two_cta_edge_k_tail_seed_overrides
from ..cute.thread_budget import CUTE_REGISTER_TILE_MAX_ELEMENTS
from .common import dedupe_configs
from .common import is_canonical_row_reduction
from .registry import AutotunerHeuristic

if TYPE_CHECKING:
    from collections.abc import Mapping
    from collections.abc import Sequence

    from ...autotuner.config_fragment import BlockSizeFragment
    from ...autotuner.config_spec import ConfigSpec
    from ...autotuner.config_spec import MatmulFact
    from ...autotuner.config_spec import MemoryOpFact
    from ...autotuner.config_spec import ReductionLoopSpec
    from ..compile_environment import CompileEnvironment
    from ..cute.cute_mma import Tcgen05GroupedWorklistAnalysis
    from ..cute.gdn_recurrence import GdnRecurrenceGeometry
    from ..cute.grouped_worklist_policy import GroupedWorklistTargetPolicy
    from ..device_ir import DeviceIR
    from .registry import CompilerHeuristicSpecializationFact


def _seq_config_list(
    seq: Any,  # noqa: ANN401 - BlockIdSequence of any spec type
    overrides: Mapping[int, object],
) -> list[object]:
    """Build a full-length config list for a BlockIdSequence, filling
    non-overridden slots with each spec's default.  Seeds must match the
    live spec length exactly (``_encode_flat_values`` asserts on it), and
    slot order varies (e.g. ``num_threads`` registers tile slots first
    while ``cute_vector_widths`` keeps the rdim slot at index 0), so build
    by block id instead of by position."""
    return [
        overrides[item.block_id] if item.block_id in overrides else item._fill_missing()
        for item in seq
    ]


def _has_async_state_load_candidate(env: CompileEnvironment) -> bool:
    """Cheap device-IR gate for the stricter generated-AST matcher.

    This intentionally admits an input-layout-independent superset: a 16-bit
    tensor that is both read and written in one graph. The late AST pass proves
    the exact vector width, row/thread coverage, address equality, and alias
    facts from cache-specialized metadata.
    """
    by_tensor_graph: dict[tuple[str, int], list[MemoryOpFact]] = {}
    for fact in env.config_spec.memory_op_facts:
        if (
            fact.tensor_name is None
            or fact.dtype not in (torch.float16, torch.bfloat16)
            or fact.ndim < 2
        ):
            continue
        by_tensor_graph.setdefault((fact.tensor_name, fact.graph_id), []).append(fact)
    return any(
        any(fact.kind == "load" for fact in facts)
        and any(fact.kind == "store" for fact in facts)
        for facts in by_tensor_graph.values()
    )


class CutePackedSingleTokenRank1Heuristic(AutotunerHeuristic):
    """Seed packed one-warp single-token rank-1 recurrences.

    This is deliberately a cheap structural superset of the fail-closed FX
    matcher.  It never keys on a function or tensor name: the late matcher
    remains responsible for proving the complete recurrence and its layouts.
    """

    name = "cute_packed_single_token_rank1"
    backend = "cute"
    CACHE_SPECIALIZATION_FACTS = frozenset({"input_tensor_metadata"})

    @classmethod
    def _value_block_id(
        cls, env: CompileEnvironment, device_ir: DeviceIR
    ) -> int | None:
        spec = env.config_spec
        grid_fact = spec.kernel_grid_fact
        if (
            spec.matmul_facts
            or len(spec.block_sizes) != 1
            or grid_fact is None
            or len(grid_fact.roots) != 1
        ):
            return None
        (root,) = grid_fact.roots
        if len(root.block_ids) != 3:
            return None
        value_spec = cast("Any", spec.block_sizes[0])
        if value_spec.block_id != root.block_ids[-1] or not any(
            value_spec.min_size <= tile <= value_spec.max_size for tile in (8, 16)
        ):
            return None

        reduction_blocks = [block for block in env.block_sizes if block.reduction]
        if len(reduction_blocks) != 1:
            return None
        try:
            reduction_size = int(reduction_blocks[0].numel)
        except (TypeError, ValueError):
            return None
        if reduction_size != 128:
            return None

        facts = [fact for fact in spec.memory_op_facts if fact.tensor_name is not None]
        root_index_loads = [
            fact
            for fact in facts
            if fact.graph_id == root.root_graph_id
            and fact.kind == "load"
            and fact.ndim == 1
            and fact.dtype in (torch.int32, torch.int64)
        ]
        if len(root_index_loads) != 1:
            return None

        by_tensor_graph: dict[tuple[str, int], list[MemoryOpFact]] = {}
        by_tensor: dict[str, list[MemoryOpFact]] = {}
        for fact in facts:
            assert fact.tensor_name is not None
            by_tensor_graph.setdefault((fact.tensor_name, fact.graph_id), []).append(
                fact
            )
            by_tensor.setdefault(fact.tensor_name, []).append(fact)
        state_candidates = [
            (name, graph_id)
            for (name, graph_id), tensor_facts in by_tensor_graph.items()
            if tensor_facts[0].dtype is torch.bfloat16
            and tensor_facts[0].ndim == 4
            and sum(fact.kind == "load" for fact in tensor_facts) == 1
            and sum(fact.kind == "store" for fact in tensor_facts) == 1
        ]
        if len(state_candidates) != 1:
            return None
        _, recurrence_graph_id = state_candidates[0]
        has_packed_input = any(
            tensor_facts[0].dtype is torch.bfloat16
            and tensor_facts[0].ndim == 2
            and sum(
                fact.kind == "load" and fact.graph_id == recurrence_graph_id
                for fact in tensor_facts
            )
            >= 3
            for tensor_facts in by_tensor.values()
        )
        has_branched_output = any(
            tensor_facts[0].dtype is torch.bfloat16
            and tensor_facts[0].ndim == 4
            and all(fact.kind == "store" for fact in tensor_facts)
            and any(fact.graph_id == recurrence_graph_id for fact in tensor_facts)
            and any(fact.graph_id != recurrence_graph_id for fact in tensor_facts)
            for tensor_facts in by_tensor.values()
        )
        return value_spec.block_id if has_packed_input and has_branched_output else None

    @classmethod
    def is_eligible(cls, env: CompileEnvironment, device_ir: DeviceIR) -> bool:
        return cls._value_block_id(env, device_ir) is not None

    @classmethod
    def register_facts(
        cls, env: CompileEnvironment, device_ir: DeviceIR
    ) -> frozenset[CompilerHeuristicSpecializationFact]:
        return (
            cls.CACHE_SPECIALIZATION_FACTS
            if cls._value_block_id(env, device_ir) is not None
            else frozenset()
        )

    @classmethod
    def _seed_configs(
        cls, env: CompileEnvironment, device_ir: DeviceIR
    ) -> list[Config]:
        value_block_id = cls._value_block_id(env, device_ir)
        if value_block_id is None:
            return []
        spec = env.config_spec
        value_spec = cast("Any", spec.block_sizes[0])
        reduction_blocks = [block for block in env.block_sizes if block.reduction]
        if len(reduction_blocks) != 1:
            return []
        reduction_block_id = reduction_blocks[0].block_id
        if not {value_block_id, reduction_block_id}.issubset(
            spec.num_threads.valid_block_ids()
        ):
            return []

        def make_seed(tile_rows: int, num_warps: int) -> Config:
            num_threads = (
                _seq_config_list(
                    spec.num_threads,
                    {
                        value_block_id: 1,
                        reduction_block_id: 32,
                    },
                )
                if num_warps == 1
                else _seq_config_list(spec.num_threads, {})
            )
            return Config(
                block_sizes=cast(
                    "list[int]",
                    _seq_config_list(
                        spec.block_sizes,
                        {value_block_id: tile_rows},
                    ),
                ),
                # CuTe SIMT autotuning represents launch topology with
                # per-axis ``num_threads``.  Keep ``num_warps`` as the direct,
                # pinned-config compatibility signal, but encode one value-row
                # thread by 32 reduction threads so flatten/unflatten preserves
                # the one-warp seed.
                num_threads=cast("list[int]", num_threads),
                loop_orders=[[2, 1, 0]],
                num_warps=num_warps,
                num_stages=1,
                indexing="pointer",
                pid_type="flat",
            )

        seeds = [
            make_seed(tile_rows, 1)
            for tile_rows in (16, 8)
            if value_spec.min_size <= tile_rows <= value_spec.max_size
        ]
        if value_spec.min_size <= 16 <= value_spec.max_size:
            # Preserve an explicit path to the existing 256-thread B1 body.
            seeds.append(make_seed(16, 8))
        return seeds

    @classmethod
    def get_seed_config(
        cls, env: CompileEnvironment, device_ir: DeviceIR
    ) -> Config | None:
        seeds = cls._seed_configs(env, device_ir)
        return seeds[0] if seeds else None

    @classmethod
    def get_seed_configs(
        cls, env: CompileEnvironment, device_ir: DeviceIR
    ) -> list[Config] | None:
        seeds = cls._seed_configs(env, device_ir)
        return seeds or None


class CuteFixedTokenRank1Heuristic(AutotunerHeuristic):
    """Seed the grouped fixed-token rank-1 recurrence schedule.

    The seed is intentionally selected from device-IR structure rather than a
    function or benchmark name.  The late fixed-token matcher remains the
    authority and fails closed unless it proves the complete recurrence.
    """

    name = "cute_fixed_token_rank1"
    backend = "cute"
    CACHE_SPECIALIZATION_FACTS = frozenset({"input_tensor_metadata"})

    @classmethod
    def _value_block_id(
        cls, env: CompileEnvironment, device_ir: DeviceIR
    ) -> int | None:
        spec = env.config_spec
        grid_fact = spec.kernel_grid_fact
        if (
            spec.matmul_facts
            or len(spec.block_sizes) != 1
            or grid_fact is None
            or len(grid_fact.roots) != 1
        ):
            return None
        (root,) = grid_fact.roots
        if len(root.block_ids) != 3:
            return None
        value_spec = cast("Any", spec.block_sizes[0])
        if (
            value_spec.block_id != root.block_ids[-1]
            or not value_spec.min_size <= 32 <= value_spec.max_size
        ):
            return None

        reduction_blocks = [block for block in env.block_sizes if block.reduction]
        if len(reduction_blocks) != 1:
            return None
        try:
            reduction_size = int(reduction_blocks[0].numel)
        except (TypeError, ValueError):
            return None
        if reduction_size != 128:
            return None

        by_tensor_graph: dict[tuple[str, int], list[MemoryOpFact]] = {}
        for fact in spec.memory_op_facts:
            if (
                fact.tensor_name is not None
                and fact.graph_id == root.root_graph_id
                and fact.dtype is torch.bfloat16
            ):
                by_tensor_graph.setdefault(
                    (fact.tensor_name, fact.graph_id), []
                ).append(fact)
        state_store_counts = [
            sum(fact.kind == "store" for fact in facts)
            for facts in by_tensor_graph.values()
            if facts[0].ndim == 4 and sum(fact.kind == "load" for fact in facts) == 1
        ]
        if (
            len(state_store_counts) != 1
            or not 2 <= state_store_counts[0] <= 6
            or sum(
                fact.kind == "store" and fact.ndim == 3
                for fact in spec.memory_op_facts
                if fact.graph_id == root.root_graph_id
            )
            != state_store_counts[0]
        ):
            return None
        return value_spec.block_id

    @classmethod
    def is_eligible(cls, env: CompileEnvironment, device_ir: DeviceIR) -> bool:
        return cls._value_block_id(env, device_ir) is not None

    @classmethod
    def register_facts(
        cls, env: CompileEnvironment, device_ir: DeviceIR
    ) -> frozenset[CompilerHeuristicSpecializationFact]:
        return (
            cls.CACHE_SPECIALIZATION_FACTS
            if cls._value_block_id(env, device_ir) is not None
            else frozenset()
        )

    @classmethod
    def get_seed_config(
        cls, env: CompileEnvironment, device_ir: DeviceIR
    ) -> Config | None:
        value_block_id = cls._value_block_id(env, device_ir)
        if value_block_id is None:
            return None
        return Config(
            block_sizes=cast(
                "list[int]",
                _seq_config_list(
                    env.config_spec.block_sizes,
                    {value_block_id: 32},
                ),
            ),
            num_warps=4,
            num_stages=1,
            indexing="pointer",
            pid_type="flat",
        )


def _affine_scan_search_context(
    env: CompileEnvironment, *, require_supported_extent: bool
) -> tuple[int, int, int, dict[tuple[str, int], list[MemoryOpFact]]] | None:
    spec = env.config_spec
    grid_fact = spec.kernel_grid_fact
    if (
        spec.matmul_facts
        or len(spec.block_sizes) != 1
        or grid_fact is None
        or len(grid_fact.roots) != 1
    ):
        return None
    (root,) = grid_fact.roots
    row_spec = cast("Any", spec.block_sizes[0])
    row_block_id = row_spec.block_id
    if row_block_id not in root.block_ids:
        return None

    reduction_blocks = [block for block in env.block_sizes if block.reduction]
    if len(reduction_blocks) != 1:
        return None
    reduction = reduction_blocks[0]
    try:
        feature_extent = int(reduction.numel)
    except (TypeError, ValueError):
        return None
    if require_supported_extent and feature_extent != 128:
        return None

    by_tensor: dict[tuple[str, int], list[MemoryOpFact]] = {}
    for fact in spec.memory_op_facts:
        if fact.tensor_name is not None and fact.graph_id == root.root_graph_id:
            by_tensor.setdefault((fact.tensor_name, fact.graph_id), []).append(fact)
    return row_block_id, reduction.block_id, len(root.block_ids), by_tensor


def _affine_scan_search_geometry(
    env: CompileEnvironment,
) -> tuple[int, int, int, int] | None:
    """Infer an unambiguous seed from a possible affine-scan region.

    This is deliberately a structural superset of the semantic matcher.  The
    late lowering remains authoritative for the recurrence, accesses, aliases,
    and generated thread coordinates.
    """

    context = _affine_scan_search_context(env, require_supported_extent=True)
    if context is None:
        return None
    row_block_id, feature_block_id, root_rank, by_tensor = context
    possible_step_counts: set[int] = set()
    for state_key, facts in by_tensor.items():
        if (
            facts[0].dtype is not torch.bfloat16
            or facts[0].ndim < 2
            or not any(fact.kind == "load" for fact in facts)
        ):
            continue
        step_count = sum(fact.kind == "store" for fact in facts)
        if not 2 <= step_count <= 8:
            continue
        non_state_stores = sum(
            fact.kind == "store" and fact.dtype is torch.bfloat16
            for key, other_facts in by_tensor.items()
            if key != state_key
            for fact in other_facts
        )
        if non_state_stores >= step_count:
            possible_step_counts.add(step_count)
    if len(possible_step_counts) != 1:
        return None
    (step_count,) = possible_step_counts
    return row_block_id, feature_block_id, step_count, root_rank


def _may_have_affine_scan(
    env: CompileEnvironment, *, require_supported_extent: bool
) -> bool:
    """Cheap superset used to expose direct choices without seed assumptions."""

    context = _affine_scan_search_context(
        env, require_supported_extent=require_supported_extent
    )
    if context is None:
        return False
    by_tensor = context[3]
    return any(
        facts[0].dtype is torch.bfloat16
        and facts[0].ndim >= 2
        and any(fact.kind == "load" for fact in facts)
        and sum(fact.kind == "store" for fact in facts) >= 2
        and sum(
            fact.kind == "store" and fact.dtype is torch.bfloat16
            for other_name, other_facts in by_tensor.items()
            if other_name != name
            for fact in other_facts
        )
        >= 2
        for name, facts in by_tensor.items()
    )


class CuteAffineScanHeuristic(AutotunerHeuristic):
    """Expose the generic direct-affine schedule behind a structural gate."""

    name = "cute_affine_scan"
    backend = "cute"
    CACHE_SPECIALIZATION_FACTS = frozenset({"input_tensor_metadata"})

    @classmethod
    def register_facts(
        cls, env: CompileEnvironment, device_ir: DeviceIR
    ) -> frozenset[CompilerHeuristicSpecializationFact]:
        capability = env.config_spec.target_device_capability
        if capability is None or capability < (8, 0) or not env.settings.fast_math:
            return frozenset()
        if not _may_have_affine_scan(env, require_supported_extent=False):
            return frozenset()
        if not _may_have_affine_scan(env, require_supported_extent=True):
            return cls.CACHE_SPECIALIZATION_FACTS
        geometry = _affine_scan_search_geometry(env)
        env.config_spec.enable_cute_affine_scan_search(
            step_count=None if geometry is None else geometry[2]
        )
        # The geometry predicate consumes runtime tensor extents.  Keep the
        # negative binding specialized too, so a later dynamic-shape call that
        # does match cannot reuse a ConfigSpec where the choices stayed hidden.
        return cls.CACHE_SPECIALIZATION_FACTS

    @classmethod
    def is_eligible(cls, env: CompileEnvironment, device_ir: DeviceIR) -> bool:
        return env.config_spec.cute_affine_scan_schedule is not None

    @classmethod
    def get_seed_configs(
        cls, env: CompileEnvironment, device_ir: DeviceIR
    ) -> list[Config] | None:
        geometry = _affine_scan_search_geometry(env)
        if geometry is None or env.config_spec.cute_affine_scan_schedule is None:
            return None
        row_block_id, feature_block_id, step_count, root_rank = geometry
        from ..cute.direct_affine_plan import DirectAffineMma
        from ..cute.direct_affine_plan import decode_direct_affine_schedule
        from ..cute.direct_affine_plan import select_direct_affine_schedule

        schedule_name = select_direct_affine_schedule(step_count)
        schedule = decode_direct_affine_schedule(schedule_name)
        if schedule is None:
            return None
        row_extent = 64 if schedule.mma is DirectAffineMma.M16N8 else 128
        row_spec = cast("Any", env.config_spec.block_sizes[0])
        if not row_spec.min_size <= row_extent <= row_spec.max_size or not {
            row_block_id,
            feature_block_id,
        }.issubset(env.config_spec.num_threads.valid_block_ids()):
            return None
        values = {
            "block_sizes": cast(
                "list[int]",
                _seq_config_list(
                    env.config_spec.block_sizes,
                    {row_block_id: row_extent},
                ),
            ),
            "num_threads": cast(
                "list[int]",
                _seq_config_list(
                    env.config_spec.num_threads,
                    {row_block_id: row_extent // 16, feature_block_id: 32},
                ),
            ),
            "loop_orders": [list(reversed(range(root_rank)))],
            "num_warps": row_extent // 16,
            "num_stages": 1,
            "indexing": "pointer",
            "pid_type": "flat",
            CUTE_AFFINE_SCAN_SCHEDULE_KEY: schedule_name,
        }
        return [Config.from_dict(values)]

    @classmethod
    def get_seed_config(
        cls, env: CompileEnvironment, device_ir: DeviceIR
    ) -> Config | None:
        seeds = cls.get_seed_configs(env, device_ir)
        return seeds[0] if seeds else None


class CuteAsyncStateLoadHeuristic(AutotunerHeuristic):
    """Seed the proven shared-memory ring for in-place vector state updates.

    Eligibility is deliberately broader than codegen matching so it can be
    derived from stable device-IR facts. The AST pass is fail-closed and emits
    no shared allocation unless one exact disjoint row/vector region matches.
    """

    name = "cute_async_state_load"
    backend = "cute"

    @classmethod
    def register_facts(
        cls, env: CompileEnvironment, device_ir: DeviceIR
    ) -> frozenset[CompilerHeuristicSpecializationFact]:
        if cp_async_supported(
            env.config_spec.target_device_capability
        ) and _has_async_state_load_candidate(env):
            env.config_spec.enable_cute_async_load_pipeline()
            env.config_spec.enable_cute_bf16x2_recurrence()
            env.config_spec.enable_cute_proven_bounds()
            # Generated scheduling consumes exact tensor extents and strides.
            # Make those values part of the bound-kernel cache key so a later
            # dynamic-shape/layout call cannot reuse an incompatible ring.
            return frozenset({"input_tensor_metadata"})
        return frozenset()

    @classmethod
    def is_eligible(cls, env: CompileEnvironment, device_ir: DeviceIR) -> bool:
        return (
            cp_async_supported(env.config_spec.target_device_capability)
            and env.config_spec.cute_async_load_pipeline_enabled
        )

    @staticmethod
    def _seed_overrides() -> dict[str, object]:
        return {
            "cute_async_load_stages": 5,
            "cute_async_load_lookahead": 4,
            "cute_async_load_group_rows": 2,
            "cute_async_load_cache": "cg",
            "cute_proven_bounds": False,
        }

    @classmethod
    def get_seed_config(
        cls, env: CompileEnvironment, device_ir: DeviceIR
    ) -> Config | None:
        if not cls.is_eligible(env, device_ir):
            return None
        values = dict(env.config_spec.autotune_reference_config().config)
        values.update(cls._seed_overrides())
        return Config.from_dict(values)


def _cute_seed_vec_width(
    env: CompileEnvironment,
    rl_spec: ReductionLoopSpec,
    max_threads: int,
    size_hint: int,
    device_ir: DeviceIR,
) -> int:
    """Pick a default vector width for the cute_vector_widths seed.

    Returns 1 (scalar) when the kernel has no plausible LDG.128 win, or
    the dtype is not supported by the vector load helper. For supported
    dtypes, prefer 4 (fp32) / 8 (fp16/bf16) when the reduction is wide
    enough that a vec-load actually halves the number of inner-loop
    iters.  For fp16/bf16 the V=8 seed is sampled even when the picked
    tile doesn't exactly match the seed size_hint — the per-block
    strategy at construction time validates ``EPT % V == 0`` and falls
    back to V=1 if the chosen lattice can't fit V=8, so over-seeding is
    safe and lets the hill-climber discover the V>1 lattices that lift
    softmax-style reductions from scalar LDG to LDG.64/LDG.128.
    """
    spec = env.config_spec
    if not spec.cute_vector_widths.valid_block_ids():
        return 1
    if size_hint < max_threads:
        # Reduction extent barely fits in one wide chunk; vec wouldn't
        # remove enough loop iters to matter.
        return 1
    return _cute_tile_seed_vec_width_for_dtype(
        _cute_seed_reduction_dtype(rl_spec, device_ir)
    )


def _cute_seed_reduction_dtype(
    rl_spec: ReductionLoopSpec, device_ir: DeviceIR
) -> torch.dtype | None:
    """Find the dtype of the reduction-source tensor by walking nodes that
    have a fake-tensor value matching the reduction extent."""
    rdim_size = rl_spec.size_hint
    for graph_info in device_ir.graphs:
        for node in graph_info.graph.nodes:
            val = node.meta.get("val")
            if isinstance(val, torch.Tensor) and val.ndim >= 1:
                last = val.shape[-1]
                if isinstance(last, int) and last == rdim_size:
                    return val.dtype
    return None


class CuteReductionTileHeuristic(AutotunerHeuristic):
    """Seed config for canonical reduction kernels (RMS norm, softmax, etc.).

    Seeds the "narrow chunk" config: bs=1, nt=1, reduction_loops=[None] for
    N<=max_threads (single-pass persistent reduction) or
    reduction_loops=[max_threads] for N>max_threads (one element per
    thread per iter, no lane loop). This config keeps the M-axis at one
    row per block so the reduction recruits all available threads, and
    the two-pass load fusion (helion/_compiler/cute/fuse_two_pass_loads.py)
    eliminates the redundant gmem reload of x in the post-reduction sweep.

    A persistent row whose static extent is a power of two additionally
    seeds the one-vector-per-thread layout: ``N / V`` threads (a multiple of
    32) each own one 16-byte fragment and the per-thread V-folds are combined
    once with the cross-warp two-stage shared reduce.  For a 1024-wide bf16
    row that is a 128-thread CTA issuing one LDG.128 per thread (the Triton
    kernel's shape) instead of 1024 threads loading one scalar each.
    """

    name = "cute_reduction_tile"
    backend = "cute"

    @classmethod
    def is_eligible(cls, env: CompileEnvironment, device_ir: DeviceIR) -> bool:
        return is_canonical_row_reduction(env)

    @classmethod
    def get_seed_config(
        cls, env: CompileEnvironment, device_ir: DeviceIR
    ) -> Config | None:
        spec = env.config_spec
        rl_spec = cast("ReductionLoopSpec", spec.reduction_loops[0])
        max_threads = spec.max_reduction_threads or 1024
        size_hint = rl_spec.size_hint
        if size_hint <= max_threads:
            # Persistent reduction (no roll). The normalize step will keep
            # reduction_loops[0]=None when the M-axis allows it.
            reduction_loops: list[int | None] = [None]
        else:
            reduction_loops = [max_threads]
        seed: dict[str, Any] = {
            "block_sizes": [1],
            "num_threads": _seq_config_list(spec.num_threads, {}),
            "reduction_loops": reduction_loops,
        }
        vec = _cute_seed_vec_width(env, rl_spec, max_threads, size_hint, device_ir)
        if vec > 1:
            seed["cute_vector_widths"] = _seq_config_list(
                spec.cute_vector_widths, {rl_spec.block_id: vec}
            )
        return Config(**seed)

    @classmethod
    def multiwarp_vector_row_seed_config(
        cls, env: CompileEnvironment, device_ir: DeviceIR
    ) -> Config | None:
        """One 16-byte vector per thread across a warp-aligned CTA.

        ``PersistentReductionStrategy`` applies ``cute_vector_widths`` only when
        V exactly covers each thread's slice, so the layout needs
        ``num_threads = N / V`` on the reduction block.  Requires a persistent
        (unrolled) static power-of-two extent -- a dynamic extent is masked and
        never vectorized, whatever its size hint -- and at least one full warp
        of threads.
        """
        spec = env.config_spec
        rl_spec = cast("ReductionLoopSpec", spec.reduction_loops[0])
        max_threads = spec.max_reduction_threads or 1024
        block_id = rl_spec.block_id
        numel = env.block_sizes[block_id].numel
        if not numel.is_Integer:
            return None
        extent = int(numel)
        if (
            extent > max_threads
            or extent & (extent - 1)
            or block_id not in spec.num_threads.valid_block_ids()
            or block_id not in spec.cute_vector_widths.valid_block_ids()
        ):
            return None
        vec = _cute_tile_seed_vec_width_for_dtype(
            _cute_seed_reduction_dtype(rl_spec, device_ir)
        )
        if vec <= 1 or extent % vec:
            return None
        threads = extent // vec
        if threads < 32 or threads % 32:
            return None
        seed: dict[str, Any] = {
            "block_sizes": [1],
            "num_threads": _seq_config_list(spec.num_threads, {block_id: threads}),
            "reduction_loops": [None],
            "cute_vector_widths": _seq_config_list(
                spec.cute_vector_widths, {block_id: vec}
            ),
        }
        return Config(**seed)

    @classmethod
    def get_seed_configs(
        cls, env: CompileEnvironment, device_ir: DeviceIR
    ) -> list[Config] | None:
        primary = cls.get_seed_config(env, device_ir)
        if primary is None:
            return None
        alternate = cls.multiwarp_vector_row_seed_config(env, device_ir)
        if alternate is None or alternate == primary:
            return [primary]
        return [primary, alternate]


class CuteRegisterTileHeuristic(AutotunerHeuristic):
    """Seed a per-thread register tile for a reduction over a vectorized tile.

    Kernels that reduce a 2-D tile along its strided axis while the stride-1
    axis stays a free tile (the fused linear-attention state update,
    ``sum(q[:, None] * state, 0)``) get one 16-byte fragment of the stride-1
    axis per thread and a trace-time reduction lane loop outside that vector
    loop (``cute/register_tile_reductions.py``): eight vector threads cover a
    128-byte row segment per warp row, every lane's packet load issues before
    the first store, and each tile column is combined once with the
    shared-memory column reduce.  The seed sizes the reduction thread count so
    the unrolled register tile holds ``CUTE_REGISTER_TILE_MAX_ELEMENTS`` per
    thread.

    Disjoint from ``CuteColumnReductionHeuristic``, which seeds the reduction
    over a serial device-loop axis of a kernel without reduction loops (for
    ``cute_vloop_sink``): this seed needs exactly one reduction loop, so no
    kernel is eligible for both and the seeds need no precedence.
    """

    name = "cute_register_tile"
    backend = "cute"
    VECTOR_THREADS = 8

    @classmethod
    def _geometry(
        cls, env: CompileEnvironment, device_ir: DeviceIR
    ) -> tuple[int, int, int, int, int, int] | None:
        """``(tile_block_id, tile_block, tile_threads, reduction_block_id,
        reduction_threads, vec)``, or ``None`` when the kernel lacks the shape."""
        spec = env.config_spec
        if spec.matmul_facts or len(spec.reduction_loops) != 1:
            return None
        rl_spec = cast("ReductionLoopSpec", spec.reduction_loops[0])
        if rl_spec.block_id not in spec.cute_register_tile_reduction_blocks:
            return None
        max_threads = spec.max_reduction_threads
        size_hint = rl_spec.size_hint
        if max_threads is None or size_hint > max_threads or size_hint < 2:
            return None
        tile_block_ids = [
            block_id
            for block_id in spec.block_sizes.valid_block_ids()
            if block_id in spec.cute_vector_widths.valid_block_ids()
            and block_id in spec.num_threads.valid_block_ids()
        ]
        if len(tile_block_ids) != 1:
            return None
        (tile_block_id,) = tile_block_ids
        if rl_spec.block_id not in spec.num_threads.valid_block_ids():
            return None
        vec = _cute_tile_seed_vec_width_for_dtype(
            _cute_tile_inner_block_dtype(env, device_ir, tile_block_id)
        )
        if vec <= 1:
            return None
        numel = env.block_sizes[tile_block_id].numel
        if not isinstance(numel, (int, sympy.Integer)):
            return None
        tile_block = min(int(numel), cls.VECTOR_THREADS * vec)
        if tile_block % vec or (int(numel) % tile_block):
            return None
        tile_threads = tile_block // vec
        lanes = max(1, CUTE_REGISTER_TILE_MAX_ELEMENTS // vec)
        reduction_threads = next_power_of_2(max(1, -(-size_hint // lanes)))
        if size_hint % reduction_threads or tile_threads * reduction_threads > (
            spec.max_reduction_threads or 1024
        ):
            return None
        if size_hint // reduction_threads < 2:
            # One row per thread needs no lane loop; the persistent
            # one-vector layouts cover that shape.
            return None
        return (
            tile_block_id,
            tile_block,
            tile_threads,
            rl_spec.block_id,
            reduction_threads,
            vec,
        )

    @classmethod
    def is_eligible(cls, env: CompileEnvironment, device_ir: DeviceIR) -> bool:
        return cls._geometry(env, device_ir) is not None

    @classmethod
    def get_seed_config(
        cls, env: CompileEnvironment, device_ir: DeviceIR
    ) -> Config | None:
        geometry = cls._geometry(env, device_ir)
        if geometry is None:
            return None
        (
            tile_block_id,
            tile_block,
            tile_threads,
            reduction_block_id,
            reduction_threads,
            vec,
        ) = geometry
        spec = env.config_spec
        seed: dict[str, Any] = {
            "block_sizes": [
                tile_block if block_id == tile_block_id else 1
                for block_id in spec.block_sizes.valid_block_ids()
            ],
            "num_threads": _seq_config_list(
                spec.num_threads,
                {tile_block_id: tile_threads, reduction_block_id: reduction_threads},
            ),
            "reduction_loops": [None],
            "cute_vector_widths": _seq_config_list(
                spec.cute_vector_widths, {tile_block_id: vec}
            ),
        }
        return Config(**seed)


def _cute_tile_seed_vec_width_for_dtype(dtype: torch.dtype | None) -> int:
    """V seed for ``PerThreadNDTileStrategy`` lane-loop vec on a given dtype.

    Seeds a full 16-byte LDG.128 per thread per outer iter: V=4 for fp32,
    V=8 for fp16/bf16 (a single ``cute.arch.load(..., V=8)``; the old 4+4
    split workaround for the ``nvvm.load.ext`` ICE is gone as of cutlass
    4.7).
    """
    if dtype is torch.float32:
        return 4
    if dtype in (torch.float16, torch.bfloat16):
        return 8
    return 1


def _cute_tile_inner_block_dtype(
    env: CompileEnvironment, device_ir: DeviceIR, block_id: int
) -> torch.dtype | None:
    """Walk the device graphs to find the dtype of any tensor whose
    LAST dim corresponds to ``block_id``'s tile.  Used to seed the per-
    block vec width when the kernel has no rolled reduction (e.g.
    softmax_two_pass — its two ``hl.tile`` loops over the reduction
    axis don't go through the ``ReductionLoopSpec`` path)."""
    bs = env.block_sizes[block_id]
    if env.is_jagged_tile(block_id):
        # Jagged lengths have no static numel. Their tile symbol still
        # identifies data values in the traced body; ignore index/mask tensors.
        for graph_info in device_ir.graphs:
            for node in graph_info.graph.nodes:
                val = node.meta.get("val")
                if (
                    isinstance(val, torch.Tensor)
                    and val.ndim >= 1
                    and val.dtype in (torch.float16, torch.bfloat16, torch.float32)
                    and isinstance(val.shape[-1], torch.SymInt)
                    and val.shape[-1]._sympy_() == bs.var._sympy_()
                ):
                    return val.dtype
        return None
    block_numel = bs.numel
    try:
        block_numel_int = int(block_numel)
    except (TypeError, ValueError):
        return None
    for graph_info in device_ir.graphs:
        for node in graph_info.graph.nodes:
            val = node.meta.get("val")
            if isinstance(val, torch.Tensor) and val.ndim >= 1:
                last = val.shape[-1]
                if isinstance(last, int) and last == block_numel_int:
                    return val.dtype
    return None


class CutePersistentSubwarpRowsHeuristic(AutotunerHeuristic):
    """Seed a row-tiled, one-vector persistent reduction.

    This targets the general shape of a small row tile sharing a short static
    reduction: eight row threads, one 16-byte reduction fragment per thread,
    and register reloads across repeated reduction sweeps.  It is deliberately
    an autotuning seed only; no architecture has promoted it to the default.
    """

    name = "cute_persistent_subwarp_rows"
    backend = "cute"
    CACHE_SPECIALIZATION_FACTS = frozenset({"input_tensor_metadata"})
    FULL_ROW_BLOCK_SIZE = 128
    RECURRENT_STYLE_REDUCTION_SIZE = 128
    RECURRENT_STYLE_REDUCTION_THREADS = 32
    RECURRENT_STYLE_ROW_THREADS = 1
    RECURRENT_STYLE_VECTOR_WIDTH = 4

    @classmethod
    def register_facts(
        cls, env: CompileEnvironment, device_ir: DeviceIR
    ) -> frozenset[CompilerHeuristicSpecializationFact]:
        # The lane-splitting legality proof consumes exact runtime strides.
        # Register this independently of seed generation so explicitly pinned
        # configs and autotuner-disabled compilation remain cache-safe.
        return (
            cls.CACHE_SPECIALIZATION_FACTS if cls._plan(env, device_ir) else frozenset()
        )

    @staticmethod
    def _reduction_dtype(
        device_ir: DeviceIR, reduction_size: int
    ) -> torch.dtype | None:
        # Ignore the integer FakeTensor produced by ``hl.arange`` itself and
        # find a vector-loadable tensor value using that trailing dimension.
        best_dtype: torch.dtype | None = None
        best_width = 1
        for graph_info in device_ir.graphs:
            for node in graph_info.graph.nodes:
                value = node.meta.get("val")
                target_name = getattr(node.target, "__name__", "")
                if (
                    isinstance(value, torch.Tensor)
                    and value.ndim >= 1
                    and isinstance(value.shape[-1], int)
                    and value.shape[-1] == reduction_size
                    and target_name in ("_host_tensor", "load")
                ):
                    width = _cute_tile_seed_vec_width_for_dtype(value.dtype)
                    if width > best_width:
                        best_dtype = value.dtype
                        best_width = width
        return best_dtype

    @classmethod
    def _plan(
        cls, env: CompileEnvironment, device_ir: DeviceIR
    ) -> tuple[int, int, int] | None:
        spec = env.config_spec
        if spec.matmul_facts or spec.reduction_loops or len(spec.block_sizes) != 1:
            return None
        reduction_blocks = [block for block in env.block_sizes if block.reduction]
        if len(reduction_blocks) != 1:
            return None
        reduction_block = reduction_blocks[0]
        try:
            reduction_size = int(reduction_block.numel)
        except (TypeError, ValueError):
            return None
        vec = _cute_tile_seed_vec_width_for_dtype(
            cls._reduction_dtype(device_ir, reduction_size)
        )
        if vec <= 1 or not 128 <= reduction_size <= 256:
            return None
        if reduction_size % vec:
            return None
        reduction_threads = reduction_size // vec
        if reduction_threads not in (16, 32):
            return None

        row_spec = cast("Any", spec.block_sizes[0])
        if len(row_spec.block_ids) != 1:
            return None
        if not row_spec.min_size <= 16 <= row_spec.max_size:
            return None
        row_block_id = row_spec.block_id
        required = (
            (spec.num_threads, row_block_id),
            (spec.num_threads, reduction_block.block_id),
            (spec.cute_vector_widths, reduction_block.block_id),
            (spec.cute_lane_layouts, reduction_block.block_id),
            (spec.cute_reduction_reloads, reduction_block.block_id),
        )
        if any(
            block_id not in sequence.valid_block_ids()
            for sequence, block_id in required
        ):
            return None
        return row_block_id, reduction_block.block_id, reduction_threads

    @classmethod
    def is_eligible(cls, env: CompileEnvironment, device_ir: DeviceIR) -> bool:
        return cls._plan(env, device_ir) is not None

    @classmethod
    def get_seed_config(
        cls, env: CompileEnvironment, device_ir: DeviceIR
    ) -> Config | None:
        plan = cls._plan(env, device_ir)
        if plan is None:
            return None
        row_block_id, reduction_block_id, reduction_threads = plan
        return cls._seed_config(
            env,
            row_block_id,
            reduction_block_id,
            reduction_threads,
            row_block_size=16,
        )

    @classmethod
    def _seed_config(
        cls,
        env: CompileEnvironment,
        row_block_id: int,
        reduction_block_id: int,
        reduction_threads: int,
        *,
        row_block_size: int,
        row_threads: int = 8,
    ) -> Config:
        reduction_size = int(env.block_sizes[reduction_block_id].numel)
        vec = reduction_size // reduction_threads
        seed: dict[str, Any] = {
            "block_sizes": _seq_config_list(
                env.config_spec.block_sizes, {row_block_id: row_block_size}
            ),
            "num_threads": _seq_config_list(
                env.config_spec.num_threads,
                {row_block_id: row_threads, reduction_block_id: reduction_threads},
            ),
            "cute_vector_widths": _seq_config_list(
                env.config_spec.cute_vector_widths, {reduction_block_id: vec}
            ),
            "cute_lane_layouts": _seq_config_list(
                env.config_spec.cute_lane_layouts, {reduction_block_id: "blocked"}
            ),
            "cute_reduction_reloads": _seq_config_list(
                env.config_spec.cute_reduction_reloads,
                {reduction_block_id: "register"},
            ),
            "num_warps": max(1, row_threads * reduction_threads // 32),
            "num_stages": 1,
            "pid_type": "flat",
        }
        return Config(**seed)

    @classmethod
    def _recurrent_style_seed_config(
        cls,
        env: CompileEnvironment,
        device_ir: DeviceIR,
        row_block_id: int,
        reduction_block_id: int,
    ) -> Config | None:
        reduction_size = int(env.block_sizes[reduction_block_id].numel)
        if reduction_size != cls.RECURRENT_STYLE_REDUCTION_SIZE:
            return None
        dtype_vec = _cute_tile_seed_vec_width_for_dtype(
            cls._reduction_dtype(device_ir, reduction_size)
        )
        if dtype_vec < cls.RECURRENT_STYLE_VECTOR_WIDTH:
            return None
        if reduction_size % cls.RECURRENT_STYLE_VECTOR_WIDTH:
            return None
        reduction_threads = reduction_size // cls.RECURRENT_STYLE_VECTOR_WIDTH
        if reduction_threads != cls.RECURRENT_STYLE_REDUCTION_THREADS:
            return None
        return cls._seed_config(
            env,
            row_block_id,
            reduction_block_id,
            reduction_threads,
            row_block_size=16,
            row_threads=cls.RECURRENT_STYLE_ROW_THREADS,
        )

    @classmethod
    def get_seed_configs(
        cls, env: CompileEnvironment, device_ir: DeviceIR
    ) -> list[Config] | None:
        """Add recurrent-style, row-one, one-warp, and full-row schedules.

        The recurrent-style sibling maps one row thread and 32 reduction
        threads into a single-warp CTA with V=4 for K=128 updates.  The row-one
        sibling maps all 16 rows onto independent 16-thread groups in an
        eight-warp CTA.  This exposes enough resident warps to hide the
        state-load latency of short recurrent updates.  A 128-row tile instead
        maps eight groups across a short row loop, which amortizes invariant
        setup, while a 32-row one-warp sibling targets latency-sensitive
        workloads.  The existing 16-row seed stays rank zero and therefore
        preserves the no-autotune/default behavior.
        """
        plan = cls._plan(env, device_ir)
        if plan is None:
            return None
        row_block_id, reduction_block_id, reduction_threads = plan
        primary = cls._seed_config(
            env,
            row_block_id,
            reduction_block_id,
            reduction_threads,
            row_block_size=16,
        )
        row_spec = cast("Any", env.config_spec.block_sizes[0])
        seeds = [primary]
        recurrent_style = cls._recurrent_style_seed_config(
            env,
            device_ir,
            row_block_id,
            reduction_block_id,
        )
        if recurrent_style is not None:
            seeds.append(recurrent_style)
        if reduction_threads == 16:
            seeds.append(
                cls._seed_config(
                    env,
                    row_block_id,
                    reduction_block_id,
                    reduction_threads,
                    row_block_size=16,
                    row_threads=16,
                )
            )
        one_warp_row_threads = max(1, 32 // reduction_threads)
        if row_spec.max_size >= 32:
            seeds.append(
                cls._seed_config(
                    env,
                    row_block_id,
                    reduction_block_id,
                    reduction_threads,
                    row_block_size=32,
                    row_threads=one_warp_row_threads,
                )
            )
        if row_spec.max_size >= cls.FULL_ROW_BLOCK_SIZE:
            seeds.append(
                cls._seed_config(
                    env,
                    row_block_id,
                    reduction_block_id,
                    reduction_threads,
                    row_block_size=cls.FULL_ROW_BLOCK_SIZE,
                )
            )
        return seeds


class CuteAsyncPersistentSubwarpRowsHeuristic(AutotunerHeuristic):
    """Compose the full-row reduction and async state-load schedules.

    The component heuristics deliberately remain useful independently.  This
    seed joins their measured settings only when the kernel has one 3-D root
    whose innermost axis is the row tile.  No tensor names or model shapes are
    part of the match.

    ``xyz`` is included only when exact, metadata-specialized root extents prove
    that every axis fits the CUDA y/z limit even at a one-element block.  That
    stronger proof keeps every nearby block-size/loop-order candidate safe; the
    global conservative ``allowed_pid_types`` restriction remains untouched.
    """

    name = "cute_async_persistent_subwarp_rows"
    backend = "cute"
    CACHE_SPECIALIZATION_FACTS = frozenset({"input_tensor_metadata"})

    @classmethod
    def _plan(
        cls, env: CompileEnvironment, device_ir: DeviceIR
    ) -> tuple[int, int, int, int] | None:
        if not CuteAsyncStateLoadHeuristic.is_eligible(env, device_ir):
            return None
        persistent_plan = CutePersistentSubwarpRowsHeuristic._plan(env, device_ir)
        if persistent_plan is None:
            return None
        row_block_id, reduction_block_id, reduction_threads = persistent_plan
        row_spec = cast("Any", env.config_spec.block_sizes[0])
        full_row_size = CutePersistentSubwarpRowsHeuristic.FULL_ROW_BLOCK_SIZE
        row_size = env.block_sizes[row_block_id].size
        if (
            row_spec.max_size < full_row_size
            or not isinstance(row_size, (int, torch.SymInt))
            or not isinstance(
                row_extent := env.try_concretize_symint(row_size),
                int,
            )
            or not 0 <= row_extent <= full_row_size
        ):
            return None

        grid_fact = env.config_spec.kernel_grid_fact
        if grid_fact is None or len(grid_fact.roots) != 1:
            return None
        (root,) = grid_fact.roots
        if len(root.block_ids) != 3 or root.block_ids[-1] != row_block_id:
            return None
        matching_loop_orders = [
            spec
            for spec in env.config_spec.loop_orders
            if tuple(spec.block_ids) == root.block_ids
        ]
        if len(matching_loop_orders) != 1:
            return None
        return (
            row_block_id,
            reduction_block_id,
            reduction_threads,
            matching_loop_orders[0].block_id,
        )

    @staticmethod
    def _metadata_specialized_xyz_is_safe(env: CompileEnvironment) -> bool:
        """Prove every searchable 3-D launch stays within y/z limits.

        Each program count is at most its full axis extent because every legal
        block size is positive.  Requiring all three exact extents below the
        y/z limit therefore remains valid if the tuner changes either the block
        size or loop order around this seed.  ``try_concretize_symint`` accepts
        backed input-shape symbols; ``CACHE_SPECIALIZATION_FACTS`` makes those
        exact runtime shapes part of the bound-kernel cache key.
        """

        spec = env.config_spec
        grid_fact = spec.kernel_grid_fact
        if (
            grid_fact is None
            or len(grid_fact.roots) != 1
            or "flat" not in spec.allowed_pid_types
            or "input_tensor_metadata" not in env.compiler_fact_specialization_facts
        ):
            return False
        (root,) = grid_fact.roots
        if len(root.block_ids) != 3:
            return False
        if "xyz" not in spec.allowed_pid_types:
            reason = spec.disallowed_pid_type_reasons.get("xyz", "")
            if not reason.startswith("grid does not fit the y/z launch grid"):
                return False

        limit = get_max_y_grid()
        for block_id in root.block_ids:
            if not 0 <= block_id < len(env.block_sizes):
                return False
            block = env.block_sizes[block_id]
            if block.reduction or not isinstance(block.size, (int, torch.SymInt)):
                return False
            extent = env.try_concretize_symint(block.size)
            if not isinstance(extent, int) or not 0 <= extent < limit:
                return False
        return True

    @classmethod
    def register_facts(
        cls, env: CompileEnvironment, device_ir: DeviceIR
    ) -> frozenset[CompilerHeuristicSpecializationFact]:
        # Async registration runs earlier in the CuTe registry.  Keep the exact
        # input metadata in the cache key for both the async matcher and the
        # optional backed-SymInt xyz proof.
        return (
            cls.CACHE_SPECIALIZATION_FACTS if cls._plan(env, device_ir) else frozenset()
        )

    @classmethod
    def is_eligible(cls, env: CompileEnvironment, device_ir: DeviceIR) -> bool:
        return cls._plan(env, device_ir) is not None

    @classmethod
    def get_seed_config(
        cls, env: CompileEnvironment, device_ir: DeviceIR
    ) -> Config | None:
        plan = cls._plan(env, device_ir)
        if plan is None:
            return None
        (
            row_block_id,
            reduction_block_id,
            reduction_threads,
            loop_order_block_id,
        ) = plan
        values = dict(
            CutePersistentSubwarpRowsHeuristic._seed_config(
                env,
                row_block_id,
                reduction_block_id,
                reduction_threads,
                row_block_size=CutePersistentSubwarpRowsHeuristic.FULL_ROW_BLOCK_SIZE,
            ).config
        )
        values.update(
            {
                "loop_orders": _seq_config_list(
                    env.config_spec.loop_orders,
                    {loop_order_block_id: [1, 0, 2]},
                ),
            }
        )
        values.update(CuteAsyncStateLoadHeuristic._seed_overrides())
        from ..cute.cutedsl_compat import fixed_l2_evict_last_store_policy_supported

        values.update(
            {
                "cute_async_store_policy": (
                    "l2_evict_last"
                    if fixed_l2_evict_last_store_policy_supported(
                        env.config_spec.target_device_capability,
                        torch.version.cuda,
                    )
                    else "default"
                ),
                "cute_bf16x2_recurrence": True,
            }
        )
        if cls._metadata_specialized_xyz_is_safe(env):
            values["pid_type"] = "xyz"
        return Config.from_dict(values)


class CuteTileVecHeuristic(AutotunerHeuristic):
    """Seed config for canonical tile kernels (softmax_two_pass etc.)
    that drive their own explicit tile loop over the reduction axis.

    Seeds the "wide reduction + per-thread vec" config: block_size=
    [1, R] on the M and reduction axes (1 row per grid block), num_threads
    sized so each thread owns V contiguous elements (lane_extent = V),
    cute_vector_widths=[1, V].  This lets the strategy hoist a single
    LDG.64 / LDG.128 per outer-tile iter, lifting the kernel from scalar
    LDG bandwidth.

    The heuristic fires when:
    * The kernel has exactly 2 tile blocks (one outer row tile + one
      inner reduction tile), no matmul facts, no rolled reductions.
    * The inner tile has a stride-1 fp16/bf16/fp32 source tensor.
    """

    name = "cute_tile_vec"
    backend = "cute"

    @classmethod
    def is_eligible(cls, env: CompileEnvironment, device_ir: DeviceIR) -> bool:
        spec = env.config_spec
        if spec.matmul_facts:
            return False
        # Two-tile pattern: outer row + inner reduction (no rolled
        # reductions registered — those use the
        # CuteReductionTileHeuristic seed instead).
        if (
            len(spec.block_sizes) != 2
            or spec.reduction_loops
            or (
                spec.kernel_grid_fact is not None
                and len(spec.kernel_grid_fact.roots) > 1
            )
        ):
            return False
        # The inner tile block must have a vec slot registered
        # (added by ``register_rollable_reductions`` for cute tile blocks).
        inner_block_id = (
            cast("Any", spec.block_sizes[1]).block_ids[0]
            if hasattr(cast("Any", spec.block_sizes[1]), "block_ids")
            else None
        )
        if inner_block_id is None:
            return False
        if inner_block_id not in spec.cute_vector_widths.valid_block_ids():
            return False
        # Need a recognisable dtype to seed V.
        dtype = _cute_tile_inner_block_dtype(env, device_ir, inner_block_id)
        return _cute_tile_seed_vec_width_for_dtype(dtype) > 1

    @classmethod
    def get_seed_config(
        cls, env: CompileEnvironment, device_ir: DeviceIR
    ) -> Config | None:
        spec = env.config_spec
        inner_block_id = (
            cast("Any", spec.block_sizes[1]).block_ids[0]
            if hasattr(cast("Any", spec.block_sizes[1]), "block_ids")
            else None
        )
        if inner_block_id is None:
            return None
        dtype = _cute_tile_inner_block_dtype(env, device_ir, inner_block_id)
        vec = _cute_tile_seed_vec_width_for_dtype(dtype)
        if vec <= 1:
            return None
        # Pick a reasonable inner block_size: prefer 1024 (matches
        # SM100 warp + L2 hit cadence) when reachable, else cap at the
        # inner tile's fragment.high.  ``num_threads`` is sized so the
        # lane_extent equals V (one vec load per thread per outer iter).
        bn_high = spec.block_sizes[1]._fragment(spec).high
        block_n = 1024 if bn_high >= 1024 else max(bn_high, vec)
        # Threads = block_n // V so each thread owns V contiguous elts.
        nt_n = max(1, block_n // vec)
        seed: dict[str, Any] = {
            "block_sizes": [1, block_n],
            "num_threads": _seq_config_list(spec.num_threads, {inner_block_id: nt_n}),
            "cute_vector_widths": _seq_config_list(
                spec.cute_vector_widths, {inner_block_id: vec}
            ),
        }
        try:
            return Config(**seed)
        except Exception:
            return None


class CuteScanTileHeuristic(AutotunerHeuristic):
    """Seed for a 2-D grid tile scanned along one axis.

    ``hl.associative_scan(fn, x[tile_rows, tile_cols], dim=0)`` (a segmented
    reduction, a per-column prefix over a row tile) puts the scan on the
    dependence-carrying axis and leaves the other axis embarrassingly
    parallel.  The autotuner's natural winners split the scan axis over
    threads, paying a shuffle scan per row and one scalar load per element.
    Seed the layout that needs neither: one thread per V-wide strip of the
    contiguous axis owning the whole scan axis (a carried in-register prefix,
    no cross-thread traffic), 16-byte vector loads and, for atomic outputs,
    16-byte vector atomics along the strip, and the scan lane loop unrolled
    loads-first (``cute_lane_unroll``) so every row's loads are in flight
    before the first row computes.  The unroll depth becomes a searchable
    knob once seeded.  Seeds only layouts the vector protocol realises: the
    strip is the innermost grid block and its extent is a multiple of the
    vector width.
    """

    name = "cute_scan_tile"
    backend = "cute"
    SCAN_ROWS = 16
    ALTERNATE_SCAN_ROWS = 32
    # Column strips per CTA (one warp of 16-byte strips).
    STRIP_THREADS = 32
    # Shrink the row tile of a small problem until the grid holds at least
    # this many CTAs per SM (a 2000-row input at 16 rows is 125 CTAs).
    MIN_CTAS_PER_SM = 2

    @classmethod
    def _match(
        cls, env: CompileEnvironment, device_ir: DeviceIR
    ) -> tuple[int, int, torch.dtype] | None:
        """``(scan_block_id, strip_block_id, dtype)`` when the kernel is a
        single 2-D grid tile whose body scans a ``[scan, strip]``-shaped tile
        along ``scan`` and loads such a tile from a 16/32-bit tensor
        contiguous along ``strip``."""
        spec = env.config_spec
        if spec.matmul_facts or spec.reduction_loops:
            return None
        if len(spec.block_sizes) != 2 or any(
            len(item.block_ids) != 1 for item in spec.block_sizes
        ):
            return None
        if spec.kernel_grid_fact is not None and len(spec.kernel_grid_fact.roots) > 1:
            return None
        block_ids = [item.block_ids[0] for item in spec.block_sizes]
        if set(block_ids) != set(spec.grid_block_ids):
            return None
        for sequence in (
            spec.num_threads,
            spec.cute_vector_widths,
            spec.cute_lane_layouts,
        ):
            if not set(block_ids).issubset(sequence.valid_block_ids()):
                return None
        symbols = {
            block_id: _symint_sympy_expr(env.block_sizes[block_id].var)
            for block_id in block_ids
        }

        def block_of(size: object) -> int | None:
            if not isinstance(size, torch.SymInt):
                return None
            expr = _symint_sympy_expr(size)
            return next((b for b in block_ids if symbols[b] == expr), None)

        for graph_info in device_ir.graphs:
            for node in graph_info.graph.nodes:
                if node.op != "call_function" or node.target is not _associative_scan:
                    continue
                inputs = node.args[1]
                dim = node.args[2]
                first = (
                    inputs[0]
                    if isinstance(inputs, (tuple, list)) and inputs
                    else inputs
                )
                value = (
                    first.meta.get("val") if isinstance(first, torch.fx.Node) else None
                )
                if (
                    not isinstance(value, torch.Tensor)
                    or value.ndim != 2
                    or not isinstance(dim, int)
                    or dim not in (-2, -1, 0, 1)
                ):
                    continue
                dim %= 2
                scan_block = block_of(value.shape[dim])
                strip_block = block_of(value.shape[1 - dim])
                if (
                    scan_block is None
                    or strip_block is None
                    or scan_block == strip_block
                ):
                    continue
                dtype = cls._strip_load_dtype(
                    device_ir, scan_block, strip_block, symbols
                )
                if dtype is not None:
                    return scan_block, strip_block, dtype
        return None

    @classmethod
    def _strip_load_dtype(
        cls,
        device_ir: DeviceIR,
        scan_block: int,
        strip_block: int,
        symbols: dict[int, sympy.Expr],
    ) -> torch.dtype | None:
        """dtype of a ``[scan, strip]`` (or transposed) tile load whose source
        tensor is contiguous along the strip axis."""
        for graph_info in device_ir.graphs:
            for node in graph_info.graph.nodes:
                if node.op != "call_function" or node.target is not language_load:
                    continue
                loaded = node.meta.get("val")
                tensor_node = node.args[0] if node.args else None
                tensor = (
                    tensor_node.meta.get("val")
                    if isinstance(tensor_node, torch.fx.Node)
                    else None
                )
                if (
                    not isinstance(loaded, torch.Tensor)
                    or loaded.ndim != 2
                    or loaded.dtype
                    not in (torch.float16, torch.bfloat16, torch.float32)
                    or not isinstance(tensor, torch.Tensor)
                    or tensor.ndim != 2
                ):
                    continue
                shape = [
                    _symint_sympy_expr(size) if isinstance(size, torch.SymInt) else None
                    for size in loaded.shape
                ]
                for strip_dim in (0, 1):
                    if (
                        shape[strip_dim] == symbols[strip_block]
                        and shape[1 - strip_dim] == symbols[scan_block]
                        and tensor.stride(strip_dim) == 1
                    ):
                        return loaded.dtype
        return None

    @classmethod
    def is_eligible(cls, env: CompileEnvironment, device_ir: DeviceIR) -> bool:
        return cls.get_seed_config(env, device_ir) is not None

    @classmethod
    def _seed(
        cls, env: CompileEnvironment, device_ir: DeviceIR, rows: int
    ) -> Config | None:
        match = cls._match(env, device_ir)
        if match is None:
            return None
        scan_block, strip_block, dtype = match
        spec = env.config_spec
        vec = _cute_tile_seed_vec_width_for_dtype(dtype)
        if vec <= 1:
            return None
        strip_spec = spec.block_sizes.block_id_lookup(strip_block)
        scan_spec = spec.block_sizes.block_id_lookup(scan_block)
        # The tile vector protocol (16-byte packets, the vector atomic flush)
        # runs on the innermost grid block and needs the strip extent to be a
        # multiple of the vector width; a strip elsewhere (a column-major
        # input) or of another width (98 columns) would seed scalar code.
        if (
            strip_block != spec.block_sizes[-1].block_ids[0]
            or strip_spec.size_hint % vec
        ):
            return None
        strip = min(strip_spec.max_size, cls.STRIP_THREADS * vec)
        rows = min(rows, scan_spec.max_size)
        if strip % vec or strip < vec or rows < 2:
            return None
        ctas_wanted = cls.MIN_CTAS_PER_SM * max(spec.num_sm, 1)
        strips = -(-max(strip_spec.size_hint, 1) // strip)
        while (
            rows > 2 and -(-max(scan_spec.size_hint, 1) // rows) * strips < ctas_wanted
        ):
            rows //= 2
        unroll = max(
            choice
            for choice in _CUTE_LANE_UNROLL_CHOICES
            if choice <= rows and rows % choice == 0
        )
        sizes = {scan_block: rows, strip_block: strip}
        seed: dict[str, Any] = {
            "block_sizes": [sizes[item.block_ids[0]] for item in spec.block_sizes],
            "num_threads": _seq_config_list(
                spec.num_threads, {scan_block: 1, strip_block: strip // vec}
            ),
            "cute_vector_widths": _seq_config_list(
                spec.cute_vector_widths, {strip_block: vec}
            ),
            "cute_lane_unroll": unroll,
        }
        try:
            return Config(**seed)
        except Exception:
            return None

    @classmethod
    def get_seed_config(
        cls, env: CompileEnvironment, device_ir: DeviceIR
    ) -> Config | None:
        return cls._seed(env, device_ir, cls.SCAN_ROWS)

    @classmethod
    def get_seed_configs(
        cls, env: CompileEnvironment, device_ir: DeviceIR
    ) -> list[Config] | None:
        primary = cls.get_seed_config(env, device_ir)
        if primary is None:
            return None
        alternate = cls._seed(env, device_ir, cls.ALTERNATE_SCAN_ROWS)
        if alternate is None or alternate.config == primary.config:
            return [primary]
        return [primary, alternate]


class CuteTileVecWarpReduceHeuristic(AutotunerHeuristic):
    """Sibling seed for ``CuteTileVecHeuristic`` favouring a warp-sized
    thread block over the wider 1024-thread lattice.

    For tile kernels that reduce across the inner axis per outer-tile
    iter (softmax_two_pass, RMS norm, etc.), the cross-thread combine
    is the dominant cost. With ``num_threads <= 32`` the reduction
    strategy lowers to ``cute.arch.warp_reduction`` (one warp-shuffle,
    no shared memory, no CTA-wide barrier); with ``num_threads > 32``
    it lowers to ``_cute_grouped_reduce_shared_two_stage`` which costs
    two ``sync_threads`` per reduction. For wide reduction axes the
    larger number of outer iters is more than offset by the per-iter
    savings.

    Seeds ``block_sizes=[1, V * 32]``, ``num_threads=[0, 32]``,
    ``cute_vector_widths=[1, V]`` so each thread owns V contiguous
    elements (one vec load per outer iter) and the cross-thread
    reduction stays inside a single warp. Applies only when the
    reduction extent is large enough to amortise the launch cost of
    many CTAs (each row is a CTA) and the dtype admits a vec >= 2.
    """

    name = "cute_tile_vec_warp_reduce"
    backend = "cute"

    @classmethod
    def is_eligible(cls, env: CompileEnvironment, device_ir: DeviceIR) -> bool:
        spec = env.config_spec
        if spec.matmul_facts:
            return False
        if (
            len(spec.block_sizes) != 2
            or spec.reduction_loops
            or (
                spec.kernel_grid_fact is not None
                and len(spec.kernel_grid_fact.roots) > 1
            )
        ):
            return False
        inner_block_id = (
            cast("Any", spec.block_sizes[1]).block_ids[0]
            if hasattr(cast("Any", spec.block_sizes[1]), "block_ids")
            else None
        )
        if inner_block_id is None:
            return False
        if inner_block_id not in spec.cute_vector_widths.valid_block_ids():
            return False
        dtype = _cute_tile_inner_block_dtype(env, device_ir, inner_block_id)
        vec = _cute_tile_seed_vec_width_for_dtype(dtype)
        if vec <= 1:
            return False
        # Only worth it when the reduction extent is wide enough that
        # the warp-only reduction's many outer iters still amortise
        # against the launch cost (and an autotuner-picked warp lattice
        # can hold the row).  We use the inner block fragment's high
        # bound as a proxy for the reduction extent.
        bn_high = spec.block_sizes[1]._fragment(spec).high
        return bn_high >= vec * 32

    @classmethod
    def get_seed_config(
        cls, env: CompileEnvironment, device_ir: DeviceIR
    ) -> Config | None:
        spec = env.config_spec
        inner_block_id = (
            cast("Any", spec.block_sizes[1]).block_ids[0]
            if hasattr(cast("Any", spec.block_sizes[1]), "block_ids")
            else None
        )
        if inner_block_id is None:
            return None
        dtype = _cute_tile_inner_block_dtype(env, device_ir, inner_block_id)
        vec = _cute_tile_seed_vec_width_for_dtype(dtype)
        if vec <= 1:
            return None
        # Each thread owns V contiguous elements; one warp = 32 threads
        # = 32 * V elements per outer-tile iter. Cap by the fragment's
        # high bound so the seed is reachable for short reduction axes.
        bn_high = spec.block_sizes[1]._fragment(spec).high
        block_n = vec * 32
        if bn_high < block_n:
            return None
        seed: dict[str, Any] = {
            "block_sizes": [1, block_n],
            "num_threads": _seq_config_list(spec.num_threads, {inner_block_id: 32}),
            "cute_vector_widths": _seq_config_list(
                spec.cute_vector_widths, {inner_block_id: vec}
            ),
        }
        try:
            return Config(**seed)
        except Exception:
            return None


class CuteCollectiveMatmulHeuristic(AutotunerHeuristic):
    """Seed collective operand staging for independent contractions."""

    name = "cute_collective_matmul"
    backend = "cute"
    CACHE_SPECIALIZATION_FACTS = frozenset({"input_tensor_metadata"})

    @classmethod
    def register_facts(
        cls, env: CompileEnvironment, device_ir: DeviceIR
    ) -> frozenset[CompilerHeuristicSpecializationFact]:
        # Copy legality needs guarded strides even when heuristic seeds are
        # disabled and the caller explicitly selects a collective config.
        if cls._axes(env, device_ir):
            env.config_spec.enable_cute_proven_bounds()
            return cls.CACHE_SPECIALIZATION_FACTS
        return frozenset()

    @classmethod
    def is_eligible(cls, env: CompileEnvironment, device_ir: DeviceIR) -> bool:
        return bool(cls.get_seed_configs(env, device_ir))

    @classmethod
    def get_seed_config(
        cls, env: CompileEnvironment, device_ir: DeviceIR
    ) -> Config | None:
        seeds = cls.get_seed_configs(env, device_ir)
        return seeds[0] if seeds else None

    @staticmethod
    def _axes(
        env: CompileEnvironment, device_ir: DeviceIR
    ) -> tuple[tuple[int, int, int, int], ...]:
        placements = cute_matmul_root_placements(env, device_ir)
        if not placements:
            return ()
        axes = []
        occupied: dict[int, tuple[int, ...]] = {}
        roots: dict[tuple[int, ...], tuple[int, int]] = {}
        factors: dict[int, int] = {}
        block_specs = {
            block_id: item
            for item in env.config_spec.block_sizes
            for block_id in item.block_ids
        }
        for fact, root in placements:
            m, n, k = fact.m_block_id, fact.n_block_id, fact.k_block_id
            factor = 1
            if k is None:
                packed = packed_axis_for_fact(env, device_ir, fact)
                if packed is not None:
                    k, factor = packed.block_id, packed.factor
            if (
                m is None
                or n is None
                or k is None
                or len({m, n, k}) != 3
                or fact.lhs_ndim not in (2, 3)
                or fact.rhs_ndim != fact.lhs_ndim
                or fact.lhs_dtype not in (torch.float16, torch.bfloat16, torch.float32)
                or fact.rhs_dtype != fact.lhs_dtype
                or fact.lhs_dtype == torch.float32
                and (
                    not cute_fp32_dot_uses_tf32()
                    or env.config_spec.target_device_capability is None
                    or env.config_spec.target_device_capability[0] < 8
                )
                or fact.lhs_ndim == 3
                and not all(
                    (item := block_specs.get(block_id)) is not None
                    and item.max_size == 1
                    for block_id in root
                    if block_id not in (m, n)
                )
                or n not in root
                or k in root
                or root in roots
                and roots[root] != (m, n)
                or any(
                    block_id in occupied and occupied[block_id] != root
                    for block_id in (m, n, k)
                )
                or k in factors
                and factors[k] != factor
            ):
                return ()
            if (m, n, k, factor) not in axes:
                axes.append((m, n, k, factor))
            roots[root] = (m, n)
            occupied.update(dict.fromkeys((m, n, k), root))
            factors[k] = factor
        return tuple(axes)

    @staticmethod
    def _gathered_candidate(env: CompileEnvironment, device_ir: DeviceIR) -> bool:
        """A cheap structural superset of the late gathered-row proof.

        This only seeds direct rank-2 gathered A and rank-3 group-indexed B.
        Complete effects, masks, alignment, zero seed and scatter equivalence
        are proved by generated-AST admission before this schedule can run.
        """
        placements = cute_matmul_root_placements(env, device_ir)
        if len(placements) != 1:
            return False
        fact, root = placements[0]
        if fact.m_block_id in root or len(root) != 2:
            return False
        contractions = [
            node
            for graph in device_ir.graphs
            for node in graph.graph.nodes
            if node.op == "call_function"
            and node.target is torch.ops.aten.addmm.default
        ]
        if len(contractions) != 1:
            return False
        node = contractions[0]
        operands = node.args[1:3]
        if any(
            not isinstance(operand, torch.fx.Node)
            or operand.target is not language_load
            or not isinstance(operand.args[0], torch.fx.Node)
            for operand in operands
        ):
            return False
        lhs, rhs = cast("tuple[torch.fx.Node, torch.fx.Node]", operands)
        lhs_base, rhs_base = lhs.args[0], rhs.args[0]
        assert isinstance(lhs_base, torch.fx.Node) and isinstance(
            rhs_base, torch.fx.Node
        )
        lhs_tensor, rhs_tensor = lhs_base.meta.get("val"), rhs_base.meta.get("val")
        indices = lhs.args[1]
        if (
            not isinstance(lhs_tensor, torch.Tensor)
            or not isinstance(rhs_tensor, torch.Tensor)
            or (lhs_tensor.ndim, rhs_tensor.ndim) != (2, 3)
            or not isinstance(indices, (tuple, list))
            or len(indices) != 2
            or not isinstance(indices[0], torch.fx.Node)
        ):
            return False
        gathered_rows = indices[0].meta.get("val")
        return (
            isinstance(gathered_rows, torch.Tensor)
            and gathered_rows.ndim == 1
            and gathered_rows.dtype == torch.int32
        )

    @staticmethod
    def _bounded_k_seeds(
        env: CompileEnvironment,
        device_ir: DeviceIR,
        axes: tuple[tuple[int, int, int, int], ...],
        seeds: list[Config],
    ) -> tuple[list[Config], tuple[str, ...]]:
        """Explore config-owned outer chunks together with the MMA geometry.

        A collective seed at the default outer chunk may launch only a few
        CTAs. Mutating the chunk after the search has selected a scalar tile
        does not recover the collective's coordinated M/N/thread settings.
        Follow the compiler's config-expression provenance, independent of
        user parameter names, to seed both choices together.
        """

        def keys(expression: ConfigValueExpression) -> set[str]:
            result: set[str] = set()
            for argument in expression.arguments:
                if isinstance(argument, str):
                    result.add(argument)
                elif isinstance(argument, ConfigValueExpression):
                    result.update(keys(argument))
            return result

        spec = env.config_spec
        blocks = {
            item.block_id: item for item in spec.block_sizes if len(item.block_ids) == 1
        }
        root_ids = {block_id for root in device_ir.grid_block_ids for block_id in root}
        default = spec._base_default_config()
        result = []
        parameters: list[str] = []
        for _m, _n, k, _factor in axes:
            if k not in blocks:
                continue
            bound_id = blocks[k].bounded_by_block_id
            if bound_id is None or bound_id not in root_ids:
                continue
            source = env.block_sizes[bound_id].block_size_source
            if not isinstance(source, FixedBlockSizeSource) or not isinstance(
                source.value, torch.SymInt
            ):
                continue
            expression = env.config_value_expressions.get(
                _symint_sympy_expr(source.value)
            )
            if expression is None:
                continue
            parameter_keys = keys(expression)
            if len(parameter_keys) != 1:
                continue
            parameter = next(iter(parameter_keys))
            fragment = spec.user_defined_tunables[parameter]
            values = fragment.search_values(limit=32)
            if values is None:
                continue
            for seed in seeds:
                if seed.get("cute_collective_copy") == "scalar":
                    continue
                inner = spec.block_sizes.config_get(seed.block_sizes, k)
                assert isinstance(inner, int)
                for value in values:
                    if (
                        type(value) is not int
                        or value <= 0
                        or value == default[parameter]
                    ):
                        continue
                    candidate = Config.from_dict(
                        default.config | seed.config | {parameter: value}
                    )
                    if expression.evaluate(candidate) >= inner:
                        result.append(
                            Config.from_dict(seed.config | {parameter: value})
                        )
                        if parameter not in parameters:
                            parameters.append(parameter)
        return result, tuple(parameters)

    @staticmethod
    def _interleave_bounded_k_seeds(
        spec: ConfigSpec,
        seeds: list[Config],
        parameters: tuple[str, ...],
    ) -> list[Config]:
        """Expose compound schedules before the initial-population cutoff.

        The seed generator nests geometries, pipelines, and then config-owned
        K chunks. Taking its prefix can test every pipelined geometry only at
        the default chunk, even though all the coupled choices exist later.
        Register-produced A can additionally require native seed reuse,
        vector recipes, cooperative epilogues, and proved bounds together.
        FP32 native MMA can instead convert vector register loads directly,
        avoiding an asynchronous copy's raw shared-memory staging. Rotate its
        paired copy/recipe choices before repeating geometries. When the TMEM
        storage alternative is present, rotate through complete
        schedules as well as compute/copy/depth/chunk groups, retaining the
        ranked geometry order within each. This only reorders existing seeds;
        the first seed, default promotion, other heuristics, and search budget
        stay unchanged. Unrelated user knobs never supply a grouping dimension.
        """
        tmem_operand_schedules = any(
            seed.get("cute_collective_tmem_a", False) for seed in seeds
        )
        register_recipe_schedules = any(
            seed.get("cute_collective_compute") == "tcgen05"
            and seed.get("cute_collective_copy") == "scalar"
            and seed.get("cute_collective_recipe") in ("vector", "vector_unrolled")
            for seed in seeds
        )
        packet_schedules = any(
            seed.get("cute_collective_operand_packets", False) for seed in seeds
        )
        if (
            not parameters
            and not tmem_operand_schedules
            and not register_recipe_schedules
            and not packet_schedules
        ):
            return seeds
        default = spec._base_default_config()
        groups: dict[tuple[object, ...], list[Config]] = {}
        for seed in seeds:
            key = (
                seed.get("cute_collective_compute", "warp"),
                seed.get("cute_collective_copy", "scalar"),
                seed.get("cute_collective_stages", 1),
                *(seed.get(parameter, default[parameter]) for parameter in parameters),
            )
            if tmem_operand_schedules:
                key += (
                    seed.get("cute_collective_native_seeded", False),
                    seed.get("cute_collective_recipe", "scalar"),
                    seed.get("cute_collective_epilogue", "scalar"),
                    seed.get("cute_collective_tmem_seed", False),
                    seed.get("cute_proven_bounds", False),
                    seed.get("cute_collective_tmem_a", False),
                )
            elif register_recipe_schedules:
                key += (seed.get("cute_collective_recipe", "scalar"),)
            if packet_schedules:
                key += (seed.get("cute_collective_operand_packets", False),)
            groups.setdefault(key, []).append(seed)
        return [
            seed
            for row in zip_longest(*groups.values())
            for seed in row
            if seed is not None
        ]

    @classmethod
    def get_seed_configs(
        cls, env: CompileEnvironment, device_ir: DeviceIR
    ) -> list[Config]:
        # The collective proof imports DeviceIR, which imports the runtime
        # kernel while this registry is being initialized.
        from ..cute.collective_matmul import has_collective_native_seed_candidate
        from ..cute.collective_matmul import has_collective_tmem_operand_candidate

        spec = env.config_spec
        # Those search families do not carry collective controls. Their
        # flatten/unflatten path would silently turn these into unrelated
        # native-MMA seeds instead of measuring the requested collective.
        if spec.cute_tcgen05_search_enabled or spec.cute_flash_search_enabled:
            return []
        axes = cls._axes(env, device_ir)
        if not axes:
            return []
        blocks = {
            item.block_id: item for item in spec.block_sizes if len(item.block_ids) == 1
        }
        axis_ids = {block_id for m, n, k, _ in axes for block_id in (m, n, k)}
        singleton_axes = set(blocks) - axis_ids
        if any(blocks[block_id].max_size != 1 for block_id in singleton_axes):
            return []
        fp32_inputs = any(
            fact.lhs_dtype == torch.float32
            for fact, _root in cute_matmul_root_placements(env, device_ir)
        )
        fixed_k = axis_ids - set(blocks)
        if any(
            block_id not in {k for _, _, k, _ in axes}
            or not env.block_sizes[block_id].reduction
            or not env.block_sizes[block_id].numel.is_Integer
            or not 1 < int(env.block_sizes[block_id].numel) <= 128
            for block_id in fixed_k
        ):
            return []
        fragments = {
            block_id: item._fragment(spec) for block_id, item in blocks.items()
        }
        seeded_native = has_collective_native_seed_candidate(device_ir.graphs)
        result = []
        for bm, bn, bk in (
            (64, 32, 64),
            (64, 64, 64),
            (32, 32, 64),
            (32, 32, 32),
            (128, 32, 64),
            (64, 32, 32),
            (128, 64, 128),
            (64, 64, 128),
            (32, 64, 32),
            (32, 64, 64),
        ):
            if any(bk % factor for _, _, _, factor in axes):
                continue
            values = {
                block_id: value
                for m, n, k, factor in axes
                for block_id, value in zip(
                    (m, n, k), (bm, bn, bk // factor), strict=True
                )
                if block_id in blocks
            }
            threads = {
                block_id: value
                for m, n, k, _ in axes
                for block_id, value in zip((m, n, k), (128 // bn, bn, 1), strict=True)
            }
            values.update(dict.fromkeys(singleton_axes, 1))
            threads.update(dict.fromkeys(singleton_axes, 0))
            if not all(
                fragments[block_id].low <= value <= fragments[block_id].high
                for block_id, value in values.items()
            ):
                continue
            copy_modes = (
                ("scalar",)
                if any(factor > 1 for _, _, _, factor in axes)
                else ("scalar", "async", "async_cached")
            )
            for copy in copy_modes:
                seed = Config.from_dict(
                    {
                        "block_sizes": _seq_config_list(spec.block_sizes, values),
                        "num_threads": _seq_config_list(spec.num_threads, threads),
                        "cute_vector_widths": _seq_config_list(
                            spec.cute_vector_widths,
                            dict.fromkeys(axis_ids | singleton_axes, 1),
                        ),
                        "cute_lane_layouts": _seq_config_list(
                            spec.cute_lane_layouts,
                            dict.fromkeys(axis_ids | singleton_axes, "blocked"),
                        ),
                        "cute_collective_mma": True,
                        "cute_collective_copy": copy,
                    }
                )
                if (
                    fp32_inputs
                    and bm in (64, 128)
                    and spec.target_device_capability is not None
                    and spec.target_device_capability[0] == 10
                ):
                    # Retain the established native candidates and ordering;
                    # the warp alternative also admits a smaller M32 tile.
                    result.append(
                        Config.from_dict(
                            seed.config | {"cute_collective_compute": "tcgen05"}
                        )
                    )
                result.append(seed)
            if (
                bm in (64, 128)
                and spec.target_device_capability is not None
                and spec.target_device_capability[0] == 10
            ):
                # Native MMA consumes the same generic shared recipes, including
                # the scalar fallback for transformed or unaligned operands.
                native_seed = Config.from_dict(
                    result[-1].config | {"cute_collective_compute": "tcgen05"}
                )
                if not fp32_inputs:
                    result.append(native_seed)
                if seeded_native:
                    result.append(
                        Config.from_dict(
                            native_seed.config | {"cute_collective_native_seeded": True}
                        )
                    )
        if (
            len(axes) == 1
            and axes[0][3] == 1
            and spec.target_device_capability is not None
            and spec.target_device_capability[0] == 10
            and cls._gathered_candidate(env, device_ir)
        ):
            m, n, k, _factor = axes[0]
            base = next(
                (
                    seed
                    for seed in result
                    if spec.block_sizes.config_get(seed.block_sizes, m) == 128
                    and spec.block_sizes.config_get(seed.block_sizes, n) == 32
                    and spec.block_sizes.config_get(seed.block_sizes, k) == 64
                ),
                None,
            )
            if base is not None:
                result.extend(
                    Config.from_dict(
                        base.config
                        | {
                            "cute_collective_compute": "tma_gather",
                            "cute_gathered_mma_n": columns,
                            "cute_gathered_mma_stages": stages,
                        }
                    )
                    for columns in (128, 256, 512)
                    for stages in (2, 3, 4)
                    if columns != 512 or stages == 2
                )
        result.extend(
            [
                Config.from_dict(seed.config | {"cute_collective_stages": stages})
                for seed in result
                if seed.get("cute_collective_compute", "warp") == "warp"
                and seed.get("cute_collective_copy") == "async_cached"
                for stages in (2, 4)
            ]
        )
        bounded_seeds, bounded_parameters = cls._bounded_k_seeds(
            env, device_ir, axes, result
        )
        result.extend(bounded_seeds)
        # Keep register-vector recipe traversal paired with a complete MMA
        # geometry. Unrolling is a separate search choice because its register
        # pressure can outweigh the saved loop and address instructions.
        result.extend(
            [
                Config.from_dict(seed.config | {"cute_collective_recipe": recipe})
                for seed in result
                if (
                    seed.get("cute_collective_copy") == "async_cached"
                    or (
                        fp32_inputs
                        and seed.get("cute_collective_compute") == "tcgen05"
                        and seed.get("cute_collective_copy") == "scalar"
                    )
                )
                and seed.get("cute_collective_compute", "warp") != "tma_gather"
                and seed.get("cute_collective_stages", 1) == 1
                for recipe in ("vector", "vector_unrolled")
            ]
        )
        # Pair cooperative epilogues with complete copy/compute geometries.
        # Keep scalar epilogues available when repartitioning increases register
        # pressure or the output's stride/mask proof cannot vectorize stores.
        result.extend(
            [
                Config.from_dict(seed.config | {"cute_collective_epilogue": epilogue})
                for seed in result
                if seed.get("cute_collective_recipe") == "vector_unrolled"
                for epilogue in ("vector", "vector_unrolled")
            ]
        )
        # A dependent native contraction can carry its FP32 seed directly
        # through TMEM. Keep the shared route available as a search alternative.
        result.extend(
            [
                Config.from_dict(seed.config | {"cute_collective_tmem_seed": True})
                for seed in result
                if seed.get("cute_collective_compute") == "tcgen05"
                and seed.get("cute_collective_native_seeded", False)
                and seed.get("cute_collective_recipe") == "vector_unrolled"
                and seed.get("cute_collective_epilogue") == "vector_unrolled"
            ]
        )
        if spec.cute_proven_bounds_enabled:
            result.extend(
                [
                    Config.from_dict(seed.config | {"cute_proven_bounds": True})
                    for seed in result
                    if seed.get("cute_collective_recipe") == "vector_unrolled"
                    and seed.get("cute_collective_epilogue") == "vector_unrolled"
                ]
            )
        if (
            not fp32_inputs
            and all(factor == 1 for _m, _n, _k, factor in axes)
            and has_collective_tmem_operand_candidate(device_ir.graphs)
        ):
            # TMEM A changes register ownership as well as storage. Couple it
            # to complete native/vector geometries, retaining seed reuse and
            # proven bounds when available, rather than waiting for unrelated
            # coordinate mutations to discover the full schedule.
            result.extend(
                [
                    Config.from_dict(seed.config | {"cute_collective_tmem_a": True})
                    for seed in result
                    if seed.get("cute_collective_compute") == "tcgen05"
                    and seed.get("cute_collective_recipe") == "vector_unrolled"
                    and seed.get("cute_collective_epilogue") == "vector_unrolled"
                ]
            )
        if fp32_inputs:
            # Store four already-rounded operand words together. This can save
            # shared instructions/bank conflicts, but changes register lifetime;
            # retain the scalar stores and both recipe loop schedules.
            result.extend(
                [
                    Config.from_dict(
                        deepcopy(seed.config)
                        | {"cute_collective_operand_packets": True}
                    )
                    for seed in result
                    if seed.get("cute_collective_recipe")
                    in ("vector", "vector_unrolled")
                    and seed.get("cute_collective_copy") == "scalar"
                    and seed.get("cute_collective_stages", 1) == 1
                    and seed.get("cute_collective_compute", "warp") != "tma_gather"
                ]
            )
        return cls._interleave_bounded_k_seeds(
            spec, dedupe_configs(result), bounded_parameters
        )


def _cute_reread_cache_policies(
    spec: ConfigSpec, inner_block_ids: tuple[int, ...]
) -> list[str]:
    # A repeated input benefits from retention on the earlier passes and
    # eviction on the last. Seed this alongside ordinary cache policies;
    # the compiler never infers a cache choice from a kernel name or size.
    cache_policies = [""] * spec.load_eviction_policies.length
    tensor_passes: dict[str, list[tuple[int, int]]] = {}
    for fact in spec.memory_op_facts:
        axes = set(fact.subscript_block_ids).intersection(inner_block_ids)
        if (
            fact.kind == "load"
            and fact.eviction_index is not None
            and fact.tensor_name is not None
            and len(axes) == 1
        ):
            pass_index = inner_block_ids.index(next(iter(axes)))
            tensor_passes.setdefault(fact.tensor_name, []).append(
                (pass_index, fact.eviction_index)
            )
    for accesses in tensor_passes.values():
        passes = {pass_index for pass_index, _ in accesses}
        if len(passes) > 1:
            last_pass = max(passes)
            for pass_index, eviction_index in accesses:
                cache_policies[eviction_index] = (
                    "l1_l2_first" if pass_index == last_pass else "l1_l2_last"
                )
    return cache_policies


class CuteSiblingRowHeuristic(AutotunerHeuristic):
    """Coherent vector/thread seeds for distinct sibling row-tile passes.

    Independent tile IDs make it unlikely for an ordinary coordinate search
    to discover a common layout for the reduction and consume passes. Seed
    warp-sized chunks and whole-row tiles with the same configuration for
    every pass, including a multi-row warp layout for short rows.
    """

    name = "cute_sibling_row"
    backend = "cute"
    CACHE_SPECIALIZATION_FACTS = frozenset({"input_tensor_metadata"})

    @classmethod
    def is_eligible(cls, env: CompileEnvironment, device_ir: DeviceIR) -> bool:
        return bool(cls.get_seed_configs(env, device_ir))

    @classmethod
    def get_seed_config(
        cls, env: CompileEnvironment, device_ir: DeviceIR
    ) -> Config | None:
        seeds = cls.get_seed_configs(env, device_ir)
        return seeds[0] if seeds else None

    @classmethod
    def get_seed_configs(
        cls, env: CompileEnvironment, device_ir: DeviceIR
    ) -> list[Config]:
        spec = env.config_spec
        if spec.matmul_facts or spec.reduction_loops:
            return []
        plan = sibling_row_loop_blocks(env, device_ir, device_ir.graphs)
        jagged = False
        if plan is None:
            # Dynamic row lengths have no host-side bound to equate. Seeds
            # may still configure sibling passes coherently; the compiler
            # retains each pass's own bound and masks.
            paths = tile_loop_paths(device_ir, device_ir.graphs)
            if (
                len(paths) >= 2
                and all(
                    len(path) == 2 and all(len(axis) == 1 for axis in path)
                    for path in paths
                )
                and len({path[0][0] for path in paths}) == 1
                and all(env.is_jagged_tile(path[1][0]) for path in paths)
            ):
                plan = (
                    paths[0][0][0],
                    tuple(dict.fromkeys(path[1][0] for path in paths)),
                )
                jagged = True
        if plan is None or len(plan[1]) < 2:
            return []
        row_block_id, inner_block_ids = plan
        block_ids = {row_block_id, *inner_block_ids}
        if len(spec.block_sizes) != len(block_ids) or any(
            len(item.block_ids) != 1 for item in spec.block_sizes
        ):
            return []
        block_specs = {item.block_id: item for item in spec.block_sizes}
        if set(block_specs) != block_ids:
            return []
        for sequence in (
            spec.num_threads,
            spec.cute_vector_widths,
            spec.cute_lane_layouts,
        ):
            if not set(inner_block_ids).issubset(sequence.valid_block_ids()):
                return []
        vec = min(
            _cute_tile_seed_vec_width_for_dtype(
                _cute_tile_inner_block_dtype(env, device_ir, block_id)
            )
            for block_id in inner_block_ids
        )
        if vec <= 1:
            return []
        row_fragment = block_specs[row_block_id]._fragment(spec)
        inner_fragments = [
            block_specs[block_id]._fragment(spec) for block_id in inner_block_ids
        ]
        low = max(fragment.low for fragment in inner_fragments)
        high = min(fragment.high for fragment in inner_fragments)
        row_extent = (
            1 << (max(1, block_specs[inner_block_ids[0]].size_hint) - 1).bit_length()
        )
        candidates: list[tuple[int, int, int]] = []
        if jagged:
            # Size hints cannot describe device-resident row lengths. Offer
            # several register footprints so a cold search can discover wide,
            # vectorized sweeps without synchronizing many independent knobs.
            candidates.extend(
                (1, threads * elements_per_thread, threads)
                for threads in (128, 256, 512)
                for elements_per_thread in (32, 64)
            )
        for threads in (256, 128, 512):
            if row_extent % (threads * vec) == 0 and row_extent // threads <= 64:
                candidates.append((1, row_extent, threads))
        if row_extent <= 2048 and row_extent % (32 * vec) == 0:
            candidates.append((4, row_extent, 32))
        wide_chunk = min(1024, high)
        if wide_chunk >= vec:
            candidates.append((1, wide_chunk, wide_chunk // vec))
        candidates.extend(((1, 32 * vec, 32), (4, 32 * vec, 32)))

        cache_policies = _cute_reread_cache_policies(spec, inner_block_ids)

        seeds: list[Config] = []
        for rows, columns, threads in candidates:
            if not (
                row_fragment.low <= rows <= row_fragment.high and low <= columns <= high
            ):
                continue
            seeds.append(
                Config.from_dict(
                    {
                        "block_sizes": _seq_config_list(
                            spec.block_sizes,
                            {
                                row_block_id: rows,
                                **dict.fromkeys(inner_block_ids, columns),
                            },
                        ),
                        "num_threads": _seq_config_list(
                            spec.num_threads,
                            {
                                row_block_id: rows,
                                **dict.fromkeys(inner_block_ids, threads),
                            },
                        ),
                        "cute_vector_widths": _seq_config_list(
                            spec.cute_vector_widths, dict.fromkeys(inner_block_ids, vec)
                        ),
                        "cute_lane_layouts": _seq_config_list(
                            spec.cute_lane_layouts,
                            dict.fromkeys(inner_block_ids, "strided"),
                        ),
                    }
                )
            )
            if any(cache_policies):
                seeds.append(
                    Config.from_dict(
                        {**seeds[-1].config, "load_eviction_policies": cache_policies}
                    )
                )
        packet_seeds: list[Config] = []
        for seed in seeds:
            block_sizes = seed.block_sizes
            thread_counts = seed.num_threads
            if block_sizes[
                spec.block_sizes.block_id_to_index(row_block_id)
            ] != 1 or not all(
                block_sizes[spec.block_sizes.block_id_to_index(block_id)] == row_extent
                for block_id in inner_block_ids
            ):
                continue
            for packet_width in dict.fromkeys((vec, max(2, vec // 2))):
                if not all(
                    row_extent
                    % (
                        thread_counts[spec.num_threads.block_id_to_index(block_id)]
                        * packet_width
                    )
                    == 0
                    for block_id in inner_block_ids
                ):
                    continue
                packet_seeds.append(
                    Config.from_dict(
                        deepcopy(seed.config)
                        | {
                            "cute_vector_widths": _seq_config_list(
                                spec.cute_vector_widths,
                                dict.fromkeys(inner_block_ids, packet_width),
                            ),
                            "cute_independent_reduction": True,
                            "cute_replicated_reduction": True,
                            "cute_vector_packet_unroll": True,
                        }
                    )
                )
        return dedupe_configs([*seeds, *packet_seeds])


class CuteNestedRowHeuristic(AutotunerHeuristic):
    """Seed matching layouts for sibling passes over nested row tiles.

    A coalesced outer feature axis can own the threads while an inner
    jagged axis accumulates serially. Configuring each sibling independently
    makes this layout difficult to discover through individual mutations.
    """

    name = "cute_nested_row"
    backend = "cute"
    CACHE_SPECIALIZATION_FACTS = frozenset({"input_tensor_metadata"})

    @classmethod
    def is_eligible(cls, env: CompileEnvironment, device_ir: DeviceIR) -> bool:
        return bool(cls.get_seed_configs(env, device_ir))

    @classmethod
    def get_seed_config(
        cls, env: CompileEnvironment, device_ir: DeviceIR
    ) -> Config | None:
        seeds = cls.get_seed_configs(env, device_ir)
        return seeds[0] if seeds else None

    @classmethod
    def get_seed_configs(
        cls, env: CompileEnvironment, device_ir: DeviceIR
    ) -> list[Config]:
        spec = env.config_spec
        if spec.matmul_facts or spec.reduction_loops:
            return []
        paths = tile_loop_paths(device_ir, device_ir.graphs)
        if len(paths) < 2 or any(
            len(path) != 3 or any(len(axis) != 1 for axis in path) for path in paths
        ):
            return []
        roots = {path[0][0] for path in paths}
        outer = {path[1][0] for path in paths}
        inner = {path[2][0] for path in paths}
        if (
            len(roots) != 1
            or len(outer) != len(paths)
            or len(inner) != len(paths)
            or roots & (outer | inner)
            or outer & inner
            or any(env.is_jagged_tile(block_id) for block_id in outer)
            or not all(env.is_jagged_tile(block_id) for block_id in inner)
        ):
            return []
        axes = roots | outer | inner
        if any(len(item.block_ids) != 1 for item in spec.block_sizes):
            return []
        blocks = {item.block_id: item for item in spec.block_sizes}
        if set(blocks) != axes or any(
            not axes.issubset(sequence.valid_block_ids())
            for sequence in (
                spec.num_threads,
                spec.cute_vector_widths,
                spec.cute_lane_layouts,
            )
        ):
            return []
        extents = {blocks[block_id].size_hint for block_id in outer}
        if len(extents) != 1:
            return []
        (extent,) = extents
        columns = 1 << (max(1, extent) - 1).bit_length()
        fragments = {bid: block._fragment(spec) for bid, block in blocks.items()}
        seeds = []
        for column_tile in dict.fromkeys((columns, min(columns, 128))):
            for reduction_tile in (32, 128, 256):
                values = {
                    **dict.fromkeys(roots, 1),
                    **dict.fromkeys(outer, column_tile),
                    **dict.fromkeys(inner, reduction_tile),
                }
                if not all(
                    fragments[bid].low <= value <= fragments[bid].high
                    for bid, value in values.items()
                ):
                    continue
                threads = {
                    **dict.fromkeys(roots | inner, 1),
                    **dict.fromkeys(outer, min(column_tile, 256)),
                }
                seeds.append(
                    Config.from_dict(
                        {
                            "block_sizes": _seq_config_list(spec.block_sizes, values),
                            "num_threads": _seq_config_list(spec.num_threads, threads),
                            "cute_vector_widths": _seq_config_list(
                                spec.cute_vector_widths, dict.fromkeys(axes, 1)
                            ),
                            "cute_lane_layouts": _seq_config_list(
                                spec.cute_lane_layouts, dict.fromkeys(axes, "strided")
                            ),
                        }
                    )
                )
        return dedupe_configs(seeds)


class CuteResidentRowHeuristic(AutotunerHeuristic):
    """Register-resident whole-row seed for softmax-shaped tile kernels.

    Seeds ``block_sizes=[1, N]`` (the whole reduction axis as one tile) with
    a multi-warp thread block, V=8 vec loads/stores, and the strided
    (coalesced) lane layout.  With the single-trip tile loop the cross-sweep
    load fuser caches the row in a register fragment (one gmem read for the
    whole kernel), the lane-reduce collapse runs ONE grouped reduction per
    sweep, and the vec-store flush writes 128-bit stores.  Measured ~2x over
    the warp-reduce family on (32768, 4096..16384) bf16 rows on B200.
    """

    name = "cute_resident_row"
    backend = "cute"

    @classmethod
    def _plan(
        cls, env: CompileEnvironment, device_ir: DeviceIR
    ) -> tuple[int, int, int, int] | None:
        """Return ``(row_extent, num_threads, vec, cluster_n)`` or None."""
        spec = env.config_spec
        if spec.matmul_facts:
            return None
        if (
            len(spec.block_sizes) != 2
            or spec.reduction_loops
            or (
                spec.kernel_grid_fact is not None
                and len(spec.kernel_grid_fact.roots) > 1
            )
        ):
            return None
        inner = cast("Any", spec.block_sizes[1])
        inner_block_id = inner.block_ids[0] if hasattr(inner, "block_ids") else None
        if inner_block_id is None:
            return None
        if inner_block_id not in spec.cute_vector_widths.valid_block_ids():
            return None
        if inner_block_id not in spec.cute_lane_layouts.valid_block_ids():
            return None
        dtype = _cute_tile_inner_block_dtype(env, device_ir, inner_block_id)
        vec = _cute_tile_seed_vec_width_for_dtype(dtype)
        if vec <= 1:
            return None
        try:
            n = int(env.block_sizes[inner_block_id].numel)
        except (TypeError, ValueError):
            return None
        # The whole-row block must be a reachable block size (power of 2)
        # and fit the per-thread register budget at some thread count.
        if n & (n - 1) or n <= 0:
            return None
        bn_fragment = inner._fragment(spec)
        bn_high = getattr(bn_fragment, "high", None)
        if not isinstance(bn_high, int) or bn_high < n:
            return None
        # Prefer <=64 elements per thread (no spills) at 256 threads, using
        # the smallest cluster that fits — a 256-thread CTA with a wider
        # cluster measures well ahead of a 512-thread CTA at the same
        # per-thread footprint (5090 vs 3374 GB/s on 32768x32768 bf16).
        # Each cluster CTA owns a contiguous register-resident slice; one
        # DSM cluster reduce per sweep.
        for threads in (256, 512, 128):
            for cluster_n in (1, 2, 4, 8, 16):
                per_cta = n // cluster_n
                if per_cta % (threads * vec) == 0 and per_cta // threads <= 64:
                    return n, threads, vec, cluster_n
        return None

    @classmethod
    def is_eligible(cls, env: CompileEnvironment, device_ir: DeviceIR) -> bool:
        return cls._plan(env, device_ir) is not None

    @classmethod
    def get_seed_config(
        cls, env: CompileEnvironment, device_ir: DeviceIR
    ) -> Config | None:
        plan = cls._plan(env, device_ir)
        if plan is None:
            return None
        n, threads, vec, cluster_n = plan
        spec = env.config_spec
        inner_block_id = spec.block_sizes[1].block_id
        seed: dict[str, Any] = {
            "block_sizes": [1, n],
            "num_threads": _seq_config_list(
                spec.num_threads, {inner_block_id: threads}
            ),
            "cute_vector_widths": _seq_config_list(
                spec.cute_vector_widths, {inner_block_id: vec}
            ),
            "cute_lane_layouts": _seq_config_list(
                spec.cute_lane_layouts, {inner_block_id: "strided"}
            ),
        }
        if cluster_n > 1:
            seed["cute_cluster_n"] = cluster_n
        if cluster_n >= 4:
            # Wide clusters need occupancy over registers (measured +9-27%
            # at cluster 4-16 on B200).
            seed["cute_min_blocks_per_mp"] = 3
        try:
            return Config(**seed)
        except Exception:
            return None


class CuteResidentRowWideClusterHeuristic(AutotunerHeuristic):
    """Wide-cluster occupancy-squeeze variant of ``CuteResidentRowHeuristic``.

    With the cluster online-pair rewrite (one packed DSM exchange per row
    instead of two) wide clusters of small CTAs win big rows.  The best
    measured family keeps 64 elements per thread (the fused u16 x-cache +
    f32 exp-cache footprint that fits ~80-95 registers) and squeezes
    ptxas to ~24 warps/SM via ``min_blocks_per_mp = 768 // threads``: on
    B200 the extra resident CTA outweighs ~10 spilled registers
    (65536: T128/CL8/mb6 4861 vs mb2 4712 GB/s; 131072: T128/CL16/mb6
    4821 vs quack 4614; 262144: T256/CL16/mb3 4304 vs quack 4284).
    Rows that cannot hit 64/thread at any cluster width (e.g. odd-multiple
    rows whose per-CTA slice divides 128 lanes but not 256) fall back to
    the 128-elements/thread register-capped family at ``mb=3``; power-of-2
    rows too big even for that leave the heuristic ineligible.
    """

    # minnctapersm target: ~24 warps/SM measured best for the
    # 64-element/thread family on B200 (see class docstring).
    _TARGET_THREADS_PER_SM = 768

    name = "cute_resident_row_wide_cluster"
    backend = "cute"

    @classmethod
    def _plan(
        cls, env: CompileEnvironment, device_ir: DeviceIR
    ) -> tuple[int, int, int, int, int] | None:
        base = CuteResidentRowHeuristic._plan(env, device_ir)
        if base is None:
            return None
        n, _threads, vec, _cluster_n = base
        for max_per_thread, threads in ((64, 128), (64, 256), (128, 128)):
            for cluster_n in (2, 4, 8, 16):
                per_cta = n // cluster_n
                if (
                    per_cta % (threads * vec) == 0
                    and per_cta // threads <= max_per_thread
                ):
                    return n, threads, vec, cluster_n, max_per_thread
        return None

    @classmethod
    def is_eligible(cls, env: CompileEnvironment, device_ir: DeviceIR) -> bool:
        return cls._plan(env, device_ir) is not None

    @classmethod
    def get_seed_config(
        cls, env: CompileEnvironment, device_ir: DeviceIR
    ) -> Config | None:
        plan = cls._plan(env, device_ir)
        if plan is None:
            return None
        n, threads, vec, cluster_n, max_per_thread = plan
        spec = env.config_spec
        inner_block_id = spec.block_sizes[1].block_id
        seed: dict[str, Any] = {
            "block_sizes": [1, n],
            "num_threads": _seq_config_list(
                spec.num_threads, {inner_block_id: threads}
            ),
            "cute_vector_widths": _seq_config_list(
                spec.cute_vector_widths, {inner_block_id: vec}
            ),
            "cute_lane_layouts": _seq_config_list(
                spec.cute_lane_layouts, {inner_block_id: "strided"}
            ),
            "cute_cluster_n": cluster_n,
        }
        if max_per_thread > 64:
            # 128 elements/thread: the exp/load caches alone need ~128
            # registers, so cap the budget for 3 CTAs/SM.
            seed["cute_min_blocks_per_mp"] = 3
        else:
            # 64/thread: squeeze to ~24 warps/SM (85-register cap at 128
            # threads); a handful of spills costs less than the lost CTA.
            seed["cute_min_blocks_per_mp"] = cls._TARGET_THREADS_PER_SM // threads
        try:
            return Config(**seed)
        except Exception:
            return None


class CuteResidentMultiRowHeuristic(AutotunerHeuristic):
    """Multi-row variant of ``CuteResidentRowHeuristic`` for short rows.

    A short reduction axis (N <= 2048) leaves a whole-row CTA with too few
    threads/CTAs doing too little work each; packing several rows per CTA
    with one warp per row keeps the reduction a pure warp shuffle (no
    shared memory) while restoring the CTA size.
    """

    name = "cute_resident_multi_row"
    backend = "cute"

    _ROWS_PER_CTA = 4
    _THREADS_PER_ROW = 32
    _MAX_ROW_EXTENT = 2048

    @classmethod
    def _plan(
        cls, env: CompileEnvironment, device_ir: DeviceIR
    ) -> tuple[int, int] | None:
        spec = env.config_spec
        if spec.matmul_facts:
            return None
        if (
            len(spec.block_sizes) != 2
            or spec.reduction_loops
            or (
                spec.kernel_grid_fact is not None
                and len(spec.kernel_grid_fact.roots) > 1
            )
        ):
            return None
        inner = cast("Any", spec.block_sizes[1])
        inner_block_id = inner.block_ids[0] if hasattr(inner, "block_ids") else None
        if inner_block_id is None:
            return None
        if inner_block_id not in spec.cute_vector_widths.valid_block_ids():
            return None
        if inner_block_id not in spec.cute_lane_layouts.valid_block_ids():
            return None
        dtype = _cute_tile_inner_block_dtype(env, device_ir, inner_block_id)
        vec = _cute_tile_seed_vec_width_for_dtype(dtype)
        if vec <= 1:
            return None
        try:
            n = int(env.block_sizes[inner_block_id].numel)
        except (TypeError, ValueError):
            return None
        if n & (n - 1) or n <= 0 or n > cls._MAX_ROW_EXTENT:
            return None
        if n % (cls._THREADS_PER_ROW * vec) != 0:
            return None
        bn_fragment = inner._fragment(spec)
        bn_high = getattr(bn_fragment, "high", None)
        if not isinstance(bn_high, int) or bn_high < n:
            return None
        return n, vec

    @classmethod
    def is_eligible(cls, env: CompileEnvironment, device_ir: DeviceIR) -> bool:
        return cls._plan(env, device_ir) is not None

    @classmethod
    def get_seed_config(
        cls, env: CompileEnvironment, device_ir: DeviceIR
    ) -> Config | None:
        plan = cls._plan(env, device_ir)
        if plan is None:
            return None
        n, vec = plan
        spec = env.config_spec
        outer_block_id, inner_block_id = (item.block_id for item in spec.block_sizes)
        seed: dict[str, Any] = {
            "block_sizes": [cls._ROWS_PER_CTA, n],
            "num_threads": _seq_config_list(
                spec.num_threads,
                {
                    outer_block_id: cls._ROWS_PER_CTA,
                    inner_block_id: cls._THREADS_PER_ROW,
                },
            ),
            "cute_vector_widths": _seq_config_list(
                spec.cute_vector_widths, {inner_block_id: vec}
            ),
            "cute_lane_layouts": _seq_config_list(
                spec.cute_lane_layouts, {inner_block_id: "strided"}
            ),
        }
        try:
            return Config(**seed)
        except Exception:
            return None


class CuteTileVecWarpPerRowHeuristic(AutotunerHeuristic):
    """P15: warp-per-row layout for softmax-shaped tile kernels.

    Sibling seed for ``CuteTileVecWarpReduceHeuristic`` that puts MORE
    than one row per CTA — each warp owns one row. The warp-per-row
    plan in ``layout_propagation.py`` swaps the thread-axis assignment
    so:

    * N (reduction axis) lands on ``thread_idx[0]`` (32 contiguous
      threads = one warp per row)
    * M (outer grid row axis) lands on ``thread_idx[1]`` (warp index =
      row index)

    The strided reduction dispatcher then picks the direct
    ``cute.arch.warp_reduction_*`` path with ``threads_in_group=32``
    (group_span == 32, one warp per group), avoiding the
    cross-warp shared-memory two-stage reduce that would dominate when
    rows are spread across threads.

    Seeds ``block_sizes=[2, V * 32]``, ``num_threads=[0, 32]``,
    ``cute_vector_widths=[1, V]`` so each row stays inside a single
    warp and 2 rows fit in one CTA (giving 64 threads = 2 warps per
    CTA -> higher occupancy on softmax-shaped reductions).

    Eligible whenever ``CuteTileVecWarpReduceHeuristic`` is eligible
    and the outer tile fragment admits M >= 2.
    """

    name = "cute_tile_vec_warp_per_row"
    backend = "cute"

    @classmethod
    def is_eligible(cls, env: CompileEnvironment, device_ir: DeviceIR) -> bool:
        spec = env.config_spec
        if spec.matmul_facts:
            return False
        if (
            len(spec.block_sizes) != 2
            or spec.reduction_loops
            or (
                spec.kernel_grid_fact is not None
                and len(spec.kernel_grid_fact.roots) > 1
            )
        ):
            return False
        inner_block_id = (
            cast("Any", spec.block_sizes[1]).block_ids[0]
            if hasattr(cast("Any", spec.block_sizes[1]), "block_ids")
            else None
        )
        if inner_block_id is None:
            return False
        if inner_block_id not in spec.cute_vector_widths.valid_block_ids():
            return False
        dtype = _cute_tile_inner_block_dtype(env, device_ir, inner_block_id)
        vec = _cute_tile_seed_vec_width_for_dtype(dtype)
        if vec <= 1:
            return False
        bn_high = spec.block_sizes[1]._fragment(spec).high
        if bn_high < vec * 32:
            return False
        # Outer (M) fragment must admit M=2 (warp-per-row launches 2
        # warps per CTA so each row is one warp).
        bm_fragment = spec.block_sizes[0]._fragment(spec)
        return bm_fragment.low <= 2 <= bm_fragment.high

    @classmethod
    def get_seed_config(
        cls, env: CompileEnvironment, device_ir: DeviceIR
    ) -> Config | None:
        spec = env.config_spec
        inner_block_id = (
            cast("Any", spec.block_sizes[1]).block_ids[0]
            if hasattr(cast("Any", spec.block_sizes[1]), "block_ids")
            else None
        )
        if inner_block_id is None:
            return None
        dtype = _cute_tile_inner_block_dtype(env, device_ir, inner_block_id)
        vec = _cute_tile_seed_vec_width_for_dtype(dtype)
        if vec <= 1:
            return None
        bn_high = spec.block_sizes[1]._fragment(spec).high
        block_n = vec * 32
        if bn_high < block_n:
            return None
        seed: dict[str, Any] = {
            "block_sizes": [2, block_n],
            "num_threads": _seq_config_list(spec.num_threads, {inner_block_id: 32}),
            "cute_vector_widths": _seq_config_list(
                spec.cute_vector_widths, {inner_block_id: vec}
            ),
        }
        try:
            return Config(**seed)
        except Exception:
            return None


class CuteColumnReductionHeuristic(AutotunerHeuristic):
    """Coalesced seeds for a reduction over a serial tile axis whose other
    axis is the grid (a column sum: ``acc += sum(x[tile_m, tile_n], dim=0)``).

    The autotuner's natural winner for this shape puts the threads along the
    reduced rows (uncoalesced 2-byte loads), and the coalesced layouts that
    exist in the space (lanes and the vector along the contiguous grid axis)
    only pay off together with ``cute_vloop_sink``, which interchanges the
    grid axis' constexpr vector loop into the row loops so each thread issues
    one 16-byte vector load per row.  Seed that layout: a few threads along
    the contiguous grid axis owning one vector each (32-64 contiguous bytes
    per row per CTA), the remaining threads along the reduced axis with a
    strided lane layout, the whole reduced extent per CTA, sinking on and
    the row lane loop unrolled.  Sinking and the unroll depth become
    searchable knobs once seeded.
    """

    name = "cute_column_reduction"
    backend = "cute"
    # Vector loads over a dynamic extent need the exact input metadata: the
    # extent and the row strides must be proven multiples of the vector width.
    CACHE_SPECIALIZATION_FACTS = frozenset({"input_tensor_metadata"})

    @classmethod
    def _match(
        cls, env: CompileEnvironment, device_ir: DeviceIR
    ) -> tuple[int, int, torch.Tensor] | None:
        """``(grid_block_id, reduced_block_id, source)`` when the kernel reduces
        a ``[reduced, grid]`` tile loaded from the 2-D 16/32-bit input
        ``source`` along its serial device-loop axis, the grid tile has a zero
        origin, ``source`` is contiguous along the grid axis and the seed
        vector fits one transaction: what sinking needs independently of this
        binding's extents and strides (``_plan`` checks those)."""
        from ..device_ir import ForLoopGraphInfo

        spec = env.config_spec
        if spec.matmul_facts or spec.reduction_loops:
            return None
        paths = tile_loop_paths(device_ir, device_ir.graphs)
        if (
            len(paths) != 1
            or len(paths[0]) != 2
            or any(len(axis) != 1 for axis in paths[0])
        ):
            return None
        grid_block_id, reduced_block_id = paths[0][0][0], paths[0][1][0]
        if grid_block_id in device_ir.noncanonical_task_origin_block_ids:
            # ``hl.tile(8, n)``: the chunks are not V-aligned and the column
            # mask differs per element, so no load can be widened.
            return None
        for sequence in (
            spec.num_threads,
            spec.cute_vector_widths,
            spec.cute_lane_layouts,
        ):
            if not {grid_block_id, reduced_block_id}.issubset(
                sequence.valid_block_ids()
            ):
                return None
        if len(spec.block_sizes) != 2 or any(
            len(item.block_ids) != 1 for item in spec.block_sizes
        ):
            return None
        grid_symbol = _symint_sympy_expr(env.block_sizes[grid_block_id].var)
        reduced_symbol = _symint_sympy_expr(env.block_sizes[reduced_block_id].var)
        for graph_info in device_ir.graphs:
            if not isinstance(graph_info, ForLoopGraphInfo) or list(
                graph_info.block_ids
            ) != [reduced_block_id]:
                continue
            for node in graph_info.graph.nodes:
                if node.op != "call_function":
                    continue
                target_name = getattr(node.target, "__name__", "")
                if target_name.split(".")[0] not in (
                    "sum",
                    "amax",
                    "amin",
                    "prod",
                    "mean",
                ):
                    continue
                dims = node.args[1] if len(node.args) > 1 else node.kwargs.get("dim")
                if dims not in (0, [0], (0,)):
                    continue
                source = node.args[0]
                if not isinstance(source, torch.fx.Node):
                    continue
                value = source.meta.get("val")
                if not (isinstance(value, torch.Tensor) and value.ndim == 2):
                    continue
                reduced_dim, grid_dim = value.shape
                if not (
                    isinstance(reduced_dim, torch.SymInt)
                    and isinstance(grid_dim, torch.SymInt)
                    and _symint_sympy_expr(reduced_dim) == reduced_symbol
                    and _symint_sympy_expr(grid_dim) == grid_symbol
                ):
                    continue
                while (
                    source.op == "call_function"
                    and getattr(source.target, "__name__", "").startswith(
                        "convert_element_type"
                    )
                    and isinstance(source.args[0], torch.fx.Node)
                ):
                    source = source.args[0]
                loaded = source.meta.get("val")
                tensor_node = source.args[0] if source.args else None
                tensor = (
                    tensor_node.meta.get("val")
                    if isinstance(tensor_node, torch.fx.Node)
                    else None
                )
                if not (
                    source.target is language_load
                    and isinstance(loaded, torch.Tensor)
                    and loaded.dtype in (torch.float16, torch.bfloat16, torch.float32)
                    and isinstance(tensor, torch.Tensor)
                    and tensor.ndim == 2
                ):
                    continue
                vec = _cute_tile_seed_vec_width_for_dtype(tensor.dtype)
                column_stride = tensor.stride(1)
                if (
                    vec > 1
                    and vec * tensor.dtype.itemsize <= _CUTE_VECTOR_MAX_BYTES
                    and isinstance(column_stride, int)
                    and column_stride == 1
                ):
                    return grid_block_id, reduced_block_id, tensor
        return None

    @classmethod
    def _plan(
        cls, env: CompileEnvironment, device_ir: DeviceIR
    ) -> tuple[int, int, torch.Tensor] | None:
        """The match when sinking can fire for this binding: the grid extent
        and the source's row stride are multiples of the seed vector width
        (one aligned V-wide chunk per row)."""
        match = cls._match(env, device_ir)
        if match is None:
            return None
        grid_block_id, _reduced_block_id, source = match
        vec = _cute_tile_seed_vec_width_for_dtype(source.dtype)
        if not (
            env.specialized_multiple(source.stride(0), vec)
            and env.specialized_multiple(env.block_sizes[grid_block_id].numel, vec)
        ):
            return None
        return match

    @classmethod
    def register_facts(
        cls, env: CompileEnvironment, device_ir: DeviceIR
    ) -> frozenset[CompilerHeuristicSpecializationFact]:
        match = cls._match(env, device_ir)
        if match is None:
            # Nothing this binding's metadata could add would let a seed fire,
            # so this hook adds no facts.  Other heuristics (the resident
            # sequence and bounded loop cache seeds) may still key the same
            # binding on its exact input metadata.
            return frozenset()
        grid_block_id, _reduced_block_id, source = match
        # Static extents and strides prove the vector layout by themselves;
        # only dynamic ones need this binding's exact metadata.
        if isinstance(env.block_sizes[grid_block_id].size, torch.SymInt) or any(
            isinstance(source.stride(dim), torch.SymInt) for dim in range(source.ndim)
        ):
            return cls.CACHE_SPECIALIZATION_FACTS
        return frozenset()

    @classmethod
    def is_eligible(cls, env: CompileEnvironment, device_ir: DeviceIR) -> bool:
        return bool(cls.get_seed_configs(env, device_ir))

    @classmethod
    def get_seed_config(
        cls, env: CompileEnvironment, device_ir: DeviceIR
    ) -> Config | None:
        seeds = cls.get_seed_configs(env, device_ir)
        return seeds[0] if seeds else None

    @classmethod
    def get_seed_configs(
        cls, env: CompileEnvironment, device_ir: DeviceIR
    ) -> list[Config]:
        plan = cls._plan(env, device_ir)
        if plan is None:
            return []
        grid_block_id, reduced_block_id, source = plan
        spec = env.config_spec
        vec = _cute_tile_seed_vec_width_for_dtype(source.dtype)
        block_specs = {item.block_id: item for item in spec.block_sizes}
        grid_fragment = block_specs[grid_block_id]._fragment(spec)
        reduced_fragment = block_specs[reduced_block_id]._fragment(spec)
        reduced_hint = max(1, block_specs[reduced_block_id].size_hint)
        # The whole reduced extent per CTA (one serial trip), capped by the
        # fragment so the seed stays reachable for very tall inputs.
        rows = min(1 << (reduced_hint - 1).bit_length(), reduced_fragment.high)
        seeds: list[Config] = []
        # (threads along the grid axis, CTA threads, vector divisor): 2 x V
        # elements per row per CTA is one 32-byte sector for a 16-byte
        # vector.  The half-width vector (four grid threads owning 8-byte
        # vectors, 128 row threads) keeps that sector with twice the rows in
        # flight per CTA and was the measured best at 1024^2 and 4096^2.
        for grid_threads, cta_threads, vec_divisor in (
            (2, 512, 1),
            (4, 512, 1),
            (2, 256, 1),
            (4, 512, 2),
        ):
            seed_vec = vec // vec_divisor
            if seed_vec < 2:
                continue
            columns = grid_threads * seed_vec
            row_threads = cta_threads // grid_threads
            while row_threads > 32 and rows // row_threads < 4:
                row_threads //= 2
            if not (
                grid_fragment.low <= columns <= grid_fragment.high
                and reduced_fragment.low <= rows <= reduced_fragment.high
            ):
                continue
            seeds.append(
                Config.from_dict(
                    {
                        "block_sizes": _seq_config_list(
                            spec.block_sizes,
                            {reduced_block_id: rows, grid_block_id: columns},
                        ),
                        "num_threads": _seq_config_list(
                            spec.num_threads,
                            {
                                reduced_block_id: row_threads,
                                grid_block_id: grid_threads,
                            },
                        ),
                        "cute_vector_widths": _seq_config_list(
                            spec.cute_vector_widths, {grid_block_id: seed_vec}
                        ),
                        "cute_lane_layouts": _seq_config_list(
                            spec.cute_lane_layouts, {reduced_block_id: "strided"}
                        ),
                        "cute_vloop_sink": True,
                        "cute_lane_unroll": 8,
                        # The launch overlaps the output's zero fill.
                        "cute_pdl": True,
                    }
                )
            )
        return dedupe_configs(seeds)


class CuteReductionWideChunkHeuristic(AutotunerHeuristic):
    """Companion seed: chunk = max(max_threads, size_hint/2) so the inner
    reduction loop has very few outer iterations and lane_extent absorbs
    the bulk of the work.

    For large N this lattice (1-2 outer iters, large lane_extent) tends to
    schedule better than the narrow-chunk lattice (many outer iters,
    lane_extent=1) on B200 — the SASS is dominated by per-iter scheduling
    bubbles in the narrow case, while the wide case lets the compiler
    overlap the load/compute/store traffic across the unrolled lane
    iterations. Only applies when size_hint > max_threads (otherwise the
    narrow heuristic already gives the same lattice).
    """

    name = "cute_reduction_wide_chunk"
    backend = "cute"

    @classmethod
    def is_eligible(cls, env: CompileEnvironment, device_ir: DeviceIR) -> bool:
        if not is_canonical_row_reduction(env):
            return False
        spec = env.config_spec
        rl_spec = cast("ReductionLoopSpec", spec.reduction_loops[0])
        max_threads = spec.max_reduction_threads or 1024
        return rl_spec.size_hint > 2 * max_threads

    @classmethod
    def get_seed_config(
        cls, env: CompileEnvironment, device_ir: DeviceIR
    ) -> Config | None:
        spec = env.config_spec
        rl_spec = cast("ReductionLoopSpec", spec.reduction_loops[0])
        max_threads = spec.max_reduction_threads or 1024
        size_hint = rl_spec.size_hint
        # Halve the size_hint until it fits in the reduction_loop chunk
        # spec's [low, high] range; the autotuner explores power-of-2
        # chunks so we keep this seed PoT.
        chunk = size_hint // 2
        if chunk < max_threads:
            chunk = max_threads
        seed: dict[str, Any] = {
            "block_sizes": [1],
            "num_threads": _seq_config_list(spec.num_threads, {}),
            "reduction_loops": [chunk],
        }
        vec = _cute_seed_vec_width(env, rl_spec, max_threads, size_hint, device_ir)
        if vec > 1:
            seed["cute_vector_widths"] = _seq_config_list(
                spec.cute_vector_widths, {rl_spec.block_id: vec}
            )
        return Config(**seed)


class CuteRolledRowLadderHeuristic(AutotunerHeuristic):
    """Quack-style ladder seed for rolled row reductions (layernorm /
    rmsnorm family): moderate threads-per-row that grow with the row width,
    128-bit vectorized strided lanes, and a wide loop chunk.

    Measured on B200 bf16 rows (see benchmarks/cute/layernorm_plan.md):
    threads-per-row 32 @ N<=2k, 128 @ <=8k, 256 @ <=32k, 512 @ <=64k, and
    the chunk-derived maximum beyond; rows-per-CTA fills the CTA to >=128
    threads for narrow rows.  The reload choice is left at "auto" (register
    fragment up to 64 elements/thread, gmem/L2 reload beyond), which
    matched the hand-tuned best at every measured width.
    """

    name = "cute_rolled_row_ladder"
    backend = "cute"

    @classmethod
    def is_eligible(cls, env: CompileEnvironment, device_ir: DeviceIR) -> bool:
        return is_canonical_row_reduction(env)

    @classmethod
    def get_seed_config(
        cls, env: CompileEnvironment, device_ir: DeviceIR
    ) -> Config | None:
        spec = env.config_spec
        rl_spec = cast("ReductionLoopSpec", spec.reduction_loops[0])
        max_threads = spec.max_reduction_threads or 1024
        size_hint = rl_spec.size_hint
        vec = _cute_seed_vec_width(env, rl_spec, max_threads, size_hint, device_ir)
        if size_hint <= 2048:
            threads_per_row = 32
        elif size_hint <= 8192:
            threads_per_row = 128
        elif size_hint <= 32768:
            threads_per_row = 256
        elif size_hint <= 65536:
            threads_per_row = 512
        else:
            threads_per_row = 0  # auto: chunk-derived (1024)
        rows_per_cta = max(1, 128 // threads_per_row) if threads_per_row else 1
        if rows_per_cta > 1 and not _block_size_value_reachable(spec, 0, rows_per_cta):
            rows_per_cta = 1
        chunk = min(size_hint // 2, 65536)
        chunk = max(chunk, max(threads_per_row, 1) * max(vec, 1))
        if chunk >= size_hint or chunk < 2:
            return None
        rdim_id = rl_spec.block_id
        tile_id = spec.block_sizes[0].block_id
        nt_overrides: dict[int, object] = {tile_id: rows_per_cta}
        if threads_per_row:
            nt_overrides[rdim_id] = threads_per_row
        seed: dict[str, Any] = {
            "block_sizes": [rows_per_cta],
            "num_threads": _seq_config_list(spec.num_threads, nt_overrides),
            "reduction_loops": [chunk],
            "cute_lane_layouts": _seq_config_list(
                spec.cute_lane_layouts, {rdim_id: "strided"}
            ),
        }
        if vec > 1:
            seed["cute_vector_widths"] = _seq_config_list(
                spec.cute_vector_widths, {rdim_id: vec}
            )
        return Config(**seed)


class CuteRolledClusterLadderHeuristic(AutotunerHeuristic):
    """Cluster row-split seed for very wide rolled row reductions: split
    each row across a thread-block cluster so every CTA rolls a ~16k-element
    slice (one DSM exchange combines the partials; every CTA gets the full
    result and consumes only its slice).

    Below the cluster the single-CTA rolled form must reload the whole row
    for the consume sweep from gmem — at multi-hundred-KB rows that second
    read misses L2 and costs ~1.5x DRAM traffic.  The 16k-element slice
    target matches both the Quack rmsnorm heuristic (cluster_n =
    N/16384 capped at 16) and the B200 hand-transplant measurements
    (see benchmarks/cute/compare_rmsnorm_backends.py): 128 threads/CTA,
    single roll trip over the slice.
    """

    name = "cute_rolled_cluster_ladder"
    backend = "cute"

    _SLICE_TARGET = 16384
    _MAX_CLUSTER = 16
    _THREADS_PER_ROW = 128

    @classmethod
    def is_eligible(cls, env: CompileEnvironment, device_ir: DeviceIR) -> bool:
        if not is_canonical_row_reduction(env):
            return False
        spec = env.config_spec
        rl_spec = cast("ReductionLoopSpec", spec.reduction_loops[0])
        return rl_spec.size_hint >= 4 * cls._SLICE_TARGET

    @classmethod
    def get_seed_config(
        cls, env: CompileEnvironment, device_ir: DeviceIR
    ) -> Config | None:
        spec = env.config_spec
        rl_spec = cast("ReductionLoopSpec", spec.reduction_loops[0])
        size_hint = rl_spec.size_hint
        vec = _cute_seed_vec_width(
            env, rl_spec, spec.max_reduction_threads or 1024, size_hint, device_ir
        )
        # Power of two only: the cute_cluster_n EnumFragment enumerates
        # {1,2,4,8,16}, and an off-surface value would one-hot encode as
        # all zeros in the search surrogate.
        cluster_n = 1 << (
            min(cls._MAX_CLUSTER, size_hint // cls._SLICE_TARGET).bit_length() - 1
        )
        threads_per_row = cls._THREADS_PER_ROW
        # The rolled cluster split requires every CTA to roll whole chunks
        # of its own contiguous slice (see LoopedReductionStrategy).
        while cluster_n > 1 and size_hint % (cluster_n * threads_per_row * max(vec, 1)):
            cluster_n //= 2
        if cluster_n <= 1:
            return None
        # A chunk a few trips smaller than the slice schedules better than
        # one whole-slice trip (measured on B200 at N=262144: 4616 vs
        # 4350 GB/s) — the shorter unrolled body overlaps its loads across
        # roll iterations instead of one long dependency chain.
        slice_len = size_hint // cluster_n
        chunk = max(threads_per_row * max(vec, 1), min(4096, slice_len))
        while slice_len % chunk:
            chunk //= 2
        rdim_id = rl_spec.block_id
        tile_id = spec.block_sizes[0].block_id
        seed: dict[str, Any] = {
            "block_sizes": [1],
            "num_threads": _seq_config_list(
                spec.num_threads, {tile_id: 1, rdim_id: threads_per_row}
            ),
            "reduction_loops": [chunk],
            "cute_cluster_n": cluster_n,
            "cute_lane_layouts": _seq_config_list(
                spec.cute_lane_layouts, {rdim_id: "strided"}
            ),
        }
        if vec > 1:
            seed["cute_vector_widths"] = _seq_config_list(
                spec.cute_vector_widths, {rdim_id: vec}
            )
        try:
            return Config(**seed)
        except Exception:
            return None


def _block_size_value_reachable(
    spec: ConfigSpec,
    block_index: int,
    value: int,
) -> bool:
    if block_index < 0 or block_index >= len(spec.block_sizes):
        return False
    fragment = spec.block_sizes[block_index]._fragment(spec)
    return fragment.low <= value <= fragment.high


def _filter_reachable_block_size_configs(
    spec: ConfigSpec,
    configs: Sequence[Config],
) -> list[Config]:
    """Keep seeds whose block sizes are reachable in the live config spec."""
    result: list[Config] = []
    for config in configs:
        block_sizes = config.config.get("block_sizes")
        if not isinstance(block_sizes, list) or len(block_sizes) != len(
            spec.block_sizes
        ):
            continue
        if all(
            type(value) is int and _block_size_value_reachable(spec, index, value)
            for index, value in enumerate(block_sizes)
        ):
            result.append(config)
    return result


def _tcgen05_grouped_fact(env: CompileEnvironment) -> MatmulFact | None:
    spec = env.config_spec
    if (
        not spec.cute_tcgen05_search_enabled
        or len(spec.matmul_facts) != 1
        or len(spec.block_sizes) != 3
    ):
        return None
    fact = _tcgen05_fact_with_static_provenance(spec, spec.matmul_facts[0])
    if fact.lhs_dtype is not fact.rhs_dtype or fact.lhs_dtype not in (
        torch.float16,
        torch.bfloat16,
    ):
        return None
    if (
        fact.m_block_id is None
        or fact.n_block_id is None
        or fact.k_block_id is None
        or fact.static_m is None
        or fact.static_n is None
        or fact.static_k is None
    ):
        return None
    try:
        block_indices = (
            spec.block_sizes.block_id_to_index(fact.m_block_id),
            spec.block_sizes.block_id_to_index(fact.n_block_id),
            spec.block_sizes.block_id_to_index(fact.k_block_id),
        )
    except KeyError:
        return None
    if block_indices != (0, 1, 2):
        return None
    if fact.static_m % 128 != 0 or fact.static_n % 64 != 0:
        return None
    return fact


def _tcgen05_fact_with_static_provenance(
    spec: ConfigSpec,
    fact: MatmulFact,
) -> MatmulFact:
    static_extents = spec._tcgen05_matmul_compile_time_static_extents()
    if static_extents is None:
        return fact
    return fact._replace(
        static_m=static_extents[0],
        static_n=static_extents[1],
        static_k=static_extents[2],
    )


def _tcgen05_grouped_worklist_structural_fact(
    env: CompileEnvironment,
) -> MatmulFact | None:
    """Return structural grouped facts before dynamic shape hints are frozen."""
    spec = env.config_spec
    if len(spec.matmul_facts) != 1 or len(spec.block_sizes) != 3:
        return None
    fact = _tcgen05_fact_with_static_provenance(spec, spec.matmul_facts[0])
    if (
        fact.lhs_dtype not in (torch.float16, torch.bfloat16)
        or fact.rhs_dtype != fact.lhs_dtype
    ):
        return None
    if (
        fact.m_block_id is None
        or (fact.k_block_id is None and fact.static_k != 0)
        or (fact.n_block_id is None and fact.static_n != 0)
    ):
        return None
    if fact.k_block_id is None:
        # A statically empty reduction erases the K block association from the
        # matmul fact, but the registered third block axis remains its source.
        # Recover it so the full grouped-worklist proof below can decide whether
        # this kernel needs input-metadata specialization.
        fact = fact._replace(k_block_id=spec.block_sizes[2].block_id)
    try:
        assert fact.m_block_id is not None
        assert fact.k_block_id is not None
        m_index = spec.block_sizes.block_id_to_index(fact.m_block_id)
        k_index = spec.block_sizes.block_id_to_index(fact.k_block_id)
        n_index = (
            None
            if fact.n_block_id is None
            else spec.block_sizes.block_id_to_index(fact.n_block_id)
        )
    except KeyError:
        return None
    return fact if (m_index, n_index, k_index) in ((0, 1, 2), (0, None, 2)) else None


def _tcgen05_grouped_worklist_fact(
    env: CompileEnvironment,
) -> MatmulFact | None:
    if not env.config_spec.cute_tcgen05_search_enabled:
        return None
    return _tcgen05_grouped_worklist_structural_fact(env)


def _tcgen05_grouped_dynamic_bk64_fact(env: CompileEnvironment) -> MatmulFact | None:
    fact = _tcgen05_grouped_fact(env)
    if fact is None or cast("int", fact.static_k) % 64 != 0:
        return None
    spec = env.config_spec
    if not (
        _block_size_value_reachable(spec, 0, 128)
        and _block_size_value_reachable(spec, 1, 64)
        and _block_size_value_reachable(spec, 2, 64)
    ):
        return None
    if not spec._tcgen05_grouped_dynamic_stages_fit_for_target(
        dtype_bytes=fact.lhs_dtype.itemsize,
        output_dtype_bytes=fact.lhs_dtype.itemsize,
        device=env.device,
        bm=128,
        bn=64,
        bk=64,
        cluster_m=1,
        ab_stages=TCGEN05_GROUPED_DYNAMIC_AB4_STAGE,
        c_stages=2,
    ):
        return None
    return fact


def _tcgen05_grouped_seed_grid_is_valid(device_ir: DeviceIR, fact: MatmulFact) -> bool:
    return (
        len(device_ir.root_ids) == 1
        and len(device_ir.grid_block_ids) == 1
        and device_ir.grid_block_ids[0] == [fact.m_block_id, fact.n_block_id]
    )


def _tcgen05_grouped_static_common_k_block_k(static_k: int) -> int | None:
    return next(
        (bk for k, bk in TCGEN05_GROUPED_STATIC_COMMON_K_BLOCK_PAIRS if static_k == k),
        None,
    )


def _tcgen05_grouped_static_common_k_fact(env: CompileEnvironment) -> MatmulFact | None:
    fact = _tcgen05_grouped_fact(env)
    if fact is None:
        return None
    bk = _tcgen05_grouped_static_common_k_block_k(cast("int", fact.static_k))
    if bk is None:
        return None
    spec = env.config_spec
    if not (
        _block_size_value_reachable(spec, 0, 128)
        and _block_size_value_reachable(spec, 1, 64)
        and _block_size_value_reachable(spec, 2, bk)
    ):
        return None
    return fact


def _tcgen05_grouped_seed_config(bk: int) -> Config:
    config = Config(
        block_sizes=[128, 64, bk],
        l2_groupings=[1],
        loop_orders=[[0, 1]],
        num_stages=2,
        num_warps=8,
        pid_type=TCGEN05_TWO_CTA_SEED_PID_TYPE,
        tcgen05_cluster_m=1,
        tcgen05_cluster_n=1,
        tcgen05_ab_stages=2,
        tcgen05_acc_stages=2,
        tcgen05_c_stages=2,
        tcgen05_num_epi_warps=4,
    )
    config.config[TCGEN05_GROUPED_MODE_CONFIG_KEY] = TCGEN05_GROUPED_MODE_STATIC
    config.config[TCGEN05_PERSISTENCE_MODEL_CONFIG_KEY] = (
        Tcgen05PersistenceModel.STATIC_PERSISTENT.value
    )
    return config


# These B200 values shape generic reservation seeds only. Their SM reservations
# scale proportionally on other devices; exact measured policy overrides remain
# restricted to the product and SM count recorded in their workload envelope.
_TCGEN05_GROUPED_B200_REFERENCE_NUM_SMS = 148
_TCGEN05_GROUPED_B200_LOW_RESERVED_SMS = 32
_TCGEN05_GROUPED_B200_HIGH_RESERVED_SMS = 52
_TCGEN05_GROUPED_B200_PANEL_RESERVED_SMS = 20
# Grouped tcgen05 lowering is supported on both Blackwell compute capabilities;
# target-specific seed ranking remains separate from this architecture gate.
_TCGEN05_GROUPED_SUPPORTED_CAPABILITIES = frozenset({"sm100", "sm103"})
# The bound-kernel key already carries device kind and capability. Registering
# every policy identity as a named promotion target adds the exact product name,
# so two products on the same architecture cannot reuse different ranked seeds.
_TCGEN05_GROUPED_TARGET_IDENTITIES = grouped_worklist_target_identities()
assert {
    capability for _kind, _name, capability in _TCGEN05_GROUPED_TARGET_IDENTITIES
} <= _TCGEN05_GROUPED_SUPPORTED_CAPABILITIES


def _tcgen05_grouped_worklist_config(
    source_m_tile: int,
    block_k: int,
    ab_stages: int,
    consumer_regs: int,
    *,
    runtime_direct: bool = True,
    l2_swizzle_size: int | None = None,
    reserved_sms: int | None = None,
    clc: bool = False,
) -> Config:
    if clc and not runtime_direct:
        raise ValueError("grouped worklist CLC requires runtime_direct=True")
    cluster_m = (
        1
        if source_m_tile in TCGEN05_GROUPED_WORKLIST_ONE_CTA_SOURCE_M_TILE_CHOICES
        else 2
    )
    values: dict[str, object] = {
        "block_sizes": [256, 128, block_k],
        "l2_groupings": [1],
        "loop_orders": [[0, 1, 2]],
        "num_stages": 7,
        "num_warps": 8,
        "pid_type": "persistent_interleaved",
        "tcgen05_cluster_m": cluster_m,
        "tcgen05_cluster_n": 1,
        "tcgen05_ab_stages": ab_stages,
        "tcgen05_acc_stages": 2,
        "tcgen05_c_stages": 2,
        "tcgen05_num_epi_warps": 4,
        TCGEN05_CONSUMER_REGS_CONFIG_KEY: consumer_regs,
        TCGEN05_GROUPED_MODE_CONFIG_KEY: TCGEN05_GROUPED_MODE_WORKLIST_NM,
        TCGEN05_GROUPED_WORKLIST_SOURCE_M_TILE_CONFIG_KEY: source_m_tile,
    }
    if runtime_direct:
        values[TCGEN05_GROUPED_RUNTIME_DIRECT_CONFIG_KEY] = True
    if l2_swizzle_size is not None:
        values[TCGEN05_L2_SWIZZLE_SIZE_CONFIG_KEY] = l2_swizzle_size
    if reserved_sms is not None:
        values[TCGEN05_GROUPED_STATIC_RESERVED_SMS_CONFIG_KEY] = reserved_sms
    if clc:
        values.update(
            {
                TCGEN05_STRATEGY_CONFIG_KEY: (
                    Tcgen05Strategy.ROLE_LOCAL_WITH_SCHEDULER.value
                ),
                TCGEN05_WARP_SPEC_SCHEDULER_WARPS_KEY: 1,
                TCGEN05_PERSISTENCE_MODEL_CONFIG_KEY: (
                    Tcgen05PersistenceModel.CLC_PERSISTENT.value
                ),
            }
        )
    return Config.from_dict(values)


def _tcgen05_grouped_worklist_target_seed(
    *,
    groups: int,
    n: int,
    k: int,
    b_major: GroupedBMajor,
    source_m_tile: int,
    source_tiles: int,
    num_sm: int,
    target_policy: GroupedWorklistTargetPolicy,
    worklist_rows: tuple[tuple[int, int, int, int], ...] | None,
) -> Config | None:
    tuning = target_policy.tuning_for(
        groups=groups,
        n=n,
        k=k,
        b_major=b_major,
        source_m_tile=source_m_tile,
        source_tiles=source_tiles,
        num_sm=num_sm,
        worklist_rows=worklist_rows,
    )
    if tuning is None:
        return None
    return _tcgen05_grouped_worklist_config(
        source_m_tile,
        tuning.block_k,
        tuning.ab_stages,
        tuning.consumer_regs,
        runtime_direct=tuning.runtime_direct,
        l2_swizzle_size=tuning.l2_swizzle_size,
        reserved_sms=tuning.reserved_sms,
        clc=tuning.clc,
    )


def _tcgen05_grouped_scaled_reserved_sms(
    num_sm: int,
    b200_reserved_sms: int,
) -> int:
    value = round(num_sm * b200_reserved_sms / _TCGEN05_GROUPED_B200_REFERENCE_NUM_SMS)
    # The reviewed B200 occupancy splits were selected on a two-SM reservation
    # lattice.  Preserve that lattice after proportional scaling; an odd rounded
    # value moves up so the seed never reserves less than the scaled reference.
    value += value % 2
    return min(
        max(value, 0),
        max(num_sm - 2, 0),
        TCGEN05_GROUPED_STATIC_RESERVED_SMS_MAX,
    )


def _tcgen05_grouped_small_m_reserved_sms(
    *,
    groups: int,
    work_clusters: int,
    num_sm: int,
) -> tuple[int, int]:
    """Rank low/high reserved-SM seeds scaled from B200 occupancy splits."""
    low = _tcgen05_grouped_scaled_reserved_sms(
        num_sm,
        _TCGEN05_GROUPED_B200_LOW_RESERVED_SMS,
    )
    high = _tcgen05_grouped_scaled_reserved_sms(
        num_sm,
        _TCGEN05_GROUPED_B200_HIGH_RESERVED_SMS,
    )
    active_high = num_sm - high
    high_first = (
        groups <= 8
        and work_clusters > num_sm
        and active_high > 0
        and work_clusters % active_high == 0
    )
    return (high, low) if high_first else (low, high)


def _tcgen05_grouped_worklist_seed_family(
    *,
    groups: int,
    packed_m: int,
    n: int,
    k: int,
    b_major: GroupedBMajor,
    source_m_tile: int,
    num_sm: int,
    target_policy: GroupedWorklistTargetPolicy,
    worklist_rows: tuple[tuple[int, int, int, int], ...] | None = None,
) -> tuple[list[Config], Config | None]:
    """Build one ranked family and return its exact target seed, if any."""
    if any(
        type(value) is not int or value <= 0
        for value in (groups, packed_m, n, k, num_sm)
    ):
        raise ValueError("grouped seed dimensions and num_sm must be positive integers")
    if b_major not in ("k", "n"):
        raise ValueError(f"unsupported grouped B major {b_major!r}")
    if source_m_tile not in TCGEN05_GROUPED_WORKLIST_SOURCE_M_TILE_CHOICES:
        raise ValueError(f"unsupported grouped source M tile {source_m_tile!r}")
    if packed_m % source_m_tile != 0:
        raise ValueError("packed M extent must be divisible by source_m_tile")

    source_tiles = packed_m // source_m_tile
    logical_n_per_cluster = (
        128 if source_m_tile == TCGEN05_GROUPED_WORKLIST_SMALL_SOURCE_M_TILE else 256
    )
    work_clusters = source_tiles * (
        (n + logical_n_per_cluster - 1) // logical_n_per_cluster
    )
    target_seed = _tcgen05_grouped_worklist_target_seed(
        groups=groups,
        n=n,
        k=k,
        b_major=b_major,
        source_m_tile=source_m_tile,
        source_tiles=source_tiles,
        num_sm=num_sm,
        target_policy=target_policy,
        worklist_rows=worklist_rows,
    )

    if source_m_tile == TCGEN05_GROUPED_WORKLIST_SMALL_SOURCE_M_TILE:
        preferred_reservation, alternate_reservation = (
            _tcgen05_grouped_small_m_reserved_sms(
                groups=groups,
                work_clusters=work_clusters,
                num_sm=num_sm,
            )
        )
        high_reservation = _tcgen05_grouped_scaled_reserved_sms(
            num_sm,
            _TCGEN05_GROUPED_B200_HIGH_RESERVED_SMS,
        )
        panel_reservation = _tcgen05_grouped_scaled_reserved_sms(
            num_sm,
            _TCGEN05_GROUPED_B200_PANEL_RESERVED_SMS,
        )
        bk128 = {
            "preferred_reserved": _tcgen05_grouped_worklist_config(
                source_m_tile,
                128,
                5,
                256,
                reserved_sms=preferred_reservation,
            ),
            "alternate_reserved": _tcgen05_grouped_worklist_config(
                source_m_tile,
                128,
                5,
                256,
                reserved_sms=alternate_reservation,
            ),
            "unreserved": _tcgen05_grouped_worklist_config(source_m_tile, 128, 5, 256),
        }
        bk64 = {
            "high_reserved": _tcgen05_grouped_worklist_config(
                source_m_tile, 64, 7, 240, reserved_sms=high_reservation
            ),
            "direct": _tcgen05_grouped_worklist_config(source_m_tile, 64, 7, 240),
            "panel4": _tcgen05_grouped_worklist_config(
                source_m_tile,
                64,
                7,
                240,
                l2_swizzle_size=4,
                reserved_sms=panel_reservation,
            ),
            "panel8": _tcgen05_grouped_worklist_config(
                source_m_tile,
                64,
                7,
                240,
                l2_swizzle_size=8,
                reserved_sms=panel_reservation,
            ),
            "mailbox": _tcgen05_grouped_worklist_config(
                source_m_tile, 64, 7, 240, runtime_direct=False
            ),
        }
        if groups >= 16:
            if n > k:
                generic_primary = bk64["panel8"]
            elif n < k:
                generic_primary = bk64["panel4"]
            else:
                generic_primary = bk64["direct"]
        elif n >= 9 * k // 4:
            generic_primary = bk128["alternate_reserved"]
        elif n >= 2 * k:
            generic_primary = bk64["high_reserved"]
        elif k > n:
            generic_primary = bk64["direct"]
        else:
            generic_primary = bk128["preferred_reserved"]
        primary = generic_primary if target_seed is None else target_seed
        return (
            dedupe_configs([primary, generic_primary, *bk128.values(), *bk64.values()]),
            target_seed,
        )

    if source_m_tile == TCGEN05_GROUPED_WORKLIST_SOURCE_M_TILE_DEFAULT:
        # Source-224 normally keeps the reviewed panel-8 direct config as its
        # deterministic primary; target policy may replace it only for an
        # exact measured workload.
        panel8_direct = _tcgen05_grouped_worklist_config(
            source_m_tile,
            64,
            7,
            256,
            l2_swizzle_size=8,
        )
        mailbox_by_ab_stages = {
            ab_stages: _tcgen05_grouped_worklist_config(
                source_m_tile, 64, ab_stages, 240, runtime_direct=False
            )
            for ab_stages in range(7, 3, -1)
        }
        bk128_direct = _tcgen05_grouped_worklist_config(source_m_tile, 128, 3, 240)
        primary = panel8_direct if target_seed is None else target_seed
        return (
            dedupe_configs(
                [
                    primary,
                    panel8_direct,
                    *mailbox_by_ab_stages.values(),
                    bk128_direct,
                ]
            ),
            target_seed,
        )

    bk128 = {
        "mailbox": _tcgen05_grouped_worklist_config(
            source_m_tile, 128, 3, 240, runtime_direct=False
        ),
        "direct": _tcgen05_grouped_worklist_config(source_m_tile, 128, 3, 240),
        "panel8": _tcgen05_grouped_worklist_config(
            source_m_tile, 128, 3, 240, l2_swizzle_size=8
        ),
    }
    bk64 = {
        "mailbox_regs224": _tcgen05_grouped_worklist_config(
            source_m_tile, 64, 6, 224, runtime_direct=False
        ),
        "mailbox_regs240": _tcgen05_grouped_worklist_config(
            source_m_tile, 64, 6, 240, runtime_direct=False
        ),
        "direct_regs240": _tcgen05_grouped_worklist_config(source_m_tile, 64, 6, 240),
        "panel16_regs224": _tcgen05_grouped_worklist_config(
            source_m_tile, 64, 6, 224, l2_swizzle_size=16
        ),
        "panel8_stage5_regs224": _tcgen05_grouped_worklist_config(
            source_m_tile, 64, 5, 224, l2_swizzle_size=8
        ),
    }
    # Runtime CLC uses fixed full-allocation TensorMaps.  In N,M orientation,
    # logical N is the physical MMA-M dimension, so the immutable descriptor
    # path requires a whole 256-row physical tile.  Keep tail-N shapes on the
    # dynamic-TensorMap runtime-direct or mailbox families.
    clc_by_consumer_regs = (
        {
            consumer_regs: _tcgen05_grouped_worklist_config(
                source_m_tile,
                64,
                6,
                consumer_regs,
                l2_swizzle_size=8,
                clc=True,
            )
            for consumer_regs in (240, 256)
        }
        if (
            n % logical_n_per_cluster == 0
            and work_clusters <= TCGEN05_GROUPED_RUNTIME_DIRECT_CLC_MAX_CLUSTERS
        )
        else {}
    )
    clc_configs = list(clc_by_consumer_regs.values())
    # Ranking-only splits fitted from the reviewed B200 source-256 cases:
    # 16 groups marks high fan-out, N/K=2 and 9/4 are aspect buckets, and
    # 8/24 tiles per group separate short, medium, and long expert waves.
    tiles_per_group = source_tiles // groups
    clc_ready = bool(clc_configs) and work_clusters >= num_sm
    if groups >= 16:
        if k > n or n >= 9 * k // 4:
            generic_primary = bk128["mailbox"]
        elif n >= 2 * k:
            generic_primary = bk64["direct_regs240"]
        else:
            generic_primary = bk64["mailbox_regs224"]
    elif tiles_per_group >= 8:
        if k > n and clc_ready:
            preferred_clc_consumer_regs = 256 if groups <= 4 else 240
            generic_primary = clc_by_consumer_regs[preferred_clc_consumer_regs]
        elif n >= 9 * k // 4:
            generic_primary = (
                bk64["panel16_regs224"] if b_major == "n" else bk128["panel8"]
            )
        elif n >= 2 * k:
            generic_primary = (
                clc_by_consumer_regs[240]
                if b_major == "n" and clc_ready
                else bk64["direct_regs240"]
            )
        elif n == k:
            generic_primary = (
                bk128["direct"]
                if tiles_per_group >= 24
                else bk64["panel8_stage5_regs224"]
            )
        else:
            generic_primary = bk64["mailbox_regs240"]
    elif b_major == "n" and n >= 2 * k:
        generic_primary = bk64["direct_regs240"]
    else:
        generic_primary = bk64["mailbox_regs240"]
    primary = generic_primary if target_seed is None else target_seed
    return (
        dedupe_configs(
            [primary, generic_primary, *clc_configs, *bk64.values(), *bk128.values()]
        ),
        target_seed,
    )


def _tcgen05_grouped_worklist_source_analysis(
    env: CompileEnvironment,
    analysis: Tcgen05GroupedWorklistAnalysis,
) -> tuple[
    tuple[int, ...],
    tuple[tuple[int, int, int, int], ...] | None,
]:
    """Return legal source-M families and any exact reviewed row signature."""
    if analysis.input_kind == "device_split_sizes":
        # Compact A has no physical source-tile constraint. Source-32 uses the
        # one-CTA mailbox path with the same device-derived interval metadata.
        return (
            (
                TCGEN05_GROUPED_WORKLIST_SOURCE_M_TILE_DEFAULT,
                TCGEN05_GROUPED_WORKLIST_LARGE_SOURCE_M_TILE,
                TCGEN05_GROUPED_WORKLIST_SMALL_SOURCE_M_TILE,
            ),
            None,
        )

    facts = analysis.seed_facts
    from ..cute.grouped_worklist import (
        has_tcgen05_grouped_worklist_runtime_specialization,
    )
    from ..cute.grouped_worklist import tcgen05_grouped_worklist_rows

    reviewed_rows = _tcgen05_grouped_worklist_reviewed_rows(env)
    if not has_tcgen05_grouped_worklist_runtime_specialization(
        env, analysis.metadata_tensor
    ):
        return (), None
    worklist = env.runtime_value_for_tensor(analysis.metadata_tensor)
    if not isinstance(worklist, torch.Tensor):
        return (), None
    from ..cute.grouped_worklist import (
        tcgen05_grouped_worklist_compatible_source_m_tiles,
    )
    from ..cute.grouped_worklist import (
        tcgen05_grouped_worklist_source_m_tiles_by_preference,
    )

    rows = tcgen05_grouped_worklist_rows(worklist)
    if rows is None:
        return (), None
    compatible = tcgen05_grouped_worklist_compatible_source_m_tiles(
        rows,
        group_count=facts.groups_hint,
        packed_m=facts.packed_m_hint,
    )
    return (
        tcgen05_grouped_worklist_source_m_tiles_by_preference(compatible),
        rows if rows in reviewed_rows else None,
    )


_TCGEN05_GROUPED_WORKLIST_AUTOMATIC_SEED_LIMIT = 8
# Seed ranking leaves room for CuTe pipeline bookkeeping beyond the explicit
# shared arena. Final codegen/resource validation still decides admissibility.
_TCGEN05_GROUPED_OUTPUT_RING_SMEM_HEADROOM = 1024


def _bounded_grouped_worklist_seed_families(
    families: Sequence[Sequence[Config]],
    *,
    preferred_config: Config | None = None,
) -> list[Config]:
    """Keep every legal family represented without expanding tuning startup."""
    nonempty = [family for family in families if family]
    if preferred_config is not None and not any(
        preferred_config in family for family in nonempty
    ):
        raise ValueError("preferred_config must belong to a nonempty seed family")
    if not nonempty:
        return []
    ranked = [] if preferred_config is None else [preferred_config]
    ranked.extend(
        family[index]
        for index in range(max(map(len, nonempty)))
        for family in nonempty
        if index < len(family)
    )
    return dedupe_configs(ranked)[:_TCGEN05_GROUPED_WORKLIST_AUTOMATIC_SEED_LIMIT]


def _tcgen05_grouped_output_ring_seeds(
    seeds: Sequence[Config],
    *,
    group_count: int,
    dtype_bytes: int,
    capacity_bytes: int,
) -> list[Config]:
    """Cover the alternate output ring for device-metadata mailbox schedules.

    Grouped mode and its source-M tile are seed-only search coordinates. Their
    existing seeds all use C2, so random configurations cannot sample a complete
    C4 schedule. Add one C4/default-register witness per existing two-CTA
    source-M/BK geometry, retaining the original seed prefix at the caller.
    """
    budget = capacity_bytes - _TCGEN05_GROUPED_OUTPUT_RING_SMEM_HEADROOM
    if group_count <= 0 or dtype_bytes != 2 or budget <= 0:
        return []
    seen: set[tuple[int, int]] = set()
    result: list[Config] = []
    for seed in seeds:
        block_k = cast("list[int]", seed.config["block_sizes"])[2]
        profile = resolve_tcgen05_grouped_worklist_mma_profile(
            seed.config, block_k=block_k
        )
        if profile is None or profile.cluster_m != 2:
            continue
        key = (profile.source_m_tile, block_k)
        if key in seen:
            continue
        seen.add(key)
        # The existing grouped C4 envelope admits at most three AB stages.
        # Select the deepest inherited stage count that fits the physical
        # worklist tile, which differs from the logical [256, 128] config tile.
        ab_stages = min(cast("int", seed.config["tcgen05_ab_stages"]), 3)
        while ab_stages > 0:
            required = tcgen05_grouped_worklist_smem_bytes(
                group_count=group_count,
                device_split_sizes=True,
                sched_stage_count=cast(
                    "int", seed.config.get(TCGEN05_SCHED_STAGE_COUNT_CONFIG_KEY, 1)
                ),
                bm=profile.mma_m,
                bn=profile.mma_n,
                bk=block_k,
                dtype_bytes=dtype_bytes,
                ab_stages=ab_stages,
                acc_stages=cast("int", seed.config["tcgen05_acc_stages"]),
                c_stages=4,
                cluster_m=profile.cluster_m,
            )
            if required <= budget:
                values = dict(seed.config)
                values["tcgen05_ab_stages"] = ab_stages
                values["tcgen05_c_stages"] = 4
                values[TCGEN05_CONSUMER_REGS_CONFIG_KEY] = TCGEN05_CONSUMER_REGS_DEFAULT
                values.pop(TCGEN05_GROUPED_STATIC_RESERVED_SMS_CONFIG_KEY, None)
                result.append(Config.from_dict(values))
                break
            ab_stages -= 1
    return dedupe_configs(result)


def _tcgen05_grouped_worklist_hardware_identity(
    env: CompileEnvironment,
) -> GroupedWorklistHardwareIdentity | None:
    """Resolve the exact policy identity, failing closed on inconsistent data."""
    from ..._argument_device import _canonicalize_argument_device
    from ..._hardware import get_hardware_info

    try:
        hardware = get_hardware_info(_canonicalize_argument_device(env.device))
    except RuntimeError:
        return None
    capability = env.config_spec.target_device_capability
    if (
        capability is None
        or hardware.compute_capability != f"sm{capability[0]}{capability[1]}"
    ):
        return None
    return (
        hardware.device_kind,
        hardware.hardware_name,
        hardware.compute_capability,
    )


def _tcgen05_grouped_worklist_reviewed_rows(
    env: CompileEnvironment,
) -> frozenset[tuple[tuple[int, int, int, int], ...]]:
    """Return exact worklist signatures eligible for a target-specific override."""
    if env.settings.disable_autotuner_heuristics:
        return frozenset()
    policy = get_grouped_worklist_target_policy(
        _tcgen05_grouped_worklist_hardware_identity(env)
    )
    return policy.reviewed_worklist_rows()


class CuteTcgen05GroupedWorklistHeuristic(AutotunerHeuristic):
    """Rank grouped-worklist configs for validated Blackwell products.

    B200 uses the generic structural ranking. GB300 prepends a target-specific
    primary only for an exact measured worklist; other rows retain the generic
    rank-0 while live autotuning receives the complete legal seed set.
    """

    name = "cute_tcgen05_grouped_worklist"
    backend = "cute"
    promote_seed_to_default = True
    PROMOTE_TARGETS = (("cuda", "sm100"), ("cuda", "sm103"))
    CACHE_NAMED_TARGETS = _TCGEN05_GROUPED_TARGET_IDENTITIES
    CACHE_SPECIALIZATION_FACTS = frozenset({"config_num_sm", "input_tensor_metadata"})

    @classmethod
    def register_facts(
        cls, env: CompileEnvironment, device_ir: DeviceIR
    ) -> frozenset[CompilerHeuristicSpecializationFact]:
        """Record grouped SMEM facts independently of seed generation.

        Grouped semantics are discovered from DeviceIR rather than a user
        annotation. Publish seed specialization even when an empty first
        binding cannot emit seeds, and input specialization when heuristics are
        disabled but correctness facts still depend on runtime metadata.
        """
        spec = env.config_spec
        fact = _tcgen05_grouped_worklist_structural_fact(env)
        if fact is None:
            return frozenset()
        from ..cute.cute_mma import analyze_tcgen05_grouped_worklist

        analysis = analyze_tcgen05_grouped_worklist(
            env,
            device_ir,
            fact,
        )
        if analysis is None:
            return frozenset()
        # Explicit configs may compile outside the ordinary sampler's block
        # domains. Keep their semantic/codegen support separate from whether
        # this binding can declare an automatic coverage carrier.
        spec._cute_tcgen05_config.grouped_full_coverage_supported = (
            analysis.full_coverage_supported
            and spec.target_device_capability == (10, 0)
        )
        spec._cute_tcgen05_config.grouped_row_union_supported = (
            analysis.dense_row_union_supported
            and spec.target_device_capability == (10, 0)
        )
        spec._cute_tcgen05_config.grouped_row_union_cluster4_supported = (
            analysis.dense_row_union_cluster4_supported
            and spec.target_device_capability == (10, 0)
            and CuteTcgen05Config.per_cta_smem_capacity_bytes(env.device)
            >= TRANSPOSED.shared_upper_bound
        )
        spec._cute_tcgen05_config.grouped_row_union_paired_clc_supported = (
            analysis.dense_row_union_paired_clc_supported
            and spec.target_device_capability == (10, 0)
            and CuteTcgen05Config.per_cta_smem_capacity_bytes(env.device)
            >= PAIRED_CLC.shared_upper_bound
        )
        spec._cute_tcgen05_config.grouped_row_union_multi_resident_supported = (
            spec._cute_tcgen05_config.grouped_row_union_supported
            and resident_ctas_supported(
                2, CuteTcgen05Config.per_cta_smem_capacity_bytes(env.device)
            )
        )
        seed_facts = analysis.seed_facts
        if analysis.input_kind == "external_worklist":
            from ..cute.grouped_worklist import (
                register_tcgen05_grouped_worklist_runtime_specialization,
            )

            register_tcgen05_grouped_worklist_runtime_specialization(
                env,
                analysis.metadata_tensor,
                grouped_tensor=analysis.grouped_tensor,
                packed_tensor=analysis.packed_tensor,
                reviewed_rows=_tcgen05_grouped_worklist_reviewed_rows(env),
            )
        if seed_facts.groups_hint > 0:
            spec.register_cute_tcgen05_grouped_worklist_smem_facts(
                group_count=seed_facts.groups_hint,
                device_split_sizes=seed_facts.device_split_sizes,
            )
        # A coordinate without any carrier would perturb the old random domain
        # even when additive coverage has no declaration. Share the complete
        # proposal predicate with the declaration builder, including live block
        # domains. Final lowering independently checks guarded runtime metadata.
        spec._cute_tcgen05_config.grouped_full_coverage_eligible = (
            _grouped_full_coverage_carrier(env, device_ir) is not None
            or _grouped_full_coverage_carrier(env, device_ir, block_k=128) is not None
        )
        spec._cute_tcgen05_config.grouped_row_union_eligible = (
            grouped_row_union_carrier(env, device_ir) is not None
        )
        spec._cute_tcgen05_config.grouped_row_union_cluster4_eligible = (
            grouped_row_union_cluster4_carrier(env, device_ir) is not None
        )
        spec._cute_tcgen05_config.grouped_row_union_paired_clc_eligible = (
            grouped_row_union_paired_clc_carrier(env, device_ir) is not None
        )
        if env.settings.disable_autotuner_heuristics:
            return frozenset({"input_tensor_metadata"})
        return cls.CACHE_SPECIALIZATION_FACTS

    @classmethod
    def _eligible_inputs(
        cls,
        env: CompileEnvironment,
        device_ir: DeviceIR,
    ) -> tuple[MatmulFact, Tcgen05GroupedWorklistAnalysis] | None:
        spec = env.config_spec
        fact = _tcgen05_grouped_worklist_fact(env)
        if (
            fact is None
            or (fact.static_n is not None and fact.static_n % 32 != 0)
            or spec.target_device_capability is None
            or f"sm{spec.target_device_capability[0]}{spec.target_device_capability[1]}"
            not in _TCGEN05_GROUPED_SUPPORTED_CAPABILITIES
            or not _block_size_value_reachable(spec, 0, 256)
            or not _block_size_value_reachable(spec, 1, 128)
            or not any(
                _block_size_value_reachable(spec, 2, block_k)
                for block_k in TCGEN05_GROUPED_WORKLIST_BLOCK_K_CHOICES
            )
        ):
            return None
        from ..cute.cute_mma import analyze_tcgen05_grouped_worklist

        analysis = analyze_tcgen05_grouped_worklist(env, device_ir, fact)
        if (
            analysis is None
            or min(
                analysis.seed_facts.groups_hint,
                analysis.seed_facts.packed_m_hint,
                analysis.seed_facts.n_hint,
                analysis.seed_facts.k_hint,
            )
            <= 0
            or analysis.seed_facts.n_hint % 32 != 0
        ):
            return None
        if not tcgen05_runtime_n_ptx_compatible():
            warn_tcgen05_runtime_n_ptx_fallback()
            return None
        return fact, analysis

    @classmethod
    def _seed_configs(
        cls,
        env: CompileEnvironment,
        device_ir: DeviceIR,
    ) -> list[Config]:
        eligible = cls._eligible_inputs(env, device_ir)
        if eligible is None:
            return []
        fact, analysis = eligible
        spec = env.config_spec
        seed_facts = analysis.seed_facts
        source_m_tiles, reviewed_rows = _tcgen05_grouped_worklist_source_analysis(
            env, analysis
        )
        if not source_m_tiles:
            return []
        families: list[list[Config]] = []
        target_policy = get_grouped_worklist_target_policy(
            None
            if seed_facts.device_split_sizes
            else _tcgen05_grouped_worklist_hardware_identity(env)
        )
        preferred_target_seed: Config | None = None
        for source_m_tile in source_m_tiles:
            # ``packed_m_hint`` remains the exact compiler fact. Seed selection
            # only needs a tile-wave estimate, so round this local ranking input
            # upward. Runtime/codegen validation never consumes the rounded value.
            ranking_quantum = (
                seed_facts.groups_hint * source_m_tile
                if seed_facts.device_split_sizes
                else source_m_tile
            )
            ranking_packed_m = (
                (seed_facts.packed_m_hint + ranking_quantum - 1) // ranking_quantum
            ) * ranking_quantum
            family, family_target_seed = _tcgen05_grouped_worklist_seed_family(
                groups=seed_facts.groups_hint,
                packed_m=ranking_packed_m,
                n=seed_facts.n_hint,
                k=seed_facts.k_hint,
                b_major=seed_facts.b_major,
                source_m_tile=source_m_tile,
                num_sm=spec.num_sm,
                target_policy=target_policy,
                worklist_rows=reviewed_rows,
            )
            if seed_facts.device_split_sizes:
                # Device split-size kernels derive group rows on device and are
                # supported only by the scheduler-mailbox family. Convert direct
                # seeds rather than dropping useful BK/reservation variants;
                # panel swizzles and CLC have no mailbox equivalent.
                mailbox_family: list[Config] = []
                for config in family:
                    values = dict(config.config)
                    l2_swizzle_size = values.get(
                        TCGEN05_L2_SWIZZLE_SIZE_CONFIG_KEY,
                        1,
                    )
                    if values.get(
                        TCGEN05_PERSISTENCE_MODEL_CONFIG_KEY
                    ) == Tcgen05PersistenceModel.CLC_PERSISTENT.value or (
                        type(l2_swizzle_size) is int and l2_swizzle_size > 1
                    ):
                        continue
                    values.pop(TCGEN05_GROUPED_RUNTIME_DIRECT_CONFIG_KEY, None)
                    mailbox_family.append(Config.from_dict(values))
                if source_m_tile == TCGEN05_GROUPED_WORKLIST_SMALL_SOURCE_M_TILE:
                    # Consumer registers are seed-only. Keep the existing BK64
                    # mailbox witness inside the bounded family interleave.
                    mailbox_family.insert(
                        0,
                        _tcgen05_grouped_worklist_config(
                            source_m_tile, 64, 7, 240, runtime_direct=False
                        ),
                    )
                family = dedupe_configs(mailbox_family)
            family = [
                config
                for config in family
                if seed_facts.k_hint
                % cast("list[int]", config.config["block_sizes"])[2]
                == 0
            ]
            family = _filter_reachable_block_size_configs(spec, family)
            if (
                preferred_target_seed is None
                and family_target_seed is not None
                and family_target_seed in family
            ):
                preferred_target_seed = family_target_seed
            families.append(family)
        seeds = _bounded_grouped_worklist_seed_families(
            families,
            preferred_config=preferred_target_seed,
        )
        if seed_facts.device_split_sizes:
            seeds = dedupe_configs(
                [
                    *seeds,
                    *_tcgen05_grouped_output_ring_seeds(
                        [
                            *seeds,
                            *(config for family in families for config in family),
                        ],
                        group_count=seed_facts.groups_hint,
                        dtype_bytes=fact.lhs_dtype.itemsize,
                        capacity_bytes=CuteTcgen05Config.per_cta_smem_capacity_bytes(
                            env.device
                        ),
                    ),
                ]
            )
        return seeds

    @classmethod
    def should_promote(cls, env: CompileEnvironment) -> bool:
        fact = _tcgen05_grouped_worklist_fact(env)
        return (
            tcgen05_runtime_n_ptx_compatible()
            and fact is not None
            and fact.static_k is not None
            and super().should_promote(env)
        )

    @classmethod
    def is_eligible(cls, env: CompileEnvironment, device_ir: DeviceIR) -> bool:
        return cls._eligible_inputs(env, device_ir) is not None

    @classmethod
    def get_seed_config(
        cls, env: CompileEnvironment, device_ir: DeviceIR
    ) -> Config | None:
        configs = cls._seed_configs(env, device_ir)
        return configs[0] if configs else None

    @classmethod
    def get_seed_configs(
        cls, env: CompileEnvironment, device_ir: DeviceIR
    ) -> list[Config] | None:
        return cls._seed_configs(env, device_ir)


def grouped_row_union_carrier(
    env: CompileEnvironment, device_ir: DeviceIR
) -> Config | None:
    """One ordinary dense carrier, without grouped scheduler requirements.

    Input metadata only proposes the seed. Codegen repeats the complete
    semantic, allocation, typed-index and layout proof under shape guards.
    """
    spec = env.config_spec
    if not spec._cute_tcgen05_config.grouped_row_union_supported:
        return None
    fact = _tcgen05_grouped_worklist_structural_fact(env)
    if fact is None:
        return None
    from ..cute.cute_mma import analyze_tcgen05_grouped_worklist

    analysis = analyze_tcgen05_grouped_worklist(env, device_ir, fact)
    if analysis is None or not analysis.dense_row_union_supported:
        return None
    hints = analysis.seed_facts
    if not row_union_index_domain(
        hints.groups_hint, hints.packed_m_hint, hints.n_hint, hints.k_hint
    ):
        return None
    blocks = spec._tcgen05_matmul_seed_block_sizes(bm=128, bn=64, bk=128)
    if blocks is None:
        return None
    # The existing per-CTA budget excludes pipeline/barrier overhead. Only the
    # two ordinary BF16 A/B rings occupy bulk SMEM; output uses SIMT stores.
    if (
        CuteTcgen05Config.per_cta_smem_budget_bytes(env.device)
        < 2 * (128 + 64) * 128 * 2
    ):
        return None
    carrier = Config.from_dict(
        {
            "block_sizes": blocks,
            "loop_orders": _seq_config_list(spec.loop_orders, {}),
            "l2_groupings": _seq_config_list(
                spec.l2_groupings, {item.block_id: 1 for item in spec.l2_groupings}
            ),
            "pid_type": "persistent_interleaved",
            "tcgen05_cluster_m": 1,
            "tcgen05_cluster_n": 1,
            "tcgen05_ab_stages": 2,
            "tcgen05_acc_stages": 2,
            "tcgen05_c_stages": 2,
            "tcgen05_num_epi_warps": 4,
            "tcgen05_strategy": "role_local_monolithic",
            "tcgen05_persistence_model": "static_persistent",
        }
    )
    return carrier if _filter_reachable_block_size_configs(spec, [carrier]) else None


def grouped_row_union_cluster4_carrier(
    env: CompileEnvironment, device_ir: DeviceIR
) -> Config | None:
    """A coherent physical schedule, appended after the existing carriers."""
    return _grouped_row_union_physical_carrier(env, TRANSPOSED_SCHEDULE)


def grouped_row_union_paired_clc_carrier(
    env: CompileEnvironment, device_ir: DeviceIR
) -> Config | None:
    return _grouped_row_union_physical_carrier(env, PAIRED_CLC_SCHEDULE)


def _grouped_row_union_physical_carrier(
    env: CompileEnvironment, schedule: str
) -> Config | None:
    spec = env.config_spec
    if not spec._cute_tcgen05_config.row_union_profile_supported(schedule):
        return None
    blocks = spec._tcgen05_matmul_seed_block_sizes(bm=128, bn=64, bk=128)
    if blocks is None:
        return None
    carrier = Config.from_dict(
        {
            "block_sizes": blocks,
            "loop_orders": _seq_config_list(spec.loop_orders, {}),
            "l2_groupings": _seq_config_list(
                spec.l2_groupings, {item.block_id: 1 for item in spec.l2_groupings}
            ),
            "pid_type": "persistent_interleaved",
            "tcgen05_cluster_m": 1,
            "tcgen05_cluster_n": 1,
            "tcgen05_ab_stages": 2,
            "tcgen05_acc_stages": 2,
            "tcgen05_c_stages": 2,
            "tcgen05_num_epi_warps": 4,
            "tcgen05_strategy": "role_local_monolithic",
            "tcgen05_persistence_model": "static_persistent",
            "tcgen05_grouped_dense_row_union": True,
            GROUPED_ROW_UNION_SCHEDULE_KEY: schedule,
        }
    )
    return carrier if _filter_reachable_block_size_configs(spec, [carrier]) else None


def _grouped_full_coverage_carrier(
    env: CompileEnvironment,
    device_ir: DeviceIR,
    *,
    block_k: int = 64,
    source_m_tile: int = 32,
) -> Config | None:
    """One shared predicate for the optional domain and its coverage carrier."""
    spec = env.config_spec
    profile = next(
        (profile for profile in FULL_COVERAGE_PIPELINES if profile[0] == block_k), None
    )
    if profile is None:
        return None
    _, ab_stages, consumer_regs = profile
    if not full_coverage_pipeline_supported(
        block_k, ab_stages, consumer_regs, source_m_tile=source_m_tile
    ):
        return None
    if spec.target_device_capability != (10, 0):
        return None
    eligible = CuteTcgen05GroupedWorklistHeuristic._eligible_inputs(env, device_ir)
    if eligible is None:
        return None
    _fact, analysis = eligible
    hints = analysis.seed_facts
    if not analysis.full_coverage_supported or not full_coverage_index_domain(
        hints.groups_hint,
        hints.packed_m_hint,
        hints.n_hint,
        hints.k_hint,
        source_m_tile,
        128,
        block_k,
    ):
        return None
    if block_k == 128 and full_coverage_smem_upper_bound(
        hints.groups_hint, block_k, ab_stages, source_m_tile=source_m_tile
    ) > CuteTcgen05Config.per_cta_smem_capacity_bytes(env.device):
        return None
    carrier = _tcgen05_grouped_worklist_config(
        source_m_tile,
        block_k,
        ab_stages,
        consumer_regs,
        runtime_direct=False,
        l2_swizzle_size=1,
    )
    if block_k == 128:
        # Reuse the ordinary general worklist reservation lattice. This is a
        # coherent pipeline carrier, not a shape-specific scheduler selection.
        carrier.config[TCGEN05_GROUPED_STATIC_RESERVED_SMS_CONFIG_KEY] = (
            _tcgen05_grouped_scaled_reserved_sms(spec.num_sm, 32)
        )
    if not _filter_reachable_block_size_configs(spec, [carrier]):
        return None
    # TCGen role and AB-stage fields fully specify this carrier. The generic
    # warp/stage aliases are absent from its flat serializer; omit only those
    # redundant aliases from this new declaration, leaving legacy seeds intact.
    carrier.config.pop("num_stages")
    carrier.config.pop("num_warps")
    return carrier


def grouped_full_coverage_configs(
    env: CompileEnvironment, device_ir: DeviceIR, *, block_k: int = 64
) -> list[Config]:
    """Return independent carrier/witness configs for additive compiler coverage.

    The generic coverage facility owns population assembly and explicit override
    handling. These records never enter the capped legacy seed family. Hints
    restrict proposal generation only; final lowering rechecks guarded metadata.
    """
    if not env.config_spec._cute_tcgen05_config.grouped_full_coverage_eligible:
        return []
    carrier = _grouped_full_coverage_carrier(env, device_ir, block_k=block_k)
    if carrier is None:
        return []
    dense = Config.from_dict(
        deepcopy(carrier.config)
        | {
            TCGEN05_GROUPED_FULL_COVERAGE_CONFIG_KEY: TCGEN05_GROUPED_FULL_COVERAGE_DENSE
        }
    )
    return [carrier, dense]


class CuteTcgen05GroupedSource64Heuristic(AutotunerHeuristic):
    """Add one larger ONE tile without replacing existing grouped seeds."""

    name = "cute_tcgen05_grouped_source64"
    backend = "cute"
    CACHE_SPECIALIZATION_FACTS = frozenset({"config_num_sm", "input_tensor_metadata"})

    @classmethod
    def is_eligible(cls, env: CompileEnvironment, device_ir: DeviceIR) -> bool:
        return cls.get_seed_config(env, device_ir) is not None

    @classmethod
    def get_seed_config(
        cls, env: CompileEnvironment, device_ir: DeviceIR
    ) -> Config | None:
        carrier = _grouped_full_coverage_carrier(
            env, device_ir, block_k=128, source_m_tile=64
        )
        if carrier is not None:
            carrier.config[TCGEN05_GROUPED_FULL_COVERAGE_CONFIG_KEY] = (
                TCGEN05_GROUPED_FULL_COVERAGE_DENSE_LOCAL
            )
        return carrier


class CuteTcgen05GroupedStaticCommonKHeuristic(AutotunerHeuristic):
    """Seed grouped-static configs for common K tails without partial TMA."""

    name = "cute_tcgen05_grouped_static_common_k"
    backend = "cute"

    @classmethod
    def is_eligible(cls, env: CompileEnvironment, device_ir: DeviceIR) -> bool:
        from ..cute.cute_mma import tcgen05_grouped_static_seed_has_common_k_proof

        fact = _tcgen05_grouped_static_common_k_fact(env)
        return (
            fact is not None
            and _tcgen05_grouped_seed_grid_is_valid(device_ir, fact)
            and tcgen05_grouped_static_seed_has_common_k_proof(env, device_ir, fact)
        )

    @classmethod
    def get_seed_config(
        cls, env: CompileEnvironment, device_ir: DeviceIR
    ) -> Config | None:
        fact = _tcgen05_grouped_static_common_k_fact(env)
        if fact is None:
            return None
        static_k = cast("int", fact.static_k)
        bk = _tcgen05_grouped_static_common_k_block_k(static_k)
        if bk is None:
            return None
        config = _tcgen05_grouped_seed_config(bk)
        if (
            static_k >= 3 * bk
            and static_k % bk == 0
            and env.config_spec._tcgen05_ab_stages_three_fits(
                bm=128,
                bn=64,
                bk=bk,
                cluster_m=1,
            )
        ):
            config.config["tcgen05_ab_stages"] = 3
        return config


class CuteTcgen05GroupedDynamicBk64Heuristic(AutotunerHeuristic):
    """Seed the proven BK64 dynamic TensorMap grouped-static config.

    This is intentionally narrow: it only fires for one tcgen05 FP16/BF16
    rank-3 RHS grouped-NT matmul whose graph proves the exact per-group
    ``k_sizes[safe_group]`` mask on both A and grouped B operands. The dynamic
    TensorMap flag stays seed-only and is not exposed as a broad random-search
    knob.
    """

    name = "cute_tcgen05_grouped_dynamic_bk64"
    backend = "cute"

    @classmethod
    def is_eligible(cls, env: CompileEnvironment, device_ir: DeviceIR) -> bool:
        from ..cute.cute_mma import tcgen05_grouped_dynamic_bk64_seed_has_exact_k_proof

        fact = _tcgen05_grouped_dynamic_bk64_fact(env)
        return (
            fact is not None
            and _tcgen05_grouped_seed_grid_is_valid(device_ir, fact)
            and tcgen05_grouped_dynamic_bk64_seed_has_exact_k_proof(
                env,
                device_ir,
                fact,
            )
        )

    @classmethod
    def get_seed_config(
        cls, env: CompileEnvironment, device_ir: DeviceIR
    ) -> Config | None:
        fact = _tcgen05_grouped_dynamic_bk64_fact(env)
        if fact is None:
            return None
        config = _tcgen05_grouped_seed_config(64)
        config.config[TCGEN05_GROUPED_MODE_CONFIG_KEY] = TCGEN05_GROUPED_MODE_DYNAMIC
        config.config[TCGEN05_GROUPED_STATIC_RESERVED_SMS_CONFIG_KEY] = 3
        config.config["tcgen05_ab_stages"] = TCGEN05_GROUPED_DYNAMIC_AB4_STAGE
        return config


class CuteChunkRecurrenceHeuristic(AutotunerHeuristic):
    """Expose legal BT16 recurrence schedules and register caps."""

    name = "cute_chunk_recurrence"
    backend = "cute"
    promote_seed_to_default = True
    PROMOTE_TARGETS = (("cuda", "sm100"), ("cuda", "sm103"))
    CACHE_SPECIALIZATION_FACTS = frozenset({"config_num_sm", "input_tensor_metadata"})

    @classmethod
    def register_facts(
        cls, env: CompileEnvironment, device_ir: DeviceIR
    ) -> frozenset[CompilerHeuristicSpecializationFact]:
        from ..cute.chunk_recurrence import _select_sm100_dv_partitions
        from ..cute.chunk_recurrence import detect_chunk_recurrence_search_geometry

        geometry = detect_chunk_recurrence_search_geometry(device_ir.graphs)
        capability = env.config_spec.target_device_capability
        if geometry is None or capability is None or capability[0] != 10:
            return frozenset()
        preferred = _select_sm100_dv_partitions(
            total_chunks=geometry.total_chunks,
            sequences=geometry.sequences,
            heads=geometry.heads,
            num_sm=env.config_spec.num_sm,
        )
        env.config_spec.enable_cute_chunk_recurrence_search(
            preferred_partitions=preferred
        )
        return cls.CACHE_SPECIALIZATION_FACTS

    @classmethod
    def is_eligible(cls, env: CompileEnvironment, device_ir: DeviceIR) -> bool:
        return (
            env.config_spec.cute_chunk_recurrence_dv_partitions is not None
            and env.config_spec.cute_chunk_recurrence_register_cap is not None
        )

    @classmethod
    def get_seed_configs(
        cls, env: CompileEnvironment, device_ir: DeviceIR
    ) -> list[Config] | None:
        fragment = env.config_spec.cute_chunk_recurrence_dv_partitions
        register_cap_fragment = env.config_spec.cute_chunk_recurrence_register_cap
        if fragment is None or register_cap_fragment is None:
            return None
        register_caps = (
            72,
            *(
                cap
                for cap in register_cap_fragment.choices
                if cap is not None and cap != 72
            ),
            *((None,) if None in register_cap_fragment.choices else ()),
        )
        return [
            Config.from_dict(
                {
                    CUTE_CHUNK_RECURRENCE_DV_PARTITIONS_KEY: partitions,
                    CUTE_CHUNK_RECURRENCE_REGISTER_CAP_KEY: register_cap,
                }
            )
            for partitions in fragment.choices
            for register_cap in register_caps
            if _cute_chunk_recurrence_config_is_safe(partitions, register_cap)
        ]

    @classmethod
    def get_seed_config(
        cls, env: CompileEnvironment, device_ir: DeviceIR
    ) -> Config | None:
        seeds = cls.get_seed_configs(env, device_ir)
        return seeds[0] if seeds else None


class CuteGdnRecurrenceHeuristic(AutotunerHeuristic):
    """Seed the tcgen05 schedule of the gated-delta-rule chunk recurrence.

    The whole-root ``gdn_recurrence`` planner fires only for the dstate tiles
    its geometry admits (a 128-row TMEM tile, replicated for narrower tiles),
    so the seeds pin
    ``block_sizes`` to the preferred tile and its half to make sure the
    autotuner measures the tensor-core path.  The TMA ring depth and the
    epilogue warp count are real trade-offs and stay searchable knobs: the
    depth domain is the union over every tile the planner lowers, including
    the wider tiles the ``block_sizes`` search reaches for a non-power-of-two
    dstate, and ``normalize`` re-validates it per tile.  Every seed is legal
    as written, and no searched config reaches codegen with a depth its tile
    cannot hold.  The dstate tile's own floor is raised to the smallest
    admitted tile: the SM100 dot minimum leaves it at one row, and no lowering
    of this kernel compiles a narrower tile, so the autotuner must not sample
    one.
    """

    name = "cute_gdn_recurrence"
    backend = "cute"
    promote_seed_to_default = True
    PROMOTE_TARGETS = (("cuda", "sm100"), ("cuda", "sm103"))
    CACHE_SPECIALIZATION_FACTS = frozenset({"input_tensor_metadata"})

    @classmethod
    def _geometry(
        cls, env: CompileEnvironment, device_ir: DeviceIR
    ) -> GdnRecurrenceGeometry | None:
        from ..cute.gdn_recurrence import detect_gdn_recurrence_search_geometry

        capability = env.config_spec.target_device_capability
        host_function = device_ir.host_function
        if capability is None or capability[0] != 10 or host_function is None:
            return None
        with host_function:
            return detect_gdn_recurrence_search_geometry(device_ir.graphs)

    @classmethod
    def register_facts(
        cls, env: CompileEnvironment, device_ir: DeviceIR
    ) -> frozenset[CompilerHeuristicSpecializationFact]:
        from ..cute.gdn_recurrence import gdn_recurrence_mma_m_choices_by_tile
        from ..cute.gdn_recurrence import gdn_recurrence_stage_choices_by_tile
        from ..cute.gdn_recurrence import gdn_recurrence_token_group_choices_by_tile
        from ..cute.gdn_recurrence_geometry import GDN_ADMITTED_BLOCK_V
        from ..cute.gdn_recurrence_geometry import gdn_epilogue_warp_choices

        geometry = cls._geometry(env, device_ir)
        if geometry is None:
            return frozenset()
        # Both dots of this kernel need a 16-row dstate tile in every lowering
        # (tensor-core or SIMT), but the SM100 dot minimum leaves the tile's
        # spec at one row: raise the hard floor so no sampled config can fail.
        env.config_spec.block_sizes.block_id_lookup(geometry.value_block_id).update_min(
            GDN_ADMITTED_BLOCK_V[-1]
        )
        env.config_spec.enable_cute_gdn_recurrence_search(
            value_block_id=geometry.value_block_id,
            stage_choices_by_tile=gdn_recurrence_stage_choices_by_tile(geometry),
            epilogue_warp_choices=gdn_epilogue_warp_choices(
                geometry.chunk, geometry.dhead
            ),
            mma_m_choices_by_tile=gdn_recurrence_mma_m_choices_by_tile(geometry),
            token_group_choices_by_tile=gdn_recurrence_token_group_choices_by_tile(
                geometry
            ),
        )
        return cls.CACHE_SPECIALIZATION_FACTS

    @classmethod
    def is_eligible(cls, env: CompileEnvironment, device_ir: DeviceIR) -> bool:
        return (
            env.config_spec.cute_gdn_recurrence_stages is not None
            and env.config_spec.cute_gdn_recurrence_epilogue_warps is not None
            and env.config_spec.cute_gdn_recurrence_token_groups is not None
            and env.config_spec.cute_gdn_recurrence_mma_m is not None
        )

    @classmethod
    def get_seed_configs(
        cls, env: CompileEnvironment, device_ir: DeviceIR
    ) -> list[Config] | None:
        from ..cute.gdn_recurrence import gdn_recurrence_warp_choices
        from ..cute.gdn_recurrence import gdn_seed_block_sizes
        from ..cute.gdn_recurrence_geometry import gdn_mma_m_choices
        from ..cute.gdn_recurrence_geometry import gdn_stage_choices
        from ..cute.gdn_recurrence_geometry import gdn_token_group_choices

        spec = env.config_spec
        if (
            spec.cute_gdn_recurrence_stages is None
            or spec.cute_gdn_recurrence_epilogue_warps is None
            or spec.cute_gdn_recurrence_token_groups is None
            or spec.cute_gdn_recurrence_mma_m is None
        ):
            return None
        geometry = cls._geometry(env, device_ir)
        if geometry is None:
            return None
        # The seed pins the whole block_sizes list, so it is only sound when
        # the dstate tile is the sole tunable tile of the kernel.
        if spec.block_sizes.valid_block_ids() != [geometry.value_block_id]:
            return None
        seeds: list[Config] = []
        # Seed the preferred dstate tile and its half; the remaining admitted
        # tiles stay reachable through the ordinary block_sizes search.  Each
        # seed carries the preferred tcgen05 M of its tile and warps (M = 64
        # for tiles of at most 64 rows) and that M's preferred depths.
        for block_v in gdn_seed_block_sizes(geometry):
            for warps in gdn_recurrence_warp_choices(geometry, block_v):
                mma_m = gdn_mma_m_choices(
                    geometry.chunk, geometry.dhead, block_v, warps
                )[0]
                stage_choices = gdn_stage_choices(
                    geometry.chunk, geometry.dhead, block_v, mma_m
                )
                for stages in stage_choices[:2]:
                    seeds.append(
                        Config.from_dict(
                            {
                                "block_sizes": [block_v],
                                CUTE_GDN_RECURRENCE_STAGES_KEY: stages,
                                CUTE_GDN_RECURRENCE_EPILOGUE_WARPS_KEY: warps,
                                CUTE_GDN_RECURRENCE_TOKEN_GROUPS_KEY: (
                                    gdn_token_group_choices(
                                        geometry.chunk, block_v, warps, mma_m
                                    )[0]
                                ),
                                CUTE_GDN_RECURRENCE_MMA_M_KEY: mma_m,
                            }
                        )
                    )
        return seeds or None

    @classmethod
    def get_seed_config(
        cls, env: CompileEnvironment, device_ir: DeviceIR
    ) -> Config | None:
        seeds = cls.get_seed_configs(env, device_ir)
        return seeds[0] if seeds else None


class CuteTopKHeuristic(AutotunerHeuristic):
    """Seed subgroup geometry from bounded per-lane selection fragments."""

    name = "cute_topk"
    backend = "cute"

    @staticmethod
    def _supports_float32_bit_keys(dtype: torch.dtype, n: int) -> bool:
        if dtype not in (torch.float16, torch.bfloat16):
            return False
        index_bits = (n - 1).bit_length()
        index_mask = (1 << index_bits) - 1
        min_key = -(32767 << index_bits)
        max_key = (32767 << index_bits) | index_mask
        # Match the emitter's biased-key proof: real keys are positive normal
        # finite Float32 values, leaving zero below every real key for padding.
        return 0x40000000 + min_key >= 0x00800000 and 0x40000000 + max_key <= 0x7F7FFFFF

    @classmethod
    def register_facts(
        cls, env: CompileEnvironment, device_ir: DeviceIR
    ) -> frozenset[CompilerHeuristicSpecializationFact]:
        from ..cute.memory_ops import register_cute_tensor_alias_specializations
        from ..cute.topk import match_topk_root
        from ..cute.topk import topk_tensors_are_proven_disjoint

        host_function = device_ir.host_function
        if host_function is None or len(device_ir.root_ids) != 1:
            return frozenset()
        with host_function:
            plan = match_topk_root(
                device_ir.graphs,
                noncanonical_block_ids=device_ir.noncanonical_task_origin_block_ids,
            )
            # The structural match precedes real-argument availability. Wait
            # until binding can prove disjoint storage before freezing generic
            # tiling; the registered alias classifier guards bound-cache reuse.
            if plan is not None:
                # Singleton top-k has no reduction dimension, so the reduction
                # registration pass may not have installed its alias facts.
                register_cute_tensor_alias_specializations(env)
                if topk_tensors_are_proven_disjoint(plan, env, allow_unbound=True):
                    env.config_spec.enable_cute_topk_search(plan.selection_dtype)
                    env.config_spec.cute_topk_coarse_keys_available = (
                        plan.selection_dtype == torch.float32
                        and 1 < plan.n <= (1 << 23)
                        and (1 << (plan.k - 1).bit_length()) <= plan.n
                    )
        return frozenset()

    @classmethod
    def is_eligible(cls, env: CompileEnvironment, device_ir: DeviceIR) -> bool:
        return env.config_spec.cute_topk_search_enabled

    @classmethod
    def get_seed_configs(
        cls, env: CompileEnvironment, device_ir: DeviceIR
    ) -> list[Config] | None:
        from ..cute.topk import match_topk_root
        from ..cute.topk import topk_tensors_are_proven_disjoint

        host_function = device_ir.host_function
        if host_function is None or len(device_ir.root_ids) != 1:
            return None
        with host_function:
            plan = match_topk_root(
                device_ir.graphs,
                noncanonical_block_ids=device_ir.noncanonical_task_origin_block_ids,
            )
            # A structural candidate can still fail the final runtime alias
            # proof. Do not seed its specialized schedule without that proof.
            if plan is None or not topk_tensors_are_proven_disjoint(plan, env):
                return None
        full_precision = plan.selection_dtype == torch.float32
        integer_key = "int64" if full_precision else "int32"
        padded_k = 1 << (plan.k - 1).bit_length()
        seeds = []
        # Retain the original register-pressure and occupancy candidates. All
        # seeds are search hints, not promoted defaults.
        for target, threads, value_mode, rank_mode, layout in (
            (32, 128, "decode", "ordinal", "replicated"),
            (64, 128, "decode", "signed", "replicated"),
            (128, 64, "gather", "signed", "replicated"),
            (32, 64, "decode", "ordinal", "distributed"),
        ):
            elements_per_lane = max(padded_k, target)
            required_lanes = (plan.n + elements_per_lane - 1) // elements_per_lane
            lanes = min(32, padded_k, 1 << (required_lanes - 1).bit_length())
            config = env.config_spec.default_config()
            config.config.update(
                cute_topk_lanes_per_row=lanes,
                cute_topk_rows_per_block=threads // lanes,
                cute_topk_vector_width=8,
                cute_topk_output_vector_width=4,
                cute_topk_value_mode=value_mode,
                cute_topk_key_dtype=integer_key,
                cute_topk_rank_mode=rank_mode,
                cute_topk_selection_layout=layout,
            )
            seeds.append(config)

        # Growing distributed fragments need not contain K keys in every lane.
        # Native floating-point comparisons provide a complementary replicated
        # schedule; their precision guard can fall back to integer keys.
        for target, layout, key_dtype in (
            (8, "distributed", "int32"),
            (16, "distributed", "int32"),
            (32, "replicated", "float32_native"),
            (64, "replicated", "float32_native"),
        ):
            distributed = layout == "distributed"
            elements_per_lane = target if distributed else max(padded_k, target)
            required_lanes = (plan.n + elements_per_lane - 1) // elements_per_lane
            lanes = min(
                32,
                32 if distributed else padded_k,
                1 << (required_lanes - 1).bit_length(),
            )
            per_lane = (plan.n + lanes - 1) // lanes
            input_vector = min(8, 1 << (per_lane.bit_length() - 1))
            config = env.config_spec.default_config()
            config.config.update(
                cute_topk_lanes_per_row=lanes,
                cute_topk_rows_per_block=128 // lanes,
                cute_topk_vector_width=input_vector,
                cute_topk_output_vector_width=4,
                cute_topk_value_mode="decode",
                cute_topk_key_dtype=integer_key if full_precision else key_dtype,
                cute_topk_rank_mode="ordinal",
                cute_topk_selection_layout=layout,
                cute_topk_sort_network="compact_pruned",
            )
            seeds.append(config)
        if full_precision:
            # Couple exact coarse-key recovery with value gathering at two bounded
            # register budgets. The existing full-precision seeds stay first.
            if env.config_spec.cute_topk_coarse_keys_available:
                for register_target in (16, 32):
                    required_lanes = (plan.n + register_target - 1) // register_target
                    lanes = min(32, 1 << (required_lanes - 1).bit_length())
                    per_lane = (plan.n + lanes - 1) // lanes
                    rows = 64 // lanes
                    if per_lane > register_target or (
                        rows
                        not in env.config_spec.cute_topk_choices[
                            "cute_topk_rows_per_block"
                        ]
                    ):
                        continue
                    config = env.config_spec.default_config()
                    config.config.update(
                        cute_topk_lanes_per_row=lanes,
                        cute_topk_rows_per_block=rows,
                        cute_topk_vector_width=min(8, 1 << (per_lane.bit_length() - 1)),
                        cute_topk_output_vector_width=1,
                        cute_topk_value_mode="gather",
                        cute_topk_key_dtype="int64",
                        cute_topk_rank_mode="ordinal",
                        cute_topk_selection_layout="distributed",
                        cute_topk_sort_network="compact_pruned",
                        cute_topk_key_encoder="dsl",
                        cute_topk_defer_value_gathers=False,
                        cute_topk_merge_schedule="sequential",
                        cute_topk_coarse_keys=True,
                        cute_topk_key_recovery="packed",
                    )
                    seeds.append(config)
            return dedupe_configs(seeds)
        # Replicated ordinal decoding can avoid irregular value gathers. Add
        # all encoder implementations at two bounded register-fragment sizes;
        # these remain unpromoted search hints with the ordinary merge default.
        for target in (32, 64):
            elements_per_lane = max(padded_k, target)
            required_lanes = (plan.n + elements_per_lane - 1) // elements_per_lane
            lanes = min(32, padded_k, 1 << (required_lanes - 1).bit_length())
            for encoder in ("dsl", "asm", "paired"):
                config = env.config_spec.default_config()
                config.config.update(
                    cute_topk_lanes_per_row=lanes,
                    cute_topk_rows_per_block=128 // lanes,
                    cute_topk_vector_width=8,
                    cute_topk_output_vector_width=4,
                    cute_topk_value_mode="decode",
                    cute_topk_key_dtype=integer_key,
                    cute_topk_rank_mode="ordinal",
                    cute_topk_selection_layout="replicated",
                    cute_topk_sort_network="compact_pruned",
                    cute_topk_key_encoder=encoder,
                    cute_topk_defer_value_gathers=True,
                )
                seeds.append(config)
        # Complement the existing integer/replicated hints with a bounded
        # distributed floating-key family at two occupancy budgets. Keep the
        # original seed order and promoted/default configuration unchanged.
        if cls._supports_float32_bit_keys(plan.selection_dtype, plan.n):
            for register_target in (32, 64):
                required_lanes = (plan.n + register_target - 1) // register_target
                lanes = min(32, 1 << (required_lanes - 1).bit_length())
                per_lane = (plan.n + lanes - 1) // lanes
                if per_lane > register_target:
                    continue
                input_vector = min(4, 1 << (per_lane.bit_length() - 1))
                output_vector = min(4, max(1, padded_k // lanes))
                for threads in (128, 256):
                    rows = threads // lanes
                    if (
                        rows
                        not in env.config_spec.cute_topk_choices[
                            "cute_topk_rows_per_block"
                        ]
                    ):
                        continue
                    config = env.config_spec.default_config()
                    config.config.update(
                        cute_topk_lanes_per_row=lanes,
                        cute_topk_rows_per_block=rows,
                        cute_topk_vector_width=input_vector,
                        cute_topk_output_vector_width=output_vector,
                        cute_topk_value_mode="decode",
                        cute_topk_key_dtype="float32_bits",
                        cute_topk_rank_mode="ordinal",
                        cute_topk_selection_layout="distributed",
                        cute_topk_sort_network="batcher",
                        cute_topk_key_encoder="paired",
                        cute_topk_defer_value_gathers=False,
                        cute_topk_merge_schedule="sequential",
                    )
                    seeds.append(config)
        # Keep scalar single-warp hints before paired-store two-warp hints.
        if plan.selection_dtype in (torch.float16, torch.bfloat16):
            for threads, output_width in ((32, 1), (64, 2)):
                for register_target in (32, 64):
                    required_lanes = (plan.n + register_target - 1) // register_target
                    lanes = min(32, 1 << (required_lanes - 1).bit_length())
                    per_lane = (plan.n + lanes - 1) // lanes
                    if per_lane > register_target:
                        continue
                    rows = threads // lanes
                    if (
                        rows
                        not in env.config_spec.cute_topk_choices[
                            "cute_topk_rows_per_block"
                        ]
                    ):
                        continue
                    config = env.config_spec.default_config()
                    config.config.update(
                        cute_topk_lanes_per_row=lanes,
                        cute_topk_rows_per_block=rows,
                        cute_topk_vector_width=min(8, 1 << (per_lane.bit_length() - 1)),
                        cute_topk_output_vector_width=min(
                            output_width, max(1, padded_k // lanes)
                        ),
                        cute_topk_value_mode="decode",
                        cute_topk_key_dtype="int32",
                        cute_topk_rank_mode="ordinal",
                        cute_topk_selection_layout="distributed",
                        cute_topk_sort_network="compact_pruned",
                        cute_topk_key_encoder="paired",
                        cute_topk_defer_value_gathers=False,
                        cute_topk_merge_schedule="balanced",
                    )
                    seeds.append(config)
            # Scalar stores complement the vector-output hints at the existing
            # register budgets and multi-warp occupancies. Keep these integer
            # schedules after the original seeds; they do not change defaults.
            for register_target in (32, 64):
                required_lanes = (plan.n + register_target - 1) // register_target
                lanes = min(32, 1 << (required_lanes - 1).bit_length())
                per_lane = (plan.n + lanes - 1) // lanes
                if per_lane > register_target:
                    continue
                for threads in (128, 256):
                    rows = threads // lanes
                    if (
                        rows
                        not in env.config_spec.cute_topk_choices[
                            "cute_topk_rows_per_block"
                        ]
                    ):
                        continue
                    config = env.config_spec.default_config()
                    config.config.update(
                        cute_topk_lanes_per_row=lanes,
                        cute_topk_rows_per_block=rows,
                        cute_topk_vector_width=min(4, 1 << (per_lane.bit_length() - 1)),
                        cute_topk_output_vector_width=1,
                        cute_topk_value_mode="decode",
                        cute_topk_key_dtype="int32",
                        cute_topk_rank_mode="ordinal",
                        cute_topk_selection_layout="distributed",
                        cute_topk_sort_network="batcher",
                        cute_topk_key_encoder="paired",
                        cute_topk_defer_value_gathers=False,
                        cute_topk_merge_schedule="sequential",
                    )
                    seeds.append(config)
            # Couple a larger distributed fragment with scalar output and the
            # compact balanced network. Keep all earlier search hints first.
            register_target = 128
            required_lanes = (plan.n + register_target - 1) // register_target
            lanes = min(32, 1 << (required_lanes - 1).bit_length())
            per_lane = (plan.n + lanes - 1) // lanes
            rows = 128 // lanes
            if 64 < per_lane <= register_target and (
                rows in env.config_spec.cute_topk_choices["cute_topk_rows_per_block"]
            ):
                config = env.config_spec.default_config()
                config.config.update(
                    cute_topk_lanes_per_row=lanes,
                    cute_topk_rows_per_block=rows,
                    cute_topk_vector_width=8,
                    cute_topk_output_vector_width=1,
                    cute_topk_value_mode="decode",
                    cute_topk_key_dtype="int32",
                    cute_topk_rank_mode="ordinal",
                    cute_topk_selection_layout="distributed",
                    cute_topk_sort_network="compact_pruned",
                    cute_topk_key_encoder="paired",
                    cute_topk_defer_value_gathers=False,
                    cute_topk_merge_schedule="balanced",
                )
                seeds.append(config)
        return dedupe_configs(seeds)

    @classmethod
    def get_seed_config(
        cls, env: CompileEnvironment, device_ir: DeviceIR
    ) -> Config | None:
        seeds = cls.get_seed_configs(env, device_ir)
        return seeds[0] if seeds else None


class CuteChunkPrepareHeuristic(AutotunerHeuristic):
    """Expose exact BT16 prepare schedules with a geometry-derived seed."""

    name = "cute_chunk_prepare"
    backend = "cute"
    promote_seed_to_default = True
    PROMOTE_TARGETS = (("cuda", "sm100"), ("cuda", "sm103"))
    CACHE_SPECIALIZATION_FACTS = frozenset({"config_num_sm", "input_tensor_metadata"})

    @classmethod
    def register_facts(
        cls, env: CompileEnvironment, device_ir: DeviceIR
    ) -> frozenset[CompilerHeuristicSpecializationFact]:
        from ..cute.chunk_prepare import preferred_chunk_prepare_schedule

        capability = env.config_spec.target_device_capability
        host_function = device_ir.host_function
        if capability is None or capability[0] != 10 or host_function is None:
            return frozenset()
        with host_function:
            preferred_schedule = preferred_chunk_prepare_schedule(
                device_ir.graphs,
                env=env,
                num_sm=env.config_spec.num_sm,
            )
        if preferred_schedule is None:
            return frozenset()
        env.config_spec.enable_cute_chunk_prepare_schedule_search(
            preferred_schedule=preferred_schedule
        )
        return cls.CACHE_SPECIALIZATION_FACTS

    @classmethod
    def is_eligible(cls, env: CompileEnvironment, device_ir: DeviceIR) -> bool:
        return env.config_spec.cute_chunk_prepare_schedule is not None

    @classmethod
    def get_seed_configs(
        cls, env: CompileEnvironment, device_ir: DeviceIR
    ) -> list[Config] | None:
        fragment = env.config_spec.cute_chunk_prepare_schedule
        if fragment is None:
            return None
        return [
            Config.from_dict({CUTE_CHUNK_PREPARE_SCHEDULE_KEY: schedule})
            for schedule in fragment.choices
        ]

    @classmethod
    def get_seed_config(
        cls, env: CompileEnvironment, device_ir: DeviceIR
    ) -> Config | None:
        seeds = cls.get_seed_configs(env, device_ir)
        return seeds[0] if seeds else None


class CuteFlashAttentionHeuristic(AutotunerHeuristic):
    """Seed ``block_sizes=[1, 128, 128]`` for detected flash attention.

    When ``HELION_CUTE_FLASH`` is on (the default), a dense online-softmax
    attention kernel at [tile_b=1, tile_m=128, tile_n=128], FP16/BF16, head_dim
    in {64, 128} lowers to the fused tcgen05 flash path
    (``cute_flash.codegen_attention_flash``) -- orders of magnitude faster than
    the scalar fallback. The flash detector fires at EXACTLY 128x128 tiles, so
    unless that config is in the autotuner population the fast path is never
    measured. This seed puts it in generation 0; the search still owns every
    other knob and benchmarks the seed against the rest, dropping it if the
    accuracy/compile check ever fails.
    """

    name = "cute_flash_attention"
    backend = "cute"

    @classmethod
    def is_eligible(cls, env: CompileEnvironment, device_ir: DeviceIR) -> bool:
        return env.config_spec.cute_flash_search_enabled

    @classmethod
    def get_seed_configs(
        cls, env: CompileEnvironment, device_ir: DeviceIR
    ) -> list[Config] | None:
        spec = env.config_spec
        if not spec.cute_flash_search_enabled:
            return None
        from ..cute.cute_flash import flash_attention_seed_configs

        assert spec._cute_flash_head_dim is not None
        assert spec._cute_flash_num_kv is not None
        common = {
            "num_bh": spec._cute_flash_num_bh,
            "num_sm": spec.num_sm,
            "tensor_4d_heads": spec._cute_flash_tensor_4d_heads,
            "dtype": spec._cute_flash_dtype,
            "is_causal": spec._cute_flash_is_causal,
            "has_kv_tile_pruning": spec._cute_flash_has_kv_tile_pruning,
            "requires_ws_overlap": spec._cute_flash_requires_ws_overlap,
            "small_biased_candidate": spec._cute_flash_small_biased_candidate,
            "tmem_rowmax_compatible": spec._cute_flash_tmem_rowmax_compatible,
            "causal_resident_compatible": spec._cute_flash_causal_resident_compatible,
            "supports_tensor_4d_tma": spec._cute_flash_supports_tensor_4d_tma,
            "has_row_epilogue": spec._cute_flash_has_row_epilogue,
            "has_score_modifiers": spec._cute_flash_has_score_modifiers,
            "target_device_capability": spec.target_device_capability,
            "block_size_targets": spec._cute_flash_block_size_target_list(),
            "plain_row_body": spec._cute_flash_plain_row_body,
            "score_modifier_kinds": spec._cute_flash_score_modifier_kinds,
            "device_sm_count": spec._cute_flash_device_sm_count,
            "kv_group": spec._cute_flash_kv_group,
            "fast_math": spec._cute_flash_fast_math,
        }
        seeds = spec._legalize_cute_flash_compiler_seeds(
            flash_attention_seed_configs(
                spec._cute_flash_head_dim,
                spec._cute_flash_num_kv,
                standard_dense_output=spec._cute_flash_standard_dense_output,
                standard_causal_output=spec._cute_flash_standard_causal_output,
                has_list_walk=spec._cute_flash_has_list_walk,
                flex_trivial_walk=spec._cute_flash_flex_trivial_walk,
                **common,
            )
        )
        if seeds:
            # Slow but valid flash seeds can exceed the normal subprocess
            # timing window. Retry once with three measured launches so a
            # transient timeout does not remove a structural family.
            spec.compiler_seed_timeout_retry_repetitions = 3
        return seeds

    @classmethod
    def get_seed_config(
        cls, env: CompileEnvironment, device_ir: DeviceIR
    ) -> Config | None:
        seeds = cls.get_seed_configs(env, device_ir)
        return seeds[0] if seeds else None


class CuteFlashGatedAttentionHeuristic(AutotunerHeuristic):
    """Seed the fused tile shape for detected gated (softmax-free) attention.

    The gated tcgen05 body (``cute_flash_gated``) fires only at 128x128 tiles,
    which ``enable_cute_flash_gated_search`` pins; the seeds put every legal
    K/V TMA ring depth into generation zero so the fused family is measured
    against the rest of the search.
    """

    name = "cute_flash_gated_attention"
    backend = "cute"

    @classmethod
    def is_eligible(cls, env: CompileEnvironment, device_ir: DeviceIR) -> bool:
        return env.config_spec.cute_flash_gated_search_enabled

    @classmethod
    def get_seed_configs(
        cls, env: CompileEnvironment, device_ir: DeviceIR
    ) -> list[Config] | None:
        seeds = env.config_spec.cute_flash_gated_seed_configs()
        return seeds or None

    @classmethod
    def get_seed_config(
        cls, env: CompileEnvironment, device_ir: DeviceIR
    ) -> Config | None:
        seeds = cls.get_seed_configs(env, device_ir)
        return seeds[0] if seeds else None


class CuteTcgen05ThreadLocalEpilogueHeuristic(AutotunerHeuristic):
    """Seed the one-CTA tile used by tcgen05 thread-local epilogues.

    The structural region analysis only decides whether this seed is useful.
    The exhaustive, per-config ownership proof remains authoritative for
    codegen, so planting the seed does not widen the accepted kernel surface.
    """

    name = "cute_tcgen05_thread_local_epilogue"
    backend = "cute"
    promote_seed_to_default = True

    @classmethod
    def get_seed_configs(
        cls, env: CompileEnvironment, device_ir: DeviceIR
    ) -> list[Config]:
        seed = cls.get_seed_config(env, device_ir)
        if seed is None:
            return []
        return [seed]

    @classmethod
    def is_eligible(cls, env: CompileEnvironment, device_ir: DeviceIR) -> bool:
        from ..cute.cute_mma import tcgen05_fragment_epilogue_has_unique_anchor
        from ..cute.cute_mma import tcgen05_fragment_epilogue_present

        spec = env.config_spec
        return (
            spec.cute_tcgen05_search_enabled
            and TCGEN05_TWO_CTA_SEED_PID_TYPE in spec.allowed_pid_types
            and tcgen05_fragment_epilogue_present(device_ir.graphs)
            and tcgen05_fragment_epilogue_has_unique_anchor(
                device_ir.graphs,
                device_ir=device_ir,
            )
        )

    @classmethod
    def get_seed_config(
        cls, env: CompileEnvironment, device_ir: DeviceIR
    ) -> Config | None:
        spec = env.config_spec
        fragments = spec._tcgen05_matmul_block_fragments()
        if fragments is None:
            return None
        bm_fragment, bn_fragment, bk_fragment = fragments

        def select(fragment: BlockSizeFragment, choices: tuple[int, ...]) -> int | None:
            return next(
                (value for value in choices if fragment.low <= value <= fragment.high),
                None,
            )

        bm = select(bm_fragment, (128,))
        bn = select(bn_fragment, (128, 64))
        bk = select(bk_fragment, (128, 64, 32, 16))
        if bm is None or bn is None or bk is None:
            return None
        block_sizes = spec._tcgen05_matmul_seed_block_sizes(
            bm=bm,
            bn=bn,
            bk=bk,
        )
        if block_sizes is None:
            return None
        return Config(
            block_sizes=block_sizes,
            num_stages=2,
            num_warps=8,
            pid_type=TCGEN05_TWO_CTA_SEED_PID_TYPE,
            tcgen05_cluster_m=1,
            tcgen05_cluster_n=1,
            tcgen05_ab_stages=2,
            tcgen05_acc_stages=2,
            tcgen05_c_stages=2,
            tcgen05_num_epi_warps=4,
        )


class CuteTcgen05ClusterM2Heuristic(AutotunerHeuristic):
    name = "cute_tcgen05_cluster_m2"
    backend = "cute"
    CACHE_SPECIALIZATION_FACTS = frozenset({"device_num_sm"})

    @classmethod
    def is_eligible(cls, env: CompileEnvironment, device_ir: DeviceIR) -> bool:
        spec = env.config_spec
        constraints = spec._tcgen05_cluster_m2_search_constraints
        if constraints is None or constraints.one_wave_only:
            # One-wave-only shapes seed their narrow tiles from the config
            # spec; the 256x256 two-CTA seed would idle most SMs there.
            return False
        if TCGEN05_TWO_CTA_SEED_PID_TYPE not in spec.allowed_pid_types:
            return False
        fragments = spec._tcgen05_matmul_block_fragments()
        if fragments is None:
            return False
        bm_fragment, bn_fragment, _ = fragments
        edge_k_tail_family = constraints.allow_edge_k_tail_family
        m_tile_reachable = (
            bm_fragment.low <= TCGEN05_TWO_CTA_BLOCK_M <= bm_fragment.high
            # The edge+K-tail surface keeps the flat M search capped below 256,
            # then normalization projects cluster_m=2 candidates to 256.
            or (edge_k_tail_family and bm_fragment.low <= TCGEN05_TWO_CTA_BLOCK_M)
        )
        n_tile_reachable = (
            bn_fragment.low <= TCGEN05_TWO_CTA_BLOCK_N <= bn_fragment.high
            or (edge_k_tail_family and bn_fragment.low <= TCGEN05_TWO_CTA_BLOCK_N)
        )
        full_tile_reachable = m_tile_reachable and n_tile_reachable
        # The fp8 small-grid family seeds the bm=128/bn=128 tile, which is
        # reachable on shapes (small M/N) where the bm=256 full tile is not.
        small_grid_reachable = (
            constraints.allow_fp8_small_grid
            and not edge_k_tail_family
            and cls._small_grid_tile_reachable(spec)
        )
        return (full_tile_reachable or small_grid_reachable) and cls._select_bk(
            env
        ) is not None

    @classmethod
    def get_seed_config(
        cls, env: CompileEnvironment, device_ir: DeviceIR
    ) -> Config | None:
        spec = env.config_spec
        bk = cls._select_bk(env)
        if bk is None:
            raise AssertionError(f"{cls.name} get_seed_config called while ineligible")

        constraints = spec._tcgen05_cluster_m2_search_constraints
        edge_k_tail_family = (
            constraints is not None and constraints.allow_edge_k_tail_family
        )
        fp8_small_grid_family = (
            constraints is not None
            and constraints.allow_fp8_small_grid
            and not edge_k_tail_family
            and cls._small_grid_tile_reachable(spec)
        )
        if fp8_small_grid_family:
            # Seed the bm=128 small-grid tile only while it is the right tile
            # for the shape: it wins on B200 cold-L2 while its 128x128 cluster
            # grid fits in ~one wave (1.00-1.17x at <=72 clusters / <=0.97
            # waves) but loses from 80 clusters / 1.08 waves up (0.84-0.94x),
            # where the larger bm=256 full tile is the better seed. Above the
            # one-wave ceiling fall through to the full-tile seed -- but only
            # when that tile is actually reachable; otherwise (e.g. M not a
            # multiple of 256) keep the small-grid seed, which is still the only
            # validated cluster_m=2 starting point. The bm=128 search candidates
            # stay reachable regardless (the search-admission gate is unchanged);
            # this only chooses the heuristic's starting point.
            if cls._small_grid_within_one_wave(env) or not cls._full_tile_reachable(
                spec
            ):
                return cls._fp8_small_grid_seed_config(env, bk)
        # Generalized known-good CtaGroup.TWO template (the DEFAULT-layout,
        # non-FFI config family that the hand-pinned per-shape seeds shared).
        # Pinning the full perf-critical knob set — not just the tile + cluster
        # — gives the autotuner a strong, complete starting point for ANY
        # 2-CTA-eligible matmul shape instead of relying on the search to
        # rediscover num_warps/num_stages/staging from a partial seed.
        # ``tcgen05_strategy`` (ROLE_LOCAL_MONOLITHIC) is the default, so it is
        # left implicit; the search still owns every one of these knobs.
        block_sizes = spec._tcgen05_matmul_seed_block_sizes(
            bm=TCGEN05_TWO_CTA_BLOCK_M,
            bn=TCGEN05_TWO_CTA_BLOCK_N,
            bk=bk,
        )
        if block_sizes is None:
            return None
        seed: dict[str, Any] = {
            "block_sizes": block_sizes,
            "num_warps": 8,
            "num_stages": 4,
            "pid_type": TCGEN05_TWO_CTA_SEED_PID_TYPE,
            "tcgen05_cluster_m": 2,
            "tcgen05_cluster_n": 1,
            "tcgen05_acc_stages": 2,
            # Matches the validated tcgen05 search restriction.
            "tcgen05_num_epi_warps": 4,
            TCGEN05_PERSISTENCE_MODEL_CONFIG_KEY: (
                Tcgen05PersistenceModel.STATIC_PERSISTENT.value
            ),
        }
        if edge_k_tail_family:
            seed.update(tcgen05_two_cta_edge_k_tail_seed_overrides())
        else:
            seed["l2_groupings"] = [TCGEN05_TWO_CTA_SEED_L2_GROUPING]
            seed["tcgen05_c_stages"] = 2
            # When the SMEM-budget gate admits ``ab=3`` for this seed tile
            # shape, seed the canonical fast config family directly so it
            # reaches the autotuner's initial population without depending on a
            # search-stage mutation.
            if spec._tcgen05_ab_stages_three_fits(
                bm=TCGEN05_TWO_CTA_BLOCK_M,
                bn=TCGEN05_TWO_CTA_BLOCK_N,
                bk=bk,
                cluster_m=2,
            ):
                seed["tcgen05_ab_stages"] = 3
        if spec.indexing.length == 3:
            # Pure matmul has exactly the A/B/C indexing slots. Fused epilogues
            # add more memory ops, so leave those seeds to the spec default
            # rather than constructing a partial list.
            seed["indexing"] = [
                "tensor_descriptor",
                "tensor_descriptor",
                "tensor_descriptor",
            ]
        elif edge_k_tail_family:
            seed["indexing"] = ["tensor_descriptor"] * spec.indexing.length
        return Config(**seed)

    @staticmethod
    def _select_bk(env: CompileEnvironment) -> int | None:
        spec = env.config_spec
        constraints = spec._tcgen05_cluster_m2_search_constraints
        fragments = spec._tcgen05_matmul_block_fragments()
        if constraints is None or fragments is None:
            return None
        bk_fragment = fragments[2]
        if constraints.allow_edge_k_tail_family:
            if (
                bk_fragment.low
                <= TCGEN05_TWO_CTA_EDGE_K_TAIL_BLOCK_K
                <= bk_fragment.high
                and spec._tcgen05_cluster_m2_bk_is_valid(
                    TCGEN05_TWO_CTA_EDGE_K_TAIL_BLOCK_K,
                    constraints,
                )
            ):
                return TCGEN05_TWO_CTA_EDGE_K_TAIL_BLOCK_K
            return None
        bk = bk_fragment.high
        while bk >= bk_fragment.low:
            if spec._tcgen05_cluster_m2_bk_is_valid(bk, constraints):
                return bk
            bk //= 2
        return None

    @staticmethod
    def _small_grid_tile_reachable(spec: ConfigSpec) -> bool:
        """True when the fp8 small-grid 2-CTA tile (bm=128/bn=128) is in range."""
        fragments = spec._tcgen05_matmul_block_fragments()
        if fragments is None:
            return False
        bm_fragment, bn_fragment, _ = fragments
        return (
            bm_fragment.low
            <= TCGEN05_TWO_CTA_FP8_SMALL_GRID_BLOCK_M
            <= bm_fragment.high
            and bn_fragment.low
            <= TCGEN05_TWO_CTA_FP8_SMALL_GRID_BLOCK_N
            <= bn_fragment.high
        )

    @staticmethod
    def _full_tile_reachable(spec: ConfigSpec) -> bool:
        """True when the bm=256/bn=256 full-tile cluster_m=2 tile is in range."""
        fragments = spec._tcgen05_matmul_block_fragments()
        if fragments is None:
            return False
        bm_fragment, bn_fragment, _ = fragments
        return (
            bm_fragment.low <= TCGEN05_TWO_CTA_BLOCK_M <= bm_fragment.high
            and bn_fragment.low <= TCGEN05_TWO_CTA_BLOCK_N <= bn_fragment.high
        )

    @staticmethod
    def _small_grid_within_one_wave(env: CompileEnvironment) -> bool:
        """True when the bm=128 small-grid cluster grid fits in ~one wave.

        Each 128x128 cluster spans 2 CTAs, so the grid fills the device once at
        ``clusters * 2 == num_sms``; the small-grid tile is the right *seed*
        only at or below that point (B200 cold-L2: 1.00-1.17x at <=72 clusters,
        0.84-0.94x from 80 clusters up). Mirrors the ``num_sms // 2`` ceiling
        rationale; uses static M/N from the single matmul fact. A non-CUDA /
        unknown SM count (0) keeps the small-grid seed (search still owns the
        final choice), matching the wave-quantization gate's mocked-host policy.
        """
        facts = env.config_spec.matmul_facts
        if len(facts) != 1:
            return True
        fact = facts[0]
        if fact.static_m is None or fact.static_n is None:
            return True
        from ...runtime import get_num_sm

        try:
            num_sm = get_num_sm(env.device)
        except (AssertionError, NotImplementedError):
            return True
        if num_sm <= 0:
            return True
        clusters = (fact.static_m // TCGEN05_TWO_CTA_FP8_SMALL_GRID_BLOCK_M) * (
            fact.static_n // TCGEN05_TWO_CTA_FP8_SMALL_GRID_BLOCK_N
        )
        return clusters <= num_sm // 2

    @classmethod
    def _fp8_small_grid_seed_config(cls, env: CompileEnvironment, bk: int) -> Config:
        """Seed the fp8 small-grid 2-CTA family (per-CTA 64xbn, bm=128/bn=128).

        Pins the small-grid tile plus the deep-prefetch pipeline the cold-L2
        sweeps found optimal on the small/wave-limited fp8 serving GEMMs:
        ``ab_stages=12`` (max A/B prefetch to hide the cold DRAM read),
        ``acc_stages=1`` and ``c_stages=2`` (lean accumulator + C ring),
        ``l2_groupings=1`` (no scheduler swizzle). Measured cold-L2 vs
        torch._scaled_mm on B200: 512x2048x4096 1.14x and 512x2048x2048 1.01x,
        both ahead of the shallower ab=8/acc=2/c=4/l2=4 seed (1.02x / 0.88x).
        The bm=256 full-tile seed underfills this regime (16 clusters), so this
        small-grid seed is the strong starting point the autotuner needs.

        ``ab_stages=12`` is the validator max and sits near the B200 SMEM optin
        budget; on a lower-SMEM Blackwell SKU it is dropped gracefully by the
        seed transfer (``seed_flat_config_pairs`` catches ``InvalidConfig``) and
        the search falls back to shallower samples, so seeding the max is safe.
        """
        spec = env.config_spec
        block_sizes = spec._tcgen05_matmul_seed_block_sizes(
            bm=TCGEN05_TWO_CTA_FP8_SMALL_GRID_BLOCK_M,
            bn=TCGEN05_TWO_CTA_FP8_SMALL_GRID_BLOCK_N,
            bk=bk,
        )
        if block_sizes is None:
            raise AssertionError("fp8 small-grid seed requested without matmul axes")
        seed: dict[str, Any] = {
            "block_sizes": block_sizes,
            "num_warps": 8,
            "num_stages": 4,
            "pid_type": TCGEN05_TWO_CTA_SEED_PID_TYPE,
            "tcgen05_cluster_m": 2,
            "tcgen05_cluster_n": 1,
            "tcgen05_acc_stages": 1,
            "tcgen05_c_stages": 2,
            "tcgen05_ab_stages": 12,
            "tcgen05_num_epi_warps": 4,
            "l2_groupings": [1],
            TCGEN05_PERSISTENCE_MODEL_CONFIG_KEY: (
                Tcgen05PersistenceModel.STATIC_PERSISTENT.value
            ),
        }
        if spec.indexing.length == 3:
            seed["indexing"] = [
                "tensor_descriptor",
                "tensor_descriptor",
                "tensor_descriptor",
            ]
        return Config(**seed)


class CutePointwiseVecHeuristic(AutotunerHeuristic):
    """Seed config for PURE pointwise kernels (add, gelu, cast, ...).

    The cute default maps one thread per element with scalar loads (~5% of
    HBM on B200).  Seed the vectorized lane-loop form instead: the stride-1
    tile axis gets ``block = NT * V * UNROLL`` elements served by ``NT``
    threads with ``cute_vector_widths = V`` sized to a 16-byte LDG.128
    (V=8 for 16-bit dtypes, V=4 for fp32); every other tiled axis stays at
    block 1.  Works for both the flattened (1D) and N-D grid strategies —
    both share the tile_unroll vec-hoist protocol.

    Fires on the presence of ``PointwiseElementwiseFact`` (built only in
    the absence of reduction/matmul/accumulator facts, so it never claws a
    reducing kernel into this track).
    """

    name = "cute_pointwise_vec"
    backend = "cute"

    NT = 256  # threads per CTA
    UNROLL = 2  # vectors per thread (outer lane iters)

    @classmethod
    def register_facts(
        cls, env: CompileEnvironment, device_ir: DeviceIR
    ) -> frozenset[CompilerHeuristicSpecializationFact]:
        if env.config_spec.pointwise_facts:
            # Admission uses the actual launch's tensor metadata behind a
            # guard; no example size or new binding specialization is needed.
            env.config_spec.enable_cute_proven_bounds()
            env.config_spec.enable_cute_packet_prefetch()
        return frozenset()

    @classmethod
    def _vec_axis_and_width(
        cls, env: CompileEnvironment
    ) -> tuple[int, int, int, bool] | None:
        """Returns (vec_block_id, V, size_hint, flatten) or None if no axis
        can host a vec lane loop.  ``flatten`` is True when the innermost
        extent is not V-divisible but the flattened total is: the seed then
        flattens the tile (flat V-chunks stay memory-contiguous for
        full-cover contiguous tensors, odd row length or not)."""
        spec = env.config_spec
        if not spec.pointwise_facts:
            return None
        fact = spec.pointwise_facts[0]
        if not spec.block_sizes:
            return None
        candidates = [s.block_id for s in spec.block_sizes]
        vec_block = None
        for bid in reversed(candidates):
            if bid in fact.contig_block_ids:
                vec_block = bid
                break
        if vec_block is None:
            vec_block = candidates[-1]
        if vec_block not in spec.cute_vector_widths.valid_block_ids():
            return None
        if vec_block not in spec.num_threads.valid_block_ids():
            return None
        size_hint = spec.block_sizes.block_id_lookup(vec_block).size_hint
        choices = (
            spec.cute_vector_widths.block_id_lookup(vec_block)._fragment(spec).choices
        )
        full_vec = max(
            cast("int", value)
            for value in choices
            if cast("int", value) <= 16 // max(1, fact.storage_itemsize)
        )
        # The hoist requires numel % V == 0; shrink V until it divides.
        vec = full_vec
        while vec > 1 and size_hint % vec != 0:
            vec //= 2
        if vec > 1:
            return vec_block, vec, size_hint, False
        # Innermost extent is odd: flatten and vectorize the flat space.
        flatten_group = next(
            (f for f in spec.flatten_loops if vec_block in f.block_ids), None
        )
        if flatten_group is None:
            return None
        total = 1
        for bid in flatten_group.block_ids:
            total *= spec.block_sizes.block_id_lookup(bid).size_hint
        vec = full_vec
        while vec > 1 and total % vec != 0:
            vec //= 2
        if vec <= 1:
            return None
        return vec_block, vec, total, True

    @classmethod
    def is_eligible(cls, env: CompileEnvironment, device_ir: DeviceIR) -> bool:
        return cls._vec_axis_and_width(env) is not None

    @classmethod
    def get_seed_config(
        cls, env: CompileEnvironment, device_ir: DeviceIR
    ) -> Config | None:
        spec = env.config_spec
        if spec.kernel_grid_fact is not None and len(spec.kernel_grid_fact.roots) > 1:
            seeds = cls._multi_root_seed_configs(env)
            return seeds[0] if seeds else None
        picked = cls._vec_axis_and_width(env)
        if picked is None:
            return None
        vec_block, vec, size_hint, flatten = picked
        bs_high = spec.block_sizes.block_id_lookup(vec_block)._fragment(spec).high
        nt, unroll = cls.NT, cls.UNROLL
        while nt * vec * unroll > bs_high and unroll > 1:
            unroll //= 2
        while nt * vec * unroll > bs_high and nt > 1:
            nt //= 2
        block = nt * vec * unroll
        if block > bs_high or nt <= 1:
            return None
        seed: dict[str, Any] = {
            "block_sizes": [
                block if s.block_id == vec_block else 1 for s in spec.block_sizes
            ],
            "num_threads": _seq_config_list(spec.num_threads, {vec_block: nt}),
            "cute_vector_widths": _seq_config_list(
                spec.cute_vector_widths, {vec_block: vec}
            ),
        }
        if flatten:
            seed["flatten_loops"] = [True for _ in spec.flatten_loops]
        # Streamed-once pointwise inputs benefit from L2::evict_last on the
        # hoisted vec loads (triton's pointwise winners routinely carry
        # evict_last; measured +1.7% on fp32 mul under do_bench's flush).
        # Seed-only: this heuristic never promotes to the autotune-off
        # default, and a plain-policy alternate is planted alongside.
        # Sized from the live spec, not memory_op_facts: loads carrying an
        # explicit ``hl.load(..., eviction_policy=...)`` get no config slot,
        # so the fact count can exceed the list the search space expects.
        n_evict = (
            spec.load_eviction_policies.length
            if spec.supports_config_key("load_eviction_policies")
            else 0
        )
        if n_evict and "l2_last" in get_valid_eviction_policies("cute"):
            seed["load_eviction_policies"] = ["l2_last"] * n_evict
        try:
            return Config(**seed)
        except Exception:
            return None

    @classmethod
    def get_seed_configs(
        cls, env: CompileEnvironment, device_ir: DeviceIR
    ) -> list[Config] | None:
        topology = env.config_spec.kernel_grid_fact
        if topology is not None and len(topology.roots) > 1:
            return cls._multi_root_seed_configs(env)
        primary = cls.get_seed_config(env, device_ir)
        if primary is None:
            return None
        spec = env.config_spec
        seeds = [primary]
        # Flattened alternate for multi-dim tiles: flat V-chunks often beat
        # the N-D row form (fewer pid div/mods, tail-free tiling), and the
        # handwritten-CuTe comparison kernels iterate flat.  Skip when the
        # primary already flattens (odd innermost extent).
        base_variants: list[dict[str, Any]] = [dict(primary.config)]
        picked = cls._vec_axis_and_width(env)
        if (
            picked is not None
            and not picked[3]
            and len(spec.block_sizes) > 1
            and spec.flatten_loops
        ):
            vec_block, vec = picked[0], picked[1]
            flatten_group = next(
                (f for f in spec.flatten_loops if vec_block in f.block_ids), None
            )
            if flatten_group is not None:
                total = 1
                for bid in flatten_group.block_ids:
                    total *= spec.block_sizes.block_id_lookup(bid).size_hint
                if total % vec == 0:
                    flat_seed: dict[str, Any] = dict(primary.config)
                    flat_seed["flatten_loops"] = [True for _ in spec.flatten_loops]
                    with contextlib.suppress(Exception):
                        seeds.append(Config(**flat_seed))
                        base_variants.append(flat_seed)
        # Plain-eviction alternate of the primary (which seeds l2_last on
        # every load): keeps a no-hint starting point in the population for
        # regimes where the L2 policy is a wash.
        if primary.config.get("load_eviction_policies"):
            plain_seed: dict[str, Any] = dict(primary.config)
            plain_seed.pop("load_eviction_policies", None)
            with contextlib.suppress(Exception):
                seeds.append(Config(**plain_seed))
        # Wide-thread sibling (NT*2, one vector per thread): kernels whose
        # per-element pipeline is ALU-heavier (e.g. a broadcast gather's
        # per-element div/mod) prefer more threads over per-thread unroll
        # (bias_add 4096x50257: 3.0 -> 4.9 TB/s on B200).
        if picked is not None:
            vec_block, vec = picked[0], picked[1]
            nt_ids = [s.block_id for s in spec.num_threads]
            if vec_block in nt_ids:
                nt_pos = nt_ids.index(vec_block)
                for base in [*base_variants]:
                    nt_list = list(base.get("num_threads") or [])
                    if nt_pos >= len(nt_list):
                        continue
                    nt2 = int(nt_list[nt_pos]) * 2
                    block_list = base.get("block_sizes") or []
                    bs_pos = [s.block_id for s in spec.block_sizes].index(vec_block)
                    block = int(block_list[bs_pos]) if bs_pos < len(block_list) else 0
                    if nt2 <= 0 or nt2 > 1024 or block % (nt2 * vec) != 0:
                        continue
                    wide_seed: dict[str, Any] = dict(base)
                    wide_seed["num_threads"] = [
                        *nt_list[:nt_pos],
                        nt2,
                        *nt_list[nt_pos + 1 :],
                    ]
                    with contextlib.suppress(Exception):
                        seeds.append(Config(**wide_seed))
            # Independent scalar chains can use one small packet per thread:
            # vector loads precede the packet's arithmetic and stores follow
            # it. Width eight may use two 128-bit transfers for FP32. Keep the
            # existing wide/unrolled seeds as alternatives for bandwidth work.
            block_ids = [item.block_id for item in spec.block_sizes]
            bs_pos = block_ids.index(vec_block)
            high = spec.block_sizes.block_id_lookup(vec_block)._fragment(spec).high
            for threads in (128, 256):
                for packet_width in (4, 8):
                    block_size = threads * packet_width
                    if block_size > high:
                        continue
                    packet = dict(primary.config)
                    packet["block_sizes"] = [
                        block_size if index == bs_pos else size
                        for index, size in enumerate(primary.block_sizes)
                    ]
                    packet["num_threads"] = _seq_config_list(
                        spec.num_threads, {vec_block: threads}
                    )
                    packet["cute_vector_widths"] = _seq_config_list(
                        spec.cute_vector_widths, {vec_block: packet_width}
                    )
                    seeds.append(Config.from_dict(packet))
        if spec.cute_proven_bounds_enabled:
            # Keep the complete existing family and its order. Add independent
            # true counterparts so ordinary cold search can compare the proof
            # with its original fallback, without changing the default config.
            seeds.extend(
                Config.from_dict(deepcopy(seed.config) | {"cute_proven_bounds": True})
                for seed in list(seeds)
                if not seed.config.get("cute_proven_bounds", False)
            )
        if (
            spec.cute_packet_prefetch_enabled
            and picked is not None
            and spec.pointwise_facts[0].storage_itemsize in (2, 4)
        ):
            # Preserve the complete existing prefix, including its paired
            # bounds variants. Only add strided off/on siblings of existing
            # multi-packet tiles; do not invent new geometries or defaults.
            vec_block = picked[0]
            block_ids = [item.block_id for item in spec.block_sizes]
            thread_ids = [item.block_id for item in spec.num_threads]
            vector_ids = [item.block_id for item in spec.cute_vector_widths]
            layout_ids = [item.block_id for item in spec.cute_lane_layouts]
            if all(
                vec_block in ids
                for ids in (block_ids, thread_ids, vector_ids, layout_ids)
            ):
                for base in list(seeds):
                    if base.config.get("cute_proven_bounds") is not True:
                        continue
                    block = base.block_sizes[block_ids.index(vec_block)]
                    threads = base.num_threads[thread_ids.index(vec_block)]
                    widths = base.config["cute_vector_widths"]
                    assert isinstance(widths, list)
                    width = widths[vector_ids.index(vec_block)]
                    packet = threads * width
                    if (
                        width not in (2, 4, 8)
                        or packet <= 0
                        or block < 2 * packet
                        or block % (2 * packet)
                    ):
                        continue
                    control = deepcopy(base.config)
                    control["cute_lane_layouts"] = _seq_config_list(
                        spec.cute_lane_layouts, {vec_block: "strided"}
                    )
                    for values in (
                        control,
                        deepcopy(control) | {"cute_packet_prefetch": 2},
                    ):
                        if all(values != previous.config for previous in seeds):
                            seeds.append(Config.from_dict(values))
        if spec.cute_rng_packet_enabled:
            # Keep the complete existing family in order. Explicit-uniform RNG
            # may reuse one Philox invocation across a vector packet; seed that
            # choice alongside the scalar path without changing stream policy
            # or relying on a later Boolean mutation to discover it.
            seeds.extend(
                Config.from_dict(deepcopy(seed.config) | {"cute_rng_packet": True})
                for seed in list(seeds)
                if not seed.config.get("cute_rng_packet", False)
            )
        return seeds

    @classmethod
    def _multi_root_seed_configs(cls, env: CompileEnvironment) -> list[Config]:
        """Seed each independent pointwise grid from its own storage accesses.

        Whole-kernel pointwise facts multiply extents across roots, so they
        cannot size individual roots' vector traffic. Use direct stride-one
        memory facts here, with scalar siblings for gather-heavy grids. This
        only seeds a bounded family; codegen remains the vector-eligibility and
        combined physical-thread-budget authority.
        """
        spec = env.config_spec
        topology = spec.kernel_grid_fact
        assert topology is not None
        axes: list[tuple[int, int]] = []
        for root in topology.roots:
            candidates = [
                item.block_id
                for item in spec.block_sizes
                if item.block_id in root.block_ids
                and item.block_id in spec.num_threads.valid_block_ids()
                and item.block_id in spec.cute_vector_widths.valid_block_ids()
            ]
            if not candidates:
                return []
            widths: dict[int, int] = {}
            for block_id in candidates:
                dtypes = [
                    fact.dtype
                    for fact in spec.memory_op_facts
                    if fact.dtype is not None
                    and any(
                        bid == block_id and stride == 1
                        for bid, stride in zip(
                            fact.subscript_block_ids,
                            fact.subscript_strides,
                            strict=True,
                        )
                    )
                ]
                if dtypes:
                    width = min(
                        _cute_tile_seed_vec_width_for_dtype(dtype) for dtype in dtypes
                    )
                    choices = (
                        spec.cute_vector_widths.block_id_lookup(block_id)
                        ._fragment(spec)
                        .choices
                    )
                    widths[block_id] = max(
                        cast("int", value)
                        for value in choices
                        if cast("int", value) <= width
                    )
            axis = next(
                (bid for bid in reversed(candidates) if bid in widths), candidates[-1]
            )
            axes.append((axis, widths.get(axis, 1)))
        # Limit family growth independently of a kernel's number of roots.
        scalar_choices = [set(), {axis for axis, _ in axes}]
        scalar_choices.extend({axis} for axis, width in axes[:4] if width > 1)
        seeds: list[Config] = []
        for threads in (128, cls.NT):
            for unroll in (1, cls.UNROLL):
                for scalar_axes in scalar_choices:
                    blocks: dict[int, object] = {
                        item.block_id: item.min_size for item in spec.block_sizes
                    }
                    thread_values: dict[int, object] = {}
                    vector_values: dict[int, object] = {}
                    for axis, width in axes:
                        width = 1 if axis in scalar_axes else width
                        fragment = spec.block_sizes.block_id_lookup(axis)._fragment(
                            spec
                        )
                        block = min(threads * width * unroll, fragment.high)
                        if block < fragment.low or block < width:
                            break
                        blocks[axis] = block
                        thread_values[axis] = min(threads, block // width)
                        vector_values[axis] = width
                    else:
                        seeds.append(
                            Config(
                                block_sizes=cast(
                                    "list[int]",
                                    _seq_config_list(spec.block_sizes, blocks),
                                ),
                                num_threads=cast(
                                    "list[int]",
                                    _seq_config_list(spec.num_threads, thread_values),
                                ),
                                cute_vector_widths=cast(
                                    "list[int]",
                                    _seq_config_list(
                                        spec.cute_vector_widths, vector_values
                                    ),
                                ),
                                cute_lane_layouts=cast(
                                    "list[str]",
                                    _seq_config_list(spec.cute_lane_layouts, {}),
                                ),
                            )
                        )
        return list(dict.fromkeys(seeds))


class CuteFp8GemmSkinnyMHeuristic(AutotunerHeuristic):
    """Seed config for skinny-M FP8 GEMM kernels.

    For small M (1-16) the optimal config is very different from a large GEMM:
    a single row per grid block (``block_sizes[0]=1``), a modest N tile, a warp
    of threads on the N axis, and a wide FP8 vector load. Seeding this anchors
    the autotuner in the valid small-tile region instead of letting the random
    population burn its budget on configs like ``block_sizes=[4096, 2048]`` or
    1024-thread launches that are structurally wrong for a 1-row problem (and
    frequently overflow shared memory).

    A/B benchmark (helion benchmarks/run.py, fp8_gemm, CuTe, 120s budget):
    on M=1 shapes the search locks onto this seed and produces a 1.8-2.0x
    faster kernel than with heuristics disabled, with ~25% fewer wasted
    compile failures.

    Seeds ``block_sizes=[1, 256]``, ``num_threads=[0, 32]``,
    ``cute_vector_widths=[4, 8]`` (the autotune-winning config for
    M=1, K=4096, N=4096).
    """

    name = "cute_fp8_gemm_skinny_m"
    backend = "cute"

    @classmethod
    def is_eligible(cls, env: CompileEnvironment, device_ir: DeviceIR) -> bool:
        spec = env.config_spec
        # Needs to be a matmul with FP8 inputs
        if not spec.matmul_facts or len(spec.matmul_facts) != 1:
            return False
        fact = spec.matmul_facts[0]
        # Check for FP8 dtypes
        is_fp8 = fact.lhs_dtype in (
            torch.float8_e4m3fn,
            torch.float8_e5m2,
        ) and fact.rhs_dtype in (
            torch.float8_e4m3fn,
            torch.float8_e5m2,
        )
        if not is_fp8:
            return False
        # Check for skinny M (small batch / decode scenario):
        # M <= 16 is the skinny-M case.
        return fact.static_m is not None and fact.static_m <= 16

    @classmethod
    def get_seed_config(
        cls, env: CompileEnvironment, device_ir: DeviceIR
    ) -> Config | None:
        # Best config from autotune benchmarks for M=1, K=4096, N=4096
        # (1.5x speedup over baseline; the M=1 search reliably converges here).
        seed: dict[str, Any] = {
            "block_sizes": [1, 256],
            "num_threads": [0, 32],
            "cute_vector_widths": [4, 8],
        }
        try:
            return Config(**seed)
        except Exception:
            return None


class CuteTcgen05ClusterM2FfiHeuristic(CuteTcgen05ClusterM2Heuristic):
    """Generalized TVM-FFI seed for full-tile CtaGroup.TWO 16-bit GEMMs.

    The generic ``--enable-tvm-ffi`` launcher builds its A/B/D TMA descriptors
    from the runtime tensor shapes, so the fast launch path is shape-GENERAL:
    the only real constraints are structural (256x256 CTA tile, cluster_m=2, a
    bk in the direct-entry stage-tuple table, bf16/fp16 operands, the 128x32
    explicit epilogue subtile). This heuristic emits that full
    ``explicit_epi_tile`` + flat-role + ``tvm_ffi_launch`` config for ANY
    eligible shape, replacing the bank of hand-pinned per-shape seeds.

    The DEFAULT-layout sibling (``CuteTcgen05ClusterM2Heuristic``) still seeds
    the non-FFI config, so the autotuner benchmarks both and keeps whichever
    wins: full-autotune A/B measured the FFI direct entry ~7-21% faster on
    smaller / square GEMMs (1024x4096x1024, 2048^3) where launch + epilogue
    overhead dominates, and tied on large compute-bound shapes
    (8192x1024x1024, 8192x2048x2048). An FFI config that fails to compile or
    the accuracy check for a given shape is dropped by the autotuner,
    degrading gracefully to the DEFAULT seed.
    """

    name = "cute_tcgen05_cluster_m2_ffi"
    backend = "cute"

    @classmethod
    def register_facts(
        cls, env: CompileEnvironment, device_ir: DeviceIR
    ) -> frozenset[CompilerHeuristicSpecializationFact]:
        # The flat-role / FFI direct-entry seed hard-requires the TMA A/B
        # pipeline and the TMA store epilogue, which codegen enables only when
        # both matmul operands and the output destination pass the TensorMap
        # alignment proof; an unaligned input keeps the scalar SMEM producers,
        # an under-aligned or N-major output takes the SIMT store body, and
        # either way the seed config fails to compile. Decide that here,
        # before any seed or the search surface consults
        # ``full_tile_direct_entry_seed_eligible``, and even when heuristic
        # seeds are disabled, because the default projection reads it too.
        host_function = device_ir.host_function
        if host_function is None or not env.config_spec.cute_tcgen05_search_enabled:
            return frozenset()
        from ..cute.cute_mma import host_function_matmul_operands_tma_provable

        # Codegen proves a pointer-preserving host view operand through its
        # input's exact metadata (``input_view_copy_facts``), which this hook
        # therefore requests (the static-shapes bind key already carries it);
        # evaluate the proof under that registration so the bind-time and
        # codegen answers agree.
        facts: frozenset[CompilerHeuristicSpecializationFact] = (
            frozenset({"input_tensor_metadata"})
            if env.settings.static_shapes
            else frozenset()
        )
        saved = env.compiler_fact_specialization_facts
        env.compiler_fact_specialization_facts = saved | facts
        try:
            provable = host_function_matmul_operands_tma_provable(env, host_function)
        finally:
            env.compiler_fact_specialization_facts = saved
        env.config_spec.cute_tcgen05_matmul_operands_tma_provable = provable
        return facts

    @classmethod
    def is_eligible(cls, env: CompileEnvironment, device_ir: DeviceIR) -> bool:
        return env.config_spec._tcgen05_full_tile_direct_entry_seed_eligible()

    @classmethod
    def get_seed_config(
        cls, env: CompileEnvironment, device_ir: DeviceIR
    ) -> Config | None:
        # Single source of truth lives on the ConfigSpec/CuteTcgen05Config so the
        # search-projection (``_fix_target1_tvm_ffi_search_config``) and this
        # population seed emit the identical FFI envelope.
        return env.config_spec._tcgen05_full_tile_direct_entry_seed_config()
