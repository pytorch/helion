"""Tiling analysis pass for the Pallas backend.

Analyzes indexing expressions to determine which tensor dimensions can be tiled.
Sets 'dim_tilings' metadata on tensors based on indexing constraints.
"""

from __future__ import annotations

from dataclasses import dataclass
from dataclasses import field
import operator
from typing import TYPE_CHECKING
from typing import cast

import sympy
import torch

from ... import exc
from .memory_access import tensor_origin_key

if TYPE_CHECKING:
    from collections.abc import Callable

    from ...runtime.config import Config
    from ..compile_environment import CompileEnvironment
    from ..device_ir import GraphInfo
    from ..host_function import SymbolOrigin
    from ..tile_dispatch import TileStrategyDispatch
    from .memory_access import MemoryAccess


@dataclass
class IndexingPattern:
    """Base class for indexing patterns detected during tiling analysis."""


@dataclass
class TilePattern(IndexingPattern):
    """Vanilla tile pattern - translates to ':' when tiled."""

    block_id: int


@dataclass
class TileIndexWithOffsetPattern(IndexingPattern):
    """Tile index with offset - no tiling allowed."""

    block_id: int
    offset: int | torch.SymInt | object


@dataclass
class TileBeginWithOffsetPattern(IndexingPattern):
    """Tile begin with offset - allow/disallow tiling based on bounds."""

    block_id: int
    offset: int | torch.SymInt | object


@dataclass
class ArbitrarySlicePattern(IndexingPattern):
    slice: slice


@dataclass
class ArbitraryIndexPattern(IndexingPattern):
    index: int | torch.SymInt | object | None


@dataclass
class NonePattern(IndexingPattern):
    """None index pattern (broadcasting dimension) - allow tiling."""


@dataclass
class TensorIndexPattern(IndexingPattern):
    """Tensor-valued index - no tiling. Resolved for indirect load/store codegen."""

    index_ndim: int = 1


@dataclass(frozen=True)
class GridScalarIndex:
    """A scalar metadata lookup that selects one grid program's tensor panel."""

    metadata_tensor: torch.Tensor = field(compare=False)
    metadata_key: str | int
    block_id: int


@dataclass
class ContiguousRangeIndexPattern(IndexingPattern):
    """Aligned ``base + arange(length)`` index addressable as one HBM window."""

    base: int | torch.SymInt | torch.fx.Node
    length: int
    alignment: int


@dataclass
class DimensionTiling:
    """Tiling decision for a specific dimension of a tensor

    can_tile: whether or not we can tile this dimension
    block_ids: which which block_ids we are indexing this dimension (there can be multiple, in which case we mustn't tile)
    """

    can_tile: bool = True
    block_ids: list[int] = field(default_factory=list)


REMOTE_SRC_INDEXING_PATTERNS = "pallas_remote_src_indexing_patterns"
REMOTE_DST_INDEXING_PATTERNS = "pallas_remote_dst_indexing_patterns"
GRID_SCALAR_INDEX_DIMS = "pallas_grid_scalar_index_dims"


def plan_tiling(
    graphs: list[GraphInfo],
    config: Config,
    tile_strategy: TileStrategyDispatch,
) -> None:
    graph_lookup = {graph_info.graph_id: graph_info for graph_info in graphs}
    parent_ids = _collect_control_flow_parent_ids(graphs)
    for graph_info in graphs:
        local_access_keys = _collect_local_access_keys_with_ancestors(
            graph_info, graph_lookup, parent_ids
        )
        _analyze_indexing_expressions(graph_info, config, local_access_keys)


def plan_grid_scalar_indices(graphs: list[GraphInfo], config: Config) -> None:
    """Find tensor panels selected by scalar metadata indexed by a grid axis.

    A source pattern such as ``table[panel_ids[work], :, :]`` can be represented
    directly by a Pallas scalar-prefetch BlockSpec: ``work`` selects one scalar
    from ``panel_ids``, and that scalar selects one panel from ``table``.  This
    pass records only structurally consistent dimensions; mixed selectors keep
    the existing ordinary indexing path.
    """
    if config.get("pallas_loop_type") != "unroll":
        return

    from ...language import _tracing_ops
    from ...language import memory_ops
    from ...language.atomic_ops import ATOMIC_OPS
    from ..device_function import DeviceFunction
    from ..device_function import PallasMemorySpace
    from ..device_ir import control_flow_parent_entries

    parent_entries = control_flow_parent_entries(graphs)
    placeholder_to_outer: dict[torch.fx.Node, torch.fx.Node] = {}
    for graph_info in graphs:
        entry = parent_entries.get(graph_info.graph_id)
        if entry is None:
            continue
        parent, arg_index = entry
        outer_args = parent.args[arg_index]
        if not isinstance(outer_args, (list, tuple)):
            continue
        placeholders = list(graph_info.graph.find_nodes(op="placeholder"))
        placeholder_to_outer.update(
            {
                placeholder: outer
                for outer, placeholder in zip(outer_args, placeholders, strict=True)
                if isinstance(outer, torch.fx.Node)
            }
        )

    def resolve(node: object) -> torch.fx.Node | None:
        seen: set[torch.fx.Node] = set()
        while isinstance(node, torch.fx.Node) and node not in seen:
            seen.add(node)
            if node.target is _tracing_ops._new_var and node.args:
                node = node.args[0]
            elif node.op == "placeholder" and node in placeholder_to_outer:
                node = placeholder_to_outer[node]
            else:
                return node
        return None

    def selector(index: object) -> GridScalarIndex | None:
        index_node = resolve(index)
        if (
            index_node is None
            or index_node.op != "call_function"
            or index_node.target is not memory_ops.load
            or len(index_node.args) < 2
        ):
            return None
        metadata_node, metadata_subscript = index_node.args[:2]
        if not isinstance(metadata_node, torch.fx.Node) or not isinstance(
            metadata_subscript, (list, tuple)
        ):
            return None
        metadata = metadata_node.meta.get("val")
        patterns = index_node.meta.get("indexing_patterns")
        if (
            not isinstance(metadata, torch.Tensor)
            or metadata.ndim != 1
            or metadata.dtype != torch.int32
            or not isinstance(patterns, list)
            or len(patterns) != 1
            or not isinstance(patterns[0], (TilePattern, TileBeginWithOffsetPattern))
            or (
                isinstance(patterns[0], TileBeginWithOffsetPattern)
                and patterns[0].offset != 0
            )
        ):
            return None
        return GridScalarIndex(
            metadata_tensor=metadata,
            metadata_key=tensor_origin_key(metadata),
            block_id=patterns[0].block_id,
        )

    access_targets = ATOMIC_OPS | {memory_ops.load, memory_ops.store}
    uses: dict[tuple[int, int], list[tuple[torch.fx.Node, GridScalarIndex | None]]] = {}
    for graph_info in graphs:
        for node in graph_info.graph.nodes:
            if node.op != "call_function" or node.target not in access_targets:
                continue
            tensor_node = node.args[0]
            subscript = node.args[1]
            if not isinstance(tensor_node, torch.fx.Node) or not isinstance(
                subscript, (list, tuple)
            ):
                continue
            tensor = tensor_node.meta.get("val")
            patterns = node.meta.get("indexing_patterns")
            if not isinstance(tensor, torch.Tensor) or not isinstance(patterns, list):
                continue
            tensor_dim = 0
            for index, pattern in zip(subscript, patterns, strict=True):
                if isinstance(pattern, NonePattern):
                    continue
                selected = (
                    selector(index)
                    if isinstance(pattern, TensorIndexPattern)
                    and pattern.index_ndim == 0
                    else None
                )
                uses.setdefault((id(tensor), tensor_dim), []).append((node, selected))
                tensor_dim += 1

    device_fn = DeviceFunction.current()
    # Scalar-prefetch BlockSpecs and raw-HBM load-site DMA currently use
    # different launcher paths. Leave the entire kernel on the established DMA
    # path when any argument needs a raw HBM ref.
    if PallasMemorySpace.HBM in device_fn.pallas_memory_space.values():
        return
    for (tensor_id, tensor_dim), dimension_uses in uses.items():
        # Raw-HBM operands already have an explicit load-site DMA plan and no
        # outer BlockSpec. Keep that established path instead of trying to
        # select the same panel through scalar-prefetch metadata.
        if device_fn.pallas_memory_space.get(tensor_id) is PallasMemorySpace.HBM:
            continue
        selected = [item for _node, item in dimension_uses if item is not None]
        if not selected or len(selected) != len(dimension_uses):
            continue
        first = selected[0]
        if any(item != first for item in selected[1:]):
            continue
        device_fn.pallas_grid_scalar_indices.setdefault(tensor_id, {})[tensor_dim] = (
            first
        )
        for node, _item in dimension_uses:
            dims = set(node.meta.get(GRID_SCALAR_INDEX_DIMS, ()))
            dims.add(tensor_dim)
            node.meta[GRID_SCALAR_INDEX_DIMS] = tuple(sorted(dims))


def _collect_local_access_keys(graph: torch.fx.Graph) -> set[str | int]:
    from ...language import memory_ops
    from ...language.atomic_ops import ATOMIC_OPS

    local_access_targets = ATOMIC_OPS | {memory_ops.load, memory_ops.store}
    local_access_keys: set[str | int] = set()
    for node in graph.nodes:
        if node.op != "call_function" or node.target not in local_access_targets:
            continue
        tensor_arg = node.args[0]
        if isinstance(tensor_arg, torch.fx.Node):
            tensor = tensor_arg.meta.get("val")
            if isinstance(tensor, torch.Tensor):
                local_access_keys.add(tensor_origin_key(tensor))
    return local_access_keys


def control_flow_child_graph_ids(node: torch.fx.Node) -> tuple[object, ...]:
    """The graph ids ``node`` traces into, or ``()`` if it is not control flow."""
    from ...language import _tracing_ops

    if _tracing_ops.is_for_loop_target(node.target):
        # args[0] is the loop body graph_id for both for-loop variants.
        return node.args[:1]
    if node.target is _tracing_ops._if:
        # args[1] and args[2] are if_graph_id and else_graph_id; args[0] is the test.
        return node.args[1:3]
    if node.target is _tracing_ops._while_loop:
        # args[0] and args[1] are cond_graph_id and body_graph_id.
        return node.args[:2]
    return ()


def _collect_control_flow_parent_ids(graphs: list[GraphInfo]) -> dict[int, int]:
    parent_ids: dict[int, int] = {}
    for graph_info in graphs:
        for node in graph_info.graph.nodes:
            if node.op != "call_function":
                continue
            for child_id in control_flow_child_graph_ids(node):
                if isinstance(child_id, int):
                    parent_ids.setdefault(child_id, graph_info.graph_id)
    return parent_ids


def _collect_local_access_keys_with_ancestors(
    graph_info: GraphInfo,
    graph_lookup: dict[int, GraphInfo],
    parent_ids: dict[int, int],
) -> set[str | int]:
    """Find local accesses visible to one nested control-flow graph.

    A child loop may communicate through a tensor initialized by its parent, so
    parent accesses keep that tensor in the resident VMEM view. Accesses in a
    sibling or later root do not: those require an HBM-backed destination that
    survives between control-flow regions.
    """
    result: set[str | int] = set()
    current = graph_info
    visited: set[int] = set()
    while current.graph_id not in visited:
        visited.add(current.graph_id)
        result.update(_collect_local_access_keys(current.graph))
        parent_id = parent_ids.get(current.graph_id)
        if parent_id is None:
            break
        current = graph_lookup[parent_id]
    return result


def _analyze_indexing_expressions(
    graph_info: GraphInfo, config: Config, local_access_keys: set[str | int]
) -> None:
    from ...language import distributed_ops
    from ...language import memory_ops
    from ...language.atomic_ops import ATOMIC_OPS

    indexing_targets = ATOMIC_OPS | {memory_ops.load, memory_ops.store}
    for node in graph_info.graph.nodes:
        if node.op != "call_function":
            continue
        if node.target is distributed_ops.make_async_remote_copy:
            _analyze_remote_copy(node, config, local_access_keys)
        elif node.target in indexing_targets:
            _analyze_indexing(node, config)


def _analyze_remote_copy(
    node: torch.fx.Node, config: Config, local_access_keys: set[str | int]
) -> None:
    if len(node.args) != 5:
        raise exc.InternalError(
            RuntimeError("remote copy was not normalized to its five-argument form")
        )
    _analyze_remote_operand(
        node,
        node.args[0],
        node.args[1],
        config,
        local_access_keys,
        REMOTE_SRC_INDEXING_PATTERNS,
        is_destination=False,
    )
    _analyze_remote_operand(
        node,
        node.args[3],
        node.args[4],
        config,
        local_access_keys,
        REMOTE_DST_INDEXING_PATTERNS,
        is_destination=True,
    )


def _analyze_remote_operand(
    node: torch.fx.Node,
    tensor_arg: object,
    subscript: object,
    config: Config,
    local_access_keys: set[str | int],
    metadata_key: str,
    *,
    is_destination: bool,
) -> None:
    if not isinstance(tensor_arg, torch.fx.Node):
        raise exc.InternalError(RuntimeError("remote-copy operand is not an FX node"))
    if not isinstance(subscript, (list, tuple)):
        raise exc.InternalError(RuntimeError("remote-copy index is not a sequence"))
    tensor = tensor_arg.meta.get("val")
    if not isinstance(tensor, torch.Tensor):
        raise exc.InternalError(RuntimeError("remote-copy operand is not a tensor"))

    from ..device_function import DeviceFunction
    from ..device_function import PallasMemorySpace

    device_fn = DeviceFunction.current()
    tensor_id = id(tensor)
    tensor_key = tensor_origin_key(tensor)
    device_fn.mark_pallas_remote_copy_operand(tensor)
    if tensor_id not in device_fn.pallas_tensor_dim_tilings:
        device_fn.pallas_tensor_dim_tilings[tensor_id] = [
            DimensionTiling() for _ in range(tensor.ndim)
        ]
    node.meta[metadata_key] = _analyze_subscript_patterns(
        tensor,
        list(subscript),
        device_fn.pallas_tensor_dim_tilings[tensor_id],
        node,
        config,
    )

    if is_destination and tensor_key not in local_access_keys:
        # A destination that is not locally accessed by this graph must retain
        # a persistent HBM allocation. This includes route-in-one-loop,
        # consume-in-a-later-loop pipelines. Once any graph needs persistence,
        # later local accesses must not downgrade the tensor to VMEM.
        device_fn.pallas_memory_space[tensor_id] = PallasMemorySpace.HBM
    elif device_fn.pallas_memory_space.get(tensor_id) != PallasMemorySpace.HBM:
        # When the same graph both communicates through and computes from a
        # tensor, its BlockSpec is the symmetric resident region addressed by
        # the remote copy. Keeping that region in VMEM avoids an unnecessary
        # HBM round trip and permits immediate consumption after the DMA wait.
        device_fn.pallas_memory_space[tensor_id] = (
            PallasMemorySpace.VMEM
            if tensor_key in local_access_keys
            else PallasMemorySpace.HBM
        )


def _analyze_indexing(node: torch.fx.Node, config: Config) -> None:
    tensor_arg = node.args[0]
    subscript = node.args[1]

    assert isinstance(subscript, (list, tuple))
    assert isinstance(tensor_arg, torch.fx.Node)
    tensor_val = tensor_arg.meta.get("val")
    assert isinstance(tensor_val, torch.Tensor)

    from helion._compiler.device_function import DeviceFunction

    device_fn = DeviceFunction.current()
    if id(tensor_val) not in device_fn.pallas_tensor_dim_tilings:
        device_fn.pallas_tensor_dim_tilings[id(tensor_val)] = [
            DimensionTiling() for _ in range(tensor_val.ndim)
        ]
    dim_tilings = device_fn.pallas_tensor_dim_tilings[id(tensor_val)]

    # Store indexing patterns directly on the memory operation node
    indexing_patterns = _analyze_subscript_patterns(
        tensor_val, list(subscript), dim_tilings, node, config
    )
    from .memory_access import MEMORY_ACCESS_META
    from .memory_access import build_memory_access

    node.meta[MEMORY_ACCESS_META] = build_memory_access(
        node, tensor_val, list(subscript), indexing_patterns
    )
    node.meta["indexing_patterns"] = indexing_patterns

    # Track SMEM eligibility (simplified — does not distinguish read vs write):
    #   SMEM: only scalar access.  VMEM: vector/slice + scalar reads.
    # A fully correct policy would check read vs write per access:
    #   - Scalar read-only tensors could stay in VMEM (no SMEM needed)
    #   - Scalar write requires SMEM
    #   - Mixed scalar-write + slice needs tensor duplication (unsupported)
    # For now we conservatively put all-scalar tensors in SMEM and
    # mixed tensors in VMEM. This is correct for the common cases
    # (scalar-only → SMEM, mixed scalar-read + slice → VMEM) but
    # over-allocates SMEM for scalar-read-only tensors.
    from ..device_function import PallasMemorySpace

    is_all_scalar = all(
        isinstance(p, (ArbitraryIndexPattern, TileBeginWithOffsetPattern, NonePattern))
        or (isinstance(p, TensorIndexPattern) and p.index_ndim == 0)
        for p in indexing_patterns
    )
    has_contiguous_hbm_window = any(
        isinstance(pattern, ContiguousRangeIndexPattern)
        for pattern in indexing_patterns
    )
    tid = id(tensor_val)
    current = device_fn.pallas_memory_space.get(tid)
    if has_contiguous_hbm_window:
        # A dynamic contiguous range cannot be represented by a static
        # BlockSpec. Keep the source argument in HBM and stage exactly the
        # selected range at its load site.
        device_fn.pallas_memory_space[tid] = PallasMemorySpace.HBM
    elif is_all_scalar:
        # Only mark for SMEM if not already assigned to VMEM or HBM
        if current is None:
            device_fn.pallas_memory_space[tid] = PallasMemorySpace.SMEM
    else:
        # Override SMEM → VMEM: this is intentional. When a tensor has
        # both scalar and slice accesses, we keep it in VMEM because
        # scalar *reads* work from VMEM (only scalar writes require
        # SMEM). We optimistically assume the scalar access is a read.
        # Don't override HBM (pipeline tensors).
        if current != PallasMemorySpace.HBM:
            device_fn.pallas_memory_space[tid] = PallasMemorySpace.VMEM


def _analyze_subscript_patterns(
    tensor: torch.Tensor,
    subscript: list[object],
    dim_tilings: list[DimensionTiling],
    node: torch.fx.Node,
    config: Config,
) -> list[IndexingPattern]:
    """Analyze subscript patterns and create indexing pattern metadata."""
    from ..compile_environment import CompileEnvironment

    env = CompileEnvironment.current()
    patterns = _detect_subscript_patterns(tensor, subscript, node, config)
    tensor_dim = 0  # Track which tensor dimension we're indexing
    for pattern in patterns:
        if isinstance(pattern, NonePattern):
            continue
        # Update dim_tilings based on the detected pattern
        _update_tiling_decision(tensor, pattern, tensor_dim, dim_tilings, env, config)
        tensor_dim += 1
    return patterns


def _detect_subscript_patterns(
    tensor: torch.Tensor,
    subscript: list[object],
    node: torch.fx.Node,
    config: Config | None = None,
) -> list[IndexingPattern]:
    """Describe an access without applying config-dependent tiling decisions."""
    from ..compile_environment import CompileEnvironment

    env = CompileEnvironment.current()
    patterns: list[IndexingPattern] = []
    tensor_dim = 0
    for position, index in enumerate(subscript):
        if index is None:
            patterns.append(NonePattern())
            continue
        if tensor_dim >= tensor.ndim:
            raise AssertionError(
                f"Indexing {tensor_dim}th dim but tensor only has {tensor.ndim} dims"
            )
        patterns.append(
            _detect_indexing_pattern(
                index,
                tensor,
                tensor_dim,
                node,
                position,
                env,
                config,
            )
        )
        tensor_dim += 1
    return patterns


def build_pallas_memory_access(node: torch.fx.Node) -> MemoryAccess:
    """Build shared memory metadata before config-dependent tiling is available."""
    from .memory_access import build_memory_access

    tensor_node, raw_subscript = node.args[:2]
    assert isinstance(tensor_node, torch.fx.Node)
    assert isinstance(raw_subscript, (list, tuple))
    tensor = tensor_node.meta.get("val")
    assert isinstance(tensor, torch.Tensor)
    subscript = list(cast("list[object] | tuple[object, ...]", raw_subscript))
    return build_memory_access(
        node,
        tensor,
        subscript,
        _detect_subscript_patterns(tensor, subscript, node),
    )


def _is_supported_slice(idx: slice) -> bool:
    """Contiguous slices with static (int/SymInt) or open bounds."""
    if idx.step is not None and idx.step != 1:
        return False
    for bound in (idx.start, idx.stop):
        if bound is None:
            continue
        if isinstance(bound, int) and bound >= 0:
            continue
        if isinstance(bound, torch.SymInt):
            continue
        return False
    return True


def _is_scalar_value(value: object) -> bool:
    if isinstance(value, (int, torch.SymInt)):
        return True
    if isinstance(value, torch.fx.Node):
        value = value.meta.get("val")
    return isinstance(value, (int, torch.SymInt)) or (
        isinstance(value, torch.Tensor) and value.ndim == 0
    )


def _constant_int(value: object) -> int | None:
    if isinstance(value, int):
        return value
    if isinstance(value, torch.fx.Node):
        node_value = value.meta.get("val")
        if isinstance(node_value, int):
            return node_value
    return None


def _is_proven_multiple(value: object, alignment: int, config: Config | None) -> bool:
    """Conservatively prove that a scalar FX expression is alignment-multiple."""
    constant = _constant_int(value)
    if constant is not None:
        return constant % alignment == 0

    symbolic_value = (
        value.meta.get("val") if isinstance(value, torch.fx.Node) else value
    )
    if isinstance(value, torch.fx.Node) and isinstance(symbolic_value, torch.SymInt):
        from ...language import _tracing_ops
        from ..compile_environment import CompileEnvironment

        if value.target is _tracing_ops._get_symnode:
            return (
                CompileEnvironment.current().size_hint(symbolic_value) % alignment == 0
            )
    tile_begin = _maybe_get_tile_begin_with_offset_info(symbolic_value)
    if (
        config is not None
        and tile_begin is not None
        and isinstance(tile_begin.offset, int)
    ):
        from ..compile_environment import CompileEnvironment

        block_size = (
            CompileEnvironment.current()
            .block_sizes[tile_begin.block_id]
            .from_config(config)
        )
        return (
            isinstance(block_size, int)
            and block_size % alignment == 0
            and tile_begin.offset % alignment == 0
        )
    if isinstance(symbolic_value, torch.SymInt):
        from ..compile_environment import CompileEnvironment
        from ..compile_environment import _symint_expr
        from ..host_function import HostFunction

        expression = _symint_expr(symbolic_value)
        if expression is not None and all(
            (origin := HostFunction.current().expr_to_origin.get(symbol)) is not None
            and origin.origin.is_host()
            for symbol in expression.free_symbols
        ):
            return (
                CompileEnvironment.current().size_hint(symbolic_value) % alignment == 0
            )
    if not isinstance(value, torch.fx.Node) or value.op != "call_function":
        return False

    if value.target in (
        operator.add,
        torch.ops.aten.add.Scalar,
        torch.ops.aten.add.Tensor,
    ):
        if value.kwargs.get("alpha", 1) != 1:
            return False
        return all(
            _is_proven_multiple(arg, alignment, config) for arg in value.args[:2]
        )
    if value.target in (
        operator.sub,
        torch.ops.aten.sub.Scalar,
        torch.ops.aten.sub.Tensor,
    ):
        if value.kwargs.get("alpha", 1) != 1:
            return False
        return all(
            _is_proven_multiple(arg, alignment, config) for arg in value.args[:2]
        )
    if value.target in (
        operator.mul,
        torch.ops.aten.mul.Scalar,
        torch.ops.aten.mul.Tensor,
    ):
        lhs, rhs = value.args[:2]
        return _is_proven_multiple(lhs, alignment, config) or _is_proven_multiple(
            rhs, alignment, config
        )
    return False


def _may_be_aligned_tile_begin(value: object, alignment: int) -> bool:
    """Return whether a tile begin has an alignment-compatible configuration.

    Config-independent memory-access discovery runs before a concrete block size
    is selected.  At that point, recognize a tile begin as a possible direct
    HBM window when at least one legal block size provides the required
    alignment.  The config-specific pass still calls ``_is_proven_multiple``
    and rejects configurations that do not provide it.
    """
    symbolic_value = (
        value.meta.get("val") if isinstance(value, torch.fx.Node) else value
    )
    tile_begin = _maybe_get_tile_begin_with_offset_info(symbolic_value)
    if (
        tile_begin is None
        or not isinstance(tile_begin.offset, int)
        or tile_begin.offset % alignment != 0
    ):
        return False

    from ..compile_environment import CompileEnvironment
    from ..compile_environment import FixedBlockSizeSource

    env = CompileEnvironment.current()
    block_id = env.canonical_block_id(tile_begin.block_id)
    source = env.block_sizes[block_id].block_size_source
    if isinstance(source, FixedBlockSizeSource):
        block_size = env.try_concretize_symint(source.value)
        return isinstance(block_size, int) and block_size % alignment == 0
    try:
        spec = env.config_spec.block_sizes.block_id_lookup(block_id)
    except KeyError:
        return False
    # Block-size choices are powers of two.  Therefore a maximum at least as
    # large as this power-of-two alignment guarantees that an aligned choice
    # exists in the search space.
    return spec.max_size >= alignment


def _iota_length(node: object) -> int | None:
    if (
        not isinstance(node, torch.fx.Node)
        or node.op != "call_function"
        or node.target is not torch.ops.prims.iota.default
    ):
        return None
    start = node.kwargs.get("start", 0)
    step = node.kwargs.get("step", 1)
    if start != 0 or step != 1 or len(node.args) != 1:
        return None
    length = node.args[0]
    if isinstance(length, torch.fx.Node):
        length = length.meta.get("val")
    if isinstance(length, torch.SymInt):
        from ..compile_environment import CompileEnvironment

        length = CompileEnvironment.current().size_hint(length)
    return length if isinstance(length, int) and length > 0 else None


def _match_contiguous_range_index(
    node: torch.fx.Node,
    tensor: torch.Tensor,
    tensor_dim: int,
    load_value: object,
    config: Config | None,
) -> ContiguousRangeIndexPattern | None:
    """Match an aligned scalar base plus an explicit unit-stride ``hl.arange``."""
    from ..host_function import HostFunction

    origin = HostFunction.current().tensor_to_origin.get(tensor)
    if (
        origin is None
        or node.op != "call_function"
        or node.target
        not in (operator.add, torch.ops.aten.add.Scalar, torch.ops.aten.add.Tensor)
        or len(node.args) != 2
        or node.kwargs.get("alpha", 1) != 1
    ):
        return None
    if not isinstance(load_value, torch.Tensor):
        return None
    from ..compile_environment import CompileEnvironment

    env = CompileEnvironment.current()
    load_shape = tuple(
        env.size_hint(size) if isinstance(size, torch.SymInt) else size
        for size in load_value.shape
    )
    if not all(isinstance(size, int) for size in load_shape):
        return None
    from .dma import is_tpu_dma_aligned_shape

    if not is_tpu_dma_aligned_shape(load_shape, tensor.dtype):
        return None
    bitwidth = min(tensor.dtype.itemsize * 8, 32)
    if tensor.ndim == 1:
        alignment = 128 * (32 // bitwidth)
    elif tensor_dim == tensor.ndim - 1:
        alignment = 128
    elif tensor_dim == tensor.ndim - 2:
        alignment = 8
    else:
        alignment = 1
    lhs, rhs = node.args
    for base, iota in ((lhs, rhs), (rhs, lhs)):
        length = _iota_length(iota)
        if length is None or length % alignment != 0:
            continue
        if not isinstance(base, (int, torch.SymInt, torch.fx.Node)):
            continue
        if not _is_scalar_value(base):
            continue
        aligned = _is_proven_multiple(base, alignment, config)
        if config is None and not aligned:
            aligned = _may_be_aligned_tile_begin(base, alignment)
        if not aligned:
            continue
        value = node.meta.get("val")
        if (
            isinstance(value, torch.Tensor)
            and value.ndim == 1
            and value.shape[0] == length
        ):
            return ContiguousRangeIndexPattern(
                base=base,
                length=length,
                alignment=alignment,
            )
    return None


def _detect_indexing_pattern(
    idx: object,
    tensor: torch.Tensor,
    tensor_dim: int,
    node: torch.fx.Node,
    subscript_index: int,
    env: CompileEnvironment,
    config: Config | None = None,
) -> IndexingPattern:
    """Detect the specific indexing pattern for a subscript element."""
    from ..indexing_strategy import _get_tile_with_offset_info
    from ..variable_origin import GridOrigin

    if isinstance(idx, torch.fx.Node):
        idx_val = idx.meta.get("val")
        if isinstance(idx_val, torch.SymInt):
            block_id = env.get_block_id(idx_val)
            if block_id is not None:
                symbol_origin = _maybe_get_symbol_origin(idx_val)
                is_hl_grid = symbol_origin is not None and isinstance(
                    symbol_origin.origin, GridOrigin
                )
                if not is_hl_grid:
                    return TilePattern(block_id=block_id)

        tile_with_offset = _get_tile_with_offset_info(idx_val, node, subscript_index)
        if tile_with_offset is not None:
            return TileIndexWithOffsetPattern(
                block_id=tile_with_offset.block_id, offset=tile_with_offset.offset
            )

        # Check for TileBeginWithOffset pattern (t.begin, t.end-1)
        tile_begin_with_offset = _maybe_get_tile_begin_with_offset_info(idx_val)
        if tile_begin_with_offset is not None:
            return TileBeginWithOffsetPattern(
                block_id=tile_begin_with_offset.block_id,
                offset=tile_begin_with_offset.offset,
            )
        from ...language import memory_ops

        if node.target is memory_ops.load:
            contiguous_range = _match_contiguous_range_index(
                idx,
                tensor,
                tensor_dim,
                node.meta.get("val"),
                config,
            )
            if contiguous_range is not None:
                return contiguous_range

        # A tensor-valued index that didn't match any arithmetic-of-tile
        # pattern is an indirect gather (e.g. table[idx, :]).
        if isinstance(idx_val, torch.Tensor):
            return TensorIndexPattern(index_ndim=idx_val.ndim)
        # Indices produced by other FX nodes, such as indices[tile] used in
        # tensor-indexed atomics, are legal but cannot participate in Pallas
        # tiling.
        return ArbitraryIndexPattern(idx)

    if isinstance(idx, slice):
        if not _is_supported_slice(idx):
            raise exc.BackendUnsupported("pallas", f"slice expr {idx!r}")
        return ArbitrarySlicePattern(idx)

    if isinstance(idx, (int, torch.SymInt)):
        return ArbitraryIndexPattern(idx)

    raise AssertionError(f"Unrecognized indexing pattern for pallas backend {idx}")


def _update_tiling_decision(
    tensor: torch.Tensor,
    pattern: IndexingPattern,
    tensor_dim: int,
    dim_tilings: list[DimensionTiling],
    env: CompileEnvironment,
    config: Config,
) -> None:
    """Update tiling decision based on the detected indexing pattern."""

    curr_dim_tiling = dim_tilings[tensor_dim]

    def _disallow_tiling() -> None:
        curr_dim_tiling.can_tile = False

    def _try_set_tiling_block_id(new_block_id: int) -> None:
        if new_block_id not in curr_dim_tiling.block_ids:
            curr_dim_tiling.block_ids.append(new_block_id)
            if len(curr_dim_tiling.block_ids) > 1:
                # we already need to tile this dim using a different block_id
                # so fallback to no-tiling so that we can access using both tiles
                _disallow_tiling()

    if isinstance(pattern, TilePattern):
        _try_set_tiling_block_id(pattern.block_id)

    elif isinstance(pattern, TileIndexWithOffsetPattern):
        _disallow_tiling()

    elif isinstance(pattern, TileBeginWithOffsetPattern):
        _try_set_tiling_block_id(pattern.block_id)
        # check bounds
        if not isinstance(pattern.offset, int) or pattern.offset < 0:
            _disallow_tiling()
        else:
            block_size = env.block_sizes[pattern.block_id].from_config(config)
            if isinstance(block_size, int) and pattern.offset >= block_size:
                _disallow_tiling()

    elif isinstance(pattern, ArbitrarySlicePattern):
        if pattern.slice != slice(None):
            # bounded slice: fixed subrange of the dim, must stay untiled
            _disallow_tiling()

    elif isinstance(
        pattern,
        (ArbitraryIndexPattern, ContiguousRangeIndexPattern, TensorIndexPattern),
    ):
        _disallow_tiling()

    elif isinstance(pattern, NonePattern):
        pass

    if isinstance(pattern, (TilePattern, TileBeginWithOffsetPattern)):
        block_size = env.block_sizes[pattern.block_id].from_config(config)
        if isinstance(block_size, int):
            from ..compile_environment import CompileEnvironment

            backend = CompileEnvironment.current().backend
            from helion._compiler.backend import PallasBackend

            assert isinstance(backend, PallasBackend)

            dim_from_end = tensor.ndim - tensor_dim - 1
            bitwidth = tensor.dtype.itemsize * 8
            required_alignment = backend._get_pallas_required_alignment(
                dim_from_end, tensor.ndim, bitwidth
            )

            if (
                block_size < tensor.shape[tensor_dim]
                and block_size % required_alignment != 0
            ):
                _disallow_tiling()


def resident_block_elements(
    tensor: torch.Tensor,
    patterns: list[IndexingPattern],
    config: Config,
) -> int | None:
    """Element count of the VMEM-resident block for one tensor access.

    Walks ``patterns`` alongside the tensor dims. Per-dim contribution:
      - ``NonePattern``: skipped (broadcast axis, no tensor dim consumed).
      - ``TilePattern`` / ``TileIndexWithOffsetPattern``: configured
        ``block_size``, clamped to the full dim extent.
      - ``TileBeginWithOffsetPattern`` / ``ArbitraryIndexPattern``: scalar
        index, contributes 1.
      - ``ContiguousRangeIndexPattern``: its fixed range length.
      - Anything else (full slice, indirect tensor index): the full dim extent.

    Returns ``None`` if any consumed dim is symbolic.
    """
    from ..compile_environment import CompileEnvironment

    env = CompileEnvironment.current()
    return _resident_block_elements(
        tensor,
        patterns,
        lambda block_id: env.block_sizes[block_id].from_config(config),
    )


def minimum_resident_block_elements(
    node: torch.fx.Node,
    tensor: torch.Tensor,
    subscript: list[object] | tuple[object, ...],
    block_size_minimums: dict[int, int],
) -> int | None:
    """Minimum resident elements permitted by any block-size configuration."""
    from ..compile_environment import CompileEnvironment

    env = CompileEnvironment.current()
    patterns: list[IndexingPattern] = []
    tensor_dim = 0
    for position, index in enumerate(subscript):
        if tensor_dim >= tensor.ndim:
            return None
        pattern = _detect_indexing_pattern(
            index,
            tensor,
            tensor_dim,
            node,
            position,
            env,
        )
        patterns.append(pattern)
        if not isinstance(pattern, NonePattern):
            tensor_dim += 1
    patterns.extend(
        ArbitrarySlicePattern(slice(None)) for _ in range(tensor_dim, tensor.ndim)
    )

    def minimum_block_size(block_id: int) -> int:
        from ..compile_environment import FixedBlockSizeSource

        canonical_id = env.canonical_block_id(block_id)
        if minimum := block_size_minimums.get(canonical_id):
            return minimum
        source = env.block_sizes[canonical_id].block_size_source
        if isinstance(source, FixedBlockSizeSource):
            value = env.try_concretize_symint(source.value)
            if isinstance(value, int):
                return value
        # Unknown non-tunable sources cannot prove structural impossibility.
        return 1

    return _resident_block_elements(
        tensor,
        patterns,
        minimum_block_size,
    )


def _resident_block_elements(
    tensor: torch.Tensor,
    patterns: list[IndexingPattern],
    block_size_for: Callable[[int], int | torch.SymInt | None],
) -> int | None:
    elements = 1
    tdim = 0
    for p in patterns:
        if isinstance(p, NonePattern):
            continue
        dim_size = tensor.shape[tdim]
        if not isinstance(dim_size, int):
            # No support for dynamic shapes.
            return None
        if isinstance(p, (TilePattern, TileIndexWithOffsetPattern)):
            bs = block_size_for(p.block_id)
            if isinstance(bs, int):
                dim_size = min(bs, dim_size)
        elif isinstance(p, (TileBeginWithOffsetPattern, ArbitraryIndexPattern)):
            dim_size = 1
        elif isinstance(p, ContiguousRangeIndexPattern):
            dim_size = p.length
        elements *= dim_size
        # Advance only on patterns that consume a tensor dim; NonePattern doesn't.
        tdim += 1
    return elements


# Helper functions moved from memory_ops.py
def _maybe_get_symbol_origin(idx: object) -> SymbolOrigin | None:
    """Get symbol origin for a subscript element."""
    from ..compile_environment import _symint_expr
    from ..host_function import HostFunction

    if not isinstance(idx, torch.SymInt):
        return None
    expr = _symint_expr(idx)
    if expr is None:
        return None
    return HostFunction.current().expr_to_origin.get(expr)


def _maybe_get_tile_begin_with_offset_info(
    idx: object,
) -> TileBeginWithOffsetPattern | None:
    """Extended version that allows out-of-bounds and symbolic offsets.

    Matches expressions that resolve to a tile's start offset within the
    full loop extent (e.g. ``tile.begin``, ``tile.end - 1``, or affine
    combinations of those with integer constants).
    """
    from ..compile_environment import CompileEnvironment
    from ..compile_environment import _symint_expr
    from ..host_function import HostFunction
    from ..host_function import SymbolOrigin
    from ..variable_origin import GridOrigin
    from ..variable_origin import TileBeginOrigin
    from ..variable_origin import TileEndOrigin
    from ..variable_origin import TileIdOrigin

    idx_symbol_origin = _maybe_get_symbol_origin(idx)
    if isinstance(idx_symbol_origin, SymbolOrigin):
        if isinstance(idx_symbol_origin.origin, TileBeginOrigin):
            return TileBeginWithOffsetPattern(
                block_id=idx_symbol_origin.origin.block_id, offset=0
            )
        if isinstance(idx_symbol_origin.origin, GridOrigin) and not isinstance(
            idx_symbol_origin.origin, (TileEndOrigin, TileIdOrigin)
        ):
            return TileBeginWithOffsetPattern(
                block_id=idx_symbol_origin.origin.block_id, offset=0
            )

    if not isinstance(idx, torch.SymInt):
        return None
    expr = _symint_expr(idx)
    if not isinstance(expr, sympy.Expr):
        return None

    args = expr.args
    origin: TileBeginOrigin | TileEndOrigin | GridOrigin | None = None
    offset = 0

    for arg in args:
        assert isinstance(arg, sympy.Expr)
        if (
            symbol_origin := HostFunction.current().expr_to_origin.get(arg)
        ) is not None:
            if isinstance(
                symbol_origin.origin, (GridOrigin, TileBeginOrigin, TileEndOrigin)
            ):
                if origin is not None:
                    # Multiple tile offset expressions - result is out of current tile
                    return None
                origin = symbol_origin.origin
            else:
                return None
        elif arg.is_constant():
            evalf_result = arg.evalf()
            f_value = float(evalf_result)  # type: ignore[arg-type]
            if not f_value.is_integer():
                return None
            offset += int(f_value)
        else:
            # pyrefly: ignore [bad-argument-type]
            offset = torch.SymInt(arg)
            break

    env = CompileEnvironment.current()
    if origin is None:
        return None

    block_id = origin.block_id

    if isinstance(origin, TileEndOrigin):
        block_size = env.block_sizes[block_id].size
        if isinstance(block_size, int) and isinstance(offset, int):
            offset = block_size + offset  # Starting from end
        else:
            # For non-integer block sizes or offsets, fall back to symbolic offset
            offset = torch.SymInt(f"{block_size} + {offset}")  # type: ignore[arg-type]

    return TileBeginWithOffsetPattern(block_id=block_id, offset=offset)
