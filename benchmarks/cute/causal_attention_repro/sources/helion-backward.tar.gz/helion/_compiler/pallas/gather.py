"""Pallas one-hot gather/scatter planning and fallback lowering."""

from __future__ import annotations

import ast
from dataclasses import dataclass
from typing import TYPE_CHECKING

import torch

from ..ast_extension import expr_from_string

if TYPE_CHECKING:
    from ...runtime.config import Config
    from ..inductor_lowering import CodegenState
    from .memory_access import MemoryAccess
    from .plan_tiling import IndexingPattern


def one_hot_access_supported(access: MemoryAccess) -> bool:
    """Whether one-hot lowering supports the access independent of tiling."""
    from .memory_access import MemoryAccessKind
    from .memory_access import memory_access_mask
    from .memory_access import tensor_index_positions

    positions = tensor_index_positions(access)
    if len(positions) != 1 or memory_access_mask(access) is not None:
        return False
    position = positions[0]
    if access.kind is MemoryAccessKind.LOAD:
        return access.tensor.dtype.is_floating_point or (
            position == 0 and access.tensor.dtype == torch.int32
        )
    if access.kind is not MemoryAccessKind.STORE:
        return False
    index = access.subscript[position]
    index_value = index.meta.get("val") if isinstance(index, torch.fx.Node) else None
    return (
        access.tensor.dtype.is_floating_point
        and position == 0
        and isinstance(index_value, torch.Tensor)
        and index_value.ndim == 1
    )


# Fail early on oversized tables instead of a generic Mosaic OOM.
# Replace with real VMEM budget accounting once available.
_GATHER_VMEM_THRESHOLD_BYTES: int = 16 << 20  # 16 MiB


def one_hot_access_may_fit_vmem(
    node: torch.fx.Node,
    tensor: torch.Tensor,
    subscript: list[object] | tuple[object, ...],
    block_size_minimums: dict[int, int],
) -> bool:
    """Whether some tiling could keep a one-hot access below the VMEM guard.

    Unknown symbolic extents are left to per-config planning rather than
    rejecting the kernel structurally.
    """
    from .plan_tiling import minimum_resident_block_elements

    resident_elements = minimum_resident_block_elements(
        node,
        tensor,
        subscript,
        block_size_minimums,
    )
    return (
        resident_elements is None
        or resident_elements * tensor.dtype.itemsize <= _GATHER_VMEM_THRESHOLD_BYTES
    )


@dataclass(frozen=True)
class GatherPlan:
    indirect_pos: int
    none_dims: tuple[int, ...]
    jnp_dtype: str
    table_ndim: int
    index_ndim: int
    emit_select: bool
    use_highest_precision: bool


@dataclass(frozen=True)
class ScatterPlan:
    indirect_pos: int
    jnp_dtype: str
    target_ndim: int
    index_ndim: int


def build_gather_plan(
    tensor: torch.Tensor,
    subscript: list[object] | tuple[object, ...],
    indirect_positions: list[int],
    patterns: list[IndexingPattern],
    config: Config,
    has_extra_mask: bool,
) -> GatherPlan:
    """Validate the gather site and return its plan. Runs during plan_tiling."""
    from ..compile_environment import CompileEnvironment
    from .plan_tiling import resident_block_elements

    if has_extra_mask:
        raise NotImplementedError(
            "Pallas gather: extra_mask is not supported for tensor indices"
        )
    if len(indirect_positions) > 1:
        raise NotImplementedError(
            "Pallas gather: multiple indirect dims are not supported"
        )
    indirect_pos = indirect_positions[0]
    emit_select = not tensor.dtype.is_floating_point
    if emit_select and indirect_pos != 0:
        raise NotImplementedError(
            "Pallas gather: integer table gather on non-zero dim is not yet supported"
        )
    if emit_select and tensor.dtype != torch.int32:
        raise NotImplementedError(
            f"Pallas gather: integer table gather only supports torch.int32, "
            f"got {tensor.dtype}"
        )

    elements = resident_block_elements(tensor, patterns, config)
    _check_resident_block_size(
        elements * tensor.dtype.itemsize if elements is not None else None
    )

    # MXU truncates fp32 to bf16 without HIGHEST. For bf16/fp16 the truncation is a no-op.
    use_highest = tensor.dtype not in (torch.bfloat16, torch.float16)

    none_dims = tuple(i for i, idx in enumerate(subscript) if idx is None)
    jnp_dtype = CompileEnvironment.current().backend.dtype_str(tensor.dtype)
    idx_element = subscript[indirect_pos]
    index_ndim = idx_element.meta["val"].ndim  # type: ignore[union-attr]

    return GatherPlan(
        indirect_pos=indirect_pos,
        none_dims=none_dims,
        jnp_dtype=jnp_dtype,
        table_ndim=tensor.ndim,
        index_ndim=index_ndim,
        emit_select=emit_select,
        use_highest_precision=use_highest,
    )


def _check_resident_block_size(table_bytes: int | None) -> None:
    from ...exc import InvalidConfig

    if table_bytes is None or table_bytes <= _GATHER_VMEM_THRESHOLD_BYTES:
        return
    raise InvalidConfig(
        f"Pallas gather: resident block is {table_bytes} bytes, exceeds "
        f"the {_GATHER_VMEM_THRESHOLD_BYTES} byte VMEM threshold. The "
        "current codegen requires the full gather axis in VMEM; reduce "
        "V, tile the broadcast dims, or use a half-precision dtype."
    )


def build_scatter_plan(
    tensor: torch.Tensor,
    subscript: list[object] | tuple[object, ...],
    indirect_positions: list[int],
    has_extra_mask: bool,
) -> ScatterPlan:
    """Validate a Pallas scatter site and return its one-hot plan."""
    from ..compile_environment import CompileEnvironment

    if not tensor.dtype.is_floating_point:
        raise NotImplementedError(
            f"Pallas scatter: only floating-point output dtypes are supported, "
            f"got {tensor.dtype}"
        )
    if has_extra_mask:
        raise NotImplementedError(
            "Pallas scatter: extra_mask is not supported for tensor indices"
        )
    if len(indirect_positions) > 1:
        raise NotImplementedError(
            "Pallas scatter: multiple indirect dims are not supported"
        )
    indirect_pos = indirect_positions[0]
    if indirect_pos != 0:
        raise NotImplementedError("Pallas scatter: only indirect dim 0 is supported")
    idx_element = subscript[indirect_pos]
    index_ndim = idx_element.meta["val"].ndim  # type: ignore[union-attr]
    if index_ndim != 1:
        raise NotImplementedError(
            "Pallas scatter: only rank-1 tensor indices are supported"
        )
    jnp_dtype = CompileEnvironment.current().backend.dtype_str(tensor.dtype)
    return ScatterPlan(
        indirect_pos=indirect_pos,
        jnp_dtype=jnp_dtype,
        target_ndim=tensor.ndim,
        index_ndim=index_ndim,
    )


def emit_gather(
    state: CodegenState,
    plan: GatherPlan,
    name: str,
) -> ast.AST:
    """Emit ``one_hot(idx, V) @ table``.

    MXU accumulates in fp32 via ``preferred_element_type``. fp32 tables need
    HIGHEST and fp32 one_hot; bf16/fp16 stay in the table dtype (MXU truncation
    is a no-op and we avoid a VMEM upcast).

    Contracting dim is ``jnp.ndim(idx)``: one_hot adds one trailing axis.
    """
    from . import codegen as pallas_codegen

    ast_subscripts = state.ast_args[1]
    assert isinstance(ast_subscripts, list)
    ast_idx = ast_subscripts[plan.indirect_pos]
    assert isinstance(ast_idx, ast.AST)
    idx_name = state.codegen.lift(ast_idx, dce=False, prefix="index").id
    tensor = state.proxy_arg(0)
    subscript = state.proxy_arg(1)
    assert isinstance(tensor, torch.Tensor)
    assert isinstance(subscript, (list, tuple))

    parts, _ = pallas_codegen.index_parts(state, subscript, tensor)
    base_index = ", ".join(parts)
    table_expr = f"{name}[{base_index}]"

    if plan.emit_select:
        mask_expr = (
            f"jax.nn.one_hot({idx_name}[...], {name}.shape[0], dtype={plan.jnp_dtype})"
        )
        for _ in range(plan.table_ndim - 1):
            mask_expr = f"jnp.expand_dims({mask_expr}, axis=-1)"
        result = expr_from_string(
            f"jnp.sum({table_expr} * {mask_expr}, "
            f"axis=jnp.ndim({idx_name}[...])"
            f").astype({plan.jnp_dtype})"
        )
        for dim in plan.none_dims:
            result = expr_from_string(
                f"jnp.expand_dims({{result}}, axis={dim})", result=result
            )
        return result

    if plan.use_highest_precision:
        oh_dtype = "jnp.float32"
        table_dot_expr = f"{table_expr}.astype(jnp.float32)"
        precision_arg = "precision=jax.lax.Precision.HIGHEST, "
    else:
        oh_dtype = plan.jnp_dtype
        table_dot_expr = table_expr
        precision_arg = ""

    p = plan.indirect_pos
    result = expr_from_string(
        "jax.lax.dot_general("
        f"jax.nn.one_hot({idx_name}[...], {name}.shape[{p}], dtype={oh_dtype}), "
        f"{table_dot_expr}, "
        f"(((jnp.ndim({idx_name}[...]),), ({p},)), ((), ())), "
        "preferred_element_type=jnp.float32, "
        f"{precision_arg}"
        f").astype({plan.jnp_dtype})"
    )
    if p > 0:
        n = plan.index_ndim
        src = tuple(range(n, n + p))
        dst = tuple(range(p))
        result = expr_from_string(
            f"jnp.moveaxis({{result}}, {src}, {dst})", result=result
        )
    for dim in plan.none_dims:
        result = expr_from_string(
            f"jnp.expand_dims({{result}}, axis={dim})", result=result
        )
    return result


def _scatter_one_hot_name(
    state: CodegenState,
    plan: ScatterPlan,
    name: str,
) -> str:
    ast_subscripts = state.ast_args[1]
    assert isinstance(ast_subscripts, list)
    ast_idx = ast_subscripts[plan.indirect_pos]
    assert isinstance(ast_idx, ast.AST)
    idx_name = state.codegen.lift(ast_idx, dce=False, prefix="index").id
    # TODO(tcombes): investigate making the metadata into dtype,
    # currently hitting Mosaic issues with bf16 mask.
    return (
        f"jax.nn.one_hot({idx_name}[...], {name}.shape[{plan.indirect_pos}], "
        "dtype=jnp.float32)"
    )


def emit_scatter_store(
    state: CodegenState,
    plan: ScatterPlan,
    name: str,
    base_index: str,
    value: ast.AST,
) -> ast.AST:
    """Emit one Pallas program's tensor-indexed store block.

    ``base_index`` is the target block with the indirect dimension replaced by
    ``:``. For ``target[idx, cols] = value`` this is ``target[:, cols]``.

    The lowering builds:
      - ``oh``: one-hot source-lane-to-target-row map, shape ``[M, V]``.
      - ``same_output_row``/``is_lane_j_after_i``/``is_last_writer``: local duplicate
        detection. If two lanes in this program target the same row, only the
        last source lane is kept.
      - ``row_to_lane``: target-row-to-source-lane map, shape ``[V, M]``.
      - ``updates``: projected values for every row in ``base_index``.
      - ``mask``: rows touched by this program.

    The final expression is ``where(mask, updates, old_target_block)`` so
    untouched rows keep their previous value. Duplicate handling is local to
    this Pallas program; duplicate writes from different programs have the same
    unspecified winner semantics as regular parallel stores in other backends.
    """

    oh = _scatter_one_hot_name(state, plan, name)
    m = f"jnp.shape({oh})[0]"
    eye = f"jnp.eye({m}, dtype=jnp.float32)"
    is_lane_j_after_i = f"jnp.triu(jnp.ones(({m}, {m}), dtype=jnp.float32), k=1)"
    same_output_row = (
        f"jax.lax.dot_general({oh}, jnp.swapaxes({oh}, 0, 1), (((1,), (0,)), ((), ())))"
    )
    is_last_writer = f"(jnp.sum(({same_output_row}) * ({is_lane_j_after_i}), axis=1) == 0).astype(jnp.float32)"
    row_to_lane = (
        f"jax.lax.dot_general(jnp.swapaxes({oh}, 0, 1), "
        f"({eye}) * jnp.expand_dims({is_last_writer}, axis=0), "
        "(((1,), (0,)), ((), ())))"
    )
    updates = expr_from_string(
        "jax.lax.dot_general("
        f"{row_to_lane}, "
        "{value}.astype(jnp.float32), "
        "(((1,), (0,)), "
        "((), ())), "
        "preferred_element_type=jnp.float32, "
        "precision=jax.lax.Precision.HIGHEST"
        f").astype({plan.jnp_dtype})",
        value=value,
    )
    mask_expr = (
        "jax.lax.dot_general("
        f"{row_to_lane}, "
        "jnp.ones_like({value}, dtype=jnp.float32), "
        "(((1,), (0,)), ((), ()))"
        ") > 0"
    )
    return expr_from_string(
        f"jnp.where({mask_expr}, {{updates}}, {name}[{base_index}])",
        updates=updates,
        value=value,
    )
