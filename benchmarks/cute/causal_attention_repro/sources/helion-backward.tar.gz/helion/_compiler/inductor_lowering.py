from __future__ import annotations

import ast
import contextlib
import dataclasses
import functools
from operator import getitem
from typing import TYPE_CHECKING
from typing import ContextManager
from typing import NamedTuple
from typing import cast

import sympy
import torch
from torch._dynamo.convert_frame import compile_lock
from torch._inductor import config as inductor_config
from torch._inductor import ir
from torch._inductor.codegen.simd import SIMDKernelFeatures
from torch._inductor.codegen.triton import TritonKernel
from torch._inductor.graph import GraphLowering
from torch._inductor.ir import ComputedBuffer
from torch._inductor.ir import FixedLayout
from torch._inductor.ir import InputBuffer
from torch._inductor.ir import Pointwise
from torch._inductor.ir import Reduction
from torch._inductor.ir import StorageBox
from torch._inductor.ir import TensorBox
from torch._inductor.lowering import to_dtype
from torch._inductor.ops_handler import DefaultHandler
from torch._inductor.utils import triton_type
from torch._inductor.virtualized import OpsValue
from torch._inductor.virtualized import V
from torch._ops import OpOverload
from torch.fx._lazy_graph_module import _LazyGraphModule
from torch.fx.experimental import proxy_tensor
from torch.fx.experimental.sym_node import SymNode
from torch.fx.interpreter import Interpreter
from torch.fx.node import Argument
from torch.fx.node import Node
from torch.fx.node import map_arg

from .. import exc
from ..exc import InductorLoweringError
from ..language._decorators import APIFunc
from ..language._decorators import is_api_func
from .ast_extension import ExtendedAST
from .ast_extension import create
from .ast_extension import expr_from_string
from .ast_extension import statement_from_string
from .aten_lowering import Lowering
from .aten_lowering import LoweringContext
from .aten_lowering import _should_use_cute_argreduce_lowering
from .aten_lowering import aten_lowering_dispatch
from .compile_environment import CompileEnvironment
from .compile_environment import FixedBlockSizeSource
from .compile_environment import _symint_expr
from .compile_environment import _symint_sympy_expr
from .cute.cute_reshape import REBOUND_CHECK_TARGETS
from .cute.cute_reshape import check_pointwise_rebound_block_ids
from .cute.view_subtile import check_view_coord_consumers
from .device_function import VarInfo
from .device_function import contains_only_block_size_symbols
from .node_masking import inductor_masked_value
from .node_masking import mask_node_inputs

if TYPE_CHECKING:
    from collections.abc import Callable
    from collections.abc import Iterator

    from torch.utils._ordered_set import OrderedSet

    from .. import Config
    from .backend import InductorOpOverrides
    from .cute.layout import MatmulAxisModel
    from .cute.layout import MatmulExecutionPlan
    from .cute.layout import ThreadLayout
    from .device_function import DeviceFunction
    from .device_ir import GraphInfo
    from .generate_ast import GenerateAST
    from .helper_function import CodegenInterface
    from .tile_dispatch import TileStrategyDispatch


def _patched_inductor_config() -> contextlib.AbstractContextManager[None]:
    settings = CompileEnvironment.current().settings
    patch: dict[str, object] = {
        # Allow implicit upcasts to FP32 for elementwise math correctness
        "triton.codegen_upcast_to_fp32": True,
        # Ensure Inductor preserves reductions (even tiny ones) as Reduction IR
        # so we can attach ReductionLowering instead of seeing pointwise fusions.
        "split_reductions": False,
        "unroll_reductions_threshold": 1,
    }
    if settings.fast_math:
        patch["use_fast_math"] = True
    return inductor_config.patch(patch)


def prepare_graph_lowerings(graph: torch.fx.Graph) -> None:
    with compile_lock:
        graph_lowering = GraphLowering(
            _LazyGraphModule({}, graph),
            shape_env=CompileEnvironment.current().shape_env,
        )

        with V.set_graph_handler(graph_lowering):
            for node in graph.nodes:
                assert node.op in {
                    "call_function",
                    "placeholder",
                    "output",
                }, node.op
                if node.op == "call_function":
                    with node.meta["location"]:
                        prepare_node_lowering(graph_lowering, node)
                        lowering = node.meta.get("lowering")
                        if isinstance(lowering, PointwiseLowering):
                            # Catch the missing-keepdim broadcast bug at graph
                            # build time (backend- and config-independent) so it
                            # is rejected consistently on every backend, before
                            # any config-specific validation or codegen.
                            lowering._check_reduction_broadcast_keepdim(node)


@functools.cache
def _functional_twins() -> dict[OpOverload, OpOverload]:
    """In-place aten overloads Inductor lowers, mapped to the functional
    overloads they mutate with (``aten.mul_.Tensor`` -> ``aten.mul.Tensor``).

    A tensor mutated inside the device loop is an SSA value: ``make_fx`` rebinds
    it to the in-place node's output, so lowering that node as its functional
    twin keeps every later read correct.  Inductor's own in-place lowerings
    (``register_inplace`` -> ``mutate_to``) hand back the mutated *input*
    buffer, which fails the ``ComputedBuffer`` check in
    ``prepare_node_lowering`` since PyTorch nightly stopped swinging a realized
    buffer's data pointer onto the new value.  Only pairs Inductor can lower on
    both sides are mapped; anything else keeps its original lowering.
    """
    from torch._inductor.lowering import lowerings

    by_name = {
        (op._schema.name, op._overloadname): op
        for op in lowerings
        if isinstance(op, OpOverload)
    }
    twins: dict[OpOverload, OpOverload] = {}
    for (name, overload), op in by_name.items():
        if name.endswith("_") and not name.endswith("__"):
            twin = by_name.get((name[:-1], overload))
            if twin is not None:
                twins[op] = twin
    return twins


# Torch computes these with a Python scalar operand at the op's opmath dtype
# (float32 for fp16/bf16 math) instead of rounding the scalar to the op's
# dtype first, as it does for comparisons, ``where``, ``pow`` and friends.
_OPMATH_SCALAR_TARGETS = {
    torch.ops.aten.add.Tensor,
    torch.ops.aten.sub.Tensor,
    torch.ops.aten.mul.Tensor,
    torch.ops.aten.div.Tensor,
}


def opmath_scalar_dtype(node: Node) -> torch.dtype | None:
    """The fp16/bf16 dtype of ``node`` when it combines a SymFloat or SymInt
    (a Python host scalar) with 16-bit tensors and torch computes it at
    float32 opmath, otherwise None.

    Such a node keeps the scalar at float32 and rounds its result to this
    dtype, as a static-shape literal scalar does.
    """
    if node.target not in _OPMATH_SCALAR_TARGETS or not any(
        isinstance(arg, Node)
        and isinstance(arg.meta["val"], (torch.SymFloat, torch.SymInt))
        for arg in node.args
    ):
        return None
    tensors = InductorLowering.input_fake_tensors(node)
    if not tensors:
        return None
    dtype = functools.reduce(torch.promote_types, [t.dtype for t in tensors])
    if dtype not in (torch.float16, torch.bfloat16):
        return None
    return dtype


def _rounded_result_dtype(node: Node) -> torch.dtype | None:
    """The 16-bit dtype ``node``'s float32 result is rounded to, as eager
    rounds it before the next op, or None to leave it as computed."""
    if (dtype := opmath_scalar_dtype(node)) is not None:
        # The float32 scalar promoted the math to float32.
        return dtype
    if node.target is torch.ops.aten.reciprocal.default:
        # Lowered as 1.0 / x with a float32 1.0.
        dtype = node.meta["val"].dtype
        if dtype in (torch.float16, torch.bfloat16):
            return dtype
    return None


def prepare_node_lowering(
    graph_lowering: GraphLowering,
    node: Node,
) -> None:
    if is_api_func(api := node.target):
        APIFuncLowering.normalize_args_kwargs(api, node)
        node.meta["lowering"] = APIFuncLowering(api)
        return

    inplace_dtype: torch.dtype | None = None
    if (twin := _functional_twins().get(node.target)) is not None:  # pyrefly: ignore [bad-argument-type]
        # ``x.mul_(y)`` lowers as ``aten.mul``; the in-place result keeps the
        # dtype of ``x`` where the functional op would promote.
        node.target = twin
        inplace_dtype = node.meta["val"].dtype

    backend_lowering = CompileEnvironment.current().backend.pre_inductor_lowering(node)
    if backend_lowering is not None:
        node.meta["lowering"] = backend_lowering
        return

    if node.target in aten_lowering_dispatch:
        if node.target in {
            torch.ops.aten.argmax.default,
            torch.ops.aten.argmin.default,
        } and not _should_use_cute_argreduce_lowering(node):
            pass
        else:
            node.meta["lowering"] = aten_lowering_dispatch[node.target](node)
            return

    if isinstance(
        val := node.meta["val"], (torch.SymInt, torch.SymFloat, torch.SymBool)
    ):
        # SymBool's `_sympy_()` is a boolean rather than the Expr the field holds.
        # pyrefly: ignore [bad-argument-type]
        node.meta["lowering"] = SympyExprLowering(val._sympy_())
        return

    # Track arguments to reuse names for duplicates
    arg_to_name: dict[Node, str] = {}
    opmath_dtype = opmath_scalar_dtype(node)

    def convert_arg(arg: Node) -> TensorBox:
        example = arg.meta["val"]

        # Reuse existing name for duplicate arguments
        if arg in arg_to_name:
            name = arg_to_name[arg]
        else:
            name = f"{node.name}_input{len(input_names)}"
            arg_to_name[arg] = name
            input_names.append(name)

        if isinstance(example, (torch.SymInt, torch.SymFloat, torch.SymBool)):
            dtype = {
                torch.SymInt: torch.int64,
                torch.SymFloat: torch.float32,
                torch.SymBool: torch.bool,
            }[type(example)]
            if (
                isinstance(example, (torch.SymFloat, torch.SymInt))
                and opmath_dtype is not None
            ):
                # Typed as the op's dtype, promotion leaves it unrounded; the
                # kernel value is float32 (see opmath_scalar_dtype).
                dtype = opmath_dtype
            input_layouts[name] = ([], [])
            result = TensorBox.create(
                InputBuffer(
                    name=name,
                    layout=FixedLayout(
                        CompileEnvironment.current().device,
                        dtype,
                        [],
                        [],
                    ),
                )
            )
        else:
            assert isinstance(example, torch.Tensor), (
                f"Expected Tensor, got {type(example)}: {node.target}"
            )
            size = [*map(_unpack_symint, example.size())]
            stride = [*map(_unpack_symint, example.stride())]
            input_layouts[name] = (size, stride)
            result = TensorBox.create(
                InputBuffer(
                    name=name,
                    layout=FixedLayout(example.device, example.dtype, size, stride),
                )
            )
        assert isinstance(result, TensorBox)
        return result

    prior_buffers = len(graph_lowering.buffers)
    input_names: list[str] = []
    input_layouts: dict[str, tuple[list[sympy.Expr], list[sympy.Expr]]] = {}
    with _patched_inductor_config():
        with node.meta["location"], graph_lowering.set_current_node(node):
            try:
                result = graph_lowering.call_function(
                    # pyrefly: ignore [bad-argument-type]
                    node.target,
                    # pyrefly: ignore [bad-argument-type]
                    *map_arg((node.args, node.kwargs), convert_arg),
                )
            # pyrefly: ignore [implicit-import]
            except torch._inductor.exc.LoweringException as e:
                # Wrap in Helion exception to get location automatically
                raise InductorLoweringError(str(e)) from e
            if inplace_dtype is not None and result.get_dtype() != inplace_dtype:
                result = to_dtype(result, inplace_dtype)
        if not isinstance(result, tuple):
            result = (result,)
        buffer_name_to_output_index = {}
        for i, r in enumerate(result):
            r.realize()
            if not isinstance(r, TensorBox) or not isinstance(r.data, StorageBox):
                raise InductorLoweringError(
                    f"Lowering {node.target} returned {type(r)}, expected TensorBox(StorageBox(...)): {r}"
                )
            if not isinstance(buffer := r.data.data, ComputedBuffer):
                raise InductorLoweringError(
                    f"Lowering {node.target} returned buffer type {type(buffer)}, expected ComputedBuffer: {buffer}"
                )
            buffer_name_to_output_index[buffer.get_name()] = i

    new_buffers = graph_lowering.buffers[prior_buffers:]
    # pyrefly: ignore [unbound-name]
    assert buffer in new_buffers
    nodes = []
    extra_input_names = []
    new_node: torch.fx.Node

    # Explicitly track the mapping from node to Inductor buffer name.
    # First, map the original input nodes to their names.
    node_to_buf_name_mapping: dict[torch.fx.Node, str] = dict(
        zip(node._input_nodes, input_names, strict=True)
    )

    for i, buffer in enumerate(new_buffers):
        if not isinstance(buffer, ComputedBuffer) or not isinstance(
            buffer.data, (Pointwise, Reduction)
        ):
            raise InductorLoweringError(
                f"Lowering {node.target} returned buffer type {type(buffer)}, expected ComputedBuffer(Pointwise|Reduction): {buffer}"
            )
        if i == len(new_buffers) - 1:
            new_node = node
            if nodes:
                new_node.kwargs = {**new_node.kwargs, "_extra_args": [*nodes]}
        else:
            new_node = create_extra_node(node, buffer, [*node._input_nodes, *nodes])

        # Store output index if this buffer corresponds to an output
        if buffer.get_name() in buffer_name_to_output_index:
            new_node.meta["output_index"] = buffer_name_to_output_index[
                buffer.get_name()
            ]

        lowering_cls = (
            PointwiseLowering
            if isinstance(buffer.data, Pointwise)
            else ReductionLowering
        )
        buffer.freeze_layout()

        current_input_nodes = new_node._input_nodes
        current_input_names = []
        for inp_node in current_input_nodes:
            current_input_names.append(node_to_buf_name_mapping[inp_node])

        used_input_names = strip_unused_inputs(
            new_node,
            buffer.get_read_names(),
            dict(zip(current_input_nodes, current_input_names, strict=True)),
        )
        new_node.meta["lowering"] = lowering = lowering_cls(buffer, used_input_names)
        lowering.input_layouts = input_layouts
        new_node.meta["orig_node"] = node
        if isinstance(lowering, ReductionLowering):
            lowering.add_input_mask(new_node)
        nodes.append(new_node)
        extra_input_names.append(buffer.get_name())

        # Add this node to our mapping for future nodes to reference
        node_to_buf_name_mapping[new_node] = buffer.get_name()

    # After all nodes are created, build the output_nodes mapping for multi-output operations
    if len(result) > 1 and nodes:
        last_node = nodes[-1]  # The last node is the main node
        output_nodes = {}
        extra_deps = []
        for n in nodes:
            if "output_index" in n.meta:
                output_nodes[n.meta["output_index"]] = n.name
                if n is not last_node and n not in last_node._input_nodes:
                    extra_deps.append(n)
        last_node.meta["output_nodes"] = output_nodes
        if extra_deps:
            # Need to ensure that the last node depends on all output nodes to prevent DCE issues
            last_node.kwargs = {**last_node.kwargs, "_extra_deps": extra_deps}


def strip_unused_inputs(
    node: torch.fx.Node,
    used_input_names: OrderedSet[str],
    input_names: dict[torch.fx.Node, str],
) -> list[str]:
    """
    Remove unused inputs from the node.  Inplace updates node.args and
    node.kwargs to replace unused inputs with None.

    Args:
        node: Node to mutate args of
        used_input_names: Set of input names that are used in the node's lowering.
        input_names: Mapping of node inputs to their names.

    Returns:
        list[str]: List of names that were used in the lowering.
    """

    def mask_unused_inputs(n: torch.fx.Node) -> torch.fx.Node | None:
        if (name := input_names[n]) in used_input_names and name not in seen_names:
            seen_names.setdefault(name)
            return n
        return None

    assert len(input_names) == len(node._input_nodes)
    seen_names: dict[str, None] = {}
    node.args = map_arg(node.args, mask_unused_inputs)
    node.kwargs = map_arg(node.kwargs, mask_unused_inputs)
    assert len(seen_names) == len(used_input_names)
    return [*seen_names]


def create_extra_node(
    original_node: torch.fx.Node,
    buffer: ComputedBuffer,
    input_nodes: list[torch.fx.Node],
) -> torch.fx.Node:
    """When inductor lowerings produce multiple buffers,
    we add extra nodes to maintain a 1:1 mapping between fx nodes and buffers."""
    from ..language._tracing_ops import _inductor_lowering_extra

    graph = original_node.graph
    with graph.inserting_before(original_node):
        node = graph.create_node(
            "call_function",
            _inductor_lowering_extra,
            (input_nodes,),
            {},
            name=f"{original_node.name}_extra",
        )
    with proxy_tensor.disable_proxy_modes_tracing():
        node.meta["val"] = torch.empty(
            # pyrefly: ignore [no-matching-overload]
            [*map(to_symint, buffer.get_size())],
            dtype=buffer.get_dtype(),
            device=buffer.get_device(),
        )
    for key in ("stack_trace", "original_aten", "location"):
        node.meta[key] = original_node.meta.get(key, None)
    return node


def to_symint(x: object) -> torch.SymInt | int:
    if isinstance(x, (int, sympy.Integer)):
        return int(x)
    assert isinstance(x, sympy.Expr)
    return torch.SymInt(
        SymNode(x, CompileEnvironment.current().shape_env, int, hint=None)
    )


def _unpack_symint(x: torch.SymInt | int) -> sympy.Expr:
    if isinstance(x, torch.SymInt):
        return _symint_sympy_expr(x)
    if isinstance(x, int):
        # type: ignore [bad-return]
        return sympy.sympify(x)
    raise TypeError(f"Expected SymInt or int, got {type(x)}")


@dataclasses.dataclass
class InductorLowering(Lowering):
    buffer: ComputedBuffer
    input_names: list[str]
    # Size and stride of each node input the inner function loads, by name.
    input_layouts: dict[str, tuple[list[sympy.Expr], list[sympy.Expr]]] = (
        dataclasses.field(default_factory=dict)
    )

    def input_asts(self, ctx: LoweringContext, node: torch.fx.Node) -> list[ast.AST]:
        def visit(n: torch.fx.Node) -> None:
            ast_val = cast("ast.AST", ctx.env[n])
            if isinstance(fake_val := n.meta["val"], torch.Tensor):
                # Don't expand scalars (0-D tensors) - let Triton handle broadcasting naturally
                # Expanding scalars with [None, None] creates incorrect broadcast shapes
                # The expands_broadcast_dims() check lets FlyDSL skip the
                # Triton-style [None, :] expand its per-thread vectors don't need.
                if (
                    fake_val.ndim < ndim
                    and fake_val.ndim > 0
                    and CompileEnvironment.current().backend.expands_broadcast_dims()
                ):
                    expand = tile_strategy.broadcast_expand_dims(
                        tuple(fake_val.shape), output_shape
                    )
                    if expand:
                        ast_val = expr_from_string(
                            "{tensor}[" + ", ".join(expand) + "]",
                            tensor=ast_val,
                        )
            elif isinstance(fake_val, torch.SymFloat):
                ast_val = backend.scalar_float_operand_ast(
                    ast_val, fake_val, computes_in_float64=computes_in_float64
                )
            elif isinstance(fake_val, torch.SymInt) and opmath_dtype is not None:
                # An integer would take the 16-bit operand's type.
                ast_val = backend.cast_ast(ast_val, torch.float32)
            if (
                isinstance(ast_val, ast.Name)
                and ast_val.id in device_function._constexpr_args
            ):
                # introduce a copy so triton doesn't complain about `id.to(...)` calls
                assert isinstance(ast_val, ExtendedAST)
                with ast_val:
                    copy_var = device_function.new_var(f"{ast_val.id}_", dce=True)
                    ctx.cg.add_statement(
                        statement_from_string(f"{copy_var} = {ast_val.id}")
                    )
                    input_asts.append(expr_from_string(f"{copy_var}"))
            else:
                input_asts.append(ast_val)

        device_function: DeviceFunction = ctx.cg.device_function
        tile_strategy = device_function.tile_strategy
        backend = CompileEnvironment.current().backend
        output_shape: tuple[int | torch.SymInt, ...] = tuple(
            map(to_symint, self.buffer.get_size())
        )
        ndim: int = len(output_shape)
        # A SymFloat input is a float32 0-d tensor (see ``convert_arg``),
        # which promotes to float64 alongside a float64 tensor.
        computes_in_float64 = any(
            isinstance(val, torch.Tensor) and val.dtype == torch.float64
            for val in (node.meta["val"], *self.input_fake_tensors(node))
        )
        opmath_dtype = opmath_scalar_dtype(node)
        input_asts: list[ast.AST] = []
        # _extra_deps should not be included in the inductor node inputs
        map_arg((node.args, {**node.kwargs, "_extra_deps": None}), visit)
        assert len(input_asts) == len(self.input_names)
        return input_asts

    @staticmethod
    def input_fake_tensors(node: torch.fx.Node) -> list[torch.Tensor]:
        def visit(n: torch.fx.Node) -> torch.fx.Node:
            if isinstance(val := n.meta["val"], torch.Tensor):
                result.append(val)
            return n

        result: list[torch.Tensor] = []
        map_arg((node.args, node.kwargs), visit)
        return result

    def codegen(self, ctx: LoweringContext, node: torch.fx.Node) -> object:
        raise NotImplementedError(
            f"codegen not implemented for {type(self).__name__}: {self.buffer}"
        )

    def install_kernel_handlers(
        self, ctx: LoweringContext, node: torch.fx.Node
    ) -> ContextManager[None]:
        return install_inductor_kernel_handlers(
            ctx.cg,
            dict(zip(self.input_names, self.input_asts(ctx, node), strict=True)),
        )


@contextlib.contextmanager
def install_inductor_kernel_handlers(
    cg: CodegenInterface,
    args: dict[str, ast.AST],
    load_check: Callable[[str, sympy.Expr], None] | None = None,
) -> Iterator[None]:
    with (
        _patched_inductor_config(),
        V.set_graph_handler(FakeGraphLowering()),
        V.set_ops_handler(GenerateASTFromInductor(cg, args, load_check)),
        V.set_kernel_handler(
            TritonKernel({}, features=SIMDKernelFeatures([], sympy.S.One))
        ),
    ):
        yield


@functools.cache
def dummy_gm() -> torch.fx.GraphModule:
    return torch.fx.symbolic_trace(lambda: None)


class FakeGraphLowering(GraphLowering):
    def __init__(self) -> None:
        env = CompileEnvironment.current()
        super().__init__(dummy_gm(), shape_env=env.shape_env)
        # Ensure Inductor helpers see a valid current device
        self.current_device = env.device


class PointwiseLowering(InductorLowering):
    def codegen(self, ctx: LoweringContext, node: torch.fx.Node) -> object:
        if (
            node.target is torch.ops.aten.clone.default
            and CompileEnvironment.current().backend_name == "cute"
        ):
            from .cute.cute_reshape import codegen_cute_virtual_clone

            if (result := codegen_cute_virtual_clone(ctx, node)) is not None:
                return result
        return self.codegen_from_input_asts(ctx, node, self.input_asts(ctx, node))

    def codegen_from_input_asts(
        self,
        ctx: LoweringContext,
        node: torch.fx.Node,
        input_asts: list[ast.AST],
        *,
        kernel_handlers: ContextManager[None] | None = None,
    ) -> object:
        """Lower this pointwise node with explicitly supplied tensor values."""
        # Validate broadcasting of tile block dimensions to catch shape mismatches
        self._check_block_broadcast_compatibility(ctx, node)
        assert len(input_asts) == len(self.input_names)
        indices = [sympy.Symbol(f"i{n}") for n in range(len(self.buffer.data.ranges))]
        with (
            install_inductor_kernel_handlers(
                ctx.cg,
                dict(zip(self.input_names, input_asts, strict=True)),
                load_check=functools.partial(
                    self._check_position_preserving_load, node, indices
                ),
            )
            if kernel_handlers is None
            else kernel_handlers
        ):
            output_name = _unpack_opsvalue(self.buffer.data.inner_fn(indices))
            result = expr_from_string(output_name)
        if (dtype := _rounded_result_dtype(node)) is not None:
            result = CompileEnvironment.current().backend.cast_ast(result, dtype)

        return self._reshape_for_size1_reduction(ctx, node, result, input_asts)

    def _check_position_preserving_load(
        self,
        node: torch.fx.Node,
        indices: list[sympy.Symbol],
        name: str,
        index: sympy.Expr,
    ) -> None:
        """Refuse a load of a node input at another position than the output's.

        Every backend lowers an element-wise node from the values its inputs
        hold at the output element's position (``GenerateASTFromInductor.load``
        returns the input's value whatever the index).  That is right when the
        index walks the input's own dims in order: ``sum(stride[d] * i[k])``
        over its dims of extent > 1, each with its own output variable and in
        the same order (broadcasting right-aligns them, a size-1 reduction
        turned element-wise keeps the other dims), with no offset.  An
        index-remapping decomposition (``torch.flip`` reads ``n - 1 - i``,
        ``torch.rot90``, a padded or shifted read, a gather) would silently
        compute the identity.  Loads of buffers produced inside the same
        lowering are inductor's own and not checked.
        """
        if name not in self.input_layouts:
            return
        size, stride = self.input_layouts[name]
        ranges = self.buffer.data.ranges
        variables = set(indices)
        unit = {
            var: 0 for var, extent in zip(indices, ranges, strict=True) if extent == 1
        }
        constant: sympy.Expr = sympy.S.Zero
        coefficients: dict[sympy.Symbol, sympy.Expr] = {}
        linear = True
        for term in sympy.Add.make_args(sympy.expand(index.xreplace(unit))):
            # The terms of an index expression are expressions.
            term = cast("sympy.Expr", term)
            used = term.free_symbols & variables
            if not used:
                constant = sympy.Add(constant, term)
                continue
            if len(used) != 1:
                linear = False
                break
            var = cast("sympy.Symbol", next(iter(used)))
            coefficient = sympy.Mul(term, sympy.Pow(var, -1))
            if coefficient.free_symbols & variables:
                linear = False
                break
            coefficients[var] = sympy.Add(
                coefficients.get(var, sympy.S.Zero), coefficient
            )
        walked = [
            coefficient
            for var in indices
            if (coefficient := coefficients.get(var, sympy.S.Zero)) != 0
        ]
        dims = [
            step
            for extent, step in zip(size, stride, strict=True)
            if extent != 1 and step != 0
        ]
        shape_env = CompileEnvironment.current().shape_env
        if not (
            linear
            and len(walked) == len(dims)
            and shape_env.simplify(constant) == 0
            and all(
                shape_env.simplify(sympy.Add(coefficient, sympy.Mul(-1, step))) == 0
                for coefficient, step in zip(walked, dims, strict=True)
            )
        ):
            raise exc.UnsupportedIndexRemapping(
                op=node.meta.get("orig_node", node).target, index=index
            )

    def _reshape_for_size1_reduction(
        self,
        ctx: LoweringContext,
        node: torch.fx.Node,
        result: ast.AST,
        input_asts: list[ast.AST] | None = None,
    ) -> ast.AST:
        # When Inductor converts a size-1 reduction to a Pointwise op, the
        # buffer has fewer ranges than the inputs.  This happens when the
        # literal 1 comes from ops like unsqueeze or keepdim=True (e.g.,
        # val.unsqueeze(0).sum(0) where val is [D] — the unsqueeze creates
        # [1, D], Inductor sees sum over literal-1 dim, converts to Pointwise
        # with ranges [D], but the inner_fn still produces a 2-D value).
        # Reshape the result to match the expected output shape.
        output_val = node.meta.get("val")
        if (
            not ctx.cg.device_function.tile_strategy.supports_index_rank_expansion()
            and isinstance(output_val, torch.Tensor)
            and output_val.ndim > len(self.buffer.data.ranges)
        ):
            # Cute lowers one element per thread, so synthetic size-1 view dims
            # (from unsqueeze/keepdim paths rewritten to pointwise) must collapse
            # back to the underlying scalar expression.
            inputs = (
                input_asts if input_asts is not None else self.input_asts(ctx, node)
            )
            if len(inputs) == 1:
                return inputs[0]

        max_input_ndim = max(
            (inp.ndim for inp in self.input_fake_tensors(node)), default=0
        )
        if max_input_ndim > len(self.buffer.data.ranges) and isinstance(
            output_val, torch.Tensor
        ):
            shape_str = ctx.cg.device_function.tile_strategy.shape_str(
                [*output_val.size()]
            )
            result = expr_from_string(
                CompileEnvironment.current().backend.reshape_expr(
                    "{result}", shape_str
                ),
                result=result,
            )
        return result

    def get_masked_value(self, node: torch.fx.Node) -> float | bool | None:
        return inductor_masked_value(self, node)

    def _check_block_broadcast_compatibility(
        self, ctx: LoweringContext, node: torch.fx.Node
    ) -> None:
        """Detect invalid broadcasting between tile-related dimensions in pointwise ops.

        This guards against patterns like subtracting a reduced tensor without
        keepdim from a 2D tile, which would otherwise silently broadcast along
        the wrong axis (e.g., [M, N] - [M] -> [M, N] by aligning on N).

        We right-align shapes and then, per-dimension, verify that there aren't
        two distinct non-1 symbolic sizes that are not known-equal. This is more
        robust than relying solely on block-id provenance and works even if
        upstream rewrites introduced fresh symbolic expressions.
        """
        env = CompileEnvironment.current()
        inputs = self.input_fake_tensors(node)
        if len(inputs) < 2:
            return

        # Right-align shapes for broadcasting comparison
        shapes: list[list[int | torch.SymInt]] = [[*t.size()] for t in inputs]
        max_rank = max((len(s) for s in shapes), default=0)
        for i, s in enumerate(shapes):
            pad = max_rank - len(s)
            if pad > 0:
                shapes[i] = [1] * pad + s

        def is_one(x: int | torch.SymInt) -> bool:
            if isinstance(x, int):
                return x == 1
            if isinstance(x, torch.SymInt):
                expr = _symint_expr(x)
                if isinstance(expr, sympy.Integer):
                    return int(expr) == 1
                # Treat tiles with a fixed block size of 1 as broadcastable-1
                block_id = env.get_block_id(x)
                if block_id is not None:
                    bs = env.block_sizes[block_id]
                    if isinstance(bs.block_size_source, FixedBlockSizeSource):
                        val = bs.block_size_source.value
                        if isinstance(val, int):
                            return val == 1
                        if isinstance(val, torch.SymInt):
                            vexpr = _symint_expr(val)
                            return isinstance(vexpr, sympy.Integer) and int(vexpr) == 1
                return False
            return False

        def block_sizes_proven_equal(block_ids: set[int]) -> bool:
            block_infos = [env.block_sizes[bid] for bid in block_ids]
            block_symbols = [info.symbol() for info in block_infos]
            base_symbol = block_symbols[0]
            if all(base_symbol == symbol for symbol in block_symbols[1:]):
                return True

            known_config_sizes = [
                size
                for info in block_infos
                if isinstance(
                    size := info.from_config(ctx.cg.device_function.config),
                    (int, torch.SymInt),
                )
            ]
            if len(known_config_sizes) == len(block_infos):
                base_config_size = known_config_sizes[0]
                if all(
                    env.known_equal(base_config_size, size)
                    for size in known_config_sizes[1:]
                ):
                    return True

            known_sizes = [
                info.size
                for info in block_infos
                if isinstance(info.size, (int, torch.SymInt))
            ]
            if len(known_sizes) != len(block_infos):
                return False
            base_size = known_sizes[0]
            return all(env.known_equal(base_size, size) for size in known_sizes[1:])

        # Check each dimension independently
        for dim in range(max_rank):
            non_one_sizes = [s[dim] for s in shapes if not is_one(s[dim])]
            if non_one_sizes:
                base_size = non_one_sizes[0]
                if all(
                    isinstance(size_i, (int, torch.SymInt))
                    and env.known_equal(base_size, size_i)
                    for size_i in non_one_sizes[1:]
                ):
                    continue

            # First, see if multiple distinct block-ids appear in this dim
            block_ids: set[int] = set()
            for s in shapes:
                size_i = s[dim]
                if is_one(size_i):
                    continue
                block_id = env.resolve_block_id(size_i)
                if block_id is not None:
                    block_ids.add(env.canonical_block_id(block_id))
            if len(block_ids) >= 2:
                if not block_sizes_proven_equal(block_ids):
                    raise exc.ShapeMismatch(
                        str(shapes[0]),
                        ", ".join(map(str, shapes[1:])),
                    )
                continue

            # Otherwise, fall back to strict symbolic inequality among non-1 sizes
            exprs: set[object] = set()
            for s in shapes:
                size_i = s[dim]
                if is_one(size_i):
                    continue
                block_id = env.resolve_block_id(size_i)
                if block_id is not None:
                    exprs.add(
                        env.block_sizes[env.canonical_block_id(block_id)].symbol()
                    )
                    continue
                if isinstance(size_i, torch.SymInt):
                    expr = _symint_expr(size_i)
                    exprs.add(env.specialize_expr(expr) if expr is not None else size_i)
                else:
                    exprs.add(size_i)
            if len(exprs) >= 2:
                raise exc.ShapeMismatch(
                    str(shapes[0]),
                    ", ".join(map(str, shapes[1:])),
                )

    def _check_reduction_broadcast_keepdim(self, node: torch.fx.Node) -> None:
        """Reject a reduction result broadcast against a *different* tile axis.

        This is the missing-``keepdim`` bug: e.g.
        ``x[tile_m, :] - torch.amax(x[tile_m, :], dim=1)`` drops the reduced N
        axis, then the surviving M axis is right-aligned onto N (``[M, N] - [M]``).
        It is rejected on **every** backend at graph-build time (so the error is
        config- and backend-independent), unlike the size-coincidence leniency in
        :meth:`_check_block_broadcast_compatibility` which would otherwise let
        ``[M, N] - [M]`` through whenever the M and N block sizes happen to match.

        The check is gated on an operand actually being a reduction result, so it
        does **not** touch structurally-identical but legitimately-handled
        patterns such as matmul-epilogue column-vector / aux-tensor broadcasts
        (``acc + colvec[tile_m]``), which the backend's epilogue classifier owns
        and rejects with its own actionable diagnostics.
        """
        env = CompileEnvironment.current()
        if not any(
            isinstance(inp.meta.get("lowering"), ReductionLowering)
            for inp in node.all_input_nodes
        ):
            return
        inputs = self.input_fake_tensors(node)
        if len(inputs) < 2:
            return

        shapes: list[list[int | torch.SymInt]] = [[*t.size()] for t in inputs]
        max_rank = max((len(s) for s in shapes), default=0)
        for i, s in enumerate(shapes):
            pad = max_rank - len(s)
            if pad > 0:
                shapes[i] = [1] * pad + s

        def is_one(x: int | torch.SymInt) -> bool:
            if isinstance(x, int):
                return x == 1
            expr = _symint_expr(x)
            if isinstance(expr, sympy.Integer):
                return int(expr) == 1
            block_id = env.get_block_id(x)
            if block_id is not None:
                bs = env.block_sizes[block_id]
                if isinstance(bs.block_size_source, FixedBlockSizeSource):
                    val = bs.block_size_source.value
                    if isinstance(val, int):
                        return val == 1
                    vexpr = _symint_expr(val) if isinstance(val, torch.SymInt) else None
                    return isinstance(vexpr, sympy.Integer) and int(vexpr) == 1
            return False

        for dim in range(max_rank):
            symbols: set[object] = set()
            for s in shapes:
                size_i = s[dim]
                if is_one(size_i):
                    continue
                block_id = env.resolve_block_id(size_i)
                if block_id is not None:
                    symbols.add(
                        env.block_sizes[env.canonical_block_id(block_id)].symbol()
                    )
            # Two *distinct* tile axes aligned in the same broadcast position is a
            # wrong-axis (missing-keepdim) reduction broadcast, even when their
            # current sizes coincide.
            if len(symbols) >= 2:
                raise exc.ShapeMismatch(
                    str(shapes[0]),
                    ", ".join(map(str, shapes[1:])),
                )


@dataclasses.dataclass
class ReductionLowering(InductorLowering):
    def __init__(
        self,
        buffer: ComputedBuffer,
        input_names: list[str],
    ) -> None:
        super().__init__(buffer, input_names)
        reduction = self.buffer.data
        assert isinstance(reduction, Reduction)
        reduction_ranges = reduction.reduction_ranges
        if len(reduction_ranges) != 1:
            # TODO(jansel): can this happen?
            raise NotImplementedError("multiple reduction dimensions")
        # In Inductor IR, reduction_ranges holds sizes, not loop vars.
        # Support both symbolic and constant sizes by allocating/looking up
        # a matching reduction dimension in the current environment.
        reduction_size = reduction_ranges[0]

        env = CompileEnvironment.current()
        if isinstance(reduction_size, sympy.Symbol):
            block_index: int | None = env.get_block_id(reduction_size)
        elif isinstance(reduction_size, (int, sympy.Integer)):
            # Allocate or find a reduction dimension matching this size.
            # Convert to a SymInt when needed.
            size_symint_or_int = to_symint(reduction_size)
            block_index = env.allocate_reduction_dimension(size_symint_or_int).block_id
        elif isinstance(reduction_size, sympy.Expr):
            # Handle symbolic expressions (including those with only block size symbols)
            if contains_only_block_size_symbols(reduction_size):
                size_symint = to_symint(reduction_size)
                block_index = env.allocate_reduction_dimension(size_symint).block_id
            else:
                raise exc.ReductionOnNonTile(reduction_size)
        else:
            raise exc.ReductionOnNonTile(reduction_size)
        assert block_index is not None
        self.block_index: int = block_index

    @property
    def reduction_type(self) -> str:
        reduction = self.buffer.data
        assert isinstance(reduction, Reduction)
        return reduction.reduction_type

    def add_input_mask(self, node: torch.fx.Node) -> None:
        """Modify the node to apply masking for the reduction if needed."""
        reduction_type = self.reduction_type
        input_dtype = None
        for inp in node.all_input_nodes:
            if isinstance(inp.meta["val"], torch.Tensor):
                input_dtype = inp.meta["val"].dtype
                break
        assert input_dtype is not None
        default = ir.Reduction.default_accumulator(reduction_type, input_dtype)
        assert isinstance(default, (float, int, bool))
        mask_node_inputs(node, default)

    def codegen(self, ctx: LoweringContext, node: torch.fx.Node) -> object:
        if CompileEnvironment.current().backend.name == "cute":
            from .cute.completed_matmul_sum import completed_matmul_sum_input

            completed = completed_matmul_sum_input(ctx, node)
            if completed is not None:
                return completed
        reduction = self.buffer.data
        assert isinstance(reduction, Reduction)
        indices = [sympy.Symbol(f"i{n}") for n in range(len(reduction.ranges))]
        reduction_indices = [
            sympy.Symbol(f"i{n}")
            for n in range(len(indices), len(indices) + len(reduction.reduction_ranges))
        ]
        with self.install_kernel_handlers(ctx, node):
            # codegen the pointwise part before reduction
            output_name = _unpack_opsvalue(
                self.buffer.data.inner_fn(indices, reduction_indices)
            )

        from .generate_ast import GenerateAST

        if not isinstance(ctx.cg, GenerateAST):
            raise exc.NotAllowedInHelperFunction

        state = CodegenState(
            ctx.cg,
            fx_node=node,
        )
        inputs = self.input_fake_tensors(node)

        if len(inputs) == 1:
            repr_input = inputs[0]
        elif node.meta["orig_node"].target == torch.ops.aten.var_mean.correction:
            assert len(inputs) == 2
            # `inputs[0]` is the original input tensor to var_mean
            repr_input = inputs[0]
        else:
            # TODO(jansel): combine multiple inputs into a single fake value
            raise NotImplementedError("reductions with >1 input")

        dims = self._get_reduction_dims(node.meta["orig_node"], repr_input)
        if len(dims) != 1:
            # TODO(jansel): support multiple reduction dims
            raise exc.MultipleReductionDims

        env = CompileEnvironment.current()

        def match_active_block_id(size: object) -> int | None:
            candidates: set[int] = set()
            block_id = env.resolve_block_id(size)
            if block_id is not None:
                block_id = env.resolve_codegen_block_id(
                    block_id,
                    state.codegen,
                    node.graph,
                )
                if state.codegen.active_device_loops.get(block_id) or (
                    state.codegen.device_function.tile_strategy.thread_axis_for_block_id(
                        block_id
                    )
                    is not None
                ):
                    candidates.add(block_id)
            for strategy in state.codegen.device_function.tile_strategy.strategies:
                for candidate_block_id in strategy.block_ids:
                    if (
                        state.codegen.device_function.tile_strategy.thread_axis_for_block_id(
                            candidate_block_id
                        )
                        is None
                    ):
                        continue
                    candidate_size = env.block_sizes[candidate_block_id].size
                    candidate_source = getattr(
                        env.block_sizes[candidate_block_id].block_size_source,
                        "value",
                        None,
                    )
                    if (
                        isinstance(size, torch.SymInt)
                        and isinstance(candidate_source, torch.SymInt)
                        and candidate_source._sympy_() == size._sympy_()
                    ):
                        candidates.add(candidate_block_id)
                        continue
                    if isinstance(size, (int, torch.SymInt)) and isinstance(
                        candidate_size, (int, torch.SymInt)
                    ):
                        if env.known_equal(candidate_size, size):
                            candidates.add(candidate_block_id)

            seen: set[int] = set()
            for loops in state.codegen.active_device_loops.values():
                for loop_state in loops:
                    key = id(loop_state)
                    if key in seen:
                        continue
                    seen.add(key)
                    for candidate_block_id, info in loop_state.block_id_to_info.items():
                        if isinstance(
                            size, (int, torch.SymInt)
                        ) and info.is_end_matching(size):
                            candidates.add(candidate_block_id)
            if len(candidates) == 1:
                return next(iter(candidates))
            return None

        active_block_id = (
            match_active_block_id(repr_input.size(dims[0]))
            if env.backend.name == "cute"
            and not env.block_sizes[self.block_index].reduction
            else None
        )
        if active_block_id is not None:
            from .reduction_strategy import BlockReductionStrategy

            strategy = BlockReductionStrategy(state, active_block_id)
        elif env.block_sizes[self.block_index].reduction:
            strategy = ctx.cg.device_function.tile_strategy.get_reduction_strategy(
                self.block_index
            )
        else:
            from .reduction_strategy import BlockReductionStrategy

            strategy = BlockReductionStrategy(state, self.block_index)

        env.backend.validate_reduction_input(strategy.block_index, repr_input)
        from .reduction_strategy import cute_mark_cross_block_vec_lanes

        cute_mark_cross_block_vec_lanes(state, strategy.block_index)
        result_ast = strategy.codegen_reduction(
            state,
            output_name,
            reduction.reduction_type,
            dims[0],
            repr_input,
            node.meta["val"],
        )
        # For looped reductions, the actual value is assigned after the loop in
        # the strategy's outer_suffix. Casting at this point would reference the
        # result before it is defined. The strategy is responsible for casting
        # to the final dtype in that case.
        from .reduction_strategy import (
            LoopedReductionStrategy,
        )  # local import to avoid cycles

        if isinstance(strategy, LoopedReductionStrategy):
            # Mark this node as having a delayed result so downstream codegen can
            # avoid emitting an early assignment or dtype assert.
            node.meta["delayed_result"] = True
            return result_ast

        # Non-looped reductions compute the value inline; cast now to ensure the
        # result dtype matches torch.* semantics reflected in meta["val"].dtype.
        desired_dtype = node.meta["val"].dtype
        return CompileEnvironment.current().backend.cast_ast(result_ast, desired_dtype)

    def get_masked_value(self, node: torch.fx.Node) -> float | bool | None:
        # reduction types that preserve zeroness
        if self.reduction_type in {"sum", "prod", "min", "max"}:
            value = inductor_masked_value(self, node)
            if value == 0:
                return value
        return None

    @staticmethod
    def _get_reduction_dims(node: torch.fx.Node, fake_input: torch.Tensor) -> list[int]:
        if fake_input.ndim == 1:
            return [0]

        dims = node.kwargs.get("dim", node.kwargs.get("dims"))
        if dims is None:
            schema = node.meta["original_aten"]._schema
            assert isinstance(schema, torch._C.FunctionSchema)
            for index, arg in enumerate(schema.arguments):
                if arg.name in {"dim", "dims"}:
                    dims = (
                        node.args[index]
                        if index < len(node.args)
                        else arg.default_value
                    )
                    break
            if dims is None:
                dims = [*range(fake_input.ndim)]

        if not isinstance(dims, (list, tuple)):
            dims = [dims]

        result = []
        for dim in dims:
            if not isinstance(dim, (int, sympy.Integer)):
                raise exc.InvalidReductionDim(dim)
            dim = int(dim)
            if dim < 0:
                dim = fake_input.ndim + dim
            if not (0 <= dim < fake_input.ndim):
                raise exc.ReductionDimInvalidForShape(dim, fake_input.shape)
            result.append(dim)
        return result


class APIFuncLowering(Lowering):
    def __init__(self, api_func: object) -> None:
        super().__init__()
        assert is_api_func(api_func)
        self.api_func: APIFunc = api_func

    def codegen(self, ctx: LoweringContext, node: torch.fx.Node) -> object:
        assert not node.kwargs
        ast_args = [*map_arg(node.args, lambda arg: ctx.env[arg])]
        proxy_args = [*map_arg(node.args, lambda arg: arg.meta["val"])]

        env = CompileEnvironment.current()
        try:
            codegen_fn = self.api_func._codegen[env.codegen_name]
        except KeyError:
            raise exc.BackendImplementationMissing(
                env.backend_name,
                f"codegen for API function {self.api_func.__qualname__}",
            ) from None
        from .generate_ast import GenerateAST

        if not isinstance(ctx.cg, GenerateAST):
            raise exc.NotAllowedInHelperFunction

        return codegen_fn(
            CodegenState(
                ctx.cg,
                fx_node=node,
                env=ctx.env,
                # pyrefly: ignore [bad-argument-type]
                proxy_args=proxy_args,
                # pyrefly: ignore [bad-argument-type]
                ast_args=ast_args,
            ),
        )

    @staticmethod
    def normalize_args_kwargs(
        api_func: APIFunc,
        node: torch.fx.Node,
    ) -> None:
        bound = api_func._signature.bind(*node.args, **node.kwargs)
        bound.apply_defaults()
        node.args = (*bound.arguments.values(),)
        node.kwargs = {}

    def get_masked_value(self, node: torch.fx.Node) -> float | bool | None:
        if self.api_func._get_masked_value is not None:
            return self.api_func._get_masked_value(node)
        return None


@dataclasses.dataclass
class SympyExprLowering(Lowering):
    expr: sympy.Expr

    def codegen(self, ctx: LoweringContext, node: torch.fx.Node) -> object:
        return expr_from_string(ctx.cg.device_function.user_sympy_expr(self.expr))

    def get_masked_value(self, node: torch.fx.Node) -> float | bool | None:
        if isinstance(self.expr, sympy.Integer):
            return int(self.expr)
        if isinstance(self.expr, sympy.Float):
            return float(self.expr)
        return None


_PLAIN_TRUE_DIVISION_TARGETS: frozenset[object] = frozenset(
    {
        torch.ops.aten.div.Tensor,
        torch.ops.aten.div.Scalar,
        torch.ops.aten.true_divide.Tensor,
        torch.ops.aten.true_divide.Scalar,
    }
)
_MODE_DIVISION_TARGETS: frozenset[object] = frozenset(
    {torch.ops.aten.div.Tensor_mode, torch.ops.aten.div.Scalar_mode}
)


def _is_plain_true_division(node: torch.fx.Node) -> bool:
    """Whether ``node`` is a true division whose quotient is the node's result.

    ``div(..., rounding_mode=None)`` counts; ``trunc``/``floor`` modes, floor
    division and remainder lower their quotient into a rounding step inside the
    same node, so an approximate quotient would change the integer result.
    """
    target = node.target
    if target in _PLAIN_TRUE_DIVISION_TARGETS:
        return True
    if target in _MODE_DIVISION_TARGETS:
        rounding_mode = node.kwargs.get("rounding_mode")
        if rounding_mode is None and len(node.args) > 2:
            rounding_mode = node.args[2]
        return rounding_mode is None
    return False


class GenerateASTFromInductor(DefaultHandler):
    def __init__(
        self,
        cg: CodegenInterface,
        input_name_lookup: dict[str, ast.AST],
        load_check: Callable[[str, sympy.Expr], None] | None = None,
    ) -> None:
        super().__init__()
        self.parent_handler: InductorOpOverrides = (
            CompileEnvironment.current().backend.inductor_op_overrides()
        )
        self.cg = cg
        self.input_name_lookup = input_name_lookup
        self.load_check = load_check

    def _cast_ast(self, x: ast.AST, target_dtype: torch.dtype) -> ast.AST:
        backend = CompileEnvironment.current().backend
        return backend.cast_ast(x, target_dtype)

    def _cast_scalar_ast(self, x: ast.AST, target_dtype: torch.dtype) -> ast.AST:
        # Cast a bare scalar (e.g. lifted from an index expr). Backends whose
        # cast syntax needs a runtime object override cast_scalar_ast; the base
        # default uses cast_ast.
        backend = CompileEnvironment.current().backend
        return backend.cast_scalar_ast(x, target_dtype)

    def _to_ast(self, x: object) -> ast.AST:
        if isinstance(x, ast.AST):
            return x
        return expr_from_string(_unpack_opsvalue(x))

    def _lift(self, expr: ast.AST) -> str:
        return self.cg.lift(expr).id

    def _expected_tensor_dtype(self) -> torch.dtype | None:
        """Best-effort retrieval of the current FX node's tensor dtype."""
        current_node = V.current_node
        if current_node is None:
            return None
        val = current_node.meta.get("val")
        if isinstance(val, torch.Tensor):
            return val.dtype
        return None

    def _create_cast_expr(self, x: object, target_dtype: torch.dtype) -> ast.AST:
        """Create a backend cast expression from AST or string input.

        Args:
            x: Input value (AST node or string/OpsValue)
            target_dtype: Target dtype

        Returns:
            AST expression for the cast operation
        """
        x_ast = self._to_ast(x)
        return self._cast_ast(x_ast, target_dtype)

    def _maybe_cast_to_expected_dtype(self, expr: ast.AST) -> ast.AST:
        """Cast expression to expected dtype if needed.

        Args:
            expr: Input expression to potentially cast

        Returns:
            Original or casted expression
        """
        expected_dtype = self._expected_tensor_dtype()
        if expected_dtype is None:
            return expr
        return self._create_cast_expr(expr, expected_dtype)

    def _default(
        self, name: str, args: tuple[object, ...], kwargs: dict[str, object]
    ) -> str:
        result_str = _unpack_opsvalue(
            getattr(self.parent_handler, name)(*args, **kwargs)
        )
        # C++ namespace syntax (::) is not valid Python.  Replace with dot
        # notation so expr_from_string can parse it as attribute access.
        if CompileEnvironment.current().backend_name == "metal" and "::" in result_str:
            result_str = result_str.replace("::", ".")
        return self._lift(expr_from_string(result_str))

    def to_dtype(
        self,
        x: object,
        dtype: torch.dtype,
        src_dtype: torch.dtype | None = None,
        use_compute_types: bool = True,
    ) -> str:
        """Emit explicit backend cast to enforce final dtype conversion.

        We avoid delegating to the parent handler to prevent reliance on global
        device context during compute-type selection, and to guarantee a visible
        cast in generated code that matches PyTorch's dtype semantics.
        """
        if (
            CompileEnvironment.current().backend.name == "cute"
            and src_dtype is torch.float8_e4m3fn
            and dtype is torch.float32
        ):
            cast_expr = expr_from_string(
                "_cute_fp8e4m3fn_to_float32({x})",
                x=self._to_ast(x),
            )
            return self._lift(cast_expr)
        cast_expr = self._create_cast_expr(x, dtype)
        return self._lift(cast_expr)

    def sigmoid(self, x: object) -> str:  # type: ignore[override]
        if CompileEnvironment.current().backend.codegen_name != "triton":
            return self._default("sigmoid", (x,), {})

        # Triton sigmoid expects fp32/fp64 inputs; enforce fp32 compute, then cast back.
        inner_name = self._lift(self._create_cast_expr(x, torch.float32))

        env = CompileEnvironment.current()
        if env.settings.fast_math and env.backend.name == "triton":
            # libdevice's fast_dividef / fast_expf exist on the Triton backend
            # only; TileIR shares the Triton codegen and keeps the exact form.
            result = expr_from_string(
                f"fast_dividef(1.0, 1.0 + fast_expf(-{inner_name}))"
            )
        else:
            result = expr_from_string(
                _unpack_opsvalue(self.parent_handler.sigmoid(inner_name))
            )

        expected_dtype = self._expected_tensor_dtype()
        if expected_dtype is not None and expected_dtype != torch.float32:
            result = self._maybe_cast_to_expected_dtype(result)
        return self._lift(result)

    def truediv(self, a: object, b: object) -> str:  # type: ignore[override]
        """Divide; under ``fast_math`` the Triton backend takes the approximate divide.

        Triton's ``/`` on fp32 is ``div.full.f32`` (2 ulp over the full range).
        ``fast_dividef`` is ``div.approx.ftz.f32``: cheaper at the same 2 ulp,
        but a subnormal divisor gives +-inf, a subnormal quotient flushes to
        zero and a divisor above 2**126 gives 0, so it is only emitted when the
        ``fast_math`` setting opts the kernel into approximations -- the same
        contract the CuTe backend follows (IEEE divide by default, approximate
        reciprocal multiply under the setting).  It is emitted only for the
        plain true divisions (``aten.div`` without a rounding mode); a quotient
        that feeds ``trunc``/``floor`` in the same node must be exact, so the
        rounding-mode divisions, ``floor_divide`` and ``remainder`` keep the
        default.  Like Triton's ``/``, the result stays fp32 (half-precision
        and integer operands are promoted to fp32 first); the consumer casts.
        TileIR shares the Triton codegen but has no libdevice ``fast_dividef``,
        so it keeps the exact divide under the setting.
        """
        env = CompileEnvironment.current()
        if env.backend.name != "triton" or not env.settings.fast_math:
            return self._default("truediv", (a, b), {})
        node = V.current_node
        if node is None or not _is_plain_true_division(node):
            return self._default("truediv", (a, b), {})
        if self._expected_tensor_dtype() not in (
            torch.float32,
            torch.float16,
            torch.bfloat16,
        ):
            return self._default("truediv", (a, b), {})
        return self._lift(
            expr_from_string(
                "fast_dividef({a}, {b})",
                a=self._create_cast_expr(a, torch.float32),
                b=self._create_cast_expr(b, torch.float32),
            )
        )

    def rsqrt(self, x: object) -> str:  # type: ignore[override]
        backend_name = CompileEnvironment.current().backend_name
        if backend_name == "cute":
            suffix = (
                ", fastmath=True"
                if CompileEnvironment.current().settings.fast_math
                else ""
            )
            return self._lift(
                expr_from_string(f"cute.math.rsqrt({{x}}{suffix})", x=self._to_ast(x))
            )
        if backend_name == "pallas":
            return self._lift(expr_from_string("lax.rsqrt({x})", x=self._to_ast(x)))
        try:
            return self._default("rsqrt", (x,), {})
        except NotImplementedError:
            # Some backend op handlers do not implement rsqrt directly.
            # Fall back to reciprocal(sqrt(x)) so lowering remains backend-agnostic.
            return self.reciprocal(self.sqrt(x))

    def _integer_shift(self, name: str, x: object, y: object) -> str:
        dtype = self._expected_tensor_dtype()
        if (
            dtype is None
            or CompileEnvironment.current().backend_name != "cute"
            or dtype
            not in (
                torch.int8,
                torch.uint8,
                torch.int16,
                torch.uint16,
            )
        ):
            return self._default(name, (x, y), {})
        # CuTe promotes a narrow integer combined with a Python shift count
        # to Int32. Torch truncates each tensor operation to its result dtype,
        # before any subsequent shift or conversion.
        result = _unpack_opsvalue(getattr(self.parent_handler, name)(x, y))
        return self._lift(self._create_cast_expr(expr_from_string(result), dtype))

    def bitwise_left_shift(self, x0: object, x1: object) -> str:
        return self._integer_shift("bitwise_left_shift", x0, x1)

    def bitwise_right_shift(self, x0: object, x1: object) -> str:
        return self._integer_shift("bitwise_right_shift", x0, x1)

    def neg(self, x: object) -> str:  # type: ignore[override]
        if CompileEnvironment.current().backend_name != "cute":
            return self._default("neg", (x,), {})
        return self._lift(expr_from_string("-({x})", x=self._to_ast(x)))

    def abs(self, x: object) -> str:  # type: ignore[override]
        if CompileEnvironment.current().backend_name != "cute":
            return self._default("abs", (x,), {})
        dtype = self._expected_tensor_dtype()
        if dtype is not None and not dtype.is_signed:
            # The DSL's abs reads an unsigned value as signed.
            return _unpack_opsvalue(x)
        return self._lift(expr_from_string("abs({x})", x=self._to_ast(x)))

    def maximum(self, a: object, b: object) -> str:  # type: ignore[override]
        if CompileEnvironment.current().backend_name != "cute":
            return self._default("maximum", (a, b), {})
        dtype = self._expected_tensor_dtype()
        if dtype is not None:
            a = self._create_cast_expr(a, dtype)
            b = self._create_cast_expr(b, dtype)
        return self._lift(
            expr_from_string(
                "cute.math.max({a}, {b}, propagate_nan=True)",
                a=self._to_ast(a),
                b=self._to_ast(b),
            )
        )

    def minimum(self, a: object, b: object) -> str:  # type: ignore[override]
        if CompileEnvironment.current().backend_name != "cute":
            return self._default("minimum", (a, b), {})
        dtype = self._expected_tensor_dtype()
        if dtype is not None:
            a = self._create_cast_expr(a, dtype)
            b = self._create_cast_expr(b, dtype)
        return self._lift(
            expr_from_string(
                "cute.math.min({a}, {b}, propagate_nan=True)",
                a=self._to_ast(a),
                b=self._to_ast(b),
            )
        )

    def mul(self, a: object, b: object) -> str:  # type: ignore[override]
        # Triton promotes scalar*tensor results to float32, deviating from
        # PyTorch semantics (e.g. x_bf16 * 0.1).  Emit an explicit cast back.
        if CompileEnvironment.current().backend.name != "triton":
            return self._default("mul", (a, b), {})

        def has_scalar_operand() -> bool:
            current_node = V.current_node
            if current_node is None:
                return False
            return any(isinstance(arg, (int, float, bool)) for arg in current_node.args)

        result_str = _unpack_opsvalue(self.parent_handler.mul(a, b))
        result_expr = expr_from_string(result_str)

        # Only cast if we have a scalar operand and expected dtype is not float32.
        # This is to handle cases like `x_bf16 * 0.1` where Triton would promote the result to float32,
        # deviating from PyTorch semantics.
        expected_dtype = self._expected_tensor_dtype()
        if (
            has_scalar_operand()
            and expected_dtype is not None
            and expected_dtype != torch.float32
        ):
            result_expr = self._maybe_cast_to_expected_dtype(result_expr)

        return self._lift(result_expr)

    def load(self, name: str, index: sympy.Expr) -> str:
        # The input's value is the one at the output element's position;
        # ``load_check`` refuses an index that names another.
        if self.load_check is not None:
            self.load_check(name, index)
        return self.cg.lift(self.input_name_lookup[name]).id

    def index_expr(self, expr: sympy.Expr, dtype: torch.dtype) -> str:
        name = self.cg.lift(
            expr_from_string(self.cg.device_function.user_sympy_expr(expr))
        ).id

        # If the lifted symbol refers to a `tl.constexpr` kernel
        # argument (for example a tile/block size constant such as
        # `_BLOCK_SIZE_1`) the resulting value is not a tensor and
        # does not need casting.
        if name in self.cg.device_function._constexpr_args:
            return name

        return self._lift(self._cast_scalar_ast(expr_from_string(name), dtype))


def _unpack_opsvalue(value: object) -> str:
    if isinstance(value, OpsValue):
        return str(value)
    assert isinstance(value, str)
    return value


class GraphInterpreter(LoweringContext, Interpreter):
    def __init__(self, graph: torch.fx.Graph, cg: CodegenInterface) -> None:
        super().__init__(_LazyGraphModule({}, graph), garbage_collect_values=False)
        self.cg = cg
        self.env = self.env

    def to_ast(self, value: object) -> ast.AST:
        """
        Convert a value to an AST expression.
        """
        if isinstance(value, torch.fx.Node):
            result = self.env[value]
            assert isinstance(result, ast.AST)
            return result
        if isinstance(value, (int, float, bool)):
            return create(ast.Constant, value=value)
        if isinstance(value, ast.AST):
            return value
        raise TypeError(f"Unsupported value type for AST conversion: {type(value)}")

    @property
    def cute_layout(self) -> ThreadLayout | None:
        if V.current_node is None:
            return None
        from .cute.layout_propagation import META_KEY

        constraint = V.current_node.meta.get(META_KEY)
        if constraint is None:
            return None
        return constraint.primary_layout()

    @property
    def cute_matmul_axes(self) -> MatmulAxisModel | None:
        if V.current_node is None:
            return None
        from .cute.layout_propagation import META_KEY

        constraint = V.current_node.meta.get(META_KEY)
        if constraint is None:
            return None
        return constraint.matmul_axes

    @property
    def cute_matmul_plan(self) -> MatmulExecutionPlan | None:
        if V.current_node is None:
            return None
        from .cute.layout_propagation import META_KEY

        constraint = V.current_node.meta.get(META_KEY)
        if constraint is None:
            return None
        return constraint.matmul_plan

    def _create_named_result(self, node: Node, result: ast.expr) -> str:
        """Create a named variable for a node result, handling block-size-only expressions as constexpr."""
        val = node.meta.get("val")
        expr = getattr(getattr(val, "node", None), "_expr", None)
        if not isinstance(expr, sympy.Expr) and isinstance(val, torch.SymInt):
            with contextlib.suppress(Exception):
                expr = val._sympy_()

        # Check if we should create a constexpr for block-size-only expressions used in tl.arange
        if (
            isinstance(val, torch.SymInt)
            and isinstance(expr, sympy.Expr)
            and contains_only_block_size_symbols(expr)
            and any(
                user.op == "call_function"
                and user.target == torch.ops.prims.iota.default
                for user in node.users
            )
        ):
            # This expression is used in tl.arange, make it a constexpr
            name = self.cg.device_function.new_var(node.name)
            self.cg.device_function.constexpr_arg(name, expr)
            return name

        # If the lowering produced a named value that is already defined elsewhere
        # (e.g., looped reduction assigned in an outer suffix), avoid emitting a
        # premature assignment that could reference it before definition.
        delayed_result = bool(node.meta.get("delayed_result", False))
        if isinstance(result, ast.Name):
            name = result.id
        else:
            # Regular variable assignment
            name = self.cg.device_function.new_var(node.name)
            self.cg.add_statement(
                statement_from_string(f"{name} = {{result}}", result=result)
            )
        # Optionally enforce and assert dtype after each device node
        settings = CompileEnvironment.current().settings
        if (
            settings.debug_dtype_asserts
            and isinstance(val, torch.Tensor)
            and not delayed_result
        ):
            # Skip pure view ops; their dtype matches their input, which we've likely asserted already
            if node.op == "call_function" and node.target in (
                torch.ops.aten.unsqueeze.default,
                torch.ops.aten.view.default,
                torch.ops.aten.reshape.default,
                torch.ops.aten.expand.default,
                torch.ops.aten.permute.default,
            ):
                return name
            expected_dtype = val.dtype
            # First, enforce the expected dtype to mirror PyTorch semantics
            self.cg.add_statement(
                statement_from_string(
                    f"{name} = tl.cast({name}, {triton_type(expected_dtype)})"
                )
            )
            self.cg.add_statement(
                statement_from_string(
                    f"tl.static_assert({name}.dtype == {triton_type(expected_dtype)})"
                )
            )
        return name

    def _collect_multi_outputs(
        self, node: Node, last_node_result: object
    ) -> tuple[object, ...]:
        """
        Collect outputs for multi-output operations using metadata.
        """
        # Check if this operation has multiple outputs using the new metadata
        assert "output_nodes" in node.meta
        output_nodes = node.meta["output_nodes"]
        outputs: list[object | None] = [None] * len(output_nodes)
        all_nodes = {
            n.name: n
            # pyrefly: ignore [missing-attribute]
            for n in self.module.graph.nodes
        }

        for idx, node_name in output_nodes.items():
            if node_name == node.name:
                # This is the last node
                outputs[idx] = last_node_result
            else:
                # This is an extra node - get its result from env
                if node_name in all_nodes:
                    extra_node = all_nodes[node_name]
                    if extra_node in self.env:
                        outputs[idx] = self.env[extra_node]

        # Ensure all outputs are found and are ast.Name nodes
        final_outputs = []
        for i, result in enumerate(outputs):
            assert result is not None
            if not isinstance(result, ast.Name):
                var_name = self.cg.device_function.new_var(f"{node.name}_output{i}")
                assert isinstance(result, ast.AST)
                self.cg.add_statement(
                    statement_from_string(f"{var_name} = {{result}}", result=result)
                )
                result = create(ast.Name, id=var_name, ctx=ast.Load())
            final_outputs.append(result)

        return tuple(final_outputs)

    def _record_final_codegen_result(self, node: Node, result: object) -> None:
        """Expose normalized results to late CuTe rewrites without changing FX metadata."""

        from .generate_ast import GenerateAST

        if isinstance(self.cg, GenerateAST) and self.cg._track_statement_owners:
            self.cg.record_codegen_result(node, result)

    def run_node(self, n: Node) -> object:
        if self.cg.device_function.inband_polls:
            from .triton.distributed_ops import flush_inband_polls

            flush_inband_polls(self.cg, n)
        if n.op == "call_function":
            with (
                self.cg.statement_owner_node(n),
                self._set_current_node(n),
                n.meta["location"],
                V.set_current_node(n),
            ):
                try:
                    cute_state = self.cg.device_function.cute_state
                    if cute_state.has_tcgen05_fragment_epilogue_plan:
                        if cute_state.is_deferred_tcgen05_fragment_epilogue_node(n):
                            n.meta["codegen"] = _DEFERRED_TCGEN05_FRAGMENT_EPILOGUE
                            return _DEFERRED_TCGEN05_FRAGMENT_EPILOGUE
                        if (
                            any(
                                self.env.get(input_node)
                                is _DEFERRED_TCGEN05_FRAGMENT_EPILOGUE
                                for input_node in n.all_input_nodes
                            )
                            and cute_state.tcgen05_fragment_epilogue_plan_for_store(n)
                            is None
                        ):
                            raise exc.BackendUnsupported(
                                "cute",
                                "deferred tcgen05 fragment epilogue escaped its "
                                "committed store",
                            )
                    # Operands exchanged between threads for this node only.
                    exchanged: dict[torch.fx.Node, ast.AST] = {}
                    # ``has_current``: test_cute_fx_replay replays ``run_node``
                    # with no CompileEnvironment.
                    if (
                        CompileEnvironment.has_current()
                        and CompileEnvironment.current().backend.name == "cute"
                    ):
                        # Local import: at module level, cute.repeated_block_ids
                        # -> completed_matmul_sum -> device_ir -> ``from helion
                        # import Config`` fails while helion/__init__ is still
                        # importing (via language -> ... -> runtime.kernel ->
                        # generate_ast -> this module).
                        from .cute.repeated_block_ids import check_repeated_block_ids

                        check_repeated_block_ids(self.cg, n)
                        check_view_coord_consumers(self.cg, n)
                        if (
                            isinstance(n.meta["lowering"], PointwiseLowering)
                            or n.target in REBOUND_CHECK_TARGETS
                        ):
                            exchanged = check_pointwise_rebound_block_ids(
                                self.cg, n, operand_env=self.env
                            )
                    lowering: Lowering = n.meta["lowering"]
                    own_values = {operand: self.env[operand] for operand in exchanged}
                    # pyrefly: ignore [no-matching-overload]
                    self.env.update(exchanged)
                    try:
                        result = lowering.codegen(self, n)
                    finally:
                        self.env.update(own_values)
                    n.meta["codegen"] = result

                    # Generic handling for operations with multiple outputs
                    if n.kwargs.get("_extra_args"):
                        # Check if this node has getitem users, indicating multiple outputs
                        getitem_users = [
                            user for user in n.users if user.target == getitem
                        ]
                        if len(getitem_users) > 0:
                            result = self._collect_multi_outputs(n, result)
                            self._record_final_codegen_result(n, result)
                            return result

                    if result is None:
                        self._record_final_codegen_result(n, None)
                        return None
                    if not isinstance(result, ast.AST):
                        self._record_final_codegen_result(n, result)
                        return result
                    assert isinstance(result, ast.expr)
                    if len(n.users) > 0:
                        if not isinstance(result, (ast.Name, ast.Constant)):
                            name = self._create_named_result(n, result)
                            result = create(ast.Name, id=name, ctx=ast.Load())
                        val = n.meta["val"]
                        expr = getattr(getattr(val, "node", None), "_expr", None)
                        if not isinstance(expr, sympy.Expr) and isinstance(
                            val, torch.SymInt
                        ):
                            expr = val._sympy_()
                        if isinstance(expr, sympy.Expr) and len(expr.free_symbols) > 0:
                            # Keep track of what variable symints are stored in to support DeviceFunction.sympy_expr()
                            with contextlib.suppress(Exception):
                                expr = CompileEnvironment.current().shape_env.simplify(
                                    expr
                                )
                            if isinstance(result, ast.Name):
                                self.cg.device_function.expr_to_var_info[expr] = (
                                    VarInfo(result.id, n)
                                )
                            else:
                                assert isinstance(result, ast.Constant)
                                self.cg.device_function.expr_to_var_info[expr] = (
                                    VarInfo(repr(result.value), n)
                                )
                        self._record_final_codegen_result(n, result)
                        return result
                    if not isinstance(result, (ast.Name, ast.Constant)):
                        self.cg.add_statement(create(ast.Expr, value=result))
                    self._record_final_codegen_result(n, None)
                    return None
                except exc.Base:
                    raise
                except Exception as e:
                    raise InductorLoweringError(
                        f"Error in codegen for node {n.name} ({n.target}): {e}"
                    ) from e
        return super().run_node(n)


_DEFERRED_TCGEN05_FRAGMENT_EPILOGUE = object()


def is_deferred_tcgen05_fragment_epilogue(value: object) -> bool:
    return value is _DEFERRED_TCGEN05_FRAGMENT_EPILOGUE


def codegen_call_with_graph(
    cg: GenerateAST,
    graph: torch.fx.Graph,
    args: list[ast.AST],
    *,
    copy_named_args: bool = True,
) -> list[object]:
    with compile_lock:
        from .cute.cute_mma import prepare_cute_collective_lane_loop_suppression

        prepare_cute_collective_lane_loop_suppression(cg, graph)
        new_args = []
        placeholders = graph.find_nodes(op="placeholder")
        for arg, placeholder in zip(args, placeholders, strict=True):
            if all(
                user.target == torch.ops.aten.sym_size.int for user in placeholder.users
            ):
                # TODO(jansel): we should remove these sym_size-only args from the graph
                new_args.append(arg)
            elif copy_named_args and isinstance(arg, ast.Name):
                # We need to copy the inputs to a loop so that phi nodes are handled properly.
                # Phi nodes will merge variable names from outside the loop, but the old value
                # of those variables could have usages.
                copy_name = cg.device_function.new_var(arg.id + "_copy")
                with cg.statement_owner_node(placeholder):
                    cg.add_statement(
                        statement_from_string(f"{copy_name} = {{arg}}", arg=arg)
                    )
                new_args.append(expr_from_string(copy_name))
            else:
                with cg.statement_owner_node(placeholder):
                    new_args.append(cg.lift(arg))
        return GraphInterpreter(graph, cg).run(*new_args)


class CodegenState(NamedTuple):
    codegen: GenerateAST
    fx_node: torch.fx.Node | None
    env: dict[torch.fx.Node, Argument] = dataclasses.field(default_factory=dict)
    proxy_args: list[object] = dataclasses.field(default_factory=list)
    ast_args: list[object] = dataclasses.field(default_factory=list)

    def proxy_arg(self, i: int) -> object:
        return self.proxy_args[i]

    def ast_arg(self, i: int) -> ast.AST:
        rv = self.ast_args[i]
        if isinstance(rv, int | float | bool | None):
            rv = ast.Constant(value=rv)
        assert isinstance(rv, ast.AST), "TODO: convert nested/defaults"
        return rv

    @property
    def fake_value(self) -> object:
        assert self.fx_node is not None
        return self.fx_node.meta["val"]

    def get_graph(self, graph_id: int | object) -> GraphInfo:
        assert isinstance(graph_id, int)
        return self.codegen.get_graph(graph_id)

    @property
    def device_function(self) -> DeviceFunction:
        return self.codegen.device_function

    @property
    def tile_strategy(self) -> TileStrategyDispatch:
        return self.codegen.device_function.tile_strategy

    @property
    def config(self) -> Config:
        return self.codegen.device_function.config

    def add_statement(self, statement: ast.AST | str) -> None:
        return self.codegen.add_statement(statement)

    def sympy_expr(self, expr: sympy.Expr) -> str:
        return self.codegen.device_function.sympy_expr(expr)

    @property
    def cute_layout(self) -> ThreadLayout | None:
        """Return the resolved CuTe ThreadLayout for the current FX node, if any."""
        if self.fx_node is None:
            return None
        from .cute.layout_propagation import META_KEY

        constraint = self.fx_node.meta.get(META_KEY)
        if constraint is None:
            return None
        return constraint.primary_layout()  # type: ignore[return-value]

    @property
    def cute_matmul_axes(self) -> MatmulAxisModel | None:
        """Return the planner-owned CuTe matmul axis model for the current FX node."""
        if self.fx_node is None:
            return None
        from .cute.layout_propagation import META_KEY

        constraint = self.fx_node.meta.get(META_KEY)
        if constraint is None:
            return None
        return constraint.matmul_axes

    @property
    def cute_matmul_plan(self) -> MatmulExecutionPlan | None:
        """Return the planner-owned CuTe matmul execution plan for the node."""
        if self.fx_node is None:
            return None
        from .cute.layout_propagation import META_KEY

        constraint = self.fx_node.meta.get(META_KEY)
        if constraint is None:
            return None
        return constraint.matmul_plan
